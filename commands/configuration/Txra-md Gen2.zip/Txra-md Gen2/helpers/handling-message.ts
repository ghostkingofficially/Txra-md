import type { WaClient } from "zapo-js";
import { fileURLToPath } from "node:url";

import { getConfig } from "../connector/config.ts";
import { log } from "../connector/logger/index-logging.ts";
import {
  commandCount,
  getCommand,
  loadCommands,
  type CommandContext,
} from "./handling-plugins.ts";
import {
  isOwner as checkOwner,
  isPrimaryOwner as checkPrimaryOwner,
} from "../lib/usermanager/owner.ts";
import {
  ensureDailyLimit,
  getOrCreateUser,
  isPremium as checkIsPremium,
  removeLimit,
} from "../lib/usermanager/users.ts";
import { resolveSenderPhone } from "../lib/usermanager/identity.ts";
import type { SerializedMessage } from "../lib/serialize/index.ts";
import { isBotSentId } from "../lib/serialize/smsg.ts";
import {
  getGroupMetadata,
  peekGroupMetadata,
  isAdmin as checkIsAdmin,
  isBotAdmin as checkIsBotAdmin,
} from "../lib/group-metadata/index.ts";

const registerPromptAt = new Map<string, number>();
const REGISTER_PROMPT_COOLDOWN_MS = 8_000;

let bootstrapPromise: Promise<void> | null = null;
const COMMANDS_DIR = fileURLToPath(new URL("../commands", import.meta.url));

function ensureCommandsLoaded(): Promise<void> {
  if (bootstrapPromise) return bootstrapPromise;

  bootstrapPromise = (async () => {
    if (commandCount() > 0) return;
    log.info(`[bootstrap] Registry kosong, load commands dari ${COMMANDS_DIR}`);
    const { total } = await loadCommands(COMMANDS_DIR);
    log.info(`[bootstrap] Selesai: ${total} command`);
    if (total === 0) {
      log.warn(`[bootstrap] Tidak ada command. Cek folder: ${COMMANDS_DIR}`);
    }
  })().catch((err) => {
    bootstrapPromise = null;
    log.error(`[bootstrap] Gagal load: ${err instanceof Error ? err.message : err}`);
  });

  return bootstrapPromise;
}

interface ParsedCommand {
  prefix: string;
  command: string;
  args: string[];
  input: string;
}

function normalizePrefixes(prefix: unknown): string[] {
  if (Array.isArray(prefix)) return prefix.map(String).filter(Boolean);
  if (typeof prefix === "string" && prefix) return [prefix];
  return [];
}

function parseCommand(rawText: string, prefixes: string[]): ParsedCommand | null {
  if (!rawText) return null;
  const text = rawText.trim();
  if (!text) return null;

  if (text.startsWith(">") || text.startsWith("$")) {
    const prefix = text[0]!;
    const input = text.slice(1).trim();
    if (!input) return null;
    const args = input.split(/\s+/);
    return {
      prefix,
      command: prefix === ">" ? "exec" : "exec2",
      args,
      input,
    };
  }

  const sorted = [...prefixes].sort((a, b) => b.length - a.length);

  for (const p of sorted) {
    if (!text.startsWith(p)) continue;

    const withoutPrefix = text.slice(p.length).trim();
    if (!withoutPrefix) return null;

    const parts = withoutPrefix.split(/\s+/);
    const command = parts.shift() ?? "";
    if (!command) return null;

    return { prefix: p, command: command.toLowerCase(), args: parts, input: parts.join(" ") };
  }
  return null;
}

async function sendReply(
  m: SerializedMessage,
  text: string | undefined,
): Promise<void> {
  if (!text || !text.trim()) return;

  try {
    await m.reply(text);
  } catch (err) {
    log.warn(`Gagal kirim reply: ${(err as Error).message}`);
  }
}


export async function handleIncomingMessage(
  client: WaClient,
  m: SerializedMessage,
): Promise<void> {
  const cfg = getConfig();
  const verbose = !!cfg.features?.verboseLog;
  const trace = (msg: string) => {
    if (verbose) log.info(`[handler] ${msg}`);
    else log.debug(`[handler] ${msg}`);
  };

  await ensureCommandsLoaded();

  if (m.chat === "status@broadcast" || m.isNewsletter) return;
  if (isBotSentId(m.id)) return;
  if (!m.text || !m.text.trim()) return;

  const prefixes = normalizePrefixes(cfg.prefix);
  const parsed = parseCommand(m.text, prefixes);
  if (!parsed) return;

  m.prefix = parsed.prefix;
  m.command = parsed.command;
  m.args = parsed.args;
  m.input = parsed.input;

  const cmd = getCommand(parsed.command);
  if (!cmd) return;

    const needOwner = !!cmd.isOwner;
  const needPrimaryOwner = !!cmd.isPrimaryOwner;
  const needAdmin = !!cmd.isAdmin;
  const needBotAdmin = !!cmd.isBotAdmin;
  const needPremium = !!cmd.isPremium;
  const noLimit = cmd.isNoLimit === true || cmd.isLimit === false;

  trace(
    `cmd="${parsed.command}" flags={prem:${needPremium} nolimit:${noLimit} ` +
      `own:${needOwner} adm:${needAdmin} botadm:${needBotAdmin} prim:${needPrimaryOwner}}`,
  );

    const candidateJids: (string | undefined)[] = [
    m.key?.participantAlt,
    m.key?.participantPn,
    m.key?.participant,
    m.sender,
  ];
  if (m.fromMe) {
    try {
      const creds = (client as any).getCredentials?.() ?? {};
      if (creds.meJid) candidateJids.push(creds.meJid);
      if (creds.meLid) candidateJids.push(creds.meLid);
    } catch { /* ignore */ }
  }

    const isOwner = m.fromMe || checkOwner(
    m.key?.participantAlt ?? m.key?.participant ?? m.sender,
    m.key?.remoteJidAlt ?? m.key?.remoteJid,
  );
  const isPrimaryOwner = m.fromMe || checkPrimaryOwner(
    m.key?.participantAlt ?? m.key?.participant ?? m.sender,
    m.key?.remoteJidAlt ?? m.key?.remoteJid,
  );

    const userPhone = await resolveSenderPhone(client, m);
  const userJid = userPhone ? `${userPhone}@s.whatsapp.net` : "";
  const user = userPhone ? getOrCreateUser(userPhone, m.pushName || "") : undefined;
  const isPremium = userPhone ? checkIsPremium(userPhone) : false;
  const isRegistered = user?.registered === true;

  if (userJid) candidateJids.push(userJid);
  const uniqueCandidates = [...new Set(candidateJids.filter(Boolean))] as string[];

    let groupMetadata: any = undefined;
  let adminStatus = false;
  let botAdminStatus = false;

  if (m.isGroup) {
    groupMetadata = peekGroupMetadata(m.chat); // cache 0ms kalau ada
    if (needAdmin || needBotAdmin || cmd.needGroupMeta) {
      try {
        if (!groupMetadata) groupMetadata = await getGroupMetadata(client, m.chat);
        if (needAdmin) adminStatus = await checkIsAdmin(client, m.chat, ...uniqueCandidates);
        if (needBotAdmin) botAdminStatus = await checkIsBotAdmin(client, m.chat);
      } catch (err) {
        log.warn(`Gagal ambil metadata ${m.chat}: ${err instanceof Error ? err.message : err}`);
      }
    }
  }

  const ctx: CommandContext = {
    client,
    args: parsed.args,
    text: m.text,
    prefix: parsed.prefix,
    command: parsed.command,
    isOwner,
    isPrimaryOwner,
    isPremium,
    isAdmin: adminStatus,
    isBotAdmin: botAdminStatus,
    isRegistered,
    pushName: m.pushName || "",
    groupMetadata,
    user,
    userJid,
    userPhone,
  } as CommandContext;


  if (!isOwner) {
    if (!user) {
      trace(`skip: identitas pengirim tidak dikenali (sender=${m.sender})`);
      await sendReply(
        m,
        mess.unresolved,
      );
      return;
    }

    if (user.banned) {
      await sendReply(m, mess.banned);
      return;
    }

    if (!cmd.noRegister && !user.registered) {
      const now = Date.now();
      const last = registerPromptAt.get(userPhone!) ?? 0;
      if (now - last > REGISTER_PROMPT_COOLDOWN_MS) {
        if (registerPromptAt.size > 1000) registerPromptAt.clear();
        registerPromptAt.set(userPhone!, now);
        await sendReply(
          m,
          mess.registered,
        );
      }
      return;
    }
  }

    if (needPrimaryOwner && !isPrimaryOwner && !isOwner) {
    await sendReply(m, mess.primaryowner);
    return;
  }

  if (needOwner && !isOwner) {
    await sendReply(m, mess.owner);
    return;
  }

  if (needPremium && !isPremium && !isOwner) {
    await sendReply(m, mess.premium);
    return;
  }

    if ((cmd.isGroup || needAdmin || needBotAdmin) && !m.isGroup) {
    await sendReply(m, mess.group);
    return;
  }

  if (cmd.isPrivate && m.isGroup) {
    await sendReply(m, mess.private);
    return;
  }

  if (needAdmin && !adminStatus && !isOwner) {
    await sendReply(m, mess.admin);
    return;
  }

  if (needBotAdmin && !botAdminStatus) {
    await sendReply(m, mess.botadmin);
    return;
  }

  
  const exempt = isOwner || !user || noLimit;

  if (!exempt) {
    ensureDailyLimit(user!);
    if (user!.limit <= 0) {
      await sendReply(m, mess.limit);
      return;
    }
  }

  const startTime = Date.now();
  try {
    await cmd.execute(m, ctx);

    if (!exempt && user) {
      const sisa = removeLimit(userJid, 1);
      if (verbose) log.info(`[limit] ${userJid.split("@")[0]} → ${sisa}`);
    }

    log.debug(`Command "${cmd.name}" selesai dalam ${Date.now() - startTime}ms`);
  } catch (err) {
    log.error(
      `Command "${cmd.name}" error: ${err instanceof Error ? err.message : String(err)}`,
    );
    if (err instanceof Error && err.stack) log.debug(err.stack);

    await sendReply(m, mess.error);
  }
}
