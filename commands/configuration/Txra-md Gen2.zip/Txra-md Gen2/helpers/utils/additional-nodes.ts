export interface BinaryNode {
  tag: string;
  attrs: Record<string, string>;
  content?: Uint8Array | string | readonly BinaryNode[];
}
export type FlowType =
  | "mixed"
  | "payment_info"
  | "order_details"
  | "catalog_message"
  | "reply_ai"
  | "payment_key_info" 
  | "poll_creation"    
  | "event_creation";  

export interface AdditionalNodesOptions {
  attrs?: Record<string, string>;
}

export const UNSUPPORTED_FLOWS: readonly string[] = ["reply_ai", "catalog_message"];

const nativeFlowBiz = (attrs: Record<string, string>): BinaryNode => ({
  tag: "biz",
  attrs: {},
  content: [{
    tag: "interactive",
    attrs: { type: "native_flow", v: "1" },
    content: [{ tag: "native_flow", attrs }],
  }],
});

export function getAdditionalNodes(
  type: FlowType | string = "mixed",
  options: AdditionalNodesOptions = {},
): BinaryNode[] {
  switch (type) {
    case "payment_info":
    case "payment_key_info":
      return [nativeFlowBiz({ name: "payment_info", ...options.attrs })];
    case "order_details":
      return [nativeFlowBiz({ name: "order_details", ...options.attrs })];
    case "catalog_message":
      return [{ tag: "biz", attrs: { native_flow_name: "catalog_message" } }];
    case "reply_ai":
      return [{ tag: "bot", attrs: { biz_bot: "1" } }, { tag: "biz", attrs: {} }];
    case "poll_creation":
    case "event_creation":
      return []; 
    case "mixed":
    default:
      return [nativeFlowBiz({ v: "9", name: "mixed" })];
  }
}

export const getAddtionalNodes = getAdditionalNodes;
export default getAdditionalNodes;