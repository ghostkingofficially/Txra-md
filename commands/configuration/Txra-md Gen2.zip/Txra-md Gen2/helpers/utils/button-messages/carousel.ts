// helpers/utils/button-messages/carousel.ts
import { Buffer } from "node:buffer";
import type { WaClient } from "zapo-js";
import { getAdditionalNodes, type BinaryNode, type FlowType } from "../additional-nodes.ts";
import { BaseBuilder } from "./base.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay, type WAMessage } from "./transport.ts";

type Obj = Record<string, any>;
const str = (v: unknown) => (typeof v === "string" ? v : JSON.stringify(v ?? {}));

export interface MakeCardOptions {
  image?: Uint8Array | string;
  video?: Uint8Array | string;
  gifPlayback?: boolean;
  body?: string;
  footer?: string;
  title?: string;
  subtitle?: string;
  buttons?: Array<{ name: string; params?: any; buttonParamsJson?: string }>;
  params?: Obj | string;
}

export class Carousel extends BaseBuilder {
  #client: WaClient;
  _cards: Obj[] = [];

  constructor(client: WaClient) {
    super();
    if (!client) throw new Error("Socket is required");
    this.#client = client;
  }

  loadFrom(msg: Obj) {
    if (!msg) throw new Error("interactiveMessage needed");
    const content = msg.message ?? msg;
    const source = content.viewOnceMessage?.message ?? content.viewOnceMessageV2?.message ?? content;
    if (!source.interactiveMessage) throw new Error("interactiveMessage not found");

    const { interactiveMessage: iM, ...extraPayload } = source;
    const carousel = iM.carouselMessage || {};

    this._title = iM.header?.title || "";
    this._subtitle = iM.header?.subtitle || "";
    this._body = iM.body?.text || "";
    this._footer = iM.footer?.text || "";
    this._contextInfo = iM.contextInfo || {};
    this._extraPayload = extraPayload;

    if (typeof carousel.messageParamsJson === "string") {
      try { this._params = JSON.parse(carousel.messageParamsJson || "{}"); } catch { this._params = {}; }
    }

    this._cards = Array.isArray(carousel.cards)
      ? carousel.cards.map((card: Obj) => ({
          ...card,
          header: { ...(card.header || {}), hasMediaAttachment: !!card.header?.hasMediaAttachment },
          body: { text: card.body?.text || "" },
          footer: { text: card.footer?.text || "" },
          nativeFlowMessage: {
            ...(card.nativeFlowMessage || {}),
            buttons: Array.isArray(card.nativeFlowMessage?.buttons)
              ? card.nativeFlowMessage.buttons.map((b: Obj) => ({ ...b, buttonParamsJson: str(b.buttonParamsJson) }))
              : [],
          },
        }))
      : [];
    return this;
  }

  addCard(card: Obj | Obj[]) {
    const cards = Array.isArray(card) ? card : [card];
    const base = this._cards.length;
    cards.forEach((c, i) => {
      if (!c?.header?.hasMediaAttachment) throw new Error(`Card [${base + i}] must include an image or video in header`);
            const btns = c.nativeFlowMessage?.buttons ?? [];
      btns.forEach((b: Obj, j: number) => {
        if (typeof b?.name !== "string") throw new Error(`Card [${base + i}] tombol #${j + 1}: "name" harus string`);
        if (typeof b.buttonParamsJson !== "string") b.buttonParamsJson = str(b.buttonParamsJson);
      });
    });
    this._cards.push(...cards);
    return this;
  }

  clearCards() { this._cards = []; return this; }
  get cardCount() { return this._cards.length; }

    async makeCard(o: MakeCardOptions = {}): Promise<Obj> {
    const { image, video, gifPlayback = false, body = "", footer = "", title = "", subtitle = "", buttons = [], params } = o;
    if (!image && !video) throw new Error("makeCard needs an image or video");

    const media = image
      ? await prepareMedia(this.#client, "image", image as any)
      : await prepareMedia(this.#client, "video", video as any, gifPlayback ? { gifPlayback: true } : {});

    return {
      header: { hasMediaAttachment: true, title, subtitle, ...media },
      body: { text: body },
      footer: { text: footer },
      nativeFlowMessage: {
        ...(params ? { messageParamsJson: str(params) } : {}),
        buttons: buttons.map((b) => ({ name: b.name, buttonParamsJson: b.buttonParamsJson ?? str(b.params) })),
      },
    };
  }

  build(jid: string, { messageId, quoted }: { messageId?: string; quoted?: any } = {}): WAMessage {
    if (!this._cards.length) throw new Error("Carousel requires at least one card");
    const hasParams = this._params && Object.keys(this._params).length > 0;

    return buildWAMessage(jid, {
      ...this._extraPayload,
      interactiveMessage: {
        header: { hasMediaAttachment: false, title: this._title, subtitle: this._subtitle },
        body: { text: this._body },
        footer: { text: this._footer },
        contextInfo: this._contextInfo,
        carouselMessage: {
          ...(hasParams && { messageParamsJson: JSON.stringify(this._params) }),
          cards: this._cards,
        },
      },
    }, { messageId: messageId || newMessageId(), quoted });
  }

  async send(
    jid: string,
    { flowType = "mixed", additionalNodes = [], quoted, messageId, ...options }:
      { flowType?: FlowType | string; additionalNodes?: BinaryNode[]; quoted?: any; messageId?: string; [k: string]: any } = {},
  ): Promise<WAMessage> {
    const msg = this.build(jid, { messageId, quoted });
    await relay(this.#client, msg.key.remoteJid, msg.message, {
      ...options,
      messageId: msg.key.id,
      additionalNodes: [...getAdditionalNodes(flowType), ...additionalNodes],
    });
    return msg;
  }
}

export default Carousel;