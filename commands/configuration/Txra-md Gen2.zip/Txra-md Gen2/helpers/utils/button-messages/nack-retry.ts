import type { BinaryNode } from "../additional-nodes.ts";

type Obj = Record<string, any>;

export const isNack479 = (e: unknown): boolean =>
  /(^|[^0-9])479([^0-9]|$)/.test(String((e as any)?.message ?? e));

const INTERACTIVE_KEYS = ["interactiveMessage", "buttonsMessage", "listMessage", "templateMessage"];
export const isInteractive = (m: Obj): boolean => INTERACTIVE_KEYS.some((k) => m?.[k]);

export function kindOf(m: Obj): string {
  const cards = m?.interactiveMessage?.carouselMessage?.cards;
  if (cards) {
    const hasBtn = Array.isArray(cards) && cards.some((c: Obj) => (c?.nativeFlowMessage?.buttons?.length ?? 0) > 0);
    return hasBtn ? "carousel-btn" : "carousel";
  }
  if (m?.interactiveMessage) return "native";
  if (m?.buttonsMessage) return "buttons";
  if (m?.listMessage) return "list";
  if (m?.templateMessage) return "template";
  return "other";
}

export function wrapViewOnce(message: Obj): Obj {
  if (message.viewOnceMessage || message.viewOnceMessageV2 || message.viewOnceMessageV2Extension) return message;
  const { messageContextInfo, ...rest } = message;
  return {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2, ...(messageContextInfo ?? {}) },
        ...rest,
      },
    },
  };
}

interface Variant { name: string; wrap: boolean; nodes: boolean }
const LADDER: Variant[] = [
  { name: "asli", wrap: false, nodes: true },
  { name: "viewOnce + node", wrap: true, nodes: true },
  { name: "viewOnce tanpa node", wrap: true, nodes: false },
  { name: "asli tanpa node", wrap: false, nodes: false },
];

const MEMORY_TTL_MS = 5 * 60_000;
const memory = new Map<string, { idx: number; at: number }>();

const recall = (kind: string): number => {
  const m = memory.get(kind);
  if (!m) return 0;
  if (Date.now() - m.at > MEMORY_TTL_MS) { memory.delete(kind); return 0; }
  return m.idx;
};

export const resetNackFallback = () => memory.clear();
export const getNackFallbackState = () =>
  Object.fromEntries([...memory].map(([k, v]) => [k, { variant: LADDER[v.idx].name, ageMs: Date.now() - v.at }]));

export async function sendWithFallback<T>(
  send: (message: Obj, nodes: readonly BinaryNode[], attempt: number) => Promise<T>,
  message: Obj,
  nodes: readonly BinaryNode[] = [],
  log: (msg: string) => void = (m) => console.warn(m),
): Promise<T> {
  if (!isInteractive(message)) return await send(message, nodes);

  const kind = kindOf(message);
  const startAt = recall(kind);
  const order = [startAt, ...LADDER.map((_, i) => i).filter((i) => i !== startAt)]
    .filter((i) => LADDER[i].nodes || nodes.length > 0); // varian "tanpa node" percuma kalau memang tanpa node
  const tried: string[] = [];
  let last: unknown;

  for (const idx of order) {
    const v = LADDER[idx];
    try {
      const res = await send(v.wrap ? wrapViewOnce(message) : message, v.nodes ? nodes : [], tried.length);
      log(`[relay] ${kind}: diterima server, varian "${v.name}", percobaan ke-${tried.length + 1}`);
      if (idx === 0) memory.delete(kind);
      else memory.set(kind, { idx, at: Date.now() });
      return res;
    } catch (e) {
      last = e;
          if (idx === startAt && startAt !== 0) memory.delete(kind);
      if (!isNack479(e)) throw e;
      tried.push(v.name);
      log(`[relay] ${kind}: varian "${v.name}" ditolak 479`);
    }
  }
  const err = new Error(`${(last as Error)?.message ?? last} (varian dicoba: ${tried.join(", ")} — semuanya ditolak 479)`);
  (err as any).cause = last;
  throw err;
}