// helpers/utils/button-messages/button.ts — NATIVE FLOW (interactiveMessage) + fallback V1
import { Buffer } from "node:buffer";
import { readFileSync } from "node:fs";
import type { WaClient } from "zapo-js";
import { CacheManager } from "../cache.ts";
import { getAdditionalNodes, type BinaryNode, type FlowType } from "../additional-nodes.ts";
import { Toolkit } from "../toolkit.ts";
import { BaseBuilder } from "./base.ts";
import {
  buildWAMessage, cloneMessage, makeButtonCacheKey, newMessageId, prepareMedia, relay, type WAMessage,
} from "./transport.ts";

type Obj = Record<string, any>;
const str = (v: unknown) => (typeof v === "string" ? v : JSON.stringify(v ?? {}));
const mediaSource = (raw: any): Uint8Array | string => (raw && typeof raw === "object" && "url" in raw ? raw.url : raw);

export interface SplitOptions {
    blank?: boolean;
    shorten?: boolean;
}
const SPLIT_BLANK = "\u0000";
const labelKey = (name: string) => (name === "single_select" ? "title" : "display_text");
const firstChar = (v: string) => Array.from(v.trim())[0] ?? "";
function paramsObj(v: unknown): Obj | null {
  if (v == null || v === "") return {};
  if (typeof v === "string") {
    try { const p = JSON.parse(v); return p && typeof p === "object" && !Array.isArray(p) ? p : null; } catch { return null; }
  }
  return typeof v === "object" && !Array.isArray(v) ? { ...(v as Obj) } : null;
}
function splitButtons(buttons: readonly Obj[], o: SplitOptions = {}): Obj[] {
  if (buttons.length < 2 || buttons.length > 3) throw new Error(`Split butuh 2–3 tombol (ada ${buttons.length})`);
  const triple = buttons.length === 3;
  const { blank = false, shorten = true } = o;
  const out: Obj[] = [{ name: "", buttonParamsJson: "{}" }];
  buttons.forEach((b, i) => {
    if (!b || typeof b.name !== "string" || !b.name) throw new Error(`Tombol split #${i + 1} butuh "name"`);
    const raw = b.params ?? b.buttonParamsJson;
    const obj = paramsObj(raw);
    if (obj && triple && (blank || shorten)) {
      const k = labelKey(b.name);
      const cur = typeof obj[k] === "string" ? obj[k] : "";
      obj[k] = blank ? SPLIT_BLANK : firstChar(cur) || SPLIT_BLANK;
    }
    out.push({ name: b.name, buttonParamsJson: obj ? JSON.stringify(obj) : String(raw) });
  });
  return out;
}

export interface RunOptions {
  bypass?: boolean;
  useCache?: boolean;
  flowType?: FlowType | string;
  additionalNodes?: BinaryNode[];
  messageId?: string;
  [k: string]: any;
}

export class Button extends BaseBuilder {
  static cache = new CacheManager<WAMessage>(3000);

  #client: WaClient;
  _beton: Obj[] = [];
  _betonOld: Obj[] = [];
  _data: Obj | null = null;
  _locationHeader: { thumbnailUrl: string } | null = null;
  _gifPlayback = false;
  _currentSelectionIndex = -1;
  _currentSectionIndex = -1;
  _type = 0;
  _carouselCards: Obj[] = [];
  _currentCardIndex = -1;
  _locationBypass = false;
  _split: SplitOptions | null = null;

  constructor(client: WaClient) {
    super();
    if (!client) throw new Error("Socket is required");
    this.#client = client;
  }

    loadFrom(msg: Obj) {
    if (!msg) throw new Error("interactiveMessage needed");
    const content = msg.message ?? msg;
    const source = content.viewOnceMessage?.message ?? content.viewOnceMessageV2?.message ?? content;
    if (!source.interactiveMessage) throw new Error("interactiveMessage not found");

    const { interactiveMessage: iM, ...extraPayload } = source;
    const header = iM.header || {};
    const nativeFlow = iM.nativeFlowMessage || {};

    this._title = header.title || "";
    this._subtitle = header.subtitle || "";
    this._body = iM.body?.text || "";
    this._footer = iM.footer?.text || "";
    this._contextInfo = iM.contextInfo || {};
    this._extraPayload = extraPayload;
    this._type = 0;

    this._beton = Array.isArray(nativeFlow.buttons)
      ? nativeFlow.buttons.map((b: Obj) => ({ ...b, buttonParamsJson: str(b.buttonParamsJson) }))
      : [];

    this._data = header.imageMessage ? { imageMessage: header.imageMessage }
      : header.videoMessage ? { videoMessage: header.videoMessage }
      : header.documentMessage ? { documentMessage: header.documentMessage }
      : header.productMessage ? { productMessage: header.productMessage }
      : null;

    this._gifPlayback = !!header.videoMessage?.gifPlayback;
    this._locationHeader = header.locationMessage ? { thumbnailUrl: "" } : null;

    this._params = {};
    if (typeof nativeFlow.messageParamsJson === "string") {
      try { this._params = JSON.parse(nativeFlow.messageParamsJson || "{}"); } catch { this._params = {}; }
    } else if (nativeFlow.messageParamsJson && typeof nativeFlow.messageParamsJson === "object") {
      this._params = { ...nativeFlow.messageParamsJson };
    }

    this._carouselCards = Array.isArray(iM.carouselMessage?.cards) ? iM.carouselMessage.cards : [];
    this._currentCardIndex = this._carouselCards.length - 1;

    this._currentSelectionIndex = this._beton.map((b) => b.name).lastIndexOf("single_select");
    this._currentSectionIndex = -1;
    if (this._currentSelectionIndex !== -1) {
      try {
        const p = JSON.parse(this._beton[this._currentSelectionIndex].buttonParamsJson || "{}");
        if (Array.isArray(p.sections) && p.sections.length) this._currentSectionIndex = p.sections.length - 1;
      } catch {
        this._currentSelectionIndex = -1;
      }
    }
    return this;
  }

  // ── Reset ──
  clearButtons() {
    this._beton = [];
    this._betonOld = [];
    this._currentSelectionIndex = -1;
    this._currentSectionIndex = -1;
    return this;
  }

  clearCards() {
    this._carouselCards = [];
    this._currentCardIndex = -1;
    return this;
  }

  // ── Media setters ──
  setImage(path: Uint8Array | string, options: Obj = {}) {
    if (!path) throw new Error("Image path required");
    this._data = typeof path === "string" ? { image: { url: path }, ...options } : { image: path, ...options };
    this._gifPlayback = false;
    return this;
  }

  setVideo(path: Uint8Array | string, options: Obj = {}) {
    if (!path) throw new Error("Video path required");
    this._data = typeof path === "string" ? { video: { url: path }, ...options } : { video: path, ...options };
    this._gifPlayback = false;
    return this;
  }

    setVideoGif(path: Uint8Array | string, options: Obj = {}) {
    if (!path) throw new Error("Video path required");
    this._data = typeof path === "string"
      ? { video: { url: path }, gifPlayback: true, ...options }
      : { video: path, gifPlayback: true, ...options };
    this._gifPlayback = true;
    return this;
  }

  setDocument(path: Uint8Array | string, options: Obj = {}) {
    if (!path) throw new Error("Document path required");
    this._data = typeof path === "string" ? { document: { url: path }, ...options } : { document: path, ...options };
    return this;
  }

  setMedia(obj: Obj) {
    if (typeof obj === "object" && !Array.isArray(obj)) this._data = obj;
    return this;
  }

    setLocationHeader(thumbnailUrl = "") {
    this._locationHeader = { thumbnailUrl };
    return this;
  }

    useV1() { this._type = 1; return this; }
  useV1Location() { this._type = 1; this._locationBypass = true; return this; }

    setButton(name: string, params: any) {
    this._beton.push({ name, buttonParamsJson: str(params) });
    return this;
  }

  addReply(display_text = "", id = "", o: Obj = {}) { return this.setButton("quick_reply", { display_text, id, ...o }); }
  addCall(display_text = "", phone_number = "", o: Obj = {}) { return this.setButton("cta_call", { display_text, phone_number, ...o }); }
  addUrl(display_text = "", url = "", webview_interaction = false, o: Obj = {}) {
    return this.setButton("cta_url", { display_text, url, webview_interaction, ...o });
  }
  addCopy(display_text = "", copy_code = "", id = "", o: Obj = {}) { return this.setButton("cta_copy", { display_text, copy_code, id, ...o }); }

  addLocation(o: Obj = {}) {
    this._beton.push({ name: "send_location", buttonParamsJson: Object.keys(o).length ? JSON.stringify(o) : "" });
    return this;
  }

  addAddress(t = "", id = "", o: Obj = {}) { return this.setButton("address_message", { display_text: t, id, ...o }); }
  addReminder(t = "", id = "", o: Obj = {}) { return this.setButton("cta_reminder", { display_text: t, id, ...o }); }
  addCancelReminder(t = "", id = "", o: Obj = {}) { return this.setButton("cta_cancel_reminder", { display_text: t, id, ...o }); }
  addMPM(t = "", id = "", o: Obj = {}) { return this.setButton("mpm", { display_text: t, id, ...o }); }
  addPayment(t = "", id = "", o: Obj = {}) { return this.setButton("payment_info", { display_text: t, id, ...o }); }
  addCatalog(t = "", id = "", o: Obj = {}) { return this.setButton("catalog_message", { display_text: t, id, ...o }); }
  addAgentTransfer(t = "", id = "", o: Obj = {}) { return this.setButton("galaxy_message", { display_text: t, id, ...o }); }
  addReviewAndPay(t = "", id = "", o: Obj = {}) { return this.setButton("review_and_pay", { display_text: t, id, ...o }); }
  addReviewOrder(t = "", id = "", o: Obj = {}) { return this.setButton("review_order", { display_text: t, id, ...o }); }

  addOpenWebview(display_text = "", url = "", o: Obj = {}) {
    return this.setButton("open_webview", { display_text, url, webview_presentation: o.presentation ?? "FULL", ...o });
  }

  addButton(name: string, params: any) { return this.setButton(name, params); }

    split(opts: SplitOptions | boolean = true) {
    this._split = opts === false ? null : opts === true ? {} : opts;
    return this;
  }
    static split = splitButtons;
   _buttons(): Obj[] { return this._split ? splitButtons(this._beton, this._split) : this._beton; }

  _buildMessageParams() { return JSON.stringify(this._params); }

    addSelection(title: string, options: Obj = {}) {
    this._beton.push({ ...options, name: "single_select", buttonParamsJson: JSON.stringify({ title, sections: [] }) });
    this._currentSelectionIndex = this._beton.length - 1;
    this._currentSectionIndex = -1;
    return this;
  }

  makeSection(title = "", highlight_label = "") {
    if (this._currentSelectionIndex === -1) throw new Error("Create selection first");
    const btn = this._beton[this._currentSelectionIndex];
    const p = JSON.parse(btn.buttonParamsJson);
    p.sections.push({ title, highlight_label, rows: [] });
    this._currentSectionIndex = p.sections.length - 1;
    btn.buttonParamsJson = JSON.stringify(p);
    return this;
  }

  makeRow(header = "", title = "", description = "", id = "") {
    if (this._currentSelectionIndex === -1 || this._currentSectionIndex === -1) throw new Error("Need selection & section first");
    const btn = this._beton[this._currentSelectionIndex];
    const p = JSON.parse(btn.buttonParamsJson);
    p.sections[this._currentSectionIndex].rows.push({ header, title, description, id });
    btn.buttonParamsJson = JSON.stringify(p);
    return this;
  }

  // ── Button v1 (buttonsMessage) ──
  setButtonV2(params: Obj) { this._betonOld.push(params); return this; }

  addV1Reply(displayText = "", id = "") {
    this._betonOld.push({ buttonId: id || "btn_" + Date.now(), buttonText: { displayText }, type: 1 });
    return this;
  }

  addV1Url(displayText = "", url = "") {
    this._betonOld.push({
      buttonId: "url_" + Date.now(),
      buttonText: { displayText },
      type: 1,
      nativeFlowInfo: { name: "cta_url", paramsJson: JSON.stringify({ display_text: displayText, url }) },
    });
    return this;
  }

  // ── Carousel ──
  addCard(body = "", footer = "") {
    this._carouselCards.push({
      body: { text: body },
      footer: { text: footer },
      header: { hasMediaAttachment: false },
      nativeFlowMessage: { buttons: [] },
    });
    this._currentCardIndex = this._carouselCards.length - 1;
    return this;
  }

  setCardImage(url: string) {
    if (this._currentCardIndex === -1) throw new Error("Add card first");
    this._carouselCards[this._currentCardIndex].header = { hasMediaAttachment: true, imageMessage: { url, mimetype: "image/jpeg" } };
    return this;
  }

  setCardVideo(url: string, { gifPlayback = false } = {}) {
    if (this._currentCardIndex === -1) throw new Error("Add card first");
    this._carouselCards[this._currentCardIndex].header = {
      hasMediaAttachment: true,
      videoMessage: { url, mimetype: "video/mp4", ...(gifPlayback && { gifPlayback: true }) },
    };
    return this;
  }

  setCardMedia(mediaAttachment: Obj = {}, { gifPlayback = false } = {}) {
    if (this._currentCardIndex === -1) throw new Error("Add card first");
    const header: Obj = { hasMediaAttachment: true, ...mediaAttachment };
    if (gifPlayback && header.videoMessage) header.videoMessage = { ...header.videoMessage, gifPlayback: true };
    this._carouselCards[this._currentCardIndex].header = header;
    return this;
  }

  setCardTitle(title = "", subtitle = "") {
    this._ensureCard();
    Object.assign(this._carouselCards[this._currentCardIndex].header, { title, subtitle });
    return this;
  }

  setCardParams(params: Obj | string = {}) {
    this._ensureCard();
    this._carouselCards[this._currentCardIndex].nativeFlowMessage.messageParamsJson = str(params);
    return this;
  }

    _ensureCard() {
    if (this._currentCardIndex === -1) this.addCard();
    return this;
  }

  addCardButton(name: string, params: any) {
    this._ensureCard();
    this._carouselCards[this._currentCardIndex].nativeFlowMessage.buttons.push({ name, buttonParamsJson: str(params) });
    return this;
  }
  addCardReply(display_text = "", id = "") { return this.addCardButton("quick_reply", { display_text, id }); }
  addCardUrl(display_text = "", url = "") { return this.addCardButton("cta_url", { display_text, url, webview_interaction: false }); }
  addCardCopy(display_text = "", copy_code = "", id = "") { return this.addCardButton("cta_copy", { display_text, copy_code, id }); }
  addCardCall(display_text = "", phone_number = "") { return this.addCardButton("cta_call", { display_text, phone_number }); }
  setCardSplit(opts: SplitOptions = {}) {
    this._ensureCard();
    const nf = this._carouselCards[this._currentCardIndex].nativeFlowMessage;
    nf.buttons = splitButtons(nf.buttons, opts);
    return this;
  }

  async _uploadData(): Promise<Obj> {
    if (!this._data || this._locationHeader) return {};
   const payload = this._gifPlayback ? { video: this._data.video } : this._data;
    const kind = Object.keys(payload)[0] as "image" | "video" | "document";
    const { [kind]: raw, ...extra } = payload;
    return await prepareMedia(this.#client, kind, mediaSource(raw), extra);
  }

  // ── Header ──
  async _buildHeader(mediaAttachment: Obj = {}): Promise<Obj> {
    if (this._locationHeader) {
      let thumb: Buffer | null = null;
      try {
        const buf = this._locationHeader.thumbnailUrl
          ? await Toolkit.fetchBuffer(this._locationHeader.thumbnailUrl, {}, { silent: true })
          : null;
        if (buf && buf.length > 0) thumb = await Toolkit.resize(buf, 300, 300);
      } catch { /* thumbnail opsional */ }

      return {
        hasMediaAttachment: false,
        locationMessage: {
          degreesLatitude: 0,
          degreesLongitude: 0,
          name: this._title,
          address: this._subtitle,
          jpegThumbnail: thumb,
        },
      };
    }

    if (this._gifPlayback && mediaAttachment.videoMessage) {
      return {
        title: this._title,
        subtitle: this._subtitle,
        hasMediaAttachment: true,
        videoMessage: { ...mediaAttachment.videoMessage, gifPlayback: true },
      };
    }

    return { title: this._title, subtitle: this._subtitle, hasMediaAttachment: !!this._data, ...mediaAttachment };
  }

  // ── toCard ──
  async toCard(): Promise<Obj> {
    const mediaForHeader = await this._uploadData();

       if (this._currentCardIndex !== -1) {
      const card = this._carouselCards[this._currentCardIndex];
      card.body = { text: this._body };
      card.footer = { text: this._footer };

      if (this._data || Object.keys(mediaForHeader).length) {
        const { title, subtitle, ...mediaHeader } = await this._buildHeader(mediaForHeader);
        card.header = {
          hasMediaAttachment: true,
          ...(title ? { title } : {}),
          ...(subtitle ? { subtitle } : {}),
          ...mediaHeader,
        };
      } else {
        Object.assign(card.header, {
          ...(this._title ? { title: this._title } : {}),
          ...(this._subtitle ? { subtitle: this._subtitle } : {}),
        });
      }

      if (!card.nativeFlowMessage.messageParamsJson) card.nativeFlowMessage.messageParamsJson = this._buildMessageParams();
      if (this._beton.length) card.nativeFlowMessage.buttons.push(...this._buttons());
      return card;
    }

    return {
      body: { text: this._body },
      footer: { text: this._footer },
      header: await this._buildHeader(mediaForHeader),
      nativeFlowMessage: { messageParamsJson: this._buildMessageParams(), buttons: this._buttons() },
    };
  }

  // ── build ──
  async build(jid: string, { messageId, quoted }: { messageId?: string; quoted?: any } = {}): Promise<WAMessage> {
    const message = await this.toCard();
    return buildWAMessage(jid, {
      ...this._extraPayload,
      interactiveMessage: { ...message, contextInfo: this._contextInfo },
    }, { messageId: messageId || newMessageId(), quoted });
  }

    async run(
    jid: string,
    conn: WaClient | null = null,
    quoted: any = "",
    { bypass = false, useCache = true, flowType = "mixed", additionalNodes = [], messageId, ...options }: RunOptions = {},
  ): Promise<WAMessage> {
    const client = conn ?? this.#client;
    const hasButtons = this._beton.length > 0 || this._betonOld.length > 0 || this._carouselCards.length > 0;
    const hasMedia = !!this._data;
    const hasParams = this._params && Object.keys(this._params).length > 0;
    // Videogif polos: cukup media + LTO/params, tanpa tombol.
    if (!hasButtons && !hasMedia && !hasParams) throw new Error("No buttons added");

    const finalNodes = [...getAdditionalNodes(flowType), ...additionalNodes];
    const q = quoted || undefined;

    // ── CAROUSEL ──
    if (this._carouselCards.length > 0) {
      const id = messageId || newMessageId();
      const msg = buildWAMessage(jid, {
        interactiveMessage: {
          body: { text: this._body },
          footer: { text: this._footer },
          header: { hasMediaAttachment: false, title: this._title },
          contextInfo: this._contextInfo,
          carouselMessage: { messageParamsJson: this._buildMessageParams(), cards: this._carouselCards },
        },
      }, { messageId: id, quoted: q });
      await relay(client, jid, msg.message, { messageId: id, additionalNodes: finalNodes, ...options });
      return msg;
    }

    // ── CACHE CHECK ──
    const d = this._data as Obj | null;
    const hasBufferMedia = !!d && (ArrayBuffer.isView(d.image) || ArrayBuffer.isView(d.video) || ArrayBuffer.isView(d.document));
    let cacheKey: string | null = null;
    if (useCache && !hasBufferMedia && !q) {
      cacheKey = Button.cache.keyFromObject(makeButtonCacheKey(this));
      const cached = Button.cache.get(cacheKey);
      if (cached) {
        const id = messageId || newMessageId();
        const copy = cloneMessage(cached); 
        copy.key = { remoteJid: jid, id, fromMe: true };
        await relay(client, jid, copy.message, { messageId: id, additionalNodes: finalNodes, ...options });
        return copy;
      }
    }

    // ── UPLOAD MEDIA ──
    const mediaAttachment = await this._uploadData();
    const id = messageId || newMessageId();
    let msg: WAMessage;

    if (this._type === 0) {
      // ── TYPE 0: interactiveMessage ──
      const header = await this._buildHeader(mediaAttachment);
      msg = buildWAMessage(jid, {
        interactiveMessage: {
          body: { text: this._body },
          footer: { text: this._footer },
          header,
          contextInfo: this._contextInfo,
          nativeFlowMessage: { messageParamsJson: this._buildMessageParams(), buttons: this._buttons() },
        },
      }, { messageId: id, quoted: q });
    } else {
      // ── TYPE 1: buttonsMessage ──
      const locBypass = bypass || this._locationBypass;
      let thumb: Buffer | null = null;

      if (this._data) {
        try {
          const key = Object.keys(this._data)[0];
          const raw = mediaSource(this._data[key]);
          const buf = typeof raw === "string" ? await Toolkit.fetchBuffer(raw, {}, { silent: true }) : Buffer.from(raw);
          if (buf.length > 0) thumb = await Toolkit.resize(buf, 300, 300);
        } catch (err) {
          console.error("[Button] gagal memproses thumbnail:", err);
        }
      }

      const buttonsMessage: Obj = {
        contentText: this._body,
        footerText: this._footer,
        headerType: locBypass ? 6 : this._data ? 0 : undefined,
        viewOnce: true,
        contextInfo: this._contextInfo,
        buttons: [
          ...this._betonOld,
          ...this._beton.map((b) => ({
            buttonId: "Bocchi",
            buttonText: { displayText: "Bocchi" },
            type: 1,
            nativeFlowInfo: { name: b.name, paramsJson: b.buttonParamsJson },
          })),
        ],
      };

      if (locBypass) {
        buttonsMessage.locationMessage = {
          degreesLatitude: 0, degreesLongitude: 0, name: this._title, address: this._subtitle, jpegThumbnail: thumb,
        };
      } else if (this._data) {
        Object.assign(buttonsMessage, this._data);
        buttonsMessage.caption = this._body;
        buttonsMessage.title = this._title;
      }

      msg = buildWAMessage(jid, { buttonsMessage }, { messageId: id, quoted: q });
    }

    await relay(client, jid, msg.message, { messageId: id, additionalNodes: finalNodes, ...options });

    if (useCache && cacheKey && !hasBufferMedia && !q) Button.cache.set(cacheKey, msg);
    return msg;
  }

  async send(
    jid: string,
    { flowType = "mixed", additionalNodes = [], quoted, messageId, ...options }: RunOptions & { quoted?: any } = {},
  ): Promise<WAMessage> {
    const msg = await this.build(jid, { messageId, quoted });
    await relay(this.#client, msg.key.remoteJid, msg.message, {
      ...options,
      messageId: msg.key.id,
      additionalNodes: [...getAdditionalNodes(flowType), ...additionalNodes],
    });
    return msg;
  }

  static async sendAudio(
    client: WaClient, jid: string, audioSrc: Uint8Array | string,
    { quoted, ptt = false }: { quoted?: any; ptt?: boolean } = {},
  ) {
    try {
      const bytes = typeof audioSrc !== "string"
        ? audioSrc
        : audioSrc.startsWith("http")
          ? await Toolkit.fetchBuffer(audioSrc, {}, { silent: false })
          : readFileSync(audioSrc);
      // ⚠ bentuk content audio zapo belum diverifikasi — cek dokumentasi client.message.send.
      await (client as any).message.send(jid, { type: "audio", media: bytes, ptt, mimetype: "audio/mpeg" }, { quote: quoted });
    } catch (e) {
      console.error("[Button.sendAudio]", (e as Error).message);
    }
  }

  static clearCache() { this.cache.clear(); }
  static getCacheStats() { return { size: this.cache.size, defaultTTL: this.cache.defaultTTL }; }
}

export default Button;