import { Buffer } from "node:buffer";
import crypto from "node:crypto";
import type { WaClient } from "zapo-js";
import type { BinaryNode } from "../additional-nodes.ts";
import { Toolkit, type UploadKind } from "../toolkit.ts";
import { rememberSentId } from "../../../lib/serialize/smsg.ts";
import { sendWithFallback } from "./nack-retry.ts";

const RELAY_TIMEOUT_MS = 60_000;

function withTimeout<T>(p: Promise<T>, ms: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<never>((_, rej) => {
    timer = setTimeout(() => rej(new Error(`${label}: tidak ada respon dari WhatsApp setelah ${ms / 1000}s`)), ms);
  });
  return Promise.race([p, timeout]).finally(() => clearTimeout(timer));
}

export interface WAMessage {
  key: { remoteJid: string; id: string; fromMe: boolean; participant?: string };
  message: Record<string, any>;
}

export function newMessageId(): string {
  return "3EB0" + crypto.randomBytes(8).toString("hex").toUpperCase();
}

export function buildWAMessage(
  jid: string,
  content: Record<string, any>,
  { messageId, quoted }: { messageId?: string; quoted?: any } = {},
): WAMessage {
  const message = content;
  if (quoted?.key && quoted?.message) {
    const inner = Object.values(message)[0] as any;
    if (inner && typeof inner === "object") {
      inner.contextInfo = {
        ...(inner.contextInfo ?? {}),
        stanzaId: quoted.key.id,
        participant: quoted.key.participant ?? quoted.key.remoteJid,
        quotedMessage: quoted.message,
      };
    }
  }
  return { key: { remoteJid: jid, id: messageId || newMessageId(), fromMe: true }, message };
}

export interface RelayOptions {
    messageId?: string;
  additionalNodes?: readonly BinaryNode[];
  [k: string]: any;
}

export async function relay(client: WaClient, jid: string, message: Record<string, any>, opts: RelayOptions = {}) {
  const { messageId, additionalNodes, ...rest } = opts;
    if (messageId) rememberSentId(messageId);
    const res: any = await withTimeout(
    sendWithFallback(
      (msg, nodes, attempt) => {
        const id = attempt === 0 ? messageId : newMessageId();
        if (id) rememberSentId(id);
        return (client as any).message.send(jid, msg, {
          ...rest,
          ...(id ? { id } : {}),
          ...(nodes.length ? { customNodes: [...nodes] } : {}),
        });
      },
      message,
      additionalNodes ?? [],
    ),
    RELAY_TIMEOUT_MS,
    "relay",
  );
  rememberSentId(res?.id);
  return res;
}

export async function prepareMedia(client: WaClient, kind: UploadKind, source: Uint8Array | string, extra: Record<string, any> = {}) {
  const bytes = typeof source === "string" ? await Toolkit.fetchBuffer(source) : source;
  if (!bytes?.length) throw new Error("Media kosong / gagal diunduh");
  const mimetype = extra.mimetype ?? Toolkit.sniffMimetype(bytes, kind);
  const up = await (client as any).message.upload(bytes, { type: kind, mimetype });
  const { gifPlayback, caption, fileName, ...rest } = extra;
  const body = {
    ...up,
    mimetype,
    ...(caption ? { caption } : {}),
    ...(fileName ? { fileName } : {}),
    ...(gifPlayback ? { gifPlayback: true } : {}),
    ...rest,
  };
  return { [`${kind}Message`]: body } as Record<string, any>;
}

export function cloneMessage<T>(value: T): T {
  if (value === null || typeof value !== "object") return value;
  if (Buffer.isBuffer(value)) return Buffer.from(value) as any;
  if (ArrayBuffer.isView(value)) return new (value as any).constructor(value);
  if (Array.isArray(value)) return value.map(cloneMessage) as any;
  const out: any = {};
  for (const k of Object.keys(value as any)) out[k] = cloneMessage((value as any)[k]);
  return out;
}

export function makeButtonCacheKey(b: any): string {
  return JSON.stringify({
    t: b._title, s: b._subtitle, b: b._body, f: b._footer,
    ci: b._contextInfo, ex: b._extraPayload, p: b._params,
    beton: b._beton, old: b._betonOld, cards: b._carouselCards,
    data: b._data, loc: b._locationHeader, gif: b._gifPlayback,
    type: b._type, lb: b._locationBypass,
  });
}