// helpers/utils/button-messages/base.ts
type Obj = Record<string, any>;
const isPlain = (v: unknown): v is Obj => typeof v === "object" && v !== null && !Array.isArray(v);

export class BaseBuilder {
  _title = "";
  _subtitle = "";
  _body = "";
  _footer = "";
  _contextInfo: Obj = {};
  _extraPayload: Obj = {};
  _params: Obj = {};

  setTitle(v: string) { this._title = v; return this; }
  setSubtitle(v: string) { this._subtitle = v; return this; }
  setBody(v: string) { this._body = v; return this; }
  setFooter(v: string) { this._footer = v; return this; }

  setContextInfo(o: Obj) { if (isPlain(o)) this._contextInfo = o; return this; }
  addPayload(o: Obj) { if (isPlain(o)) Object.assign(this._extraPayload, o); return this; }
  setParams(o: Obj) { if (isPlain(o)) this._params = o; return this; }
  addParams(o: Obj) { if (isPlain(o)) Object.assign(this._params, o); return this; }
  clearParams() { this._params = {}; return this; }

  // ── Limited Time Offer ──
  setLimitedTimeOffer(text?: string, url?: string, copyCode?: string, expirationTime?: number) {
    this._params.limited_time_offer = {
      text: text || "", url: url || "", copy_code: copyCode || "", expiration_time: expirationTime || 0,
    };
    return this;
  }

  setLimitedTimeOfferObject(o: Obj = {}) {
    this._params.limited_time_offer = {
      text: o.text || "",
      url: o.url || "",
      copy_code: o.copyCode || o.copy_code || "",
      expiration_time: o.expirationTime || o.expiration_time || 0,
    };
    return this;
  }

  setBottomSheet(o: Obj = {}) {
    this._params.bottom_sheet = {
      in_thread_buttons_limit: o.in_thread_buttons_limit ?? o.limit ?? 2,
      divider_indices: o.divider_indices ?? o.dividers ?? [],
      list_title: o.list_title ?? o.listTitle ?? o.title ?? "",
      button_title: o.button_title ?? o.buttonTitle ?? "",
    };
    return this;
  }

  setTapTarget(o: Obj = {}) {
    this._params.tap_target_configuration = {
      title: o.title ?? "",
      description: o.description ?? "",
      canonical_url: o.canonical_url ?? o.url ?? "",
      domain: o.domain ?? "",
      button_index: o.button_index ?? o.buttonIndex ?? 0,
    };
    return this;
  }

  static paramsList = {
    limited_time_offer: { text: "string", url: "string", copy_code: "string", expiration_time: "number" },
    bottom_sheet: { in_thread_buttons_limit: "number", divider_indices: ["number"], list_title: "string", button_title: "string" },
    tap_target_configuration: { title: "string", description: "string", canonical_url: "string", domain: "string", button_index: "number" },
  };
}

export default BaseBuilder;