// helpers/utils/button-messages/buttonV2.ts — BUTTONS MESSAGE (buttonsMessage lama)
import crypto from "node:crypto";
import { Buffer } from "node:buffer";
import type { WaClient } from "zapo-js";
import { getAdditionalNodes, type BinaryNode, type FlowType } from "../additional-nodes.ts";
import { Toolkit } from "../toolkit.ts";
import { BaseBuilder } from "./base.ts";
import { buildWAMessage, newMessageId, relay, type WAMessage } from "./transport.ts";

type Obj = Record<string, any>;

export class ButtonV2 extends BaseBuilder {
  #client: WaClient;
  _image?: Uint8Array | string | { base64: any; is_raw: true };
  _data?: Obj;
  _buttons: Obj[] = [];

  constructor(client: WaClient) {
    super();
    if (!client) throw new Error("Socket is required");
    this.#client = client;
  }

    loadFrom(msg: Obj) {
    if (!msg) throw new Error("buttonsMessage needed");
    const content = msg.message ?? msg;
    const source = content.viewOnceMessage?.message ?? content.viewOnceMessageV2?.message ?? content;
    if (!source.buttonsMessage) throw new Error("buttonsMessage not found");

    const { buttonsMessage: bM, ...extraPayload } = source;
    const location = bM.locationMessage || {};

    this._title = location.name || "";
    this._subtitle = location.address || "";
    this._body = bM.contentText || "";
    this._footer = bM.footerText || "";
    this._contextInfo = bM.contextInfo || {};
    this._extraPayload = extraPayload;

    this._buttons = Array.isArray(bM.buttons)
      ? bM.buttons.map((btn: Obj) => ({
          ...btn,
          ...(btn.nativeFlowInfo && {
            nativeFlowInfo: {
              ...btn.nativeFlowInfo,
              paramsJson: typeof btn.nativeFlowInfo.paramsJson === "string"
                ? btn.nativeFlowInfo.paramsJson
                : JSON.stringify(btn.nativeFlowInfo.paramsJson || {}),
            },
          }),
        }))
      : [];

        this._image = location.jpegThumbnail ? { base64: location.jpegThumbnail, is_raw: true } : undefined;

    const skip = ["contentText", "footerText", "contextInfo", "buttons", "headerType", "locationMessage", "viewOnce"];
    const media: Obj = {};
    for (const k of Object.keys(bM)) if (!skip.includes(k)) media[k] = bM[k];
    this._data = Object.keys(media).length ? media : undefined;
    return this;
  }

  clearButtons() { this._buttons = []; return this; }

  addButton(displayText = "", buttonId: string = crypto.randomUUID()) {
    this._buttons.push({ buttonId, buttonText: { displayText }, type: 1 });
    return this;
  }

  addRawButton(obj: Obj) {
    if (typeof obj !== "object" || obj === null || Array.isArray(obj)) throw new TypeError("Buttons must be a plain object");
    this._buttons.push(obj);
    return this;
  }

  setThumbnail(path: Uint8Array | string) {
    if (!path) throw new Error("Url or buffer needed");
    this._image = path;
    return this;
  }

    setRawThumbnail(thumbnail: any) {
    if (!thumbnail) throw new Error("Thumbnail needed");
    this._image = { base64: thumbnail, is_raw: true };
    return this;
  }

  setMedia(obj: Obj) {
    if (typeof obj === "object" && obj !== null && !Array.isArray(obj)) this._data = obj;
    return this;
  }

  async build(jid: string, { messageId, quoted }: { messageId?: string; quoted?: any } = {}): Promise<WAMessage> {
    let thumb: any = null;
    const img: any = this._image;
    if (img?.is_raw) {
      thumb = img.base64;
    } else if (img) {
      const buf = typeof img === "string" ? await Toolkit.fetchBuffer(img, {}, { silent: true }) : Buffer.from(img);
      if (buf.length > 0) thumb = await Toolkit.resize(buf, 300, 300);
    }

    return buildWAMessage(jid, {
      ...this._extraPayload,
      buttonsMessage: {
        contentText: this._body,
        footerText: this._footer,
        ...(this._data ?? {
          headerType: 6,
          locationMessage: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: this._title,
            address: this._subtitle,
            jpegThumbnail: thumb,
          },
        }),
        viewOnce: true,
        contextInfo: this._contextInfo,
        buttons: this._buttons,
      },
    }, { messageId: messageId || newMessageId(), quoted });
  }

  async send(
    jid: string,
    { flowType = "mixed", additionalNodes = [], quoted, messageId, ...options }:
      { flowType?: FlowType | string; additionalNodes?: BinaryNode[]; quoted?: any; messageId?: string; [k: string]: any } = {},
  ): Promise<WAMessage> {
    if (this._buttons.length < 1) throw new Error("ButtonV2 requires at least one button");
    const msg = await this.build(jid, { messageId, quoted });
    await relay(this.#client, msg.key.remoteJid, msg.message, {
      ...options,
      messageId: msg.key.id,
      additionalNodes: [...getAdditionalNodes(flowType), ...additionalNodes],
    });
    return msg;
  }
}

export default ButtonV2;