// helpers/utils/button-messages/motion-photo.ts — MOTION PHOTO (live photo) untuk zapo-js.
// Urutan: foto (pairedMediaType 5) → video pendamping (pairedMediaType 6 + messageAssociation 12 → parentMessageKey = kunci foto).
// Video WAJIB punya width/height/seconds, kalau tidak WhatsApp memperlakukannya sebagai foto biasa / bubble salah ukuran.
//
// Pemakaian:
//   import { sendMotionPhoto } from "../../helpers/utils/button-messages/index.ts";
//   await sendMotionPhoto(client, m.chat, { image: "https://.../foto.jpg", video: "https://.../klip.mp4", caption: "halo", quoted: m });
import { Toolkit } from "../toolkit.ts";
import { readMp4Info } from "../mp4.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay, type WAMessage } from "./transport.ts";

type Obj = Record<string, any>;
type Source = Uint8Array | string;

export interface MotionPhotoOptions {
  /** Foto (URL / path / bytes). Abaikan kalau `imageMessage` (hasil upload) diberikan. */
  image?: Source;
  /** Video MP4 pendamping (URL / bytes). Abaikan kalau `videoMessage` (hasil upload) diberikan. */
  video?: Source;
  /** Hasil upload yang sudah ada ({ ...imageMessage }) — dipakai ulang tanpa upload lagi (mis. dari cache). */
  imageMessage?: Obj;
  /** Hasil upload yang sudah ada ({ ...videoMessage }) — sebaiknya sudah berisi width/height/seconds. */
  videoMessage?: Obj;
  caption?: string;
  quoted?: any;
  /** Offset (ms) frame foto di dalam klip → field VideoMessage.motionPhotoPresentationOffsetMs. Kosong = tidak dikirim. */
  presentationOffsetMs?: number;
  /** EKSPERIMEN: bungkus video dalam associatedChildMessage (bentuk yang dikirim klien WhatsApp asli). Default false —
   *  zapo stok belum tentu mengenali wrapper ini saat menentukan mediatype stanza (bisa terkirim tapi tidak muncul). */
  wrapChild?: boolean;
}

const asBytes = async (s: Source): Promise<Uint8Array> =>
  typeof s === "string" ? await Toolkit.fetchBuffer(s, { timeout: 60_000 }, { silent: false }) : s;

export async function sendMotionPhoto(
  client: any, jid: string, o: MotionPhotoOptions,
): Promise<{ photo: WAMessage; video: WAMessage | null }> {
  // ── foto ──
  let imageMessage = o.imageMessage;
  if (!imageMessage) {
    if (!o.image) throw new Error("sendMotionPhoto: image / imageMessage wajib diisi");
    imageMessage = (await prepareMedia(client, "image", await asBytes(o.image))).imageMessage;
  }

  // ── video pendamping (opsional: gagal → tetap terkirim sebagai foto biasa) ──
  let videoMessage = o.videoMessage;
  if (!videoMessage && o.video) {
    try {
      const bytes = await asBytes(o.video);
      const info = readMp4Info(bytes);
      videoMessage = (await prepareMedia(client, "video", bytes, {
        mimetype: "video/mp4",
        ...(info.width ? { width: info.width, height: info.height } : {}),
        ...(info.seconds ? { seconds: info.seconds } : {}),
      })).videoMessage;
    } catch (e) {
      console.warn(`[motion-photo] video gagal (${(e as Error).message}) — dikirim sebagai foto biasa`);
    }
  }
  const paired = !!videoMessage;

  const photoId = newMessageId();
  const photo = buildWAMessage(jid, {
    imageMessage: {
      ...imageMessage,
      caption: o.caption ?? "",
      ...(paired ? { contextInfo: { pairedMediaType: 5, statusSourceType: 0 } } : {}),
    },
  }, { messageId: photoId, quoted: o.quoted ?? undefined });
  const photoRes: any = await relay(client, jid, photo.message, { messageId: photoId });
  // id yang BENAR-BENAR dipakai zapo di server. Kalau beda dari photoId, video pendamping harus menunjuk id ini,
  // kalau tidak parentMessageKey mengarah ke pesan yang tidak ada → hanya foto yang tampil.
  const sentId = String(photoRes?.id || photoId);
  if (sentId !== photoId) console.warn(`[motion-photo] id foto berbeda: dibuat ${photoId}, dipakai server ${sentId} — memakai id server`);
  const photoKey = { ...photo.key, id: sentId };
  if (!paired) return { photo, video: null };

  const child = {
    ...videoMessage,
    ...(o.presentationOffsetMs != null ? { motionPhotoPresentationOffsetMs: o.presentationOffsetMs } : {}),
    contextInfo: { pairedMediaType: 6, statusSourceType: 0 },
  };
  const video = buildWAMessage(jid, {
    ...(o.wrapChild ? { associatedChildMessage: { message: { videoMessage: child } } } : { videoMessage: child }),
    messageContextInfo: { messageAssociation: { associationType: 12, parentMessageKey: photoKey } },
  });
  await relay(client, jid, video.message, { messageId: video.key.id });
  return { photo: { ...photo, key: photoKey }, video };
}

export default sendMotionPhoto;