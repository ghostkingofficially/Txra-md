// helpers/utils/config-events.ts — kabar "pengaturan tampilan berubah" (menu, thumb, fake reply, fake quoted, audio, video).
// Store memancarkan; modul prewarm mendengarkan lalu memanaskan cache. emitConfigChange() BISA DITUNGGU:
// store memakai `await emitConfigChange()` sehingga perintah .setxxx baru membalas "berhasil" SETELAH cache hangat,
// dan perintah berikutnya tidak lagi kena jalur dingin (unduh + olah + upload).
// Dipisah supaya store tidak perlu meng-import prewarm (hindari impor melingkar).
type Listener = () => void | Promise<void>;
const listeners = new Set<Listener>();

export function onConfigChange(fn: Listener): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export async function emitConfigChange(): Promise<void> {
  await Promise.all([...listeners].map(async (fn) => {
    try { await fn(); } catch { /* pendengar tidak boleh mengganggu penyimpan */ }
  }));
}