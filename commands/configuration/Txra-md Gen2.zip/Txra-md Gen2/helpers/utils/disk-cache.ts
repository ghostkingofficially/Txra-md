// helpers/utils/disk-cache.ts — cache blob kecil di disk (hasil olahan: thumbnail JPEG, VN ogg/opus).
//
// Kenapa: cache memori hilang tiap restart, sehingga permintaan pertama setelah start harus mengunduh + mengolah ulang
// (itulah "audio menu / thumbnail lambat muncul di awal"). Hasil olahan itu kecil (puluhan–ratusan KB), jadi disimpan di sini.
// Yang disimpan HANYA hasil olahan, bukan media sumber; sumber tetap URL. Folder ada di db/ (sudah di .gitignore).
//
// - Tulis atomik (tmp + rename). Baca gagal / file rusak = dianggap tidak ada.
// - TTL berdasarkan mtime + batas total byte; yang paling lama tidak dipakai dibuang duluan.
// - Matikan: "diskCache": false di config.json → features (atau env DISK_CACHE=0).
import { mkdir, readdir, readFile, rename, rm, stat, utimes, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { PROJECT_ROOT } from "../../src/setthumblarge/store.ts";

export const BLOB_DIR = join(PROJECT_ROOT, "db", "configuration", "thumbs", "cache", "blobs");
const MAX_BYTES = Math.max(1, Number(process.env.DISK_CACHE_MAX_MB ?? 48)) * 1024 * 1024;
const ENABLED = process.env.DISK_CACHE !== "0" && process.env.DISK_CACHE !== "false";
const SAFE = /^[a-z0-9_-]{1,32}$/i;

let writesSincePrune = 0;
let pruning: Promise<void> | null = null;
let dirReady: Promise<unknown> | null = null;

const fileOf = (ns: string, key: string) => join(BLOB_DIR, `${ns}-${key}.bin`);
const valid = (ns: string, key: string) => SAFE.test(ns) && /^[a-f0-9]{8,64}$/i.test(key);

export const diskCacheEnabled = () => ENABLED;

/** Baca blob. null = tidak ada / kedaluwarsa / dimatikan. Membaca memperbarui "terakhir dipakai" (untuk pruning). */
export async function diskGet(ns: string, key: string, ttlMs: number): Promise<Buffer | null> {
  if (!ENABLED || !valid(ns, key)) return null;
  const f = fileOf(ns, key);
  try {
    const st = await stat(f);
    if (Date.now() - st.mtimeMs > ttlMs) { rm(f, { force: true }).catch(() => {}); return null; }
    const buf = await readFile(f);
    return buf.length ? buf : null;
  } catch {
    return null;
  }
}

/** Tulis blob di latar belakang (tidak pernah melempar, tidak menunggu). */
export function diskSet(ns: string, key: string, data: Uint8Array): void {
  if (!ENABLED || !valid(ns, key) || !data?.length || data.length > MAX_BYTES / 4) return;
  void (async () => {
    try {
      await (dirReady ??= mkdir(BLOB_DIR, { recursive: true }));
      const f = fileOf(ns, key);
      const tmp = `${f}.${process.pid}.tmp`;
      await writeFile(tmp, data);
      await rename(tmp, f);
      if (++writesSincePrune >= 40) { writesSincePrune = 0; void diskPrune(); }
    } catch { /* disk penuh / tidak bisa ditulis → cache disk saja yang hilang */ }
  })();
}

/** Buang satu namespace (mis. "thumb") atau semuanya. */
export async function diskClear(ns?: string): Promise<void> {
  try {
    for (const name of await readdir(BLOB_DIR)) {
      if (!ns || name.startsWith(`${ns}-`)) await rm(join(BLOB_DIR, name), { force: true }).catch(() => {});
    }
  } catch { /* folder belum ada */ }
}

/** Rapikan: buang sisa .tmp, lalu buang yang terlama sampai total ≤ batas. */
export function diskPrune(maxAgeMs = 7 * 24 * 3600_000): Promise<void> {
  return (pruning ??= (async () => {
    try {
      const now = Date.now();
      const files: Array<{ f: string; size: number; at: number }> = [];
      let total = 0;
      for (const name of await readdir(BLOB_DIR)) {
        const f = join(BLOB_DIR, name);
        try {
          const st = await stat(f);
          if (name.endsWith(".tmp") || now - st.mtimeMs > maxAgeMs) { await rm(f, { force: true }); continue; }
          files.push({ f, size: st.size, at: st.mtimeMs });
          total += st.size;
        } catch { /* hilang di tengah jalan */ }
      }
      files.sort((a, b) => a.at - b.at);
      for (const it of files) {
        if (total <= MAX_BYTES) break;
        await rm(it.f, { force: true }).catch(() => {});
        total -= it.size;
      }
    } catch { /* folder belum ada */ }
  })().finally(() => { pruning = null; }));
}

/** Tandai "baru dipakai" tanpa membaca isi (dipakai saat data sudah ada di memori). */
export function diskTouch(ns: string, key: string): void {
  if (!ENABLED || !valid(ns, key)) return;
  const t = new Date();
  utimes(fileOf(ns, key), t, t).catch(() => {});
}
