interface Entry<T> {
  value: T;
  expireAt: number;
}

export class CacheManager<T = unknown> {
  private store = new Map<string, Entry<T>>();

  constructor(public defaultTTL = 3000) {}

    keyFromObject(obj: unknown): string {
    return JSON.stringify(obj);
  }

  set(key: string, value: T, ttl = this.defaultTTL): this {
    this.sweep();
    this.store.set(key, { value, expireAt: Date.now() + ttl });
    return this;
  }

  get(key: string): T | null {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (entry.expireAt > Date.now()) return entry.value;
    this.store.delete(key);
    return null;
  }

  delete(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }

  get size(): number {
    return this.store.size;
  }

    private sweep(): void {
    const now = Date.now();
    for (const [k, e] of this.store) if (e.expireAt <= now) this.store.delete(k);
  }
}