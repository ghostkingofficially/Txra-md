import { Buffer } from "node:buffer";
import crypto from "node:crypto";
import type { WaClient } from "zapo-js";
import { BaseBuilder } from "../button-messages/base.ts";
import { buildWAMessage, newMessageId, relay, type WAMessage } from "../button-messages/transport.ts";
import { extractIE, Toolkit, waitAllPromises } from "../toolkit.ts";

type Obj = Record<string, any>;

const UNIFIED_AS_BYTES = true;
const encodeUnified = (json: string) => (UNIFIED_AS_BYTES ? Buffer.from(json) : Buffer.from(json).toString("base64"));
const decodeUnified = (data: unknown): string => {
  if (typeof data === "string") return Buffer.from(data, "base64").toString("utf8");
  if (data instanceof Uint8Array) return Buffer.from(data).toString("utf8");
  return "";
};

// ================= Error =================
export class AIRichError extends Error {
  code: string;
  constructor(message: string, code: string, meta: Obj = {}) {
    super(message);
    this.name = "AIRichError";
    this.code = code;
    Object.assign(this, meta);
  }
}
export class ItemNotFoundError extends AIRichError {
  constructor(id: string, availableIds: string[] = []) {
    super(
      `Item id "${id}" not found${availableIds.length ? ` (available: ${availableIds.join(", ")})` : " (no items have an id yet)"}`,
      "ITEM_NOT_FOUND", { id, availableIds },
    );
    this.name = "ItemNotFoundError";
  }
}
export class DuplicateIdError extends AIRichError {
  constructor(id: string) { super(`Item id "${id}" already exists`, "DUPLICATE_ID", { id }); this.name = "DuplicateIdError"; }
}
export class InvalidTargetError extends AIRichError {
  constructor(message: string, meta: Obj = {}) { super(message, "INVALID_TARGET", meta); this.name = "InvalidTargetError"; }
}
export class ContentValidationError extends AIRichError {
  constructor(message: string, meta: Obj = {}) { super(message, "CONTENT_VALIDATION", meta); this.name = "ContentValidationError"; }
}

// ================= Helper =================
const isPlain = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);
const isPlainOrPlainArray = (v: unknown) => isPlain(v) || (Array.isArray(v) && v.every(isPlain));

export interface NodeEntry { id: string | null; section: Obj | null; submessage: Obj | null }
export interface NodeOptions { id?: string; replace?: string | [string, number]; insertAt?: string | [string, number] }

export interface BuildOptions {
  forwarded?: boolean;
  notification?: boolean;
  includesUnifiedResponse?: boolean;
  includesSubmessages?: boolean;
  quoted?: any;
  quotedParticipant?: string;
  messageId?: string;
  botJid?: string;
  disclaimerText?: string;
}
export interface SendOptions extends BuildOptions {
  bypassDownload?: boolean;
  bypassDownloadDelayMs?: number;
  bypassDownloadDouble?: boolean;
}

export class AIRich extends BaseBuilder {
  #client: WaClient;
  _nodes: NodeEntry[] = [];
  _idIndex = new Map<string, NodeEntry>();
  _unsupportedTypeAlert: boolean;
  _dynamic: boolean;
  _responseId = crypto.randomUUID();
  _botResponseId = crypto.randomUUID();
  _lastMessageKey: WAMessage["key"] | null = null;

  constructor(client: WaClient, { dynamic = true, unsupportedTypeAlert = true }: { dynamic?: boolean; unsupportedTypeAlert?: boolean } = {}) {
    if (!client) throw new Error("Socket is required");
    super();
    this.#client = client;
    this._unsupportedTypeAlert = !!unsupportedTypeAlert;
    this._dynamic = !!dynamic;
  }

  loadFrom(msg: Obj) {
    if (!msg) throw new Error("AI Rich message needed");
    const message = msg.message ?? msg;
    const rich =
      message?.botForwardedMessage?.message?.richResponseMessage ??
      message?.botForwardedMessage?.richResponseMessage ??
      message?.richResponseMessage;
    if (!rich) throw new Error("richResponseMessage not found");

    this._title = message?.messageContextInfo?.botMetadata?.messageDisclaimerText ?? "";
    this._contextInfo = structuredClone(rich.contextInfo ?? {});
    const subs: Obj[] = Array.isArray(rich.submessages) ? structuredClone(rich.submessages) : [];

    let sections: Obj[] = [];
    const raw = decodeUnified(rich.unifiedResponse?.data);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed?.sections)) sections = structuredClone(parsed.sections);
      } catch { /* sekip */ }
    }

    this._nodes = [];
    this._idIndex = new Map();
    const max = Math.max(sections.length, subs.length);
    for (let i = 0; i < max; i++) this._nodes.push({ id: null, section: sections[i] ?? null, submessage: subs[i] ?? null });

    this._extraPayload = {};
    for (const [k, v] of Object.entries(message)) {
      if (k !== "messageContextInfo" && k !== "botForwardedMessage" && k !== "richResponseMessage") {
        this._extraPayload[k] = structuredClone(v);
      }
    }
    return this;
  }

  setResponseId(id: string) { this._responseId = id; return this; }
  refreshResponseId() { this._responseId = crypto.randomUUID(); return this; }
  setBotResponseId(id: string) { this._botResponseId = id; return this; }
  refreshBotResponseId() { this._botResponseId = crypto.randomUUID(); return this; }

  createAlert(type: string) {
    return this._unsupportedTypeAlert ? { messageType: 2, messageText: `[ UNSUPPORTED_TYPE - ${type}]` } : undefined;
  }

  // ================= Konten =================
  addText(text: string, { hyperlink = true, citation = true, latex = true, ...node }: NodeOptions & Obj = {}) {
    if (typeof text !== "string") throw new TypeError("Text must be a string");
    const { text: out, inline_entities } = extractIE(text, { hyperlink, citation, latex });
    const section = AIRich.newLayout("Single", {
      text: out,
      ...(inline_entities.length && { inline_entities }),
      __typename: "GenAIMarkdownTextUXPrimitive",
    });
    return this._addContent(section, [{ messageType: 2, messageText: text }], node);
  }

  addFOAText(text: string, node: NodeOptions = {}) {
    if (typeof text !== "string") throw new TypeError("Text must be a string");
    const section = AIRich.newLayout("Single", { text, __typename: "FOATextPrimitive" });
    return this._addContent(section, [{ messageType: 2, messageText: text }], node);
  }

  addCode(language: string, code: string, node: NodeOptions = {}) {
    if (typeof language !== "string" || typeof code !== "string") throw new TypeError("Language and code must be a string");
    const meta = AIRich.tokenizer(code, language);
    const section = AIRich.newLayout("Single", { language, code_blocks: meta.unified_codeBlock, __typename: "GenAICodeUXPrimitive" });
    const sub = { messageType: 5, codeMetadata: { codeLanguage: language, codeBlocks: meta.codeBlock } };
    return this._addContent(section, [sub], node);
  }

  addTable(table: string[][], { hyperlink = true, citation = true, latex = true, ...node }: NodeOptions & Obj = {}) {
    if (!Array.isArray(table)) throw new TypeError("Table must be an array");
    const meta = AIRich.toTableMetadata(table, { hyperlink, citation, latex });
    const section = AIRich.newLayout("Single", { rows: meta.unified_rows, __typename: "GenATableUXPrimitive" });
    const sub = { messageType: 4, tableMetadata: { title: meta.title, rows: meta.rows } };
    return this._addContent(section, [sub], node);
  }

  addSource(sources: any[] = [], node: NodeOptions = {}) {
    if (!Array.isArray(sources)) throw new TypeError("Sources must be an array of strings, arrays, or objects");
    const isStrings = sources.every((s) => typeof s === "string");
    const isArrays = sources.every((s) => Array.isArray(s) && s.every((x: unknown) => typeof x === "string"));
    const isObjects = sources.every(isPlain);
    if (!isStrings && !isArrays && !isObjects) throw new TypeError("Sources must be a string array, array of string arrays, or array of objects");
    const list: any[] = isStrings ? [sources] : sources;

    const items = list.map((s) => {
      if (Array.isArray(s)) { const [icon, url, title, subtitle] = s; return { icon, url, title, subtitle }; }
      return { icon: s.favicon ?? s.icon ?? "", url: s.url ?? "", title: s.title ?? "", subtitle: s.subtitle ?? "" };
    }).map(({ icon, url, title, subtitle }) => ({
      source_type: "THIRD_PARTY",
      source_display_name: title,
      source_subtitle: subtitle,
      source_url: url,
      favicon: { url: Toolkit.resolveMedia(this.#client, icon, "image"), mime_type: "image/jpeg", width: 16, height: 16 },
    }));

    const section = AIRich.newLayout("Single", { sources: items, __typename: "GenAISearchResultPrimitive" });
    return this._addContent(section, this.createAlert("GenAISearchResultPrimitive"), node);
  }

  addReels(reelsItems: Obj | Obj[] = [], node: NodeOptions = {}) {
    if (!isPlainOrPlainArray(reelsItems)) throw new TypeError("Reels items must be an object or an array of objects");
    const reels = (Array.isArray(reelsItems) ? reelsItems : [reelsItems]).map((item) => ({
      ...item,
      _avatar: Toolkit.resolveMedia(this.#client, item.profileIconUrl ?? item.profile_url ?? item.profile ?? "", "image"),
      _thumbnail: Toolkit.resolveMedia(this.#client, item.thumbnailUrl ?? item.thumbnail ?? "", "image"),
    }));

    const section = AIRich.newLayout("HScroll", reels.map((item) => ({
      reels_url: item.videoUrl ?? item.url ?? "",
      thumbnail_url: item._thumbnail,
      creator: item.username ?? item.title ?? "",
      avatar_url: item._avatar,
      reels_title: item.reels_title ?? item.title ?? "",
      likes_count: item.likes_count ?? item.like ?? 0,
      shares_count: item.shares_count ?? item.share ?? 0,
      view_count: item.view_count ?? item.view ?? 0,
      reel_source: item.reel_source ?? item.source ?? "IG",
      is_verified: !!(item.is_verified || item.verified),
      __typename: "GenAIReelPrimitive",
    })));

    const sub = {
      messageType: 9,
      contentItemsMetadata: {
        contentType: 1,
        itemsMetadata: reels.map((item) => ({
          reelItem: {
            title: item.username ?? "",
            profileIconUrl: item._avatar,
            thumbnailUrl: item._thumbnail,
            videoUrl: item.videoUrl ?? item.url ?? "",
          },
        })),
      },
    };
    return this._addContent(section, [sub], node);
  }

  addImage(
    imageUrl: string | Uint8Array | Array<string | Uint8Array>,
    { width, height, status = "READY", update_text, resolveUrl = false, ...node }: NodeOptions & Obj = {},
  ) {
    const ok = (v: unknown) => typeof v === "string" || v instanceof Uint8Array;
    if (!(ok(imageUrl) || (Array.isArray(imageUrl) && imageUrl.every(ok)))) {
      throw new TypeError("imageUrl must be string | buffer | array of string/buffer");
    }
    const list = (Array.isArray(imageUrl) ? imageUrl : [imageUrl]).map((v) => {
      const url = Toolkit.resolveMedia(this.#client, v, "image", { resolveUrl });
      return { imagePreviewUrl: url, imageHighResUrl: url, sourceUrl: url };
    });

    const sections = list.map(({ imagePreviewUrl }) =>
      AIRich.newLayout("Single", {
        media: { url: imagePreviewUrl, mime_type: "image/png", width, height },
        imagine_type: "IMAGE",
        status: { status, update_text },
        __typename: "GenAIImaginePrimitive",
      })
    );
    const sub = {
      messageType: 1,
      gridImageMetadata: { gridImageUrl: { imagePreviewUrl: list[0]?.imagePreviewUrl }, imageUrls: list },
    };
    if (node.id && sections.length !== 1) throw new Error("Cannot assign one id to multiple image sections");
    return this._addContent(sections, sub, node);
  }

    addPhoto(preview: string | Uint8Array, { full, mime_type = "image/jpeg", ...node }: NodeOptions & { full?: string | Uint8Array; mime_type?: string } = {}) {
    const previewUrl = Toolkit.resolveMedia(this.#client, preview, "image");
    const fullUrl = full ? Toolkit.resolveMedia(this.#client, full, "image") : previewUrl;
    const section = AIRich.newLayout("Single", {
      __typename: "GenAIImagePrimitive",
      preview_image: { __typename: "GenAIMediaItem", mime_type, url: previewUrl },
      full_image: { __typename: "GenAIMediaItem", mime_type, url: fullUrl },
    });
    return this._addContent(section, this.createAlert("GenAIImagePrimitive"), node);
  }

  addVideo(
    videoUrl: any,
    { autoFill = true, status = "READY", estimatedTime, ...node }: NodeOptions & { autoFill?: boolean; status?: string; estimatedTime?: number } = {},
  ) {
    const isObj = (v: any) => isPlain(v) && v.url;
    const ok = (v: unknown) => typeof v === "string" || v instanceof Uint8Array || isObj(v);
    if (!(ok(videoUrl) || (Array.isArray(videoUrl) && videoUrl.every(ok)))) throw new TypeError("videoUrl must be string | buffer | object | array");

    const items = Array.isArray(videoUrl) ? videoUrl : [videoUrl];
    const alert = this.createAlert("GenAIImaginePrimitive (ANIMATE)");
    const sections: Obj[] = [];

    for (const item of items) {
      const obj = isObj(item);
      const url = Toolkit.resolveMedia(this.#client, obj ? item.url : item, "video");
      const bufferPromise = autoFill ? Promise.resolve(url).then((u) => Toolkit.fetchBuffer(u)) : null;

      const file_length = obj && item.file_length != null ? item.file_length : autoFill ? bufferPromise!.then((b) => b?.length ?? 0) : 0;
      const duration = obj && item.duration != null ? item.duration : autoFill ? bufferPromise!.then((b) => Toolkit.getMp4Duration(b, { silent: true })) : 0;
      const thumbnail = obj && item.thumbnail
        ? Toolkit.resolveMedia(this.#client, item.thumbnail, "image", { result: "base64", resize: true, width: 300, height: 300 })
        : autoFill ? bufferPromise?.then((b) => Toolkit.getMp4Preview(b, { time: 0, result: "base64" })) : null;

      sections.push(AIRich.newLayout("Single", {
        media: { url, mime_type: obj ? (item.mime_type ?? "video/mp4") : "video/mp4", file_length, duration },
        imagine_type: "ANIMATE",
        status: { status, estimated_completion_time: estimatedTime != null ? Math.floor((Date.now() + estimatedTime) / 1000) : undefined },
        thumbnail: { raw_media: thumbnail },
        __typename: "GenAIImaginePrimitive",
      }));
    }
    return this._addContent(sections, alert, node);
  }

  addProduct(data: Obj | Obj[] = {}, node: NodeOptions = {}) {
    if (!isPlainOrPlainArray(data)) throw new TypeError("Product items must be an object or an array of objects");
    const product = (Array.isArray(data) ? data : [data]).map((item) => ({
      title: item.title,
      brand: item.brand,
      price: item.price,
      sale_price: item.sale_price,
      product_url: item.product_url ?? item.url,
      image: { url: Toolkit.resolveMedia(this.#client, item.image_url ?? item.image, "image") },
      additional_images: [{ url: Toolkit.resolveMedia(this.#client, item.icon_url ?? item.icon, "image") }],
      __typename: "GenAIProductItemCardPrimitive",
    }));
    const section = AIRich.newLayout(Array.isArray(data) ? "HScroll" : "Single", Array.isArray(data) ? product : product[0]);
    return this._addContent(section, this.createAlert("GenAIProductItemCardPrimitive"), node);
  }

  addPost(data: Obj | Obj[] = {}, node: NodeOptions = {}) {
    if (!isPlainOrPlainArray(data)) throw new TypeError("Post items must be an object or an array of objects");
    const posts = Array.isArray(data) ? data : [data];
    const primitives = posts.map((p) => ({
      title: p.title ?? "",
      subtitle: p.subtitle ?? "",
      username: p.username ?? "",
      profile_picture_url: Toolkit.resolveMedia(this.#client, p.profile_picture_url ?? p.profile_url ?? p.profile ?? "", "image"),
      is_verified: !!(p.is_verified || p.verified),
      thumbnail_url: Toolkit.resolveMedia(this.#client, p.thumbnail_url ?? p.thumbnail ?? "", "image"),
      post_caption: p.post_caption ?? p.caption ?? "",
      likes_count: p.likes_count ?? p.like ?? 0,
      comments_count: p.comments_count ?? p.comment ?? 0,
      shares_count: p.shares_count ?? p.share ?? 0,
      post_url: p.post_url ?? p.url ?? "",
      post_deeplink: p.post_deeplink ?? p.deeplink ?? "",
      source_app: p.source_app || p.source || "INSTAGRAM",
      footer_label: p.footer_label ?? p.footer ?? "",
      footer_icon: Toolkit.resolveMedia(this.#client, p.footer_icon ?? p.icon ?? "", "image"),
      is_carousel: posts.length > 1,
      orientation: p.orientation ?? "LANDSCAPE",
      post_type: p.post_type ?? "VIDEO",
      __typename: "GenAIPostPrimitive",
    }));
    return this._addContent(AIRich.newLayout("HScroll", primitives), this.createAlert("GenAIPostPrimitive"), node);
  }

  addMetadata(text: string, node: NodeOptions = {}) {
    if (typeof text !== "string") throw new TypeError("Text must be a string");
    const section = AIRich.newLayout("Single", { text, __typename: "GenAIMetadataTextPrimitive" });
    return this._addContent(section, [{ messageType: 2, messageText: text }], node);
  }

  addTip(text: string, node: NodeOptions = {}) {
    if (typeof text !== "string") throw new TypeError("Text must be a string");
    const section = AIRich.newLayout("Single", { text: "ⓘ " + text, __typename: "GenAIMetadataTextPrimitive" });
    return this._addContent(section, [{ messageType: 2, messageText: text }], node);
  }

    addWidget(data: Obj | Obj[], { layout, ...rest }: NodeOptions & Obj = {}) {
    if (!isPlainOrPlainArray(data)) throw new TypeError("Widget must be an object or an array of objects");
    const { id, replace, insertAt, ...options } = rest;
    const isArray = Array.isArray(data);
    const widgets = (isArray ? data : [data]).map((item) => ({
      __typename: "GenAI3PExtWidgetPrimitive",
      header: { __typename: "GenAI3PExtWidgetStandardHeader", title: item.title ?? "", ...(item.header ?? {}) },
      body: {
        __typename: "GenAI3PExtCalendarEventList",
        sections: item.sections ?? [],
        ctas: (item.actions ?? []).map((a: Obj) => ({
          __typename: "GenAI3PExtWidgetCTA",
          label: a.label ?? "",
          state: a.state ?? "PENDING",
          kind: a.kind ?? "OTHER",
          tool_call_id: a.tool_call_id ?? a.id ?? "",
          ...(a.toast && { toast: { __typename: "GenAI3PExtWidgetToast", label: a.toast.label ?? a.label ?? "" } }),
        })),
        ...(item.body ?? {}),
      },
    }));
    const section = AIRich.newLayout(layout ?? (isArray ? "HScroll" : "Single"), isArray ? widgets : widgets[0], options);
    return this._addContent(section, this.createAlert("GenAI3PExtWidgetStandardHeader"), { id, replace, insertAt });
  }

  addFooterAction(data: Obj | Obj[], { layout, ...rest }: NodeOptions & Obj = {}) {
    if (!isPlainOrPlainArray(data)) throw new TypeError("Footer action must be an object or an array of objects");
    const { id, replace, insertAt, ...options } = rest;
    const isArray = Array.isArray(data);
    const actions = (isArray ? data : [data]).map((item) => ({
      __typename: "GenAIFooterActionPrimitive",
      cta_text: item.text ?? item.cta_text ?? "",
      cta_type: item.type ?? item.cta_type ?? "OPEN_URL",
      cta_url: item.url ?? item.cta_url ?? "",
    }));
    const section = AIRich.newLayout(layout ?? (isArray ? "HScroll" : "Single"), isArray ? actions : actions[0], options);
    return this._addContent(section, this.createAlert("GenAIFooterActionPrimitive"), { id, replace, insertAt });
  }

  addFooterButtons(
    buttons: Array<string | Obj> = ["like", "dislike", "share"],
    { sectionId = "footer_section", ...node }: NodeOptions & { sectionId?: string } = {},
  ) {
    const list = (Array.isArray(buttons) ? buttons : [buttons]).map((b) => (typeof b === "string" ? { type: b } : b));
    if (!list.length || !list.every(isPlain)) throw new TypeError("Buttons must be string[] or object[]");
    const section = { section_id: sectionId, view_model: { __typename: "GenAIFooterViewModel", buttons: list } };
    return this._addContent(section, this.createAlert("GenAIFooterViewModel"), node);
  }

 
  addHtml(
    html: string,
    { trustedSources = [], ...node }: NodeOptions & { trustedSources?: string[] } = {},
  ) {
    if (typeof html !== "string" || !html) throw new TypeError("HTML must be a non-empty string");
    const section = AIRich.newLayout("Single", {
      payload: html,
      trusted_sources: trustedSources,
      __typename: "GenAIaeacdsnwHtmlPrimitive",
    });
    return this._addContent(section, this.createAlert("GenAIaeacdsnwHtmlPrimitive"), node);
  }

  addSuggest(suggestion: string | string[], { scroll = true, layout, ...node }: NodeOptions & { scroll?: boolean; layout?: string } = {}) {
    if (!(typeof suggestion === "string" || (Array.isArray(suggestion) && suggestion.every((v) => typeof v === "string")))) {
      throw new TypeError("Suggestion must be a string or array of strings");
    }
    const suggest = (Array.isArray(suggestion) ? suggestion : [suggestion]).map((text) => ({
      prompt_text: text,
      prompt_type: "SUGGESTED_PROMPT",
      __typename: "GenAIFollowUpSuggestionPillPrimitive",
    }));
    const type = layout ?? (suggest.length === 1 ? "Single" : scroll ? "HScroll" : "ActionRow");
    const section = AIRich.newLayout(type, type === "Single" ? suggest[0] : suggest, { __typename: "GenAIUnifiedResponseSection" });
    return this._addContent(section, this.createAlert("GenAIFollowUpSuggestionPillPrimitive"), node);
  }

  // ================= Build / Send =================
  async build(jid: string, opts: BuildOptions = {}): Promise<WAMessage> {
    const {
      forwarded = true, notification = false, includesUnifiedResponse = true, includesSubmessages = true,
      quoted, quotedParticipant, messageId, botJid = "0@bot", disclaimerText,
    } = opts;

    const forward = forwarded
      ? { forwardingScore: 1, isForwarded: true, forwardedAiBotMessageInfo: { botJid }, forwardOrigin: 4 }
      : {};
    const notif = notification
      ? { sessionTransparencyMetadata: { disclaimerText: disclaimerText ?? this._title, hcaId: `hca_${Date.now()}`, sessionTransparencyType: 1 } }
      : {};
    const qObj = quoted
      ? {
          stanzaId: quoted?.key?.id || quoted?.id,
          participant: quotedParticipant || quoted?.key?.participant || quoted?.participant || quoted?.key?.remoteJid,
          quotedType: 0,
          quotedMessage: typeof quoted === "object" ? (quoted.message ?? quoted) : undefined,
        }
      : {};

    const resolved: Obj[] = await waitAllPromises(this._sections);
        let sections = resolved;
    if (this._footer) {
      const footerText = AIRich.newLayout("Single", { text: this._footer, __typename: "GenAIMetadataTextPrimitive" });
      const at = resolved.findIndex((x) => x?.view_model?.__typename === "GenAIFooterViewModel");
      sections = at === -1 ? [...resolved, footerText] : [...resolved.slice(0, at), footerText, ...resolved.slice(at)];
    }

    if (this._dynamic) { this.refreshResponseId(); this.refreshBotResponseId(); }

    const unified = includesUnifiedResponse
      ? encodeUnified(Toolkit.stringifyEscaped({ response_id: this._responseId, sections }))
      : (UNIFIED_AS_BYTES ? new Uint8Array() : "");

    return buildWAMessage(jid, {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: this._title,
          ...notif,
          pluginMetadata: {},
          richResponseSourcesMetadata: {},
          botResponseId: this._botResponseId,
        },
      },
      ...this._extraPayload,
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: includesSubmessages ? await waitAllPromises(this._submessages) : [],
            unifiedResponse: { data: unified },
            contextInfo: { ...forward, ...qObj, ...this._contextInfo },
          },
        },
      },
    }, { messageId: messageId || newMessageId() });
  }

  async buildEdit(targetJid: string, targetId: string, { msg, messageId, ...options }: { msg?: Obj; messageId?: string } & BuildOptions = {}): Promise<WAMessage> {
    const editedMessage = msg ?? (await this.build(targetJid, options)).message;
    if (!editedMessage) throw new Error("buildEdit: message kosong");
    return buildWAMessage(targetJid, {
      botForwardedMessage: {
        message: {
          protocolMessage: {
            key: { remoteJid: targetJid, fromMe: true, id: targetId },
            type: 14, // MESSAGE_EDIT
            editedMessage,
          },
        },
      },
    }, { messageId: messageId || newMessageId() });
  }

  async sendEdit(jid?: string, id?: string, { msg, messageId, ...options }: { msg?: Obj; messageId?: string } & BuildOptions = {}) {
    jid = jid ?? this._lastMessageKey?.remoteJid;
    id = id ?? this._lastMessageKey?.id;
    if (!jid) throw new Error("JID is required");
    if (!id) throw new Error("Message id is required");

    const edit = await this.buildEdit(jid, id, { msg, messageId: messageId || newMessageId(), ...options });
    await relay(this.#client, jid, edit.message, { messageId: edit.key.id });
    return edit;
  }

  async send(
    jid: string,
    { bypassDownload = true, bypassDownloadDelayMs = 250, bypassDownloadDouble = false, ...options }: SendOptions = {},
  ) {
    const msg = await this.build(jid, options);
    await relay(this.#client, msg.key.remoteJid, msg.message, { messageId: msg.key.id });

    if ((options.includesUnifiedResponse ?? true) && bypassDownload) {
      const { messageId: _origMessageId, ...editOptions } = options;
  if (bypassDownloadDelayMs > 0) await new Promise((r) => setTimeout(r, bypassDownloadDelayMs));
      await this.sendEdit(jid, msg.key.id, editOptions);
      if (bypassDownloadDouble) {
        await new Promise((r) => setTimeout(r, Math.max(150, bypassDownloadDelayMs)));
        await this.sendEdit(jid, msg.key.id, editOptions);
      }
    }
    this._lastMessageKey = msg.key;
    return msg;
  }


  async typing(
    jid: string,
    text: string,
    { step = 6, delayMs = 400, ...options }: SendOptions & { step?: number; delayMs?: number } = {},
  ) {
    const tokens = text.split(/(\s+)/);
    let shown = "";
    let i = Math.min(step * 2, tokens.length);
    shown = tokens.slice(0, i).join("");

    this.addText(shown, { id: "typing", replace: this.hasId("typing") ? "typing" : undefined });
    const first = await this.send(jid, { ...options, bypassDownload: false });

    while (i < tokens.length) {
      await new Promise((r) => setTimeout(r, delayMs));
      i = Math.min(i + step * 2, tokens.length);
      shown = tokens.slice(0, i).join("");
      this.addText(shown, { replace: "typing" });
      await this.sendEdit(jid, first.key.id, { ...options });
    }
    if (options.bypassDownload ?? true) await this.sendEdit(jid, first.key.id, { ...options });
    this._lastMessageKey = first.key;
    return first;
  }

  // ================= Statics =================
  static newLayout(name: string, data: any, extra: Obj = {}) {
    return {
      ...extra,
      view_model: {
        [Array.isArray(data) ? "primitives" : "primitive"]: data,
        __typename: `GenAI${name}LayoutViewModel`,
      },
    };
  }

  static toTableMetadata(arr: string[][], { hyperlink = true, citation = true, latex = true }: Obj = {}) {
    if (!Array.isArray(arr) || !arr.every((r) => Array.isArray(r) && r.every((c) => typeof c === "string"))) {
      throw new TypeError("Table must be a nested array of strings");
    }
    const [header, ...rows] = arr;
    const maxLen = Math.max(header.length, ...rows.map((r) => r.length));
    const normalize = (r: string[]) => [...r, ...Array(maxLen - r.length).fill("")];

    const unified_rows = [
      { is_header: true, cells: normalize(header) },
      ...rows.map((r) => ({ is_header: false, cells: normalize(r) })),
    ].map((row) => {
      const markdown_cells = row.cells.map((cell) => {
        const ex = extractIE(cell, { hyperlink, citation, latex });
        return { text: ex.text, ...(ex.inline_entities.length ? { inline_entities: ex.inline_entities } : {}) };
      });
      return { ...row, ...(markdown_cells.some((c: Obj) => c.inline_entities?.length) ? { markdown_cells } : {}) };
    });

    return {
      title: "",
      rows: unified_rows.map((r) => ({ items: r.cells, ...(r.is_header ? { isHeading: true } : {}) })),
      unified_rows,
    };
  }

  static #KEYWORDS: Record<string, Set<string>> = Object.fromEntries(Object.entries({
    javascript: "break case catch continue debugger delete do else finally for function if in instanceof new return switch this throw try typeof var void while with true false null undefined class const let super extends export import yield static constructor async await get set",
    typescript: "abstract any as asserts bigint boolean declare enum implements infer interface is keyof module namespace never readonly require number object override private protected public satisfies string symbol type unknown using from break case catch continue do else finally for function if new return switch this throw try var void while class const let extends import export async await",
    python: "False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield",
    java: "abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while",
    golang: "break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var",
    c: "auto break case char const continue default do double else enum extern float for goto if int long register return short signed sizeof static struct switch typedef union unsigned void volatile while",
    cpp: "alignas alignof and auto bool break case catch class const constexpr continue delete do double else enum explicit export extern false float for friend if inline int long mutable namespace new noexcept nullptr operator private protected public return short signed sizeof static struct switch template this throw true try typedef typename union unsigned using virtual void while",
    php: "abstract and array as break callable case catch class clone const continue declare default do echo else elseif empty enddeclare endfor endforeach endif endswitch endwhile extends final finally fn for foreach function global goto if implements include include_once instanceof interface match namespace new null or private protected public require require_once return static switch throw trait try use var while yield",
    rust: "as break const continue crate else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while",
    html: "html head body div span p a img video audio script style link meta form input button table tr td th ul ol li section article header footer nav main",
    bash: "if then else elif fi for while do done case esac function in select until break continue return export readonly local declare",
    markdown: "# ## ### #### ##### ######",
  }).map(([k, v]) => [k, new Set(v.split(" "))]));

  static tokenizer(code: string, lang = "javascript") {
    const L = (lang || "").toLowerCase();
    if (!L || ["txt", "text", "plaintext"].includes(L)) {
      return {
        codeBlock: [{ codeContent: code, highlightType: 0 }],
        unified_codeBlock: [{ content: code, type: "DEFAULT" }],
      };
    }

    const TYPE_MAP: Record<number, string> = { 0: "DEFAULT", 1: "KEYWORD", 2: "METHOD", 3: "STR", 4: "NUMBER", 5: "COMMENT" };
    const keywords = AIRich.#KEYWORDS[L] ?? new Set<string>();
    const tokens: Array<{ codeContent: string; highlightType: number }> = [];
    let i = 0;

    const push = (content: string, type: number) => {
      if (!content) return;
      const last = tokens[tokens.length - 1];
      if (last && last.highlightType === type) last.codeContent += content;
      else tokens.push({ codeContent: content, highlightType: type });
    };
    const isIdent = (ch: string) => (L === "css" ? /[a-zA-Z0-9_$-]/ : L === "html" ? /[a-zA-Z0-9_$:-]/ : /[a-zA-Z0-9_$]/).test(ch);

    while (i < code.length) {
      const c = code[i];

      if (/\s/.test(c)) {
        const s = i; while (i < code.length && /\s/.test(code[i])) i++;
        push(code.slice(s, i), 0); continue;
      }
      if ((c === "/" && code[i + 1] === "/") || (c === "#" && ["python", "bash"].includes(L))) {
        const s = i; while (i < code.length && code[i] !== "\n") i++;
        push(code.slice(s, i), 5); continue;
      }
      if (c === '"' || c === "'" || c === "`") {
        const s = i, q = c; i++;
        while (i < code.length) {
          if (code[i] === "\\" && i + 1 < code.length) i += 2;
          else if (code[i] === q) { i++; break; }
          else i++;
        }
        push(code.slice(s, i), 3); continue;
      }
      if (/[0-9]/.test(c)) {
        const s = i; while (i < code.length && /[0-9._]/.test(code[i])) i++;
        push(code.slice(s, i), 4); continue;
      }
      if (/[a-zA-Z_$]/.test(c)) {
        const s = i; while (i < code.length && isIdent(code[i])) i++;
        const word = code.slice(s, i);
        let type = 0;

        if (keywords.has(word)) type = 1;
        else if (L === "css") {
          let j = i; while (j < code.length && /\s/.test(code[j])) j++;
          if (code[j] === ":") type = 1;
        } else if (L === "html") {
          let p = s - 1; while (p >= 0 && /\s/.test(code[p])) p--;
          if (code[p] === "<" || (code[p] === "/" && code[p - 1] === "<")) type = 1;
        }
        if (type === 0) {
          let j = i; while (j < code.length && /\s/.test(code[j])) j++;
          if (code[j] === "(") type = 2;
        }
        push(word, type); continue;
      }
      push(c, 0); i++;
    }

    return {
      codeBlock: tokens,
      unified_codeBlock: tokens.map((t) => ({ content: t.codeContent, type: TYPE_MAP[t.highlightType] })),
    };
  }

    _makeNode(id: string | null | undefined, section: Obj | null | undefined, submessage: Obj | null | undefined): NodeEntry {
    return { id: id ?? null, section: section ?? null, submessage: submessage ?? null };
  }

  _registerId(node: NodeEntry, id: unknown) {
    if (id === undefined || id === null || id === "") return;
    if (typeof id !== "string") throw new ContentValidationError("Item id must be a string", { id });
    if (this._idIndex.has(id)) throw new DuplicateIdError(id);
    node.id = id;
    this._idIndex.set(id, node);
  }

  _unregisterId(node: NodeEntry) {
    if (node.id && this._idIndex.get(node.id) === node) this._idIndex.delete(node.id);
  }

  hasId(id: string) { return typeof id === "string" && this._idIndex.has(id); }
  getIds() { return [...this._idIndex.keys()]; }

  peek(id: string) {
    const node = this._idIndex.get(id);
    return node ? { id: node.id, section: node.section, submessage: node.submessage } : null;
  }

  assignId(index: number, id: string) {
    if (!Number.isInteger(index) || index < 0 || index >= this._nodes.length) {
      throw new InvalidTargetError(`Node index ${index} is out of range (0-${this._nodes.length - 1})`, { index });
    }
    const node = this._nodes[index];
    if (node.id) throw new AIRichError(`Node at index ${index} already has id "${node.id}"`, "ALREADY_HAS_ID", { index, id: node.id });
    this._registerId(node, id);
    return this;
  }

  _getNode(id: string) {
    if (typeof id !== "string" || !id) throw new ContentValidationError("Item id must be a non-empty string", { id });
    const node = this._idIndex.get(id);
    if (!node) throw new ItemNotFoundError(id, this.getIds());
    return node;
  }

  _resolveTarget(target: string | [string, number?]) {
    if (Array.isArray(target)) {
      if (target.length < 1 || target.length > 2) throw new ContentValidationError("Target must be id or [id, offset]", { target });
      const [id, offset = 0] = target;
      if (typeof id !== "string" || !id) throw new ContentValidationError("Target id must be a non-empty string", { target });
      if (!Number.isInteger(offset)) throw new ContentValidationError("Offset must be an integer", { target });
      return { id, offset };
    }
    if (typeof target !== "string" || !target) throw new ContentValidationError("Target must be a non-empty id or [id, offset]", { target });
    return { id: target, offset: 0 };
  }

  _resolveNodeIndex(target: string | [string, number?]) {
    const { id, offset } = this._resolveTarget(target);
    const node = this._getNode(id);
    const baseIndex = this._nodes.indexOf(node);
    if (baseIndex === -1) throw new InvalidTargetError(`Item id "${id}" is registered but not present in the node list (internal desync)`, { id });
    const index = baseIndex + offset;
    if (index < 0 || index >= this._nodes.length) {
      throw new InvalidTargetError(
        `Target "${id}" with offset ${offset} resolves to index ${index}, which is out of range (0-${this._nodes.length - 1})`,
        { id, offset, index },
      );
    }
    return { id, offset, baseIndex, index };
  }

  _validateSections(section: unknown): Obj[] {
    const items = Array.isArray(section) ? section : [section];
    if (!items.length) throw new ContentValidationError("At least one section is required");
    for (const it of items) if (!isPlain(it)) throw new ContentValidationError("Sections must be plain objects");
    return items as Obj[];
  }

  _validateSubmessages(submessage: unknown): Obj[] {
    if (submessage === undefined || submessage === null) return [];
    const items = Array.isArray(submessage) ? submessage : [submessage];
    for (const it of items) if (!isPlain(it)) throw new ContentValidationError("Submessages must be plain objects");
    return items as Obj[];
  }

  _addContent(section: unknown, submessage: unknown, { id, replace, insertAt }: NodeOptions = {}) {
    const hasReplace = replace !== undefined && replace !== null && (replace as any) !== "";
    const hasInsertAt = insertAt !== undefined && insertAt !== null && (insertAt as any) !== "";
    if (hasReplace && hasInsertAt) throw new ContentValidationError("replace and insertAt cannot be used together");

    const sections = this._validateSections(section);
    const submessages = this._validateSubmessages(submessage);

    if (id !== undefined && id !== null && id !== "" && sections.length !== 1) {
      throw new ContentValidationError("One id can only be assigned to one node", { id, sectionCount: sections.length });
    }
    if (submessages.length && submessages.length !== sections.length && submessages.length !== 1) {
      throw new ContentValidationError("Section and submessage count must match");
    }

    const paired = sections.map((_, i) => (!submessages.length ? undefined : submessages.length === 1 ? submessages[0] : submessages[i]));

    if (id && this._idIndex.has(id) && !(hasReplace && this._resolveTarget(replace as any).id === id)) {
      throw new DuplicateIdError(id);
    }

    const newNodes = sections.map((s, i) => this._makeNode(i === 0 ? id : null, s, paired[i]));

    if (hasReplace) {
      if (newNodes.length !== 1) throw new ContentValidationError("replace only supports adding exactly one node");
      const target = this._resolveNodeIndex(replace as any);
      const oldNode = this._nodes[target.index];
      const newNode = newNodes[0];
      if (!newNode.id && oldNode?.id) newNode.id = oldNode.id;
      this._unregisterId(oldNode);
      this._nodes.splice(target.index, 1, newNode);
      if (newNode.id) this._idIndex.set(newNode.id, newNode);
      return this;
    }

    if (hasInsertAt) {
      const target = this._resolveNodeIndex(insertAt as any);
      const insertIndex = target.offset < 0 ? target.index : target.index + 1;
      this._nodes.splice(insertIndex, 0, ...newNodes);
      for (const n of newNodes) if (n.id) this._idIndex.set(n.id, n);
      return this;
    }

    this._nodes.push(...newNodes);
    for (const n of newNodes) if (n.id) this._idIndex.set(n.id, n);
    return this;
  }

  addSection(section: unknown, options: NodeOptions = {}) { return this._addContent(section, undefined, options); }

  addSubmessage(submessage: unknown, options: NodeOptions = {}) {
    const items = this._validateSubmessages(submessage);
    if (!items.length) throw new ContentValidationError("At least one submessage is required");
    return this._addContent(undefined, items, options);
  }

  delete(target: string | [string, number?]) {
    const { index } = this._resolveNodeIndex(target);
    const [old] = this._nodes.splice(index, 1);
    this._unregisterId(old);
    return this;
  }

  get _sections() { return this._nodes.filter((n) => n.section !== null).map((n) => n.section as Obj); }
  get _submessages() { return this._nodes.filter((n) => n.submessage !== null).map((n) => n.submessage as Obj); }
  get sections() { return this._sections; }
  get items() {
    return this._sections.flatMap((s) => {
      const vm = s?.view_model;
      return Array.isArray(vm?.primitives) ? vm.primitives : vm?.primitive ? [vm.primitive] : [];
    });
  }
}

export default AIRich;