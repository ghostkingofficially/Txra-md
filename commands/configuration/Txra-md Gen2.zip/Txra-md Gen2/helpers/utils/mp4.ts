// helpers/utils/mp4.ts — baca dimensi (width/height) + durasi MP4 langsung dari atom (tanpa ffprobe).
// Dipakai agar videoMessage punya width/height/seconds yang benar: tanpa itu WhatsApp menebak ukuran bubble
// dari jpegThumbnail (kalau thumbnail-nya gambar portrait → video landscape tampil "berdiri").

export interface Mp4Info {
  /** Lebar tampilan (sudah memperhitungkan rotasi 90°/270°). 0 = tidak terbaca. */
  width: number;
  /** Tinggi tampilan (sudah memperhitungkan rotasi). 0 = tidak terbaca. */
  height: number;
  /** Durasi dalam detik (dibulatkan ke atas, minimal 1 kalau ada durasi). 0 = tidak terbaca. */
  seconds: number;
}

interface Box { type: string; start: number; body: number; end: number }

function* boxes(dv: DataView, from: number, to: number): Generator<Box> {
  let off = from;
  while (off + 8 <= to) {
    let size = dv.getUint32(off);
    const type = String.fromCharCode(dv.getUint8(off + 4), dv.getUint8(off + 5), dv.getUint8(off + 6), dv.getUint8(off + 7));
    let head = 8;
    if (size === 1) {
      if (off + 16 > to) return;
      size = Number(dv.getBigUint64(off + 8));
      head = 16;
    } else if (size === 0) {
      size = to - off;
    }
    if (size < head || off + size > to) return;
    yield { type, start: off, body: off + head, end: off + size };
    off += size;
  }
}

const find = (dv: DataView, parent: Box | null, type: string, len: number): Box | null => {
  for (const b of boxes(dv, parent ? parent.body : 0, parent ? parent.end : len)) if (b.type === type) return b;
  return null;
};

export function readMp4Info(bytes: Uint8Array): Mp4Info {
  const out: Mp4Info = { width: 0, height: 0, seconds: 0 };
  try {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const moov = find(dv, null, "moov", bytes.byteLength);
    if (!moov) return out;

    // durasi: mvhd
    const mvhd = find(dv, moov, "mvhd", bytes.byteLength);
    if (mvhd) {
      const v = dv.getUint8(mvhd.body);
      const timescale = v === 1 ? dv.getUint32(mvhd.body + 20) : dv.getUint32(mvhd.body + 12);
      const duration = v === 1 ? Number(dv.getBigUint64(mvhd.body + 24)) : dv.getUint32(mvhd.body + 16);
      if (timescale > 0 && duration > 0) out.seconds = Math.max(1, Math.ceil(duration / timescale));
    }

    // dimensi: tkhd pertama yang lebar×tingginya > 0 (track audio = 0×0)
    for (const trak of boxes(dv, moov.body, moov.end)) {
      if (trak.type !== "trak") continue;
      const tkhd = find(dv, trak, "tkhd", bytes.byteLength);
      if (!tkhd) continue;
      const v = dv.getUint8(tkhd.body);
      const matrix = tkhd.body + (v === 1 ? 4 + 32 + 16 : 4 + 20 + 16); // awal matrix 3x3
      const wOff = matrix + 36;
      if (wOff + 8 > tkhd.end) continue;
      let w = dv.getUint32(wOff) / 65536;
      let h = dv.getUint32(wOff + 4) / 65536;
      if (!(w > 0 && h > 0)) continue;
      // matrix: a b (kolom 1), c d (kolom 2) — fixed 16.16. a=d=0 → rotasi 90°/270° → tukar lebar/tinggi.
      const a = dv.getInt32(matrix), b = dv.getInt32(matrix + 4), c = dv.getInt32(matrix + 12), d = dv.getInt32(matrix + 16);
      if (a === 0 && d === 0 && b !== 0 && c !== 0) [w, h] = [h, w];
      out.width = Math.round(w);
      out.height = Math.round(h);
      break;
    }
  } catch { /* file rusak → biarkan 0 */ }
  return out;
}
