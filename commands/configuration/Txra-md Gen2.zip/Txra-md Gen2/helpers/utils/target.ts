import type { SerializedMessage } from "../../lib/serialize/index.ts";

export function extractTarget(m: SerializedMessage): string | null {
  if (m.mentionedJid?.length > 0) {
    return m.mentionedJid[0];
  }

  // 2. Dari reply
  if (m.quoted?.sender) {
    return m.quoted.sender;
  }

  // 3. Dari argumen nomor
  const arg = m.args?.[0];
  if (arg) {
    const digits = arg.replace(/\D/g, "");
    if (digits.length >= 8 && digits.length <= 15) {
      return digits + "@s.whatsapp.net";
    }
  }

  return null;
}


export function extractAllTargets(m: SerializedMessage): string[] {
  if (m.mentionedJid?.length > 0) {
    return [...m.mentionedJid];
  }
  if (m.quoted?.sender) {
    return [m.quoted.sender];
  }
  const arg = m.args?.[0];
  if (arg) {
    const digits = arg.replace(/\D/g, "");
    if (digits.length >= 8 && digits.length <= 15) {
      return [digits + "@s.whatsapp.net"];
    }
  }
  return [];
}

export function formatJid(jid: string): string {
  if (!jid) return "unknown";
  const phone = jid.split("@")[0].split(":")[0].replace(/\D/g, "");
  return "+" + phone;
}

export function getDisplayName(
  groupMetadata: any,
  jid: string,
): string {
  if (!groupMetadata?.participants) return formatJid(jid);
  const p = groupMetadata.participants.find(
    (x: any) => x.jid === jid || x.phoneNumber === jid,
  );
  return p?.phoneNumber?.split("@")[0] ?? formatJid(jid);
}