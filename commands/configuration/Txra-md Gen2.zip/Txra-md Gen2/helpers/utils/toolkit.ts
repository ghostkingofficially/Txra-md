import { Buffer } from "node:buffer";
import { PassThrough, Readable } from "node:stream";
import axios from "axios";
import ffmpeg from "fluent-ffmpeg";
import Jimp from "jimp";
import type { WaClient } from "zapo-js";

// ================= extractIE =================
export interface ExtractIEOptions {
  extract?: boolean;
  hyperlink?: boolean;
  citation?: boolean;
  latex?: boolean;
}

export interface ExtractIEResult {
  text: string;
  ie: Array<{ type: "hyperlink" | "citation" | "latex"; ie: Record<string, any> }>;
  inline_entities: Array<Record<string, any>>;
}

function createIE(type: string, ie: Record<string, any>): Record<string, any> | undefined {
  if (type === "hyperlink") {
    return {
      key: ie.key,
      metadata: {
        display_name: ie.text,
        is_trusted: ie.is_trusted,
        url: ie.url,
        __typename: "GenAIInlineLinkItem",
      },
    };
  }
  if (type === "citation") {
    return {
      key: ie.key,
      metadata: {
        reference_id: ie.reference_id,
        reference_url: ie.url,
        reference_title: ie.url,
        reference_display_name: ie.url,
        sources: [],
        __typename: "GenAISearchCitationItem",
      },
    };
  }
  if (type === "latex") {
    return {
      key: ie.key,
      metadata: {
        latex_expression: ie.text,
        latex_image: {
          url: ie.url,
          width: Number(ie.width) || 100,
          height: Number(ie.height) || 100,
        },
        font_height: Number(ie.font_height) || 83.333333333333,
        padding: Number(ie.padding) || 15,
        __typename: "GenAILatexItem",
      },
    };
  }
}

export function extractIE(
  text: string,
  { extract = true, hyperlink = true, citation = true, latex = true }: ExtractIEOptions = {},
): ExtractIEResult {
  if (!extract) return { text, ie: [], inline_entities: [] };

  const ie: ExtractIEResult["ie"] = [];
  const inline_entities: Array<Record<string, any>> = [];
  let result = "";
  let last = 0;
  let citation_index = 1;
  let hyperlink_index = 0;
  let latex_index = 0;
  const stack: number[] = [];

  for (let i = 0; i < text.length; i++) {
    if (text[i] === "[" && text[i - 1] !== "\\") {
      stack.push(i);
    } else if (text[i] === "]" && (text[i + 1] === "(" || text[i + 1] === "<")) {
      const start = stack.pop();
      if (start == null) continue;

      const open = text[i + 1];
      const close = open === "(" ? ")" : ">";
      const type = open === "(" ? "link" : "latex";
      let end = i + 2;
      let depth = 1;

      while (end < text.length && depth) {
        if (text[end] === open && text[end - 1] !== "\\") depth++;
        else if (text[end] === close && text[end - 1] !== "\\") depth--;
        end++;
      }
      if (depth) continue;

      const raw = text.slice(start + 1, i).trim();
      let url = text.slice(i + 2, end - 1).trim();
      let key: string;
      let tag: string;
      let data: ExtractIEResult["ie"][number];

      if (type === "latex") {
        if (!latex) continue;
        const [txt = "", width = null, height = null, font_height = null, padding = null] = raw.split("|");
        key = `NIXEL_LATEX_${latex_index++}`;
        tag = `{{${key}}}${txt || "image"}{{/${key}}}`;
        data = { type: "latex", ie: { key, text: txt, url, width, height, font_height, padding } };
      } else if (raw) {
        if (!hyperlink) continue;
        const trusted = !url.startsWith("!");
        if (!trusted) url = url.slice(1);
        key = `NIXEL_HYPERLINK_${hyperlink_index++}`;
        tag = `{{${key}}}${url}{{/${key}}}`;
        data = { type: "hyperlink", ie: { key, text: raw, url, is_trusted: trusted } };
      } else {
        if (!citation) continue;
        key = `NIXEL_CITATION_${citation_index - 1}`;
        tag = `{{${key}}}${url}{{/${key}}}`;
        data = { type: "citation", ie: { reference_id: citation_index++, key, text: "", url } };
      }

      result += text.slice(last, start) + tag;
      last = end;
      ie.push(data);
      const entity = createIE(data.type, data.ie);
      if (entity) inline_entities.push(entity);
      i = end - 1;
    }
  }

  result += text.slice(last);
  return { text: result, ie, inline_entities };
}

// ================= waitAllPromises =================
export async function waitAllPromises<T = any>(input: unknown): Promise<T> {
  const isPromise = (v: any): v is Promise<unknown> => v && typeof v.then === "function";
  const isObject = (v: any) => v && typeof v === "object";

  const deep = async (v: any): Promise<any> => {
    if (isPromise(v)) return deep(await v);
    if (Array.isArray(v)) return Promise.all(v.map(deep));
    if (isObject(v)) {
      const entries = await Promise.all(
        Object.entries(v).map(async ([k, val]) => [k, await deep(val)] as const),
      );
      return Object.fromEntries(entries);
    }
    return v;
  };

  return deep(await input);
}

// ================= Toolkit =================
export type ResizeFit = "cover" | "contain" | "fill";
export type UploadKind = "image" | "video" | "document" | "audio" | "sticker";

export interface ResolveMediaOptions {
  resolveUrl?: boolean;
  resolveWAUrl?: boolean;
  result?: "url" | "buffer" | "base64";
  resize?: boolean;
  width?: number;
  height?: number;
}

export class Toolkit {
  static extractIE = extractIE;
  static waitAllPromises = waitAllPromises;

  static async resize(buffer: Uint8Array, x: number, y: number, fit: ResizeFit = "cover"): Promise<Buffer> {
    const image = await Jimp.read(Buffer.from(buffer));

    if (fit === "cover") {
      const srcW = image.getWidth();
      const srcH = image.getHeight();
      const srcRatio = srcW / srcH;
      const dstRatio = x / y;

      if (srcRatio > dstRatio) {
        const newW = Math.round(srcH * dstRatio);
        image.crop(Math.round((srcW - newW) / 2), 0, newW, srcH);
      } else if (srcRatio < dstRatio) {
        const newH = Math.round(srcW / dstRatio);
        image.crop(0, Math.round((srcH - newH) / 2), srcW, newH);
      }
      image.resize(x, y);
    } else if (fit === "contain") {
      image.contain(x, y);
    } else {
      image.resize(x, y);
    }

    return await image.getBufferAsync(Jimp.MIME_PNG);
  }

  static async fetchBuffer(
    url: string,
    options: Record<string, any> = {},
    { silent = true }: { silent?: boolean } = {},
  ): Promise<Buffer> {
    try {
      const res = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 10000,
        headers: options.headers || {},
        ...options,
      });
      return Buffer.from(res.data);
    } catch (error) {
      if (silent) return Buffer.alloc(0);
      throw error;
    }
  }

  static sniffMimetype(bytes: Uint8Array, kind: UploadKind = "image"): string {
    const b = bytes;
    if (b.length > 4) {
      if (b[0] === 0xff && b[1] === 0xd8) return "image/jpeg";
      if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
      if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return "image/gif";
      if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b.length > 11 &&
          b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
      if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return "application/pdf";
    }
    if (kind === "video" && b.length > 11 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70) {
      return "video/mp4";
    }
    return ({
      image: "image/jpeg",
      video: "video/mp4",
      audio: "audio/mpeg",
      sticker: "image/webp",
      document: "application/octet-stream",
    } as const)[kind];
  }

  static async toUrl(
    client: WaClient,
    source: Uint8Array | string,
    mediaType: UploadKind = "document",
  ): Promise<string | undefined> {
    if (!source) throw new Error("Url or buffer needed");
    const bytes = typeof source === "string" ? await Toolkit.fetchBuffer(source) : source;
    if (!bytes.length) return undefined;
    const media = await (client as any).message.upload(bytes, {
      type: mediaType,
      mimetype: Toolkit.sniffMimetype(bytes, mediaType),
    });
    return media?.url;
  }

  static async resolveMedia(
    client: WaClient,
    media: any,
    mediaType: UploadKind = "image",
    opts: ResolveMediaOptions = {},
  ): Promise<any> {
    const { resolveUrl = false, resolveWAUrl = false, result = "url", resize = false, width = 300, height = 300 } = opts;
    const isUrl = (s: string) => /^https?:\/\/.+/i.test(s);
    const isWAUrl = (s: string) => /^https?:\/\/[^/]*\.whatsapp\.net\//i.test(s);

    if (Array.isArray(media)) {
      return Promise.all(media.map((item) => Toolkit.resolveMedia(client, item, mediaType, opts)));
    }

    if (typeof media === "string" && isUrl(media)) {
      if (isWAUrl(media)) {
        if (resolveWAUrl) {
          media = await Toolkit.fetchBuffer(media);
        } else if (!resolveUrl) {
          if (result === "url") return media;
          media = await Toolkit.fetchBuffer(media);
        }
      } else if (!resolveUrl) {
        if (result === "url") return media;
        media = await Toolkit.fetchBuffer(media);
      } else {
        media = await Toolkit.fetchBuffer(media);
      }
    }

    if (typeof media === "string" && !isUrl(media)) {
      media = Buffer.from(media, "base64");
    }

    if (!(media instanceof Uint8Array) || !media.length) return;

    if (resize) media = await Toolkit.resize(media, width, height);

    if (result === "buffer") return media;
    if (result === "base64") return Buffer.from(media).toString("base64");
    return Toolkit.toUrl(client, media, mediaType);
  }

  static getMp4Duration(buffer: Uint8Array, { silent = true }: { silent?: boolean } = {}): number {
    try {
      if (!(buffer instanceof Uint8Array) || buffer.length < 8) {
        if (silent) return 0;
        throw new Error("Invalid buffer");
      }
      const buf = Buffer.from(buffer.buffer, buffer.byteOffset, buffer.byteLength);

      let offset = 0;
      while (offset < buf.length - 8) {
        const size = buf.readUInt32BE(offset);
        if (size < 8 || offset + size > buf.length) {
          if (silent) return 0;
          throw new Error("Invalid atom size");
        }

        const type = buf.toString("ascii", offset + 4, offset + 8);
        if (type === "moov") {
          let moovOffset = offset + 8;
          const moovEnd = offset + size;
          while (moovOffset < moovEnd - 8) {
            const childSize = buf.readUInt32BE(moovOffset);
            if (childSize < 8 || moovOffset + childSize > moovEnd) {
              if (silent) return 0;
              throw new Error("Invalid child atom size");
            }
            const childType = buf.toString("ascii", moovOffset + 4, moovOffset + 8);
            if (childType === "mvhd") {
              const version = buf.readUInt8(moovOffset + 8);
              if (version === 0) {
                const timescale = buf.readUInt32BE(moovOffset + 20);
                const duration = buf.readUInt32BE(moovOffset + 24);
                if (!timescale) { if (silent) return 0; throw new Error("Invalid timescale"); }
                return duration / timescale;
              }
              if (version === 1) {
                const timescale = buf.readUInt32BE(moovOffset + 32);
                const duration = Number(buf.readBigUInt64BE(moovOffset + 36));
                if (!timescale) { if (silent) return 0; throw new Error("Invalid timescale"); }
                return duration / timescale;
              }
            }
            moovOffset += childSize;
          }
        }
        offset += size;
      }

      if (silent) return 0;
      throw new Error("No mvhd found!");
    } catch (err) {
      if (silent) return 0;
      throw err;
    }
  }

  static getMp4Preview(
    videoBuffer: Uint8Array,
    { time, result = "buffer", resize = true, width = 300, height = 300, silent = true }: {
      time?: number;
      result?: "buffer" | "base64";
      resize?: boolean;
      width?: number;
      height?: number;
      silent?: boolean;
    } = {},
  ): Promise<Buffer | string> {
    return new Promise((resolve, reject) => {
      const fail = (err: unknown) => {
        if (silent) return resolve(result === "base64" ? "" : Buffer.alloc(0));
        return reject(err);
      };

      try {
        if (!(videoBuffer instanceof Uint8Array) || !videoBuffer.length) {
          return fail(new Error("videoBuffer tidak valid atau kosong"));
        }

        const inputStream = new Readable({ read() {} });
        inputStream.push(videoBuffer);
        inputStream.push(null);

        const outputStream = new PassThrough();
        const chunks: Buffer[] = [];

        outputStream.on("data", (chunk: Buffer) => chunks.push(chunk));
        outputStream.on("end", async () => {
          try {
            let output = Buffer.concat(chunks);
            if (!output.length) return fail(new Error("Output kosong"));
            if (resize) output = await Toolkit.resize(output, width, height);
            return resolve(result === "base64" ? output.toString("base64") : output);
          } catch (err) {
            return fail(err);
          }
        });
        outputStream.on("error", fail);

        time ??= Math.min(Toolkit.getMp4Duration(videoBuffer) * 0.2, 10);

        ffmpeg(inputStream)
          .outputOptions([`-ss ${time}`, "-vframes 1", "-vcodec png", "-f image2pipe"])
          .on("error", (err: Error) => fail(new Error(`ffmpeg error: ${err.message}`)))
          .pipe(outputStream, { end: true });
      } catch (err) {
        return fail(err);
      }
    });
  }

    static stringifyEscaped(obj: unknown): string {
    return JSON.stringify(obj).replace(
      /[\u007f-\uffff]/g,
      (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"),
    );
  }
}

export default Toolkit;