export { loadCommands, getCommand, getAllCommands, getCommandsByCategory, commandCount } from "./handling-plugins.ts";
export type { Command, CommandContext } from "./handling-plugins.ts";
export { handleIncomingMessage } from "./handlig-message.ts";