import { pathToFileURL } from "node:url";
import { resolve, join, relative, sep, isAbsolute } from "node:path";
import { readdir } from "node:fs/promises";
import type { Dirent } from "node:fs";
import { log } from "../connector/logger/index-logging.ts";

export interface CommandContext {
  client: any;
  args: string[];
  text: string;
  prefix: string;
  command: string;
  isOwner: boolean;
  isPrimaryOwner: boolean;
  isPremium: boolean;
  isAdmin: boolean;
  isBotAdmin: boolean;
  isRegistered: boolean;
  pushName: string;
  groupMetadata?: any;
  user?: import("../lib/usermanager/users.ts").UserData;
  flags?: import("../lib/func/markers.ts").ResolvedFlags;
}

export interface Command {
  name: string;
  alias?: string[];
  category?: string;
  description?: string;
  usage?: string;
  isOwner?: boolean;
  isPremium?: boolean;
  isGroup?: boolean;
  isPrivate?: boolean;
  isAdmin?: boolean;
  isBotAdmin?: boolean;
  isRegistered?: boolean;
  isNoLimit?: boolean;
  isLimit?: boolean;
  isBot?: boolean;
  hidden?: boolean;
  path?: string;
  execute(m: any, ctx: CommandContext): Promise<any>;
  [key: string]: any;
}

declare global {
  var __botCommandRegistry: Map<string, Command> | undefined;
  var __botAliasRegistry: Map<string, string> | undefined;
  var __botCommandsLoaded: boolean | undefined;
  var __botCommandsCount: number | undefined;
}

const registry: Map<string, Command> = (globalThis.__botCommandRegistry ??= new Map());
const aliasRegistry: Map<string, string> = (globalThis.__botAliasRegistry ??= new Map());

function isLoadedFlag(): boolean { return globalThis.__botCommandsLoaded === true; }
function setLoadedFlag(v: boolean): void { globalThis.__botCommandsLoaded = v; }
function getLastCount(): number { return globalThis.__botCommandsCount ?? 0; }
function setLastCount(n: number): void { globalThis.__botCommandsCount = n; }

function toAbsolutePath(input: string): string {
  if (isAbsolute(input)) return input;
  return resolve(process.cwd(), input);
}

function toFileUrl(absolutePath: string): string {
  return pathToFileURL(absolutePath).href;
}

interface WalkEntry {
  path: string;
  name: string;
  isFile: boolean;
  relPath: string;
}

async function* walkDir(dir: string, baseDir: string): AsyncGenerator<WalkEntry> {
  let entries: Dirent[] = [];
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch (err) {
    log.warn(`Cannot read dir ${dir}: ${(err as Error).message}`);
    return;
  }

  for (const entry of entries) {
    if (entry.name.startsWith("_") || entry.name.startsWith(".")) continue;

    const fullPath = join(dir, entry.name);
    const relPath = relative(baseDir, fullPath).split(sep).join("/");

    if (entry.isDirectory()) {
      yield* walkDir(fullPath, baseDir);
    } else if (entry.isFile()) {
      yield { path: fullPath, name: entry.name, isFile: true, relPath };
    }
  }
}

export async function loadCommands(
  baseDir: string,
  options: { force?: boolean } = {},
): Promise<{ total: number; byCategory: Record<string, number> }> {
  if (isLoadedFlag() && !options.force) {
    return { total: getLastCount(), byCategory: countByCategory() };
  }
  if (options.force) {
    registry.clear();
    aliasRegistry.clear();
  }

  const absoluteBase = toAbsolutePath(baseDir);
  const byCategory: Record<string, number> = {};
  let total = 0;
  const startTime = Date.now();

  log.info(`Scanning commands in: ${absoluteBase}`);

  for await (const entry of walkDir(absoluteBase, absoluteBase)) {
    if (!entry.isFile) continue;
    if (entry.name.endsWith(".d.ts")) continue;
    if (!entry.name.endsWith(".ts") && !entry.name.endsWith(".js")) continue;

    const fileUrl = toFileUrl(entry.path);
    const cacheBust = options.force ? `?t=${Date.now()}` : "";

    let mod: any;
    try {
      mod = await import(fileUrl + cacheBust);
    } catch (err) {
      log.error(`Import failed "${entry.relPath}": ${err instanceof Error ? err.message : err}`);
      continue;
    }

    const cmd: Command | undefined = mod.default ?? mod.command ?? mod;
    if (!cmd || typeof cmd !== "object") continue;
    if (typeof cmd.name !== "string" || !cmd.name) continue;
    if (typeof cmd.execute !== "function") continue;

    const parts = entry.relPath.split("/");
    const categoryFromPath = parts.length > 1 ? parts[0] : "root";
    cmd.category = cmd.category ?? categoryFromPath;
    cmd.path = entry.relPath;

    const name = cmd.name.toLowerCase();
    registry.set(name, cmd);

    for (const a of cmd.alias ?? []) {
      aliasRegistry.set(a.toLowerCase(), name);
    }

    byCategory[cmd.category] = (byCategory[cmd.category] ?? 0) + 1;
    total++;
    log.success(`Loaded ${entry.relPath} → ${name}`);
  }

  setLoadedFlag(true);
  setLastCount(total);
  log.success(`Commands loaded: ${total} (${Date.now() - startTime}ms)`);
  return { total, byCategory };
}

export function getCommand(name: string): Command | undefined {
  if (!name) return undefined;
  const key = name.toLowerCase();
  return registry.get(key) ?? registry.get(aliasRegistry.get(key) ?? "");
}

export function getAllCommands(): Command[] { return [...registry.values()]; }

export function getCommandsByCategory(): Record<string, Command[]> {
  const out: Record<string, Command[]> = {};
  for (const cmd of registry.values()) {
    const cat = cmd.category ?? "root";
    (out[cat] ??= []).push(cmd);
  }
  return out;
}

export function isLoaded(): boolean { return isLoadedFlag(); }
export function commandCount(): number { return registry.size; }

function countByCategory(): Record<string, number> {
  const out: Record<string, number> = {};
  for (const cmd of registry.values()) {
    const cat = cmd.category ?? "root";
    out[cat] = (out[cat] ?? 0) + 1;
  }
  return out;
}