
import type { WaClient } from "zapo-js";
import { getCachedParticipants, getGroupMetadata } from "./index.ts";
import type { GroupMetadata, GroupParticipant } from "./index.ts";
import { getLidForPhone, getPhoneForLid } from "../usermanager/owner.ts";

const lidToPnMap: Map<string, string> = ((globalThis as any).__botLidToPn ??= new Map());
const pnToLidMap: Map<string, string> = ((globalThis as any).__botPnToLid ??= new Map());
const MAP_MAX = 10_000;

export function lidKey(jid: string): string {
  const at = jid.indexOf("@");
  if (at < 0) return jid;
  return jid.slice(0, at).split(":")[0] + jid.slice(at);
}

export const isLid = (jid?: string | null): jid is string => !!jid && jid.endsWith("@lid");

export function pnDigits(input?: string | null): string {
  if (!input) return "";
  const s = String(input).trim();
  if (/^\d{7,15}$/.test(s)) return s;
  const at = s.indexOf("@");
  if (at < 0) return "";
  const server = s.slice(at + 1);
  if (server !== "s.whatsapp.net" && server !== "c.us") return "";
  const user = s.slice(0, at).split(":")[0].split("_")[0];
  return /^\d{7,15}$/.test(user) ? user : "";
}

const pnToJid = (pn: string) => `${pn}@s.whatsapp.net`;

function trim(map: Map<string, string>) {
  if (map.size >= MAP_MAX) {
    const first = map.keys().next().value;
    if (first !== undefined) map.delete(first);
  }
}

export function learnLidPn(lid?: string | null, pn?: string | null): boolean {
  if (!isLid(lid)) return false;
  const phone = pnDigits(pn);
  if (!phone) return false;
  const key = lidKey(lid);
  const changed = lidToPnMap.get(key) !== phone;
  if (changed) {
    trim(lidToPnMap);
    lidToPnMap.set(key, phone);
  }
  if (pnToLidMap.get(phone) !== key) {
    trim(pnToLidMap);
    pnToLidMap.set(phone, key);
  }
  return changed;
}

export function learnFromParticipants(participants?: GroupParticipant[] | null): number {
  let n = 0;
  for (const p of participants ?? []) {
    if (isLid(p.jid) && learnLidPn(p.jid, p.phoneNumber)) n++;
  }
  return n;
}

export function learnFromGroupMetadata(meta?: GroupMetadata | null): number {
  if (!meta) return 0;
  let n = learnFromParticipants(meta.participants);
  if (isLid(meta.owner) && learnLidPn(meta.owner, meta.ownerPhoneNumber)) n++;
  return n;
}

export function learnFromMessage(m?: { key?: Record<string, any>; sender?: string; chat?: string; senderPn?: string } | null): number {
  if (!m) return 0;
  const k = m.key ?? {};
  let n = 0;
  const pairs: Array<[unknown, unknown]> = [
    [k.participant, k.participantAlt ?? k.participantPn],
    [k.remoteJid, k.remoteJidAlt],
    [k.participantAlt, k.participant], 
    [k.remoteJidAlt, k.remoteJid],
    [m.sender, m.senderPn],
  ];
  for (const [a, b] of pairs) {
    const lid = isLid(a as string) ? (a as string) : isLid(b as string) ? (b as string) : "";
    const pn = pnDigits(a as string) ? (a as string) : pnDigits(b as string) ? (b as string) : "";
    if (lid && pn && learnLidPn(lid, pn)) n++;
  }
  return n;
}

export function lidToPn(lid?: string | null, chat?: string | null): string | undefined {
  if (!isLid(lid)) return undefined;
  const key = lidKey(lid);

  const known = lidToPnMap.get(key);
  if (known) return known;

  const owner = getPhoneForLid(key) ?? getPhoneForLid(lid);
  if (owner) {
    learnLidPn(key, owner);
    return owner;
  }

  if (chat?.endsWith("@g.us")) {
    const list = getCachedParticipants(chat);
    if (list) {
      learnFromParticipants(list);
      return lidToPnMap.get(key);
    }
  }
  return undefined;
}

export function pnToLid(input?: string | null): string | undefined {
  const pn = pnDigits(input);
  if (!pn) return undefined;
  const known = pnToLidMap.get(pn);
  if (known) return known;

  const owner = getLidForPhone(pn);
  if (owner) {
    learnLidPn(owner, pn);
    return lidKey(owner);
  }
  for (const [lid, phone] of lidToPnMap) {
    if (phone === pn) {
      pnToLidMap.set(pn, lid);
      return lid;
    }
  }
  return undefined;
}

export function lidToJid(lid?: string | null, chat?: string | null): string | undefined {
  const pn = lidToPn(lid, chat);
  return pn ? pnToJid(pn) : undefined;
}

export function jidToLid(jid?: string | null): string | undefined {
  return pnToLid(jid);
}

export function getPn(jid?: string | null, chat?: string | null): string {
  if (!jid) return "";
  return pnDigits(jid) || lidToPn(jid, chat) || "";
}

export function toPnJid(jid?: string | null, chat?: string | null): string {
  if (!jid) return "";
  const pn = getPn(jid, chat);
  return pn ? pnToJid(pn) : jid;
}

export async function fetchLidForPn(client: WaClient, input: string): Promise<string | undefined> {
  const pn = pnDigits(input);
  if (!pn) return undefined;
  try {
    const results: any[] = await (client as any).profile.getLidsByPhoneNumbers([pn]);
    for (const r of results ?? []) {
      if (!r?.lidJid) continue;
      const phone = pnDigits(r.phoneJid) || pn;
      learnLidPn(r.lidJid, phone);
      if (phone === pn) return lidKey(r.lidJid);
    }
  } catch {
      }
  return undefined;
}

export async function resolvePn(
  client: WaClient,
  jid?: string | null,
  chat?: string | null,
): Promise<string | undefined> {
  const quick = getPn(jid, chat);
  if (quick) return quick;
  if (isLid(jid) && chat?.endsWith("@g.us")) {
    const meta = await getGroupMetadata(client, chat);
    learnFromGroupMetadata(meta);
    return lidToPnMap.get(lidKey(jid)) || undefined;
  }
  return undefined;
}

export async function resolveLid(client: WaClient, jid?: string | null): Promise<string | undefined> {
  if (isLid(jid)) return lidKey(jid);
  return pnToLid(jid) ?? (await fetchLidForPn(client, jid ?? ""));
}


export interface ParticipantPn {
    jid: string;
    lid?: string;
    pn?: string;
    pnJid?: string;
  isAdmin: boolean;
  isSuperAdmin: boolean;
}

export function mapParticipants(participants?: GroupParticipant[] | null): ParticipantPn[] {
  learnFromParticipants(participants);
  return (participants ?? []).map((p) => {
    const jid = p.jid ?? p.phoneNumber ?? "";
    const pn = pnDigits(p.phoneNumber) || pnDigits(jid) || (isLid(jid) ? lidToPnMap.get(lidKey(jid)) : undefined);
    const lid = isLid(jid) ? lidKey(jid) : pn ? pnToLid(pn) : undefined;
    const superAdmin = !!p.isSuperAdmin || p.type === "superadmin";
    return {
      jid,
      lid,
      pn: pn || undefined,
      pnJid: pn ? pnToJid(pn) : undefined,
      isAdmin: superAdmin || !!p.isAdmin || p.type === "admin",
      isSuperAdmin: superAdmin,
    };
  });
}

export async function getGroupParticipantsPn(client: WaClient, groupJid: string): Promise<ParticipantPn[]> {
  const meta = await getGroupMetadata(client, groupJid);
  if (!meta) return [];
  learnFromGroupMetadata(meta);
  return mapParticipants(meta.participants);
}

export async function resolveMentionsToPn(
  client: WaClient,
  jids: Array<string | null | undefined>,
  chat?: string | null,
): Promise<string[]> {
  const out: string[] = [];
  for (const j of jids) {
    const pn = await resolvePn(client, j, chat);
    if (pn && !out.includes(pn)) out.push(pn);
  }
  return out;
}