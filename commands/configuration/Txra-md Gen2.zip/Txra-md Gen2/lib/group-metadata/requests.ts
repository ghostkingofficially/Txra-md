function getGroupApi(client: any): any {
  if (!client?.group) throw new Error("The group API is not available.");
  return client.group;
}

export async function listJoinRequests(client: any, groupJid: string): Promise<any[]> {
  const group = getGroupApi(client);
  const method = group.pendingMembers || group.pendingJoinRequests || group.listJoinRequests || group.joinRequests;
  if (typeof method !== "function") throw new Error("The group join-request API is not available.");
  const result = await method.call(group, groupJid);
  return Array.isArray(result) ? result : result?.requests ?? result?.pending ?? result?.members ?? [];
}

async function updateRequests(client: any, groupJid: string, jids: string[], action: "approve" | "reject"): Promise<any> {
  const group = getGroupApi(client);
  const names = action === "approve"
    ? ["approveJoinRequests", "approveRequests", "approvePendingMembers"]
    : ["rejectJoinRequests", "rejectRequests", "rejectPendingMembers"];
  const method = names.map((name) => group[name]).find((value) => typeof value === "function");
  if (typeof method !== "function") throw new Error(`The group ${action} request API is not available.`);
  return method.call(group, groupJid, jids);
}

export const approveJoinRequests = (client: any, groupJid: string, jids: string[]) => updateRequests(client, groupJid, jids, "approve");
export const rejectJoinRequests = (client: any, groupJid: string, jids: string[]) => updateRequests(client, groupJid, jids, "reject");