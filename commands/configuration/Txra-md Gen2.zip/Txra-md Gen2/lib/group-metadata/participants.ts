import { getGroupMetadata, invalidateGroupMemo } from "./index.ts";

function toParticipantJid(input: string): string {
  const value = String(input ?? "").trim();
  if (value.includes("@")) return value;
  const digits = value.replace(/\D/g, "");
  return digits ? `${digits}@s.whatsapp.net` : value;
}

async function updateParticipants(client: any, groupJid: string, action: string, jids: string[]): Promise<any> {
  const group = client?.group;
  const method = group?.participantsUpdate || group?.updateParticipants || group?.groupParticipantsUpdate;
  if (typeof method !== "function") throw new Error("The group participant API is not available.");
  const result = await method.call(group, groupJid, jids, action);
  const values = Array.isArray(result) ? result : result?.results ?? result?.participants ?? [];
  const failed = values.filter((item: any) => item?.status === "error" || item?.error || item?.success === false).map((item: any) => item?.jid || item?.id || item);
  const ok = failed.length ? jids.filter((jid) => !failed.includes(jid)) : jids;
  invalidateGroupMemo(groupJid);
  return { ok, failed, raw: result };
}

export async function addMembers(client: any, groupJid: string, jids: string[]): Promise<any> {
  return updateParticipants(client, groupJid, "add", jids.map(toParticipantJid));
}

export async function kickMembers(client: any, groupJid: string, jids: string[]): Promise<any> {
  return updateParticipants(client, groupJid, "remove", jids.map(toParticipantJid));
}

export async function promoteMembers(client: any, groupJid: string, jids: string[]): Promise<any> {
  return updateParticipants(client, groupJid, "promote", jids.map(toParticipantJid));
}

export async function demoteMembers(client: any, groupJid: string, jids: string[]): Promise<any> {
  return updateParticipants(client, groupJid, "demote", jids.map(toParticipantJid));
}

export function formatParticipantSummary(result: any): string {
  const ok = Array.isArray(result?.ok) ? result.ok : [];
  const failed = Array.isArray(result?.failed) ? result.failed : [];
  const lines = [`Successful: ${ok.length}`, `Failed: ${failed.length}`];
  if (failed.length) lines.push(`Failed targets: ${failed.join(", ")}`);
  return lines.join("\n");
}

export { toParticipantJid };
export { getGroupMetadata };