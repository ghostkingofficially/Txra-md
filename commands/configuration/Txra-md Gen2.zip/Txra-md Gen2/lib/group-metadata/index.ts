import type { WaClient } from "zapo-js";
import { log } from "../../connector/logger/index-logging.ts";

const DEFAULT_TTL_MS = 60 * 60 * 1000;

export interface GroupParticipant {
  jid?: string;              // LID or PN (JID primary)
  phoneNumber?: string;      // PN format @s.whatsapp.net
  type?: string;             // "participant" | "admin" | "superadmin"
  isAdmin?: boolean;
  isSuperAdmin?: boolean;
}

export interface GroupMetadata {
  jid: string;
  subject: string;
  size?: number;
  creation?: number;
  owner?: string;
  ownerPhoneNumber?: string;
  desc?: string;
  descId?: string;
  restrict?: boolean;
  announce?: boolean;
  ephemeral?: number;
  participants: GroupParticipant[];
  [key: string]: any;
}

interface CachedMetadata {
  data: GroupMetadata;
  cachedAt: number;
  index?: Map<string, GroupParticipant>;
}

function normalizeJidUser(jid?: string | null): string {
  if (!jid) return "";
  return jid.split("@")[0].split(":")[0];
}

function buildIndex(meta: GroupMetadata): Map<string, GroupParticipant> {
  const idx = new Map<string, GroupParticipant>();
  for (const p of meta.participants ?? []) {
    if (p.jid) idx.set(p.jid, p);
    if (p.phoneNumber) idx.set(p.phoneNumber, p);
  }
  return idx;
}

const cache: Map<string, CachedMetadata> = ((globalThis as any).__botGroupMetaCache ??= new Map());
const pending: Map<string, Promise<GroupMetadata | null>> = ((globalThis as any).__botGroupMetaPending ??= new Map());


export function getCachedGroupName(groupJid: string): string | undefined {
  return cache.get(groupJid)?.data?.subject;
}

export function getGroupName(groupJid: string): string {
  return cache.get(groupJid)?.data?.subject ?? groupJid.split("@")[0];
}

export function setGroupName(groupJid: string, name: string): void {
  const cached = cache.get(groupJid);
  if (cached) cached.data.subject = name;
}

export function invalidateGroupMemo(groupJid: string): void {
  cache.delete(groupJid);
}

export function clearGroupMemo(): void {
  cache.clear();
  pending.clear();
}


export async function getGroupMetadata(
  client: WaClient,
  groupJid: string,
  options: { ttlMs?: number; force?: boolean } = {},
): Promise<GroupMetadata | null> {
  if (!groupJid?.endsWith("@g.us")) return null;

  const ttl = options.ttlMs ?? DEFAULT_TTL_MS;
  const now = Date.now();

  if (!options.force) {
    const cached = cache.get(groupJid);
    if (cached) {
      if (now - cached.cachedAt >= ttl) {
             void getGroupMetadata(client, groupJid, { force: true });
      }
      return cached.data;
    }
  }

  const inFlight = pending.get(groupJid);
  if (inFlight) return inFlight;

  const task = (async (): Promise<GroupMetadata | null> => {
    try {
      const meta = await (client as any).group.queryGroupMetadata(groupJid);
      if (meta) {
        cache.set(groupJid, {
          data: meta as GroupMetadata,
          cachedAt: Date.now(),
          index: buildIndex(meta as GroupMetadata),
        });
      }
      return (meta as GroupMetadata) ?? null;
    } catch (err) {
      log.warn(
        `Gagal fetch metadata ${groupJid}: ${err instanceof Error ? err.message : err}`,
      );
      const stale = cache.get(groupJid);
      return stale?.data ?? null;
    } finally {
      pending.delete(groupJid);
    }
  })();

  pending.set(groupJid, task);
  return task;
}

export function peekGroupMetadata(groupJid: string): GroupMetadata | undefined {
  return cache.get(groupJid)?.data;
}

export function warmGroupMetadata(client: WaClient, groupJid: string): void {
  if (cache.has(groupJid)) return;
  void getGroupMetadata(client, groupJid);
}


export function getCachedParticipants(groupJid: string): GroupParticipant[] | null {
  const cached = cache.get(groupJid);
  if (!cached) return null;
  return cached.data.participants ?? [];
}

export function findParticipant(
  groupJid: string,
  ...candidates: (string | undefined | null)[]
): GroupParticipant | null | undefined {
  const cached = cache.get(groupJid);
  if (!cached) return undefined;

  const fullJids = candidates.filter(Boolean) as string[];
  if (fullJids.length === 0) return null;

    const idx = (cached.index ??= buildIndex(cached.data));
  for (const jid of fullJids) {
    const p = idx.get(jid);
    if (p) return p;
  }

    const userParts = fullJids.map(normalizeJidUser).filter(Boolean);
  if (userParts.length === 0) return null;

  for (const p of cached.data.participants ?? []) {
    const pUser = normalizeJidUser(p.jid);
    const pPn = normalizeJidUser(p.phoneNumber);

    for (const u of userParts) {
      if ((pUser && pUser === u) || (pPn && pPn === u)) {
        return p;
      }
    }
  }

  return null;
}

export function getCachedAdminStatus(
  groupJid: string,
  ...candidates: (string | undefined | null)[]
): "admin" | "superadmin" | null | undefined {
  const p = findParticipant(groupJid, ...candidates);
  if (p === undefined) return undefined;
  if (p === null) return null;
  if (p.isSuperAdmin) return "superadmin";
  if (p.isAdmin) return "admin";
  return null;
}

export async function isAdmin(
  client: WaClient,
  groupJid: string,
  ...candidates: (string | undefined | null)[]
): Promise<boolean> {
  let status = getCachedAdminStatus(groupJid, ...candidates);

  if (status === undefined) {
    await getGroupMetadata(client, groupJid);
    status = getCachedAdminStatus(groupJid, ...candidates);
  }

  return status === "admin" || status === "superadmin";
}

export async function isBotAdmin(
  client: WaClient,
  groupJid: string,
): Promise<boolean> {
  try {
    const creds = (client as any).getCredentials?.() ?? {};
    const meJid = creds.meJid ?? "";
    const meLid = creds.meLid ?? "";
    return await isAdmin(client, groupJid, meJid, meLid);
  } catch {
    return false;
  }
}

export function getGroupAdmins(groupJid: string): GroupParticipant[] {
  const cached = cache.get(groupJid);
  if (!cached) return [];
  return (cached.data.participants ?? []).filter((p) => p.isAdmin || p.isSuperAdmin);
}

export function getGroupSize(groupJid: string): number {
  return cache.get(groupJid)?.data.participants?.length ?? 0;
}
