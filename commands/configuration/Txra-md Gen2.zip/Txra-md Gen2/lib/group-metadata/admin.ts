function groupApi(client: any): any {
  if (!client?.group) throw new Error("The group API is not available.");
  return client.group;
}

async function callGroup(client: any, names: string[], groupJid: string, value: any): Promise<any> {
  const group = groupApi(client);
  const method = names.map((name) => group[name]).find((candidate) => typeof candidate === "function");
  if (typeof method !== "function") throw new Error(`The group setting API is not available: ${names.join(", ")}`);
  return method.call(group, groupJid, value);
}

export const setGroupAnnounce = (client: any, groupJid: string, value: boolean) => callGroup(client, ["setAnnouncement", "setAnnounce", "updateAnnouncement"], groupJid, value);
export const setGroupRestrict = (client: any, groupJid: string, value: boolean) => callGroup(client, ["setRestrict", "setGroupRestrict", "updateRestrict"], groupJid, value);
export const setMemberAddMode = (client: any, groupJid: string, value: boolean) => callGroup(client, ["setMemberAddMode", "setMembersCanAddMemberMode", "updateMemberAddMode"], groupJid, value);
export const setMemberLinkMode = (client: any, groupJid: string, value: boolean) => callGroup(client, ["setMemberLinkMode", "setMembersCanInviteMode", "updateMemberLinkMode"], groupJid, value);
export const setGroupPicture = (client: any, groupJid: string, bytes: Uint8Array) => callGroup(client, ["setPicture", "setProfilePicture", "updatePicture"], groupJid, bytes);
export const setGroupDescription = (client: any, groupJid: string, value: string) => callGroup(client, ["setDescription", "setGroupDescription", "updateDescription"], groupJid, value);
export const setGroupSubject = (client: any, groupJid: string, value: string) => callGroup(client, ["setSubject", "setGroupSubject", "updateSubject"], groupJid, value);