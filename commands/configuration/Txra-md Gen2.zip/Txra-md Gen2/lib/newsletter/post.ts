import type { WaClient } from "zapo-js";
import { linkToJid } from "./converter.ts";

// Link postingan: https://whatsapp.com/channel/<kode>/<serverId>
const POST_RE = /whatsapp\.com\/channel\/([A-Za-z0-9_-]+)(?:\/(\d+))?/i;

export function parseChannelPostUrl(url?: string | null): { invite: string; serverId: string | null } | null {
  const m = POST_RE.exec(String(url ?? ""));
  return m ? { invite: m[1], serverId: m[2] ?? null } : null;
}

const DEFAULT_EMOJIS = ["🔥", "❤️", "😍", "👍", "😂", "🥳", "💯", "✨"];

export function pickRandomEmoji(pool?: string[]): string {
  const p = pool?.length ? pool : DEFAULT_EMOJIS;
  return p[Math.floor(Math.random() * p.length)];
}

/**
 * React ke 1 postingan saluran. serverId dicoba sebagai string lalu number;
 * kalau errornya soal belum follow, follow dulu lalu coba lagi.
 */
export async function reactToChannelPost(
  client: WaClient,
  { newsletterJid, serverId, emoji }: { newsletterJid: string; serverId: string | number; emoji: string },
) {
  const nl = (client as any).newsletter;
  const variants = [...new Set([String(serverId), Number(serverId)])].filter((v) => !Number.isNaN(v));
  let lastErr: unknown;
  let triedFollow = false;

  for (const v of variants) {
    try {
      return await nl.react({ newsletterJid, parentMessageServerId: v, reactionCode: emoji });
    } catch (err) {
      lastErr = err;
      if (!triedFollow && /follow|subscri|member/i.test((err as Error)?.message ?? "")) {
        triedFollow = true;
        await nl.follow(newsletterJid).catch(() => {});
      }
    }
  }
  throw lastErr ?? new Error("Gagal react ke postingan saluran");
}

/** Link postingan → jid saluran + serverId (satu langkah). */
export async function resolvePostLink(client: WaClient, url: string) {
  const p = parseChannelPostUrl(url);
  if (!p) return null;
  const jid = await linkToJid(client, p.invite);
  return jid ? { newsletterJid: jid, serverId: p.serverId } : null;
}
