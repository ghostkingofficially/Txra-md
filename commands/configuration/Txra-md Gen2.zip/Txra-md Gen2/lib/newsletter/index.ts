import type { WaClient } from "zapo-js";
import { toSquareJpeg } from "../func/image.ts";
import { getConfig } from "../../connector/config.ts";
import { metaJid, parseChannelRef, type ChannelRef } from "./converter.ts";

export * from "./converter.ts";
export * from "./metadata-mex.ts";
export * from "./post.ts";

/**
 * Wrapper dasar fungsi saluran (newsletter) di atas `client.newsletter` zapo-js.
 * Semua operasi admin lewat assertChannelAdmin() supaya error-nya jelas.
 */

const META_TTL_MS = 5 * 60 * 1000;
const metaCache: Map<string, { at: number; data: any }> =
  ((globalThis as any).__botNewsletterMeta ??= new Map());

/** Urutan: ref eksplisit → saluran tempat command diketik → config.channel.id */
export async function resolveTargetJid(
  client: WaClient,
  m: { isNewsletter?: boolean; chat?: string },
  ref?: string,
): Promise<string | null> {
  const p = parseChannelRef(ref);
  if (p?.jid) return p.jid;
  if (p?.invite) return metaJid(await getChannelMeta(client, p)) ?? null;
  if (m.isNewsletter && m.chat) return m.chat;
  return ((getConfig() as any).channel?.id as string) || null;
}

// ─── Metadata ─────────────────────────────────────────────────

export async function getChannelMeta(client: WaClient, ref: ChannelRef, force = false): Promise<any> {
  const key = ref.jid ?? `invite:${ref.invite}`;
  const hit = metaCache.get(key);
  if (!force && hit && Date.now() - hit.at < META_TTL_MS) return hit.data;

  const nl = (client as any).newsletter;
  const data = ref.jid ? await nl.fetch(ref.jid) : await nl.fetchByInvite(ref.invite);
  const entry = { at: Date.now(), data };
  metaCache.set(key, entry);
  const j = metaJid(data);
  if (j) metaCache.set(j, entry);
  return data;
}

export function invalidateChannelMeta(jid: string): void {
  metaCache.delete(jid);
}

// ─── Admin ────────────────────────────────────────────────────

export async function assertChannelAdmin(client: WaClient, jid: string): Promise<void> {
  const nl = (client as any).newsletter;
  try {
    const caps = await nl.fetchAdminCapabilities(jid);
    if (caps && (caps.size ?? caps.length ?? 0) > 0) return;
  } catch { /* lanjut ke fallback */ }
  try {
    await nl.fetchAdminInfo(jid);
    return;
  } catch { /* bukan admin */ }
  throw new Error("akun bot bukan admin/owner saluran ini");
}

export async function setChannelName(client: WaClient, jid: string, name: string) {
  await assertChannelAdmin(client, jid);
  const res = await (client as any).newsletter.update(jid, { name });
  invalidateChannelMeta(jid);
  return res;
}

export async function setChannelDescription(client: WaClient, jid: string, description: string) {
  await assertChannelAdmin(client, jid);
  const res = await (client as any).newsletter.update(jid, { description });
  invalidateChannelMeta(jid);
  return res;
}

/** Foto di-crop ke persegi 640x640 JPEG lewat ffmpeg (kalau gagal, bytes asli dipakai). */
export async function normalizePicture(bytes: Uint8Array): Promise<Uint8Array> {
  return await toSquareJpeg(bytes, 640, 85);
}

function pictureSig(meta: any): string {
  const cand = ["picture", "thread_metadata.picture", "threadMetadata.picture", "pictureId", "preview", "thread_metadata.preview"];
  return JSON.stringify(cand.map((p) => {
    let cur = meta;
    for (const k of p.split(".")) cur = cur?.[k];
    return cur ?? null;
  }));
}

/**
 * Ganti foto saluran. Server bisa menerima request tapi mengabaikan format yang salah,
 * jadi hasilnya diverifikasi dengan membandingkan metadata sebelum/sesudah.
 */
export async function setChannelPicture(client: WaClient, jid: string, bytes: Uint8Array) {
  await assertChannelAdmin(client, jid);
  const picture = await normalizePicture(bytes);
  const nl = (client as any).newsletter;
  const before = pictureSig(await nl.fetch(jid).catch(() => null));

  const formats: [string, () => any][] = [
    ["bytes", () => picture],
    ["base64", () => Buffer.from(picture).toString("base64")],
    ["buffer", () => Buffer.from(picture)],
  ];
  let lastErr: unknown;
  for (const [label, make] of formats) {
    try {
      await nl.update(jid, { picture: make() });
      await new Promise((r) => setTimeout(r, 1500));
      invalidateChannelMeta(jid);
      const after = pictureSig(await nl.fetch(jid).catch(() => null));
      if (after !== before) return { changed: true, format: label };
    } catch (e) {
      lastErr = e;
    }
  }
  if (lastErr) throw lastErr;
  return { changed: false, format: "semua format diterima server tapi metadata foto tidak berubah" };
}

// ─── Follow / mute ────────────────────────────────────────────

export const followChannel = (c: WaClient, jid: string) => (c as any).newsletter.follow(jid);
export const unfollowChannel = (c: WaClient, jid: string) => (c as any).newsletter.unfollow(jid);
export const muteChannel = (c: WaClient, jid: string, mute: boolean) =>
  (c as any).newsletter.mute({ newsletterJid: jid, mute });
export const listFollowedChannels = (c: WaClient) => (c as any).newsletter.listSubscribed();

// ─── Posting ──────────────────────────────────────────────────

export async function sendToChannel(client: WaClient, jid: string, content: any) {
  await assertChannelAdmin(client, jid);
  return (client as any).newsletter.send(jid, content);
}
export const editChannelMessage = (c: WaClient, jid: string, parentId: string, content: any) =>
  (c as any).newsletter.editMessage(jid, parentId, content);
export const revokeChannelMessage = (c: WaClient, jid: string, originalMessageId: string) =>
  (c as any).newsletter.revoke({ newsletterJid: jid, originalMessageId });

// ─── Admin lanjutan (belum dipasang ke command) ───────────────

export const fetchChannelFollowers = (c: WaClient, jid: string, options?: any) =>
  (c as any).newsletter.fetchFollowers(jid, options);
export const fetchChannelMessages = (c: WaClient, jid: string, count = 20) =>
  (c as any).newsletter.fetchMessages({ newsletterJid: jid, count });
