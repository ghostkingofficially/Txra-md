import { isNewsletterJid } from "../serialize/jid.ts";

/**
 * Helper murni (tanpa client) + konversi link ⇄ id saluran.
 * Tidak mengimpor index.ts supaya tidak circular.
 */

export interface ChannelRef {
  jid?: string;
  invite?: string;
}

export const CHANNEL_LINK_BASE = "https://whatsapp.com/channel/";

export function metaJid(meta: any): string | undefined {
  const j = meta?.jid ?? meta?.id ?? meta?.key ?? meta?.newsletterJid;
  return typeof j === "string" && isNewsletterJid(j) ? j : undefined;
}

/** Ambil nilai pertama yang ada dari beberapa kemungkinan nama field (shape metadata belum diverifikasi). */
export function pick(obj: any, paths: string[]): any {
  for (const p of paths) {
    let cur = obj;
    for (const k of p.split(".")) cur = cur?.[k];
    if (cur === undefined || cur === null || cur === "") continue;
    return typeof cur === "object" && cur.text !== undefined ? cur.text : cur;
  }
  return undefined;
}

/** Terima: 123@newsletter | 15+ digit angka | link whatsapp.com/channel/<kode> | kode invite */
export function parseChannelRef(input?: string | null): ChannelRef | null {
  const s = String(input ?? "").trim();
  if (!s) return null;
  if (isNewsletterJid(s)) return { jid: s };
  const link = s.match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i);
  if (link) return { invite: link[1] };
  if (/^\d{15,}$/.test(s)) return { jid: `${s}@newsletter` };
  if (/^[A-Za-z0-9_-]{18,}$/.test(s)) return { invite: s };
  return null;
}

/** "<ref> | nilai" → { ref, value }. Kalau bagian kiri bukan ref saluran, seluruhnya dianggap nilai. */
export function splitTarget(input: string): { ref?: string; value: string } {
  const i = input.indexOf("|");
  if (i === -1) return { value: input.trim() };
  const left = input.slice(0, i).trim();
  if (!parseChannelRef(left)) return { value: input.trim() };
  return { ref: left, value: input.slice(i + 1).trim() };
}

export function buildChannelLink(invite?: string | null): string | undefined {
  const code = extractInvite(invite);
  return code ? `${CHANNEL_LINK_BASE}${code}` : undefined;
}

/** Kode invite dari link atau kode mentah. */
export function extractInvite(input?: string | null): string | undefined {
  const s = String(input ?? "").trim();
  if (!s) return undefined;
  const m = s.match(/whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i);
  if (m) return m[1];
  return /^[A-Za-z0-9_-]{18,}$/.test(s) && !/^\d+$/.test(s) ? s : undefined;
}

export function inviteFromMeta(meta: any): string | undefined {
  return extractInvite(
    pick(meta, ["invite", "inviteCode", "invite_code", "thread_metadata.invite", "threadMetadata.invite"]),
  );
}

/** link / kode invite → jid saluran (butuh 1 request ke server) */
export async function linkToJid(client: any, linkOrCode: string): Promise<string | undefined> {
  const p = parseChannelRef(linkOrCode);
  if (p?.jid) return p.jid;
  if (!p?.invite) return undefined;
  const meta = await client.newsletter.fetchByInvite(p.invite);
  return metaJid(meta);
}

/** jid saluran → link (butuh metadata penuh yang memuat kode invite) */
export async function jidToLink(client: any, jid: string): Promise<string | undefined> {
  const meta = await client.newsletter.fetch(jid);
  return buildChannelLink(inviteFromMeta(meta));
}
