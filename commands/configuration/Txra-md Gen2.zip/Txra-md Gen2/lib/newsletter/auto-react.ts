import type { WaClient } from "zapo-js";
import { getConfig } from "../../connector/config.ts";
import { log } from "../../connector/logger/index-logging.ts";
import { linkToJid } from "./converter.ts";
import { pickRandomEmoji, reactToChannelPost } from "./post.ts";

/**
 * Auto-react ke postingan baru di saluran bot.
 * Aktif kalau config.channel.autoReact.enabled = true. Target: channel.id, atau channel.link.
 * Bentuk event 'newsletter' belum terdokumentasi → beberapa nama field dicoba,
 * dan event mentah pertama dilog sekali supaya mudah disesuaikan.
 */
let loggedRaw = false;

function extract(event: any) {
  return {
    jid: event?.newsletterJid ?? event?.jid ?? event?.chat ?? event?.newsletter?.jid ?? null,
    serverId:
      event?.serverId ?? event?.messageServerId ?? event?.message?.serverId ?? event?.message?.id ?? event?.id ?? null,
  };
}

export function registerChannelAutoReact(client: WaClient): void {
  const ch = (getConfig() as any).channel ?? {};
  const cfg = ch.autoReact;
  if (!cfg?.enabled) return;

  let target: string | null = ch.id || null;

  const resolveTarget = async () => {
    if (!target && ch.link) target = (await linkToJid(client, ch.link)) ?? null;
    return target;
  };

  client.on("newsletter" as any, async (event: any) => {
    if (!loggedRaw) {
      loggedRaw = true;
      try { log.info(`[auto-react] bentuk event 'newsletter' pertama:\n${JSON.stringify(event, null, 2).slice(0, 1500)}`); } catch { /* circular */ }
    }
    const { jid, serverId } = extract(event);
    if (!target || jid !== target) return;
    if (!serverId) return log.warn("[auto-react] activity tanpa serverId, cek bentuk event di log");
    try {
      const emoji = pickRandomEmoji(cfg.emojis);
      await reactToChannelPost(client, { newsletterJid: target, serverId, emoji });
      log.info(`[auto-react] ${emoji} ke post ${serverId}`);
    } catch (err) {
      log.error(`[auto-react] gagal: ${err instanceof Error ? err.message : err}`);
    }
  });

  client.on("connection" as any, async (ev: any) => {
    if (ev?.status !== "open") return;
    try {
      const jid = await resolveTarget();
      if (jid) await (client as any).newsletter.follow(jid).catch(() => {});
    } catch (err) {
      log.error(`[auto-react] gagal resolve saluran: ${err instanceof Error ? err.message : err}`);
    }
  });
}
