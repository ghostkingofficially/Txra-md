import type { WaClient } from "zapo-js";
import { buildChannelLink, inviteFromMeta, metaJid, pick } from "./converter.ts";

/**
 * Metadata saluran yang sudah dinormalisasi + pencarian saluran yang diadmin akun bot.
 * Nama file "mex" karena data saluran di WhatsApp diambil lewat query MEX (GraphQL);
 * zapo membungkusnya di client.newsletter.*.
 */

export interface ChannelInfo {
  jid?: string;
  name?: string;
  description?: string;
  invite?: string;
  link?: string;
  role?: string;      // OWNER | ADMIN | SUBSCRIBER | GUEST (huruf besar)
  followers?: number | string;
  verified?: string | boolean;
  raw?: any;
}

const ADMIN_ROLES = new Set(["OWNER", "ADMIN", "CREATOR", "SUPERADMIN"]);

export function isAdminRole(role?: string): boolean {
  return !!role && ADMIN_ROLES.has(role.toUpperCase());
}

export function normalizeChannel(meta: any): ChannelInfo {
  const invite = inviteFromMeta(meta);
  const role = pick(meta, ["viewerRole", "role", "viewer_metadata.role", "viewerMetadata.role", "membership"]);
  return {
    jid: metaJid(meta),
    name: strOrUndef(pick(meta, ["name", "thread_metadata.name", "threadMetadata.name", "title"])),
    description: strOrUndef(pick(meta, ["description", "thread_metadata.description", "threadMetadata.description", "desc"])),
    invite,
    link: buildChannelLink(invite),
    role: role ? String(role).toUpperCase() : undefined,
    followers: pick(meta, ["subscribersCount", "subscribers", "followersCount", "thread_metadata.subscribers_count"]),
    verified: pick(meta, ["verification", "thread_metadata.verification", "verified"]),
    raw: meta,
  };
}

function strOrUndef(v: any): string | undefined {
  return v === undefined || v === null ? undefined : String(v);
}

/** Semua saluran yang diikuti akun bot (sudah dinormalisasi). */
export async function listSubscribedChannels(client: WaClient): Promise<ChannelInfo[]> {
  const list: any[] = [...(((await (client as any).newsletter.listSubscribed()) as any[]) ?? [])];
  return list.map(normalizeChannel).filter((c) => c.jid);
}

async function inBatches<T, R>(items: T[], size: number, fn: (x: T) => Promise<R>): Promise<R[]> {
  const out: R[] = [];
  for (let i = 0; i < items.length; i += size) {
    out.push(...(await Promise.all(items.slice(i, i + size).map(fn))));
  }
  return out;
}

async function hasAdminCapabilities(client: WaClient, jid: string): Promise<boolean> {
  try {
    const caps = await (client as any).newsletter.fetchAdminCapabilities(jid);
    return !!caps && (caps.size ?? caps.length ?? 0) > 0;
  } catch {
    return false;
  }
}

export interface AdminChannelsResult {
  channels: ChannelInfo[];
  /** "role" = dari field role di metadata, "capabilities" = dicek satu-satu karena role tidak terbaca */
  method: "role" | "capabilities";
  totalSubscribed: number;
}

/**
 * Saluran yang diadmin/dimiliki akun bot: id, nama, link.
 * Link dilengkapi lewat fetch(jid) kalau metadata ringkas tidak memuat kode invite.
 */
export async function listAdminChannels(client: WaClient): Promise<AdminChannelsResult> {
  const subs = await listSubscribedChannels(client);
  let admin: ChannelInfo[];
  let method: AdminChannelsResult["method"];

  if (subs.some((c) => c.role)) {
    admin = subs.filter((c) => isAdminRole(c.role));
    method = "role";
  } else {
    const flags = await inBatches(subs, 4, (c) => hasAdminCapabilities(client, c.jid!));
    admin = subs.filter((_, i) => flags[i]);
    method = "capabilities";
  }

  admin = await inBatches(admin, 4, async (c) => {
    if (c.link && c.name) return c;
    try {
      const full = normalizeChannel(await (client as any).newsletter.fetch(c.jid));
      return { ...c, ...Object.fromEntries(Object.entries(full).filter(([, v]) => v !== undefined)) } as ChannelInfo;
    } catch {
      return c;
    }
  });

  return { channels: admin, method, totalSubscribed: subs.length };
}
