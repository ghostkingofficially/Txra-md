// lib/func/lowpriority.ts — turunkan prioritas CPU proses anak (ffmpeg) supaya tidak menyaingi bot saat memproses pesan.
// Gagal (OS tidak mengizinkan / Windows) → diabaikan begitu saja.
import { setPriority } from "node:os";

const NICE = Math.min(19, Math.max(0, Number(process.env.FFMPEG_NICE ?? 10)));

export function lowPriority(pid: number | undefined): void {
  if (!pid || !NICE) return;
  try { setPriority(pid, NICE); } catch { /* abaikan */ }
}
