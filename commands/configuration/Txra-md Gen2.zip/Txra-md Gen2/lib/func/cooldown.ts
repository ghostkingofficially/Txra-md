/** Cooldown per command + anti-flood per user (in-memory). */

const perUserCommand: Map<string, number> = ((globalThis as any).__botCooldown ??= new Map());
const perUserFlood: Map<string, { hits: number[]; mutedUntil: number }> =
  ((globalThis as any).__botFlood ??= new Map());

export function checkCooldown(userId: string, command: string, cooldownMs = 0) {
  if (!cooldownMs || cooldownMs <= 0) return { onCooldown: false, remainingMs: 0 };
  const key = `${userId}:${command}`;
  const now = Date.now();
  const last = perUserCommand.get(key) ?? 0;
  if (now - last < cooldownMs) return { onCooldown: true, remainingMs: cooldownMs - (now - last) };

  if (perUserCommand.size > 5000) perUserCommand.clear();
  perUserCommand.set(key, now);
  return { onCooldown: false, remainingMs: 0 };
}

export interface FloodOptions {
  max?: number;
  windowMs?: number;
  muteMs?: number;
}

export function checkFlood(userId: string, { max = 5, windowMs = 10_000, muteMs = 30_000 }: FloodOptions = {}) {
  const now = Date.now();
  const state = perUserFlood.get(userId) ?? { hits: [], mutedUntil: 0 };
  if (state.mutedUntil > now) return { flooded: true, remainingMs: state.mutedUntil - now };

  state.hits = state.hits.filter((t) => now - t < windowMs);
  state.hits.push(now);
  if (state.hits.length > max) {
    state.mutedUntil = now + muteMs;
    state.hits = [];
    perUserFlood.set(userId, state);
    return { flooded: true, remainingMs: muteMs };
  }
  if (perUserFlood.size > 5000) perUserFlood.clear();
  perUserFlood.set(userId, state);
  return { flooded: false, remainingMs: 0 };
}
