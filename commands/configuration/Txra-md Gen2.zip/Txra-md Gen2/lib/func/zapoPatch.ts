// lib/func/zapoPatch.ts — tambalan zapo-js. Jalankan SEKALI setelah `bun install` / setiap zapo-js di-install ulang:
//   bun run patch        (= bun scripts/patch.ts)    lalu restart bot.
// Tidak bergantung pada runtime (hanya node:fs + process), jadi jalan di Bun, Node, maupun Deno.
//
// Tambalan 1 — customNodes MENIMPA node bawaan yang tag-nya sama.
//   Masalah: zapo stok membangun node <biz> sendiri untuk pesan interaktif, lalu customNodes hanya di-push di belakangnya.
//   Untuk catalog (<biz native_flow_name="catalog_message"/>) hasilnya DUA node <biz> → stanza tidak valid → pesan
//   diterima server tanpa error tapi tidak pernah tampil. Padanan Baileys: additionalNodes yang menggantikan node bawaan.
//
// Tambalan 2 — pesan pembayaran (requestPaymentMessage dst.) dihitung sebagai type="text".
//   Masalah: resolveMessageTypeAttrFrom() tidak mengenal requestPaymentMessage, jadi jatuh ke default type="media"
//   TANPA mediatype → server meng-ack lalu membuang pesan diam-diam (preset 9 di .sfr tidak pernah muncul).
//   Baileys mengirimnya sebagai type="text"; tambalan ini menyamakannya.
import { readdir, readFile, realpath, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";

export interface PatchDef { name: string; marker: string; pattern: RegExp; replacement: string; files: string[] }

// ── tambalan 1: customNodes ──
export const MARKER = "/* OVERRIDE_CUSTOM_NODES_PATCH */";

const CUSTOM_NODES: PatchDef = {
  name: "customNodes",
  marker: MARKER,
  pattern: /if\s*\(\s*input\.customNodes\s*\)\s*\{\s*for\s*\(\s*const\s+node\s+of\s+input\.customNodes\s*\)\s*\{\s*content\.push\(\s*node\s*\);?\s*\}\s*\}/,
  replacement: `${MARKER}
    if (input.customNodes) {
        for (const node of input.customNodes) {
            if (!node || !node.tag) continue;
            const existingIndex = content.findIndex(item => item && item.tag === node.tag);
            if (existingIndex !== -1) {
                content[existingIndex] = node;
            } else {
                content.push(node);
            }
        }
    }`,
  files: ["dist/esm/transport/node/builders/message.js", "dist/transport/node/builders/message.js"],
};

// ── tambalan 2: pesan pembayaran = type="text" ──
export const PAYMENT_MARKER = "/* PAYMENT_TEXT_TYPE_PATCH */";

const PAYMENT_TYPE: PatchDef = {
  name: "payment-text-type",
  marker: PAYMENT_MARKER,
  // urutan ini hanya ada di resolveMessageTypeAttrFrom (cabang yang mengembalikan TEXT)
  pattern: /msg\.interactiveMessage\s*\|\|\s*msg\.keepInChatMessage\s*\|\|/,
  replacement:
    `msg.interactiveMessage || ${PAYMENT_MARKER} msg.requestPaymentMessage || msg.sendPaymentMessage || ` +
    `msg.declinePaymentRequestMessage || msg.cancelPaymentRequestMessage || msg.keepInChatMessage ||`,
  files: ["dist/esm/message/encode/content.js", "dist/message/encode/content.js"],
};

export type PatchState = "patched" | "already" | "no-match" | "missing";
export interface PatchResult { file: string; state: PatchState }

/** Semua salinan zapo-js di node_modules: layout biasa (Bun/npm) dan layout terisolasi (node_modules/.bun, node_modules/.deno). */
async function zapoRoots(root: string): Promise<string[]> {
  const roots = new Set<string>();
  const add = async (p: string) => {
    try { roots.add(await realpath(p)); } catch { /* tidak ada */ }
  };
  const nm = join(root, "node_modules");
  await add(join(nm, "zapo-js"));
  for (const store of [".bun", ".deno"]) {
    try {
      for (const name of await readdir(join(nm, store))) {
        if (name.startsWith("zapo-js@")) await add(join(nm, store, name, "node_modules", "zapo-js"));
      }
    } catch { /* layout ini tidak dipakai */ }
  }
  return [...roots];
}

async function targets(def: PatchDef, root: string): Promise<string[]> {
  const files: string[] = [];
  for (const r of await zapoRoots(root)) {
    for (const rel of def.files) {
      const f = join(r, rel);
      try { await stat(f); files.push(f); } catch { /* tidak ada */ }
    }
  }
  return files;
}

async function applyOne(def: PatchDef, root: string): Promise<PatchResult[]> {
  const files = await targets(def, root);
  if (!files.length) return [{ file: `node_modules/zapo-js (${def.name})`, state: "missing" }];
  const out: PatchResult[] = [];
  for (const file of files) {
    const src = await readFile(file, "utf8");
    if (src.includes(def.marker)) { out.push({ file, state: "already" }); continue; }
    if (!def.pattern.test(src)) { out.push({ file, state: "no-match" }); continue; }
    await writeFile(file, src.replace(def.pattern, def.replacement));
    out.push({ file, state: "patched" });
  }
  return out;
}

async function checkOne(def: PatchDef, root: string): Promise<{ state: "patched" | "unpatched" | "unknown"; files: string[] }> {
  const files = await targets(def, root);
  if (!files.length) return { state: "unknown", files };
  let all = true;
  for (const f of files) if (!(await readFile(f, "utf8")).includes(def.marker)) all = false;
  return { state: all ? "patched" : "unpatched", files };
}

/** Pasang SEMUA tambalan (customNodes + pesan pembayaran). Nama fungsi dipertahankan agar pemanggil lama tidak perlu diubah. */
export async function applyCustomNodesPatch(root = process.cwd()): Promise<PatchResult[]> {
  return [...(await applyOne(CUSTOM_NODES, root)), ...(await applyOne(PAYMENT_TYPE, root))];
}

/** Status tambalan customNodes — dipakai setthumblarge. */
export async function checkCustomNodesPatch(root = process.cwd()) {
  return await checkOne(CUSTOM_NODES, root);
}

/** Status tambalan pesan pembayaran (preset 9 .sfr). */
export async function checkPaymentTypePatch(root = process.cwd()) {
  return await checkOne(PAYMENT_TYPE, root);
}