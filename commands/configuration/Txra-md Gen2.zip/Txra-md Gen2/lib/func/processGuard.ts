import { log } from "../../connector/logger/index-logging.ts";

let installed = false;

const WINDOW_MS = 60_000;
const MAX_ERRORS_PER_WINDOW = 20;
const stamps: number[] = [];

const msgOf = (e: unknown): string => (e instanceof Error ? e.stack ?? e.message : String(e));

/**
 * Satu promise gagal tanpa .catch tidak lagi mematikan bot — cukup dicatat.
 * Pengaman: kalau error beruntun (>20 dalam semenit) berarti prosesnya sudah tidak sehat,
 * keluar dengan kode 1 supaya pm2 / loop restart bisa menyalakannya bersih.
 */
function record(kind: string, err: unknown): void {
  log.error(`${kind}: ${msgOf(err)}`);
  const now = Date.now();
  stamps.push(now);
  while (stamps.length && now - stamps[0] > WINDOW_MS) stamps.shift();
  if (stamps.length > MAX_ERRORS_PER_WINDOW) {
    log.error(`Terlalu banyak error beruntun (${stamps.length}/menit), bot dihentikan untuk restart bersih.`);
    process.exit(1);
  }
}

export function installProcessGuards(): void {
  if (installed) return;
  installed = true;
  process.on("unhandledRejection", (reason) => record("unhandledRejection", reason));
  process.on("uncaughtException", (err) => record("uncaughtException", err));
}
