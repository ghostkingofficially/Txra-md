/**
 * Parser balasan pesan rich/interactive → { name, id, raw }.
 * Selain respon native (tombol/list), mengenali juga balasan TEKS yang mengutip pesan rich
 * (user mengetik judul tombol/baris sambil reply) → dipetakan ke id tombolnya.
 */

export interface RichReply {
  name: string;
  id: string;
  raw: any;
}

const unwrapInteractive = (quoted: any) =>
  quoted?.interactiveMessage ?? quoted?.viewOnceMessage?.message?.interactiveMessage;

/** Cek cepat (murah) untuk gerbang awal message-upsert. */
export function hasQuotedInteractive(message: any): boolean {
  const quoted = message?.extendedTextMessage?.contextInfo?.quotedMessage;
  return !!unwrapInteractive(quoted);
}

export function readRichReply(message: any): RichReply | undefined {
  if (!message) return undefined;

  const tpl = message.templateButtonReplyMessage;
  if (tpl?.selectedId) {
    return { name: "template_button_reply", id: tpl.selectedId, raw: { selectedDisplayText: tpl.selectedDisplayText } };
  }

  const flow = message.interactiveResponseMessage?.nativeFlowResponseMessage;
  if (flow) {
    let params: any = {};
    try {
      params = flow.paramsJson ? JSON.parse(flow.paramsJson) : {};
    } catch { /* abaikan */ }
    const id = params.id ?? params.selected_row_id ?? params.row_id ?? "";
    if (id) return { name: flow.name ?? "native_flow", id, raw: params };
  }

  const btn = message.buttonsResponseMessage;
  if (btn?.selectedButtonId) return { name: "buttons_response", id: btn.selectedButtonId, raw: btn };

  const rowId = message.listResponseMessage?.singleSelectReply?.selectedRowId;
  if (rowId) return { name: "list_response", id: rowId, raw: message.listResponseMessage };

  const ext = message.extendedTextMessage;
  const buttons = unwrapInteractive(ext?.contextInfo?.quotedMessage)?.nativeFlowMessage?.buttons;
  if (ext?.text && Array.isArray(buttons)) {
    for (const b of buttons) {
      let params: any = {};
      try {
        params = JSON.parse(b.buttonParamsJson || "{}");
      } catch {
        continue;
      }
      if (params.id && params.display_text === ext.text) {
        return { name: "quoted_quick_reply", id: params.id, raw: params };
      }
      for (const section of params.sections ?? []) {
        for (const row of section.rows ?? []) {
          if (row.id && (row.title === ext.text || `${row.title}\n${row.description}` === ext.text)) {
            return { name: "quoted_single_select", id: row.id, raw: row };
          }
        }
      }
    }
  }
  return undefined;
}
