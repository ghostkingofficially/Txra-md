import { fileURLToPath } from "node:url";
import { readdirSync, statSync, watch, type FSWatcher } from "node:fs";
import { isAbsolute, join, relative, resolve, sep } from "node:path";
import { log } from "../../connector/logger/index-logging.ts";
import { loadCommands } from "../../helpers/handling-plugins.ts";
import { getSettings, loadSettings } from "../settings/botSettings.ts";

const PROJECT_ROOT = fileURLToPath(new URL("../../", import.meta.url));

export const IGNORED_SEGMENTS = new Set([
  "db",
  ".git",
  "node_modules",
  "tmp",
  "manual",
  ".vscode",
  ".idea",
  "native",
  "target",
  "temp",
  "memory",
  "tests",
  "scripts",
]);

export type ChangeKind = "command" | "core" | "ignored";

const isOutside = (rel: string) => rel === ".." || rel.startsWith(".." + sep) || isAbsolute(rel);

export function classifyPath(path: string, commandsAbs: string, root: string = PROJECT_ROOT): ChangeKind {
  const rel = relative(root, path);
  if (!rel || isOutside(rel)) return "ignored";
  if (rel.split(sep).some((segment) => IGNORED_SEGMENTS.has(segment) || segment.startsWith("."))) {
    return "ignored";
  }
  if (!/\.(ts|js|tsx|jsx)$/.test(path) || path.endsWith(".d.ts")) return "ignored";

  const relCommand = relative(commandsAbs, path);
  if (!isOutside(relCommand)) {
    return relCommand.split(sep).some((segment) => segment.startsWith("_")) ? "ignored" : "command";
  }
  return "core";
}

export interface AutoReloaderOptions {
  debounceMs?: number;
  onReload?: (result: { ok: boolean; total?: number; error?: string; changed: string[] }) => void;
  onCoreChange?: (files: string[]) => void;
}

interface ReloaderState {
  watchers: FSWatcher[];
  watchedPaths: Set<string>;
  running: boolean;
  debounceTimer: ReturnType<typeof setTimeout> | null;
  pendingCommands: Set<string>;
  pendingCore: Set<string>;
  commandsDir: string;
  commandsAbs: string;
  options: AutoReloaderOptions;
}

declare global {
  var __botAutoReloader: ReloaderState | undefined;
}

function state(): ReloaderState {
  return (globalThis.__botAutoReloader ??= {
    watchers: [],
    watchedPaths: new Set<string>(),
    running: false,
    debounceTimer: null,
    pendingCommands: new Set<string>(),
    pendingCore: new Set<string>(),
    commandsDir: "./commands",
    commandsAbs: resolve(PROJECT_ROOT, "commands"),
    options: {},
  });
}

const shortName = (path: string) => relative(PROJECT_ROOT, path).split(sep).join("/");

async function flush(s: ReloaderState): Promise<void> {
  const commands = [...s.pendingCommands];
  const core = [...s.pendingCore];
  s.pendingCommands.clear();
  s.pendingCore.clear();
  if (commands.length === 0 && core.length === 0) return;

  await loadSettings();
  if (!getSettings().autoReload.enabled) return;

  if (core.length) {
    if (s.options.onCoreChange) {
      s.options.onCoreChange(core);
    } else {
      const names = core.slice(0, 3).map(shortName).join(", ") + (core.length > 3 ? ` +${core.length - 3}` : "");
      log.warn(`[auto-reload] Shared file changed: ${names}. Command files can reload live; restart for shared modules.`);
    }
  }

  if (commands.length) {
    log.info(`[auto-reload] Reloading ${commands.length} changed command file(s)...`);
    try {
      const { total } = await loadCommands(s.commandsDir, { force: true });
      log.success(`[auto-reload] Reload complete: ${total} command(s) loaded.`);
      s.options.onReload?.({ ok: true, total, changed: commands });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      log.error(`[auto-reload] Reload failed: ${message}`);
      s.options.onReload?.({ ok: false, error: message, changed: commands });
    }
  }
}

function schedule(s: ReloaderState, kind: "command" | "core", path: string): void {
  (kind === "command" ? s.pendingCommands : s.pendingCore).add(path);
  if (s.debounceTimer) clearTimeout(s.debounceTimer);
  s.debounceTimer = setTimeout(() => {
    s.debounceTimer = null;
    void flush(s);
  }, s.options.debounceMs ?? 400);
}

function shouldIgnoreDirectory(path: string): boolean {
  const rel = relative(PROJECT_ROOT, path);
  if (!rel || isOutside(rel)) return false;
  return rel.split(sep).some((segment) => IGNORED_SEGMENTS.has(segment) || segment.startsWith("."));
}

function attachWatcher(s: ReloaderState, directory: string): void {
  if (s.watchedPaths.has(directory) || shouldIgnoreDirectory(directory)) return;

  let watcher: FSWatcher;
  try {
    watcher = watch(directory, { recursive: false }, (_event, filename) => {
      if (!filename || !s.running) return;
      const changedPath = join(directory, String(filename));

      try {
        if (statSync(changedPath).isDirectory()) {
          attachDirectoryTree(s, changedPath);
          return;
        }
      } catch {
        // The path may have been deleted; the file event is handled below.
      }

      const kind = classifyPath(changedPath, s.commandsAbs);
      if (kind !== "ignored") schedule(s, kind, changedPath);
    });
  } catch (error) {
    log.error(`[auto-reload] Cannot watch ${shortName(directory)}: ${error instanceof Error ? error.message : error}`);
    return;
  }

  s.watchedPaths.add(directory);
  s.watchers.push(watcher);
  watcher.on("error", (error) => {
    if (s.running) log.error(`[auto-reload] Watcher error in ${shortName(directory)}: ${error instanceof Error ? error.message : error}`);
  });
}

function attachDirectoryTree(s: ReloaderState, directory: string): void {
  if (shouldIgnoreDirectory(directory)) return;
  attachWatcher(s, directory);

  let entries;
  try {
    entries = readdirSync(directory, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (!entry.isDirectory() || entry.name.startsWith(".") || IGNORED_SEGMENTS.has(entry.name)) continue;
    attachDirectoryTree(s, join(directory, entry.name));
  }
}

export function startAutoReloader(commandsDir = "./commands", options: AutoReloaderOptions = {}): void {
  const s = state();
  if (s.running) return;

  s.commandsDir = commandsDir;
  s.commandsAbs = isAbsolute(commandsDir) ? commandsDir : resolve(PROJECT_ROOT, commandsDir);
  s.options = options;
  s.running = true;
  void loadSettings();
  attachDirectoryTree(s, PROJECT_ROOT);

  log.success(`[auto-reload] Watching ${s.watchedPaths.size} directories on Linux-compatible file watchers.`);
}

export function stopAutoReloader(): void {
  const s = state();
  if (!s.running) return;
  s.running = false;
  for (const watcher of s.watchers) {
    try {
      watcher.close();
    } catch {
      // The watcher may already be closed.
    }
  }
  s.watchers = [];
  s.watchedPaths.clear();
  if (s.debounceTimer) {
    clearTimeout(s.debounceTimer);
    s.debounceTimer = null;
  }
  s.pendingCommands.clear();
  s.pendingCore.clear();
  log.info("[auto-reload] Watchers stopped.");
}

export function isAutoReloaderRunning(): boolean {
  return state().running;
}

export async function forceReloadNow(commandsDir?: string): Promise<{ total: number }> {
  const s = state();
  return loadCommands(commandsDir ?? s.commandsDir, { force: true });
}
