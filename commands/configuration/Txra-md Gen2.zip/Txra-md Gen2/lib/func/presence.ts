import type { WaClient } from "zapo-js";
import { log } from "../../connector/logger/index-logging.ts";

let readWarned = false;
let typingWarned = false;

/** Tandai pesan sudah dibaca (centang biru). Aman dipanggil fire-and-forget. */
export async function markRead(client: WaClient, event: any): Promise<void> {
  try {
    await (client as any).message.sendReceipt(event, { type: "read" });
  } catch (err) {
    if (!readWarned) {
      readWarned = true;
      log.warn(`Auto-read gagal: ${err instanceof Error ? err.message : err}`);
    }
  }
}

/** Indikator "sedang mengetik". Bentuk opsi chatstate belum diverifikasi, jadi dicoba dua bentuk. */
export async function sendTyping(client: WaClient, chat: string): Promise<void> {
  const p = (client as any).presence;
  try {
    await p.sendChatstate(chat, { type: "composing" });
  } catch {
    try {
      await p.sendChatstate(chat, { state: "composing" });
    } catch (err) {
      if (!typingWarned) {
        typingWarned = true;
        log.warn(`Typing indicator gagal: ${err instanceof Error ? err.message : err}`);
      }
    }
  }
}
