import { log } from "../../connector/logger/index-logging.ts";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const MARKERS_DIR = fileURLToPath(new URL("../../db/markers/", import.meta.url));
const CMD_MARKER_PATH = join(MARKERS_DIR, "cmdmarker.json");
const FOLDER_MARKER_PATH = join(MARKERS_DIR, "foldermarker.json");


export type MarkerType =
  | "nolimit"
  | "premium"
  | "owner"
  | "admin"
  | "primaryowner"
  | "error";

export type MarkerScope = "command" | "folder";

const ALL_TYPES: MarkerType[] = [
  "premium",
  "nolimit",
  "owner",
  "admin",
  "primaryowner",
  "error",
];

export const MARKER_EMOJI: Record<MarkerType, string> = {
  nolimit: "",        
  premium: "🌸",
  owner: "⛩️",
  admin: "🛡️",
  primaryowner: "👑",
  error: "💔",
};

type MarkerData = Record<MarkerType, string[]>;


interface MarkerState {
  command: Record<MarkerType, Set<string>>;
  folder: Record<MarkerType, Set<string>>;
}

function createEmpty(): Record<MarkerType, Set<string>> {
  const out = {} as Record<MarkerType, Set<string>>;
  for (const t of ALL_TYPES) out[t] = new Set();
  return out;
}

const state: MarkerState = ((globalThis as any).__botMarkers ??= {
  command: createEmpty(),
  folder: createEmpty(),
});


async function readJson(path: string): Promise<MarkerData | null> {
  try {
    const raw = await readFile(path, "utf8");
    const parsed = JSON.parse(raw);
    const out = {} as MarkerData;
    for (const t of ALL_TYPES) {
      out[t] = Array.isArray(parsed?.[t]) ? parsed[t].map(String) : [];
    }
    return out;
  } catch {
    return null;
  }
}

async function writeJson(path: string, data: MarkerData): Promise<void> {
  try {
    await writeFile(path, JSON.stringify(data, null, 2));
  } catch (err) {
    log.error(`Gagal simpan ${path}: ${err instanceof Error ? err.message : err}`);
  }
}

function toData(scope: MarkerScope): MarkerData {
  const out = {} as MarkerData;
  for (const t of ALL_TYPES) out[t] = [...state[scope][t]];
  return out;
}

export async function loadMarkers(): Promise<void> {
  try {
    await mkdir(MARKERS_DIR, { recursive: true });
  } catch { /* sudah ada */ }

    const cmdData = await readJson(CMD_MARKER_PATH);
  if (cmdData) {
    for (const t of ALL_TYPES) state.command[t] = new Set(cmdData[t]);
  } else {
    state.command = createEmpty();
    await writeJson(CMD_MARKER_PATH, toData("command"));
  }

    const folderData = await readJson(FOLDER_MARKER_PATH);
  if (folderData) {
    for (const t of ALL_TYPES) state.folder[t] = new Set(folderData[t]);
  } else {
    state.folder = createEmpty();
    await writeJson(FOLDER_MARKER_PATH, toData("folder"));
  }

  let total = 0;
  for (const t of ALL_TYPES) total += state.command[t].size + state.folder[t].size;

  log.success(`Markers dimuat (${total} entri)`);
}

async function persist(scope: MarkerScope): Promise<void> {
  const path = scope === "command" ? CMD_MARKER_PATH : FOLDER_MARKER_PATH;
  await writeJson(path, toData(scope));
}


export function getMarkers(scope: MarkerScope, type: MarkerType): string[] {
  return [...state[scope][type]];
}

export function hasMarker(scope: MarkerScope, type: MarkerType, item: string): boolean {
  return state[scope][type].has(item);
}

export function getAllMarkers(): MarkerState {
  return state;
}


export async function addMarker(
  scope: MarkerScope,
  type: MarkerType,
  item: string,
): Promise<boolean> {
  const normalized = item.toLowerCase();
  if (state[scope][type].has(normalized)) return false;
  state[scope][type].add(normalized);
  await persist(scope);
  return true;
}

export async function removeMarker(
  scope: MarkerScope,
  type: MarkerType,
  item: string,
): Promise<boolean> {
  const normalized = item.toLowerCase();
  if (!state[scope][type].has(normalized)) return false;
  state[scope][type].delete(normalized);
  await persist(scope);
  return true;
}

export interface ResolvedFlags {
  isPremium: boolean;
  isNoLimit: boolean;
  isOwner: boolean;
  isAdmin: boolean;
  isPrimaryOwner: boolean;
  isError: boolean;
  emoji: string;
  folder: string;
  sources: {
    premium: MarkerScope | "flag" | "none";
    nolimit: MarkerScope | "flag" | "none";
    owner: MarkerScope | "flag" | "none";
    admin: MarkerScope | "flag" | "none";
    primaryowner: MarkerScope | "flag" | "none";
  };
}

interface ResolveInput {
  name: string;
  path?: string;
  category?: string;
  isPremium?: boolean;
  isNoLimit?: boolean;
  isLimit?: boolean;
  isOwner?: boolean;
  isAdmin?: boolean;
  isPrimaryOwner?: boolean;
}

function extractFolder(cmd: ResolveInput): string {
  if (cmd.category) return cmd.category.toLowerCase();
  const parts = (cmd.path ?? "").split("/");
  if (parts.length > 1) return parts[0].toLowerCase();
  return "";
}

export function resolveFlags(cmd: ResolveInput): ResolvedFlags {
  const name = cmd.name.toLowerCase();
  const folder = extractFolder(cmd);

  const resolve = (
    type: MarkerType,
    cmdFlag: boolean | undefined,
  ): { value: boolean; source: MarkerScope | "flag" | "none" } => {
    if (state.command[type].has(name)) return { value: true, source: "command" };
    if (folder && state.folder[type].has(folder)) return { value: true, source: "folder" };
    if (cmdFlag === true) return { value: true, source: "flag" };
    return { value: false, source: "none" };
  };

  const prem = resolve("premium", cmd.isPremium);
  const owner = resolve("owner", cmd.isOwner);
  const admin = resolve("admin", cmd.isAdmin);
  const prim = resolve("primaryowner", cmd.isPrimaryOwner);

  let nolimit: { value: boolean; source: MarkerScope | "flag" | "none" };
  if (state.command.nolimit.has(name)) {
    nolimit = { value: true, source: "command" };
  } else if (folder && state.folder.nolimit.has(folder)) {
    nolimit = { value: true, source: "folder" };
  } else if (cmd.isNoLimit === true || cmd.isLimit === false) {
    nolimit = { value: true, source: "flag" };
  } else {
    nolimit = { value: false, source: "none" };
  }

  const isError = state.command.error.has(name) || (folder && state.folder.error.has(folder));

    let emoji = "";
  if (isError) emoji = MARKER_EMOJI.error;
  else if (prim.value) emoji = MARKER_EMOJI.primaryowner;
  else if (owner.value) emoji = MARKER_EMOJI.owner;
  else if (admin.value) emoji = MARKER_EMOJI.admin;
  else if (prem.value) emoji = MARKER_EMOJI.premium;

  return {
    isPremium: prem.value,
    isNoLimit: nolimit.value,
    isOwner: owner.value,
    isAdmin: admin.value,
    isPrimaryOwner: prim.value,
    isError,
    emoji,
    folder,
    sources: {
      premium: prem.source,
      nolimit: nolimit.source,
      owner: owner.source,
      admin: admin.source,
      primaryowner: prim.source,
    },
  };
}