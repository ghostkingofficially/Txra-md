import { rm } from "node:fs/promises";
import { log } from "../../connector/logger/index-logging.ts";

/** File yang dibuat SQLite untuk satu database: utama, WAL, shared-memory (shm), dan journal. */
const SUFFIXES = ["", "-wal", "-shm", "-journal"];

/**
 * Hapus session.db beserta session.db-wal / session.db-shm / session.db-journal.
 * Dicoba beberapa kali karena di sebagian OS file bisa masih terkunci sesaat setelah disconnect.
 * Return daftar file yang berhasil dihapus.
 */
export async function deleteSessionFiles(sqlitePath: string): Promise<string[]> {
  const removed: string[] = [];
  for (const suffix of SUFFIXES) {
    const file = sqlitePath + suffix;
    let lastErr: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await rm(file, { force: true }); // force: tidak error kalau filenya memang tidak ada
        removed.push(file);
        lastErr = undefined;
        break;
      } catch (err) {
        lastErr = err;
        await new Promise((r) => setTimeout(r, 300));
      }
    }
    if (lastErr) {
      log.error(`Gagal hapus ${file}: ${lastErr instanceof Error ? lastErr.message : lastErr}`);
    }
  }
  return removed;
}
