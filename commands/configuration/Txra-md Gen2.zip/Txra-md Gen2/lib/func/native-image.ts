// lib/func/native-image.ts — pemuat mesin gambar Rust (native/ → mybes_image_engine.node).
//
// Prinsip: Rust = jalur utama (cepat, async di thread pool, tidak memblokir event loop bot);
// kalau file .node tidak ada / gagal dimuat / sering crash → pemanggil otomatis jatuh ke ffmpeg. Bot TIDAK PERNAH mati karena ini.
//
// Cara build (sekali, di mesin yang sama dengan tempat bot jalan):   bun run native:build
// Matikan paksa:   IMAGE_NATIVE=0      Batasi paralel:   IMAGE_NATIVE_PARALLEL=2 (bawaan 2)
//
// Lokasi .node yang dicari (berurutan):
//   1. $MYBES_NATIVE_PATH
//   2. node_modules/mybes-image-engine/mybes_image_engine.node   ← hasil `bun run native:build` (satu-satunya tempat runtime)
//   3. native/prebuilt/<platform>-<arch>.node                    ← salinan kecil untuk backup/restore tanpa Rust
//   4. native/mybes_image_engine.node, native/index.node, native/target/release/*  ← lokasi lama (kompatibilitas)
// (process.dlopen menerima ekstensi apa saja).
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

export interface NativeImageOpts {
  mode?: "cover" | "fit" | "width";
  width: number;
  height?: number;
  quality?: number;
  format?: "jpeg" | "png";
}
export interface NativeImageOut {
  buffer: Uint8Array;
  width: number;
  height: number;
  error?: string | null;
}
interface NativeModule {
  processImage(input: Uint8Array, opts: NativeImageOpts): Promise<NativeImageOut>;
  processImageMulti(input: Uint8Array, jobs: NativeImageOpts[]): Promise<NativeImageOut[]>;
  configure(maxParallel: number): void;
  engineInfo(): string;
}

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..", "..");
const MAX_STRIKES = 5; // error "tak terduga" (panic / modul rusak) berturut-turut sebelum native dimatikan sampai restart

let mod: NativeModule | null | undefined; // undefined = belum dicoba
let info = "";
let reason = "";
let strikes = 0;

function candidates(): string[] {
  const n = join(ROOT, "native");
  const t = join(n, "target", "release");
  return [
    process.env.MYBES_NATIVE_PATH ?? "",
    join(ROOT, "node_modules", "mybes-image-engine", "mybes_image_engine.node"),
    join(n, "prebuilt", `${process.platform}-${process.arch}.node`),
    join(n, "mybes_image_engine.node"),
    join(n, "index.node"),
    join(t, "libmybes_image_engine.so"),
    join(t, "libmybes_image_engine.dylib"),
    join(t, "mybes_image_engine.dll"),
  ].filter(Boolean);
}

function load(): NativeModule | null {
  if (process.env.IMAGE_NATIVE === "0" || process.env.IMAGE_NATIVE === "false") { reason = "dimatikan lewat IMAGE_NATIVE=0"; return null; }
  const path = candidates().find((p) => existsSync(p));
  if (!path) { reason = "file .node tidak ditemukan (jalankan: bun run native:build, atau salin native/prebuilt/<platform>-<arch>.node)"; return null; }
  try {
    const holder: { exports: any } = { exports: {} };
    (process as any).dlopen(holder, path);
    const m = holder.exports as NativeModule;
    if (typeof m.processImage !== "function" || typeof m.processImageMulti !== "function") throw new Error("API native tidak lengkap (versi .node lama?)");
    const par = Number(process.env.IMAGE_NATIVE_PARALLEL ?? 2);
    try { m.configure(Number.isFinite(par) && par >= 1 ? Math.floor(par) : 2); } catch { /* opsional */ }
    try { info = m.engineInfo(); } catch { info = "mybes_image_engine"; }
    return m;
  } catch (e) {
    reason = `gagal memuat ${path}: ${(e as Error).message}`;
    return null;
  }
}

/** Modul native, atau null (tidak tersedia / dimatikan) → pemanggil memakai ffmpeg. */
export function getNative(): NativeModule | null {
  if (mod === undefined) {
    mod = load();
    if (mod) console.log(`[image] mesin native aktif: ${info}`);
    else console.log(`[image] mesin native tidak dipakai → ffmpeg (${reason})`);
  }
  return mod;
}

/** Catat error dari native. Error "bukan gambar / decode gagal" itu wajar (input jelek), bukan kerusakan mesin. */
export function noteNativeError(e: unknown): void {
  const msg = e instanceof Error ? e.message : String(e);
  if (/decode gambar gagal|gambar kosong|dimensi|di luar batas|mode image|format harus/i.test(msg)) return;
  if (++strikes >= MAX_STRIKES && mod) {
    mod = null;
    reason = `dimatikan setelah ${MAX_STRIKES} error beruntun: ${msg}`;
    console.warn(`[image] mesin native dimatikan sampai restart — ${reason}`);
  }
}
export function noteNativeOk(): void { strikes = 0; }

export function nativeStatus(): { active: boolean; info: string; reason: string } {
  getNative();
  return { active: !!mod, info, reason: mod ? "" : reason };
}