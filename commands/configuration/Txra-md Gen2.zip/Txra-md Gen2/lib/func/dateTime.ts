export const DEFAULT_TZ = "Asia/Jakarta";

const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const BULAN = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

const TZ_LABEL: Record<string, string> = {
  "Asia/Jakarta": "WIB",
  "Asia/Pontianak": "WIB",
  "Asia/Makassar": "WITA",
  "Asia/Jayapura": "WIT",
};

export type DateInput = Date | number | string | undefined | null;

export interface TimeParts {
  year: number;
  month: number; // 1-12
  day: number;
  hour: number; // 0-23
  minute: number;
  second: number;
  weekday: number; // 0 = Minggu
  tz: string;
}

function toDate(input?: DateInput): Date {
  if (input instanceof Date) return input;
  if (input === undefined || input === null || input === "") return new Date();
  const d = new Date(input);
  return isNaN(d.getTime()) ? new Date() : d;
}

const fmtCache = new Map<string, Intl.DateTimeFormat>();
function formatterFor(tz: string): Intl.DateTimeFormat {
  let f = fmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      hourCycle: "h23",
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
    });
    fmtCache.set(tz, f);
  }
  return f;
}

export function getTimeParts(input?: DateInput, tz: string = DEFAULT_TZ): TimeParts {
  const date = toDate(input);
  const parts: Record<string, number> = {};
  for (const p of formatterFor(tz).formatToParts(date)) {
    if (p.type !== "literal") parts[p.type] = Number(p.value);
  }
  const hour = parts.hour === 24 ? 0 : parts.hour;
  const weekday = new Date(Date.UTC(parts.year, parts.month - 1, parts.day)).getUTCDay();
  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    hour,
    minute: parts.minute,
    second: parts.second,
    weekday,
    tz,
  };
}


export type DayPeriod = "pagi" | "siang" | "sore" | "malam";

export interface Greeting {
  key: DayPeriod;
    id: string;
    jp: string;
    jpPlain: string;
  emoji: string;
}

const GREETINGS: Record<DayPeriod, Greeting> = {
  pagi: { key: "pagi", id: "Selamat pagi", jp: "Ohayō", jpPlain: "Ohayo", emoji: "🌅" },
  siang: { key: "siang", id: "Selamat siang", jp: "Konnichiwa", jpPlain: "Konnichiwa", emoji: "☀️" },
  sore: { key: "sore", id: "Selamat sore", jp: "Konnichiwa", jpPlain: "Konnichiwa", emoji: "🌇" },
  malam: { key: "malam", id: "Selamat malam", jp: "Konbanwa", jpPlain: "Konbanwa", emoji: "🌙" },
};

export function getDayPeriod(input?: DateInput, tz: string = DEFAULT_TZ): DayPeriod {
  const { hour } = getTimeParts(input, tz);
  if (hour >= 4 && hour < 11) return "pagi";
  if (hour >= 11 && hour < 15) return "siang";
  if (hour >= 15 && hour < 18) return "sore";
  return "malam";
}

export function getGreeting(input?: DateInput, tz: string = DEFAULT_TZ): Greeting {
  return GREETINGS[getDayPeriod(input, tz)];
}

export function greet(name?: string | null, input?: DateInput, tz: string = DEFAULT_TZ): string {
  const g = getGreeting(input, tz);
  const who = name?.trim();
  return who ? `${g.jp}, ${who}! ${g.id}` : `${g.jp}! ${g.id}`;
}


const pad = (n: number) => String(n).padStart(2, "0");

export function tzLabel(tz: string = DEFAULT_TZ): string {
  return TZ_LABEL[tz] ?? tz;
}

export function getDayName(input?: DateInput, tz: string = DEFAULT_TZ): string {
  return HARI[getTimeParts(input, tz).weekday];
}

export function getMonthName(input?: DateInput, tz: string = DEFAULT_TZ): string {
  return BULAN[getTimeParts(input, tz).month - 1];
}

export function formatDate(input?: DateInput, { withDay = true, tz = DEFAULT_TZ } = {}): string {
  const p = getTimeParts(input, tz);
  const base = `${p.day} ${BULAN[p.month - 1]} ${p.year}`;
  return withDay ? `${HARI[p.weekday]}, ${base}` : base;
}

export function formatTime(
  input?: DateInput,
  { withSeconds = false, withZone = true, tz = DEFAULT_TZ } = {},
): string {
  const p = getTimeParts(input, tz);
  const t = `${pad(p.hour)}.${pad(p.minute)}${withSeconds ? "." + pad(p.second) : ""}`;
  return withZone ? `${t} ${tzLabel(tz)}` : t;
}

export function formatDateTime(
  input?: DateInput,
  opts: { withDay?: boolean; withSeconds?: boolean; tz?: string } = {},
): string {
  const tz = opts.tz ?? DEFAULT_TZ;
  return `${formatDate(input, { withDay: opts.withDay ?? true, tz })} • ${formatTime(input, { withSeconds: opts.withSeconds, tz })}`;
}

export function dateKey(input?: DateInput, tz: string = DEFAULT_TZ): string {
  const p = getTimeParts(input, tz);
  return `${p.year}-${pad(p.month)}-${pad(p.day)}`;
}

export function msUntilMidnight(input?: DateInput, tz: string = DEFAULT_TZ): number {
  const p = getTimeParts(input, tz);
  const elapsed = ((p.hour * 60 + p.minute) * 60 + p.second) * 1000;
  return 24 * 60 * 60 * 1000 - elapsed;
}

 
export function formatDuration(
  ms: number,
  { short = false, maxUnits = 4 }: { short?: boolean; maxUnits?: number } = {},
): string {
  const total = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
  const units: Array<[number, string, string]> = [
    [Math.floor(total / 86400), "hari", "h"],
    [Math.floor((total % 86400) / 3600), "jam", "j"],
    [Math.floor((total % 3600) / 60), "menit", "m"],
    [total % 60, "detik", "d"],
  ];
  const out = units
    .filter(([v]) => v > 0)
    .slice(0, Math.max(1, maxUnits))
    .map(([v, long, abbr]) => (short ? `${v}${abbr}` : `${v} ${long}`));
  if (out.length === 0) return short ? "0d" : "0 detik";
  return out.join(" ");
}

export function timeAgo(input: DateInput, now: DateInput = Date.now()): string {
  const diff = toDate(now).getTime() - toDate(input).getTime();
  const future = diff < 0;
  const s = Math.abs(diff) / 1000;
  let text: string;
  if (s < 10) return "baru saja";
  if (s < 60) text = `${Math.floor(s)} detik`;
  else if (s < 3600) text = `${Math.floor(s / 60)} menit`;
  else if (s < 86400) text = `${Math.floor(s / 3600)} jam`;
  else if (s < 86400 * 30) text = `${Math.floor(s / 86400)} hari`;
  else if (s < 86400 * 365) text = `${Math.floor(s / (86400 * 30))} bulan`;
  else text = `${Math.floor(s / (86400 * 365))} tahun`;
  return future ? `dalam ${text}` : `${text} yang lalu`;
}

export function uptime(maxUnits = 3): string {
  const sec = typeof process !== "undefined" && typeof process.uptime === "function"
    ? process.uptime()
    : performance.now() / 1000;
  return formatDuration(sec * 1000, { maxUnits });
}

// ── tambahan: semua pengaturan waktu dipusatkan di sini ──────────────────────

/** Detik → "HH:MM:SS" (dipakai menu untuk "Aktif"). */
export function formatUptime(seconds: number): string {
  const s = Math.max(0, Math.floor(Number(seconds) || 0));
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}

/** Detik sejak proses bot menyala. */
export function processUptimeSeconds(): number {
  return typeof process !== "undefined" && typeof process.uptime === "function" ? process.uptime() : performance.now() / 1000;
}

/** "Ohayō (Selamat pagi)" — satu baris sapaan sesuai jam (zona waktu bot). */
export function getGreetingText(input?: DateInput, tz: string = DEFAULT_TZ): string {
  const g = getGreeting(input, tz);
  return `${g.jp} (${g.id})`;
}

/** "HH:MM:SS" tanpa zona — dipakai logger konsol. */
export function formatClock(input?: DateInput, tz: string = DEFAULT_TZ): string {
  const p = getTimeParts(input, tz);
  return `${pad(p.hour)}:${pad(p.minute)}:${pad(p.second)}`;
}

// ── durasi & masa berlaku (dipusatkan di sini; jangan tulis 3600000 / Date.now() + ... di file lain) ──

export const MINUTE_MS = 60_000;
export const HOUR_MS = 3_600_000;
export const DAY_MS = 86_400_000;

/** Timestamp (ms) `ms` milidetik dari sekarang — untuk expiration_time dan sejenisnya. */
export function expiresIn(ms: number): number {
  return Date.now() + ms;
}
