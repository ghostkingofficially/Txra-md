// lib/func/image.ts — olah gambar.
//   JALUR UTAMA : mesin Rust (native/, lihat lib/func/native-image.ts) — async di thread pool, decode sekali untuk banyak ukuran.
//   CADANGAN    : ffmpeg (bytes lewat stdin, hasil lewat stdout, prioritas CPU diturunkan), dipakai otomatis bila
//                 native belum di-build / gagal / tidak bisa membaca formatnya. Maksimal 2 proses ffmpeg serentak.
import { spawn } from "node:child_process";
import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { lowPriority } from "./lowpriority.ts";
import { getNative, noteNativeError, noteNativeOk, type NativeImageOpts } from "./native-image.ts";

export type ImageMode = "cover" | "fit" | "width";
export type ImageFormat = "jpeg" | "png";

export interface ImageOptions {
  /** cover = isi penuh + crop tengah (butuh height) | fit = muat di dalam kotak, tanpa diperbesar | width = tentukan lebar saja */
  mode?: ImageMode;
  width: number;
  height?: number;
  /** 1–100 (hanya jpeg). Bawaan 80. */
  quality?: number;
  format?: ImageFormat;
}

export interface ImageResult {
  buffer: Buffer;
  width: number;
  height: number;
}

const FFMPEG = () => process.env.FFMPEG_PATH || "ffmpeg";
const MAX_PARALLEL = 2;
const TIMEOUT_MS = 20_000;

// Cache hasil image processing. Dibatasi berdasarkan byte agar tidak menghabiskan RAM.
// Bisa diatur melalui env: IMAGE_CACHE_MAX_BYTES / IMAGE_CACHE_TTL_MS.
const IMAGE_CACHE_MAX_BYTES = Math.max(0, Number(process.env.IMAGE_CACHE_MAX_BYTES ?? 24 * 1024 * 1024));
const IMAGE_CACHE_TTL_MS = Math.max(1_000, Number(process.env.IMAGE_CACHE_TTL_MS ?? 10 * 60_000));
const IMAGE_CACHE_MAX_ENTRIES = 160;
type CachedImage = { result: ImageResult; expiresAt: number; bytes: number };
const imageCache = new Map<string, CachedImage>();
const imageInflight = new Map<string, Promise<ImageResult>>();
let imageCacheBytes = 0;

function cacheDelete(key: string) {
  const item = imageCache.get(key);
  if (!item) return;
  imageCacheBytes -= item.bytes;
  imageCache.delete(key);
}
function cacheGet(key: string): ImageResult | undefined {
  const item = imageCache.get(key);
  if (!item) return;
  if (item.expiresAt <= Date.now()) { cacheDelete(key); return; }
  // LRU: pindahkan entry yang dipakai ke ujung Map.
  imageCache.delete(key);
  imageCache.set(key, item);
  return item.result;
}
function cachePut(key: string, result: ImageResult) {
  const bytes = result.buffer.byteLength;
  if (!IMAGE_CACHE_MAX_BYTES || bytes > IMAGE_CACHE_MAX_BYTES) return;
  cacheDelete(key);
  while (imageCache.size >= IMAGE_CACHE_MAX_ENTRIES || imageCacheBytes + bytes > IMAGE_CACHE_MAX_BYTES) {
    const oldest = imageCache.keys().next();
    if (oldest.done) break;
    cacheDelete(oldest.value);
  }
  imageCache.set(key, { result, bytes, expiresAt: Date.now() + IMAGE_CACHE_TTL_MS });
  imageCacheBytes += bytes;
}
// Hash isi gambar cukup sekali per objek Buffer (thumb.ts memakai Buffer yang sama untuk semua varian).
const digests = new WeakMap<object, string>();
function inputDigest(input: Uint8Array): string {
  let d = digests.get(input);
  if (!d) { d = createHash("sha256").update(input).digest("hex"); digests.set(input, d); }
  return d;
}
function imageCacheKey(input: Uint8Array, opts: ImageOptions): string {
  const mode = opts.mode ?? (opts.height ? "cover" : "width");
  const format = opts.format ?? "jpeg";
  // "img-v2": jalur native memakai filter berbeda dari ffmpeg → kunci lama tidak dipakai lagi.
  return `${inputDigest(input)}|${mode}|${opts.width}|${opts.height ?? opts.width}|${format}|${opts.quality ?? 80}|img-v2`;
}
/** Statistik sederhana untuk observability; tidak menyertakan konten gambar. */
export function getImageCacheStats() {
  return { entries: imageCache.size, bytes: imageCacheBytes, inflight: imageInflight.size, maxBytes: IMAGE_CACHE_MAX_BYTES };
}
export function clearImageCache() {
  imageCache.clear(); imageInflight.clear(); imageCacheBytes = 0;
}

let running = 0;
const waiters: Array<() => void> = [];
async function acquire(): Promise<void> {
  if (running < MAX_PARALLEL) { running++; return; }
  await new Promise<void>((r) => waiters.push(r));
  running++;
}
function release(): void {
  running--;
  waiters.shift()?.();
}

/** JPEG 1–100 → skala q:v ffmpeg (2 = terbaik, 31 = terburuk). */
const qv = (quality: number) => Math.min(31, Math.max(2, Math.round(2 + (100 - quality) * 0.29)));

function buildFilter(o: Required<Pick<ImageOptions, "mode" | "width">> & { height: number }): string {
  const { mode, width: w, height: h } = o;
  if (mode === "cover") return `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}`;
  if (mode === "width") return `scale='min(${w},iw)':-2`;
  return `scale='min(${w},iw)':'min(${h},ih)':force_original_aspect_ratio=decrease`;
}

/** Ukuran gambar dari header JPEG (SOFn) atau PNG (IHDR). null = tidak terbaca. */
export function imageSize(b: Uint8Array): { width: number; height: number } | null {
  const buf = Buffer.from(b.buffer, b.byteOffset, b.byteLength);
  if (buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47) {
    return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  }
  if (buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    const len = buf.readUInt16BE(i + 2);
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      return { height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
    }
    i += 2 + len;
  }
  return null;
}

const toNativeOpts = (opts: ImageOptions): NativeImageOpts => ({
  mode: opts.mode ?? (opts.height ? "cover" : "width"),
  width: opts.width,
  height: opts.height ?? opts.width,
  quality: opts.quality ?? 80,
  format: opts.format ?? "jpeg",
});

/** Jalur Rust. null = native tidak tersedia / gagal (pemanggil lanjut ke ffmpeg). */
async function viaNative(input: Uint8Array, opts: ImageOptions): Promise<ImageResult | null> {
  const nat = getNative();
  if (!nat) return null;
  try {
    const r = await nat.processImage(input, toNativeOpts(opts));
    noteNativeOk();
    return { buffer: Buffer.from(r.buffer.buffer, r.buffer.byteOffset, r.buffer.byteLength), width: r.width, height: r.height };
  } catch (e) {
    noteNativeError(e);
    return null;
  }
}

/** Ubah ukuran / crop gambar (jpg, png, webp, gif → frame pertama). Native dulu, lalu ffmpeg. Melempar error kalau keduanya gagal / bukan gambar. */
export async function processImageUncached(input: Uint8Array, opts: ImageOptions): Promise<ImageResult> {
  if (!input?.length) throw new Error("gambar kosong");
  const fast = await viaNative(input, opts);
  if (fast) return fast;
  return processImageFfmpeg(input, opts);
}

/** Jalur cadangan: ffmpeg. */
export async function processImageFfmpeg(input: Uint8Array, opts: ImageOptions): Promise<ImageResult> {
  if (!input?.length) throw new Error("gambar kosong");
  const mode = opts.mode ?? (opts.height ? "cover" : "width");
  const height = opts.height ?? opts.width;
  const format = opts.format ?? "jpeg";
  const args = [
    "-hide_banner", "-loglevel", "error", "-threads", "1", "-filter_threads", "1", "-i", "pipe:0", "-frames:v", "1", "-an",
    "-vf", buildFilter({ mode, width: opts.width, height }),
    ...(format === "png"
      ? ["-c:v", "png"]
      : ["-c:v", "mjpeg", "-pix_fmt", "yuvj420p", "-q:v", String(qv(opts.quality ?? 80))]),
    "-f", "image2pipe", "pipe:1",
  ];

  await acquire();
  try {
    const out = await new Promise<Buffer>((resolve, reject) => {
      const p = spawn(FFMPEG(), args, { stdio: ["pipe", "pipe", "pipe"] });
      lowPriority(p.pid);
      const chunks: Buffer[] = [];
      let err = "";
      const timer = setTimeout(() => { p.kill("SIGKILL"); reject(new Error("ffmpeg timeout")); }, TIMEOUT_MS);
      p.stdout.on("data", (d: Buffer) => chunks.push(d));
      p.stderr.on("data", (d: Buffer) => { if (err.length < 2000) err += d.toString(); });
      p.stdin.on("error", () => {}); // ffmpeg menutup stdin lebih awal = normal
      p.on("error", (e: any) => { clearTimeout(timer); reject(new Error(e?.code === "ENOENT" ? "ffmpeg tidak ditemukan (pkg install ffmpeg)" : String(e))); });
      p.on("close", (code) => {
        clearTimeout(timer);
        const buf = Buffer.concat(chunks);
        if (code === 0 && buf.length) resolve(buf);
        else reject(new Error(`ffmpeg gagal (kode ${code}): ${err.trim().split("\n").slice(-2).join(" | ") || "bukan gambar?"}`));
      });
      p.stdin.end(Buffer.from(input.buffer, input.byteOffset, input.byteLength));
    });
    const size = imageSize(out);
    return { buffer: out, width: size?.width ?? opts.width, height: size?.height ?? height };
  } finally {
    release();
  }
}

/**
 * Image processing dengan bounded LRU + TTL + in-flight dedup.
 * Catatan: hasil buffer dibagikan antar pemanggil. Perlakukan sebagai immutable.
 */
export async function processImage(input: Uint8Array, opts: ImageOptions): Promise<ImageResult> {
  if (!input?.length) throw new Error("gambar kosong");
  const key = imageCacheKey(input, opts);
  const hit = cacheGet(key);
  if (hit) return hit;
  const active = imageInflight.get(key);
  if (active) return active;
  const task = processImageUncached(input, opts).then((result) => {
    cachePut(key, result);
    return result;
  }).finally(() => imageInflight.delete(key));
  imageInflight.set(key, task);
  return task;
}

/**
 * Banyak ukuran dari SATU gambar: native men-decode sekali (jauh lebih hemat daripada decode ulang tiap ukuran).
 * Hasil per item: ImageResult, atau null kalau ukuran itu gagal. Urutan = urutan `variants`. Tidak pernah melempar.
 * Item yang sudah ada di cache tidak dihitung ulang.
 */
export async function processImageMulti(input: Uint8Array, variants: ImageOptions[]): Promise<Array<ImageResult | null>> {
  const out: Array<ImageResult | null> = new Array(variants.length).fill(null);
  if (!input?.length || !variants.length) return out;

  const keys = variants.map((v) => imageCacheKey(input, v));
  const todo: number[] = [];
  keys.forEach((k, i) => { const hit = cacheGet(k); if (hit) out[i] = hit; else todo.push(i); });
  if (!todo.length) return out;

  const store = (i: number, r: ImageResult) => { out[i] = r; cachePut(keys[i]!, r); };

  const nat = getNative();
  if (nat) {
    try {
      const res = await nat.processImageMulti(input, todo.map((i) => toNativeOpts(variants[i]!)));
      noteNativeOk();
      res.forEach((r, n) => {
        if (r && !r.error && r.buffer?.byteLength) {
          store(todo[n]!, { buffer: Buffer.from(r.buffer.buffer, r.buffer.byteOffset, r.buffer.byteLength), width: r.width, height: r.height });
        }
      });
    } catch (e) {
      noteNativeError(e);
    }
  }
  // yang belum terisi (native tidak ada / gagal) → satu per satu lewat jalur biasa (native → ffmpeg)
  for (const i of todo) {
    if (out[i]) continue;
    try { store(i, await processImageUncached(input, variants[i]!)); } catch { /* tetap null */ }
  }
  return out;
}

/** Crop persegi JPEG. Gagal → bytes asli (dipakai apa adanya). */
export async function toSquareJpeg(bytes: Uint8Array, size = 640, quality = 85): Promise<Uint8Array> {
  try {
    return new Uint8Array((await processImage(bytes, { mode: "cover", width: size, height: size, quality })).buffer);
  } catch {
    return bytes;
  }
}