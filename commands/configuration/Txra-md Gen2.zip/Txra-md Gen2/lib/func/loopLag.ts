// lib/func/loopLag.ts — pemantau "event loop lag": seberapa lama thread utama bot TERTAHAN.
//
// Kenapa penting: semua pesan diproses di satu thread. Kalau thread itu sibuk (JSON.stringify besar, SQLite sinkron,
// spawn ffmpeg, olah gambar di thread utama, GC) maka pesan yang datang harus menunggu, apa pun kecepatan jaringan.
// Itulah sumber "kadang 500 ms, kadang 1 detik": bukan rata-rata yang lambat, tapi sesekali tertahan.
//
// Cara kerja: timer 50 ms; kalau terpanggil telat X ms berarti thread utama tertahan X ms. Biaya ≈ 0.
// Hasilnya tampil di .ping dan dicatat ke log bila tertahan > 250 ms (maks. sekali per 10 detik).
import { log } from "../../connector/logger/index-logging.ts";

const TICK_MS = 50;
const KEEP = 1200;            // 1200 × 50 ms = 60 detik terakhir
const WARN_MS = 250;
const WARN_EVERY_MS = 10_000;

const samples: number[] = ((globalThis as any).__botLoopLag ??= []);
let timer: ReturnType<typeof setInterval> | null = null;
let last = 0;
let lastWarn = 0;
let worstEver = 0;

export function startLoopLag(): void {
  if (timer) return;
  last = performance.now();
  timer = setInterval(() => {
    const now = performance.now();
    const lag = Math.max(0, now - last - TICK_MS);
    last = now;
    samples.push(lag);
    if (samples.length > KEEP) samples.shift();
    if (lag > worstEver) worstEver = lag;
    if (lag >= WARN_MS && now - lastWarn > WARN_EVERY_MS) {
      lastWarn = now;
      log.warn(`[lag] thread utama tertahan ${lag.toFixed(0)}ms — ada kerja sinkron berat (cek log [slow] / ffmpeg / JSON / SQLite)`);
    }
  }, TICK_MS);
  (timer as any).unref?.();
}

export function stopLoopLag(): void {
  if (timer) clearInterval(timer);
  timer = null;
}

/** Statistik 60 detik terakhir (ms). */
export function loopLagStats(): { p50: number; p95: number; max: number; over100: number; worstEver: number; samples: number } {
  if (!samples.length) return { p50: 0, p95: 0, max: 0, over100: 0, worstEver, samples: 0 };
  const sorted = [...samples].sort((a, b) => a - b);
  const q = (p: number) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))]!;
  return { p50: q(0.5), p95: q(0.95), max: sorted[sorted.length - 1]!, over100: samples.filter((x) => x >= 100).length, worstEver, samples: samples.length };
}