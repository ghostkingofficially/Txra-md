// lib/func/text.ts — helper teks murni (tanpa dependensi, mudah dites)

/** Ganti {kunci} di template dengan nilai dari vars. Kunci yang tidak ada dibiarkan apa adanya. */
export function fmt(template: string, vars: Record<string, string | number> = {}): string {
  return String(template ?? "").replace(/\{(\w+)\}/g, (whole, key) =>
    Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key]) : whole);
}

/**
 * Bersihkan pushName jadi username valid (2–20 karakter; huruf/angka/spasi/_ . -).
 * Dipakai auto-register. Kalau hasilnya kosong (mis. nama isinya emoji semua) → user<4 digit nomor>.
 */
export function sanitizeUserName(raw: unknown, phoneSeed = ""): string {
  let name = String(raw ?? "")
    .normalize("NFKC")
    .replace(/[^\p{L}\p{N} _.-]+/gu, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 20)
    .trim();
  if (name.length < 2 || name.toLowerCase() === "owner") {
    const tail = phoneSeed.replace(/\D/g, "").slice(-4);
    name = `user${tail || Math.floor(1000 + Math.random() * 9000)}`;
  }
  return name;
}
