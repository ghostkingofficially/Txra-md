import { Buffer } from "node:buffer";
import { spawn } from "node:child_process";
import { randomBytes } from "node:crypto";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { lowPriority } from "./lowpriority.ts";

type Bytes = Uint8Array | Buffer;


export interface SniffResult {
  mime: string;
  ext: string;
  kind: "image" | "video" | "audio" | "document" | "unknown";
    animated?: boolean;
}

const ascii = (b: Bytes, from: number, to: number) => Buffer.from(b.subarray(from, to)).toString("latin1");

export function isWebp(b: Bytes): boolean {
  return b.length > 12 && ascii(b, 0, 4) === "RIFF" && ascii(b, 8, 12) === "WEBP";
}

function webpIsAnimated(b: Bytes): boolean {
    if (ascii(b, 12, 16) === "VP8X" && (b[20] & 0x02)) return true;
  return Buffer.from(b).includes("ANIM");
}

export function sniffMedia(b: Bytes): SniffResult {
  if (!b || b.length < 4) return { mime: "application/octet-stream", ext: "bin", kind: "unknown" };
  if (b[0] === 0xff && b[1] === 0xd8) return { mime: "image/jpeg", ext: "jpg", kind: "image" };
  if (b[0] === 0x89 && ascii(b, 1, 4) === "PNG") return { mime: "image/png", ext: "png", kind: "image" };
  if (ascii(b, 0, 3) === "GIF") return { mime: "image/gif", ext: "gif", kind: "image", animated: true };
  if (isWebp(b)) return { mime: "image/webp", ext: "webp", kind: "image", animated: webpIsAnimated(b) };
  if (ascii(b, 0, 4) === "%PDF") return { mime: "application/pdf", ext: "pdf", kind: "document" };
  if (b.length > 12 && ascii(b, 4, 8) === "ftyp") {
    const brand = ascii(b, 8, 12);
    if (brand.startsWith("M4A") || brand === "M4B ") return { mime: "audio/mp4", ext: "m4a", kind: "audio" };
    if (brand.startsWith("qt")) return { mime: "video/quicktime", ext: "mov", kind: "video" };
    return { mime: "video/mp4", ext: "mp4", kind: "video" };
  }
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) {
    return { mime: "video/webm", ext: "webm", kind: "video" };
  }
  if (ascii(b, 0, 4) === "OggS") return { mime: "audio/ogg", ext: "ogg", kind: "audio" };
  if (ascii(b, 0, 3) === "ID3" || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) {
    return { mime: "audio/mpeg", ext: "mp3", kind: "audio" };
  }
  if (b.length > 12 && ascii(b, 0, 4) === "RIFF" && ascii(b, 8, 12) === "WAVE") {
    return { mime: "audio/wav", ext: "wav", kind: "audio" };
  }
  return { mime: "application/octet-stream", ext: "bin", kind: "unknown" };
}


export interface StickerMeta {
  packName?: string;
  author?: string;
    emojis?: string[];
  packId?: string;
  androidAppStoreLink?: string;
  iosAppStoreLink?: string;
}

export function buildStickerExif(meta: StickerMeta = {}): Buffer {
  const json = {
    "sticker-pack-id": meta.packId ?? randomBytes(16).toString("hex"),
    "sticker-pack-name": meta.packName ?? "",
    "sticker-pack-publisher": meta.author ?? "",
    "android-app-store-link": meta.androidAppStoreLink ?? "",
    "ios-app-store-link": meta.iosAppStoreLink ?? "",
    emojis: meta.emojis ?? [],
  };
  const header = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
    0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
  ]);
  const body = Buffer.from(JSON.stringify(json), "utf8");
  const exif = Buffer.concat([header, body]);
  exif.writeUInt32LE(body.length, 14); // raw JSON
  return exif;
}

interface Chunk {
  fourcc: string;
  data: Buffer;
}

function parseWebpChunks(webp: Bytes): Chunk[] {
  const buf = Buffer.from(webp.buffer, webp.byteOffset, webp.byteLength);
  if (!isWebp(buf)) throw new Error("Bukan file WebP yang valid");
  const chunks: Chunk[] = [];
  let pos = 12;
  while (pos + 8 <= buf.length) {
    const fourcc = buf.toString("latin1", pos, pos + 4);
    const size = buf.readUInt32LE(pos + 4);
    const start = pos + 8;
    const end = Math.min(start + size, buf.length);
    chunks.push({ fourcc, data: buf.subarray(start, end) });
    pos = start + size + (size & 1);
  }
  return chunks;
}

function makeChunk(fourcc: string, data: Buffer): Buffer {
  const header = Buffer.alloc(8);
  header.write(fourcc, 0, 4, "latin1");
  header.writeUInt32LE(data.length, 4);
  return Buffer.concat([header, data, data.length & 1 ? Buffer.alloc(1) : Buffer.alloc(0)]);
}

function assembleWebp(chunks: Chunk[]): Buffer {
  const parts = chunks.map((c) => makeChunk(c.fourcc, c.data));
  const body = Buffer.concat(parts);
  const head = Buffer.alloc(12);
  head.write("RIFF", 0, 4, "latin1");
  head.writeUInt32LE(4 + body.length, 4);
  head.write("WEBP", 8, 4, "latin1");
  return Buffer.concat([head, body]);
}

const u24 = (v: number) => Buffer.from([v & 0xff, (v >> 8) & 0xff, (v >> 16) & 0xff]);

function buildVp8x(chunks: Chunk[]): Chunk {
  let width = 0, height = 0, alpha = false;
  const vp8 = chunks.find((c) => c.fourcc === "VP8 ");
  const vp8l = chunks.find((c) => c.fourcc === "VP8L");
  if (vp8l && vp8l.data.length >= 5) {
    const bits = vp8l.data.readUInt32LE(1);
    width = (bits & 0x3fff) + 1;
    height = ((bits >> 14) & 0x3fff) + 1;
    alpha = ((bits >> 28) & 1) === 1;
  } else if (vp8 && vp8.data.length >= 10) {
    width = vp8.data.readUInt16LE(6) & 0x3fff;
    height = vp8.data.readUInt16LE(8) & 0x3fff;
  } else {
    throw new Error("WebP tidak punya data gambar VP8/VP8L");
  }
  if (chunks.some((c) => c.fourcc === "ALPH")) alpha = true;
  const flags = 0x08 | (alpha ? 0x10 : 0);
  const data = Buffer.concat([Buffer.from([flags, 0, 0, 0]), u24(width - 1), u24(height - 1)]);
  return { fourcc: "VP8X", data };
}

export function addExifToWebp(webp: Bytes, exif: Bytes): Buffer {
  let chunks = parseWebpChunks(webp).filter((c) => c.fourcc !== "EXIF");
  if (chunks[0]?.fourcc !== "VP8X") chunks = [buildVp8x(chunks), ...chunks];
  const vp8x = chunks[0];
  const data = Buffer.from(vp8x.data);
  data[0] |= 0x08; // flag EXIF
  chunks[0] = { fourcc: "VP8X", data };
  chunks.push({ fourcc: "EXIF", data: Buffer.from(exif) });
  return assembleWebp(chunks);
}

export function addStickerExif(webp: Bytes, meta: StickerMeta = {}): Buffer {
  return addExifToWebp(webp, buildStickerExif(meta));
}

export function readStickerExif(webp: Bytes): (StickerMeta & Record<string, unknown>) | null {
  try {
    const exif = parseWebpChunks(webp).find((c) => c.fourcc === "EXIF");
    if (!exif) return null;
    const text = exif.data.toString("utf8");
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start < 0 || end < start) return null;
    const j = JSON.parse(text.slice(start, end + 1));
    return {
      ...j,
      packId: j["sticker-pack-id"],
      packName: j["sticker-pack-name"],
      author: j["sticker-pack-publisher"],
      emojis: j.emojis,
    };
  } catch {
    return null;
  }
}



const FFMPEG = () => (typeof process !== "undefined" && process.env?.FFMPEG_PATH) || "ffmpeg";

function runFfmpeg(args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const p = spawn(FFMPEG(), ["-y", "-hide_banner", "-loglevel", "error", "-threads", "1", "-filter_threads", "1", ...args]);
    lowPriority(p.pid); // ffmpeg tidak boleh menyaingi bot yang sedang membalas pesan
    let err = "";
    p.stderr.on("data", (d) => (err += d.toString()));
    p.on("error", (e: any) =>
      reject(new Error(e?.code === "ENOENT" ? "ffmpeg tidak ditemukan (pkg install ffmpeg)" : String(e)))
    );
    p.on("close", (code) =>
      code === 0 ? resolve() : reject(new Error(`ffmpeg gagal (kode ${code}): ${err.trim().split("\n").slice(-3).join(" | ")}`))
    );
  });
}

async function withTemp<T>(fn: (dir: string) => Promise<T>): Promise<T> {
  const dir = await mkdtemp(join(tmpdir(), "conv-"));
  try {
    return await fn(dir);
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}


export type StickerFit = "full" | "crop" | "stretch";

export interface ToWebpOptions {
    fit?: StickerFit;
  size?: number; 
  fps?: number; 
  maxSeconds?: number;
  quality?: number; 
    maxBytes?: number;
}

function stickerFilter(fit: StickerFit, size: number): string {
  if (fit === "stretch") return `scale=${size}:${size}:flags=lanczos,format=rgba`;
  if (fit === "crop") {
    return `scale=${size}:${size}:force_original_aspect_ratio=increase:flags=lanczos,crop=${size}:${size},format=rgba`;
  }
  return (
    `scale=${size}:${size}:force_original_aspect_ratio=decrease:flags=lanczos,format=rgba,` +
    `pad=${size}:${size}:(ow-iw)/2:(oh-ih)/2:color=0x00000000`
  );
}

export async function toWebp(input: Bytes, opts: ToWebpOptions = {}): Promise<Buffer> {
  const { fit = "full", size = 512, fps = 15, maxSeconds = 8, quality = 70, maxBytes = 900_000 } = opts;
  const info = sniffMedia(input);
  if (info.kind !== "image" && info.kind !== "video") {
    throw new Error(`Tipe file tidak bisa dijadikan stiker: ${info.mime}`);
  }
  const animated = info.kind === "video" || (info.kind === "image" && !!info.animated);

  return withTemp(async (dir) => {
    const inFile = join(dir, `in.${info.ext}`);
    const outFile = join(dir, "out.webp");
    await writeFile(inFile, input);

    if (!animated) {
      await runFfmpeg([
        "-i", inFile, "-frames:v", "1", "-vf", stickerFilter(fit, size),
        "-c:v", "libwebp", "-lossless", "0", "-quality", String(quality),
        "-compression_level", "6", "-f", "webp", outFile,
      ]);
      return await readFile(outFile);
    }

      const attempts: Array<[number, number]> = [
      [quality, fps], [Math.min(quality, 50), fps], [Math.min(quality, 40), 12], [30, 10], [20, 8],
    ];
    let last: Buffer | null = null;
    for (const [q, f] of attempts) {
      await runFfmpeg([
        "-i", inFile, "-t", String(maxSeconds), "-an",
        "-vf", `fps=${f},${stickerFilter(fit, size)}`,
        "-c:v", "libwebp", "-lossless", "0", "-quality", String(q),
        "-compression_level", "6", "-loop", "0", "-preset", "default", "-vsync", "0",
        "-f", "webp", outFile,
      ]);
      last = await readFile(outFile);
      if (last.length <= maxBytes) return last;
    }
    return last!; 
  });
}

export async function toSticker(input: Bytes, opts: StickerMeta & ToWebpOptions = {}): Promise<Buffer> {
  const { packName, author, emojis, packId, androidAppStoreLink, iosAppStoreLink, ...conv } = opts;
  const webp = isWebp(input) && !Object.keys(conv).length ? Buffer.from(input) : await toWebp(input, conv);
  return addStickerExif(webp, { packName, author, emojis, packId, androidAppStoreLink, iosAppStoreLink });
}

export async function webpToPng(webp: Bytes): Promise<Buffer> {
  return withTemp(async (dir) => {
    const inFile = join(dir, "in.webp");
    const outFile = join(dir, "out.png");
    await writeFile(inFile, webp);
    await runFfmpeg(["-i", inFile, "-frames:v", "1", outFile]);
    return await readFile(outFile);
  });
}

export async function toMp3(input: Bytes, { bitrate = "128k" }: { bitrate?: string } = {}): Promise<Buffer> {
  const info = sniffMedia(input);
  return withTemp(async (dir) => {
    const inFile = join(dir, `in.${info.ext}`);
    const outFile = join(dir, "out.mp3");
    await writeFile(inFile, input);
    await runFfmpeg(["-i", inFile, "-vn", "-c:a", "libmp3lame", "-b:a", bitrate, outFile]);
    return await readFile(outFile);
  });
}

export async function toPtt(input: Bytes): Promise<Buffer> {
  const info = sniffMedia(input);
  return withTemp(async (dir) => {
    const inFile = join(dir, `in.${info.ext}`);
    const outFile = join(dir, "out.ogg");
    await writeFile(inFile, input);
    await runFfmpeg([
      "-i", inFile, "-vn", "-c:a", "libopus", "-b:a", "48k", "-compression_level", "5", // 5 ≈ 2× lebih cepat dari bawaan (10), kualitas VN nyaris sama
      "-ar", "48000", "-ac", "1", "-f", "ogg", outFile,
    ]);
    return await readFile(outFile);
  });
}