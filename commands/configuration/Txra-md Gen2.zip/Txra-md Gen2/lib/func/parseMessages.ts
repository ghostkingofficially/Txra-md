
import {
  extractMessageContent,
  getContentType,
  normalizeMessageContent,
  parseMessage,
} from "../serialize/content.ts";

type Obj = Record<string, any>;


const str = (v: unknown): string =>
  typeof v === "string" ? v : v === undefined || v === null ? "" : String(v);

function safeJsonParse(raw: unknown): Obj {
  if (raw && typeof raw === "object") return raw as Obj;
  const s = str(raw).trim();
  if (!s) return {};
  try {
    const v = JSON.parse(s);
    return v && typeof v === "object" ? v : {};
  } catch {
    return {};
  }
}

export function unwrapMessage(message?: Obj | null): Obj | undefined {
  if (!message || typeof message !== "object") return undefined;
  try {
    return parseMessage(message, extractMessageContent) ?? normalizeMessageContent(message) ?? message;
  } catch {
    return message;
  }
}


export type ButtonResponseKind =
  | "buttons" // buttonsResponseMessage
  | "template" // templateButtonReplyMessage
  | "list" // listResponseMessage
  | "native_flow" // interactiveResponseMessage.nativeFlowResponseMessage
  | "interactive" // interactiveResponseMessage non native flow
  | "unknown_response"; 

export interface ButtonResponse {
  kind: ButtonResponseKind;
  id: string;
  text: string;
  name?: string;
  params?: Obj;
  index?: number;
  description?: string;
  raw: Obj;
}

const PARAM_ID_KEYS = [
  "id", "button_id", "buttonId", "row_id", "rowId", "selectedRowId",
  "selected_id", "selectedId", "response_id", "flow_token", "prompt_text",
];
const PARAM_TEXT_KEYS = [
  "display_text", "displayText", "title", "text", "name", "label", "selectedDisplayText",
];

function pickFirst(obj: Obj, keys: string[]): string {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === "string" && v) return v;
    if (typeof v === "number") return String(v);
  }
  return "";
}

function fromNativeFlow(msg: Obj): ButtonResponse {
  const nfr = msg.nativeFlowResponseMessage ?? {};
  const params = safeJsonParse(nfr.paramsJson);
  const name = str(nfr.name);
  const id = pickFirst(params, PARAM_ID_KEYS) || name;
  const text =
    pickFirst(params, PARAM_TEXT_KEYS) || str(msg.body?.text) || str(msg.body) || "";
  return { kind: "native_flow", id, text, name: name || undefined, params, raw: msg };
}

function genericResponse(content: Obj): ButtonResponse | null {
  for (const key of Object.keys(content)) {
    if (!/(Response|Reply)(Message)?$/.test(key)) continue;
    if (key === "richResponseMessage" || key === "reactionMessage") continue; // bukan balasan tombol
    const msg = content[key];
    if (!msg || typeof msg !== "object") continue;
    const id =
      pickFirst(msg, ["selectedId", "selectedButtonId", "selectedRowId", "id", "promptText", "prompt_text"]) ||
      pickFirst(msg.singleSelectReply ?? {}, ["selectedRowId"]) ||
      pickFirst(safeJsonParse(msg.paramsJson), PARAM_ID_KEYS);
    const text =
      pickFirst(msg, ["selectedDisplayText", "title", "text", "displayText"]) || str(msg.body?.text);
    if (id || text) return { kind: "unknown_response", id, text, name: key, raw: msg };
  }
  return null;
}

export function parseButtonResponse(message?: Obj | null): ButtonResponse | null {
  const content = unwrapMessage(message);
  if (!content) return null;

  if (content.buttonsResponseMessage) {
    const m = content.buttonsResponseMessage;
    return {
      kind: "buttons",
      id: str(m.selectedButtonId),
      text: str(m.selectedDisplayText ?? m.response?.selectedDisplayText),
      raw: m,
    };
  }
  if (content.templateButtonReplyMessage) {
    const m = content.templateButtonReplyMessage;
    return {
      kind: "template",
      id: str(m.selectedId),
      text: str(m.selectedDisplayText),
      index: typeof m.selectedIndex === "number" ? m.selectedIndex : undefined,
      raw: m,
    };
  }
  if (content.listResponseMessage) {
    const m = content.listResponseMessage;
    return {
      kind: "list",
      id: str(m.singleSelectReply?.selectedRowId),
      text: str(m.title),
      description: str(m.description) || undefined,
      raw: m,
    };
  }
  if (content.interactiveResponseMessage) {
    const m = content.interactiveResponseMessage;
    if (m.nativeFlowResponseMessage) return fromNativeFlow(m);
    return { kind: "interactive", id: "", text: str(m.body?.text), raw: m };
  }
  return genericResponse(content);
}

export interface TextBodyOptions {
  preferButtonId?: boolean;
}

function templateText(content: Obj): string {
  const bm = content.buttonsMessage;
  if (bm) return str(bm.contentText) || str(bm.text);
  const lm = content.listMessage;
  if (lm) return str(lm.description) || str(lm.title);
  const im = content.interactiveMessage;
  if (im) return str(im.body?.text) || str(im.header?.title);
  const tm = content.templateMessage;
  if (tm) {
    const t = tm.hydratedTemplate ?? tm.hydratedFourRowTemplate ?? tm.fourRowTemplate ?? {};
    return str(t.hydratedContentText) || str(t.contentText);
  }
  return "";
}

function richText(content: Obj): string {
  const rich = content.richResponseMessage;
  if (!rich) return "";
  const parts: string[] = [];
  for (const sub of rich.submessages ?? []) {
    if (sub?.messageText) parts.push(str(sub.messageText));
  }
  if (parts.length) return parts.join("\n");
  const unified = decodeUnifiedResponse(rich);
  if (unified) collectKeys(unified, ["text", "prompt_text"], parts);
  return parts.join("\n");
}

export function getTextBody(message?: Obj | null, opts: TextBodyOptions = {}): string {
  const { preferButtonId = true } = opts;
  const content = unwrapMessage(message);
  if (!content) return "";

  const resp = parseButtonResponse(content);
  if (resp) return (preferButtonId ? resp.id || resp.text : resp.text || resp.id).trim();

    const direct =
    content.conversation ||
    content.extendedTextMessage?.text ||
    content.imageMessage?.caption ||
    content.videoMessage?.caption ||
    content.documentMessage?.caption ||
    content.ptvMessage?.caption ||
    content.stickerPackMessage?.name ||
    "";
  if (direct) return str(direct);

  const tpl = templateText(content);
  if (tpl) return tpl;

    const loc = content.locationMessage ?? content.liveLocationMessage;
  if (loc?.degreesLatitude !== undefined) return `${loc.degreesLatitude},${loc.degreesLongitude}`;
  if (content.contactMessage?.displayName) return str(content.contactMessage.displayName);
  const poll =
    content.pollCreationMessage ?? content.pollCreationMessageV2 ??
    content.pollCreationMessageV3 ?? content.pollCreationMessageV4 ?? content.pollCreationMessageV5;
  if (poll?.name) return str(poll.name);

    return richText(content);
}

export function getButtonId(message?: Obj | null): string {
  return parseButtonResponse(message)?.id ?? "";
}


export type MediaKind =
  | "image" | "video" | "gif" | "audio" | "ptt" | "document" | "sticker"
  | "animated_sticker" | "lottie_sticker" | "ptv" | "sticker_pack" | "album"
  | "rich_image" | "rich_video" | "rich_reel";

export interface RichMediaItem {
  kind: "rich_image" | "rich_video" | "rich_reel";
  url: string;
  thumbnailUrl?: string;
  mimetype?: string;
  width?: number;
  height?: number;
  duration?: number;
    source: string;
}

export interface MediaDetection {
  kind: MediaKind;
    mtype: string;
  mimetype?: string;
  isViewOnce: boolean;
    isRich: boolean;
    downloadable: boolean;
    items?: RichMediaItem[];
    msg: Obj;
}

export function decodeUnifiedResponse(rich: Obj): Obj | null {
  const data = rich?.unifiedResponse?.data;
  if (!data) return null;
  try {
    let text = "";
    if (typeof data === "string") {
      text = data.trim().startsWith("{") ? data : Buffer.from(data, "base64").toString("utf8");
    } else if (data instanceof Uint8Array) {
      text = Buffer.from(data).toString("utf8");
    } else if (Array.isArray(data?.data)) {
      text = Buffer.from(data.data).toString("utf8"); // Buffer hasil JSON.stringify
    }
    return text ? JSON.parse(text) : null;
  } catch {
    return null;
  }
}

function collectKeys(node: unknown, keys: string[], out: string[], depth = 0): void {
  if (!node || depth > 12) return;
  if (Array.isArray(node)) {
    for (const n of node) collectKeys(n, keys, out, depth + 1);
    return;
  }
  if (typeof node !== "object") return;
  const o = node as Obj;
  for (const [k, v] of Object.entries(o)) {
    if (keys.includes(k) && typeof v === "string" && v) out.push(v);
    else if (v && typeof v === "object") collectKeys(v, keys, out, depth + 1);
  }
}

export function getRichMedia(message?: Obj | null): RichMediaItem[] {
  const content = unwrapMessage(message);
  const rich = content?.richResponseMessage;
  if (!rich) return [];
  const items: RichMediaItem[] = [];

  const walk = (node: unknown, depth = 0): void => {
    if (!node || depth > 14) return;
    if (Array.isArray(node)) return void node.forEach((n) => walk(n, depth + 1));
    if (typeof node !== "object") return;
    const o = node as Obj;
    switch (o.__typename) {
      case "GenAIImaginePrimitive": {
        const isVideo = o.imagine_type === "ANIMATE" || str(o.media?.mime_type).startsWith("video/");
        if (o.media?.url) {
          items.push({
            kind: isVideo ? "rich_video" : "rich_image",
            url: str(o.media.url),
            mimetype: o.media.mime_type,
            width: o.media.width,
            height: o.media.height,
            duration: o.media.duration,
            source: o.__typename,
          });
        }
        break;
      }
      case "GenAIImagePrimitive": {
        const url = o.full_image?.url || o.preview_image?.url;
        if (url) {
          items.push({
            kind: "rich_image",
            url: str(url),
            thumbnailUrl: o.preview_image?.url,
            mimetype: o.full_image?.mime_type ?? o.preview_image?.mime_type,
            source: o.__typename,
          });
        }
        break;
      }
      case "GenAIReelPrimitive": {
        if (o.reels_url) {
          items.push({
            kind: "rich_reel",
            url: str(o.reels_url),
            thumbnailUrl: o.thumbnail_url,
            source: o.__typename,
          });
        }
        break;
      }
    }
    for (const v of Object.values(o)) if (v && typeof v === "object") walk(v, depth + 1);
  };
  walk(decodeUnifiedResponse(rich));

  if (items.length === 0) {
    for (const sub of rich.submessages ?? []) {
      for (const u of sub?.gridImageMetadata?.imageUrls ?? []) {
        const url = u?.imageHighResUrl || u?.imagePreviewUrl || u?.sourceUrl;
        if (url) items.push({ kind: "rich_image", url: str(url), thumbnailUrl: u?.imagePreviewUrl, source: "gridImageMetadata" });
      }
      for (const it of sub?.contentItemsMetadata?.itemsMetadata ?? []) {
        const url = it?.reelItem?.videoUrl;
        if (url) items.push({ kind: "rich_reel", url: str(url), thumbnailUrl: it.reelItem?.thumbnailUrl, source: "reelItem" });
      }
    }
  }
  return items;
}

function isViewOnceWrapped(message?: Obj | null): boolean {
  let m: Obj | undefined = message ?? undefined;
  for (let i = 0; i < 5 && m; i++) {
    if (m.viewOnceMessage || m.viewOnceMessageV2 || m.viewOnceMessageV2Extension) return true;
    const inner = m.ephemeralMessage ?? m.deviceSentMessage ?? m.editedMessage ?? m.botForwardedMessage;
    m = inner?.message;
  }
  return false;
}

export function detectMedia(message?: Obj | null): MediaDetection | null {
  const content = unwrapMessage(message);
  if (!content) return null;
  const viewOnce = isViewOnceWrapped(message) || !!Object.values(content).some((v: any) => v?.viewOnce === true);

  const mk = (kind: MediaKind, mtype: string, msg: Obj, extra: Partial<MediaDetection> = {}): MediaDetection => ({
    kind,
    mtype,
    mimetype: msg?.mimetype,
    isViewOnce: viewOnce,
    isRich: false,
    downloadable: true,
    msg,
    ...extra,
  });

  if (content.imageMessage) return mk("image", "imageMessage", content.imageMessage);
  if (content.videoMessage) {
    const v = content.videoMessage;
    return mk(v.gifPlayback ? "gif" : "video", "videoMessage", v);
  }
  if (content.audioMessage) {
    const a = content.audioMessage;
    return mk(a.ptt ? "ptt" : "audio", "audioMessage", a);
  }
  if (content.documentMessage) return mk("document", "documentMessage", content.documentMessage);
  if (content.stickerMessage) {
    const s = content.stickerMessage;
    return mk(s.isAnimated ? "animated_sticker" : "sticker", "stickerMessage", s);
  }
  if (content.lottieStickerMessage) {
    const inner = normalizeMessageContent({ lottieStickerMessage: content.lottieStickerMessage });
    const s = inner?.stickerMessage ?? content.lottieStickerMessage.message?.stickerMessage ?? content.lottieStickerMessage;
    return mk("lottie_sticker", "lottieStickerMessage", s);
  }
  if (content.ptvMessage) return mk("ptv", "ptvMessage", content.ptvMessage);
  if (content.stickerPackMessage) {
    return mk("sticker_pack", "stickerPackMessage", content.stickerPackMessage, { downloadable: false });
  }
  if (content.albumMessage) {
    return mk("album", "albumMessage", content.albumMessage, { downloadable: false });
  }
  if (content.richResponseMessage) {
    const items = getRichMedia(content);
    if (items.length) {
      return mk(items[0].kind, "richResponseMessage", content.richResponseMessage, {
        mimetype: items[0].mimetype,
        isRich: true,
        downloadable: false,
        items,
      });
    }
  }

    const mtype = getContentType(content);
  const msg = mtype ? content[mtype] : undefined;
  if (msg && typeof msg === "object" && (msg.mimetype || msg.thumbnailDirectPath)) {
    const mime = str(msg.mimetype);
    const kind: MediaKind = mime.startsWith("video/") ? "video"
      : mime.startsWith("audio/") ? "audio"
      : mime.startsWith("image/") ? "image"
      : "document";
    return mk(kind, mtype!, msg);
  }
  return null;
}

export const isMediaMessage = (message?: Obj | null): boolean => detectMedia(message) !== null;