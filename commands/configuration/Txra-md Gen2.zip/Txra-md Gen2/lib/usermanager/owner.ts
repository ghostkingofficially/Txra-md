import type { WaClient } from "zapo-js";
import { isLidJid } from "zapo-js";
import { log } from "../../connector/logger/index-logging.ts";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const OWNER_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "../../db/usermanager");
const OWNER_PATH = resolve(OWNER_DIR, "owner.json");

export interface OwnerData {
  primary: string;              
  additional: string[];         
  addedAt: Record<string, number>;
}

const EMPTY: OwnerData = { primary: "", additional: [], addedAt: {} };

let cached: OwnerData | null = null;
const lidToPhone = new Map<string, string>();
const phoneToLid = new Map<string, string>();

export async function loadOwner(): Promise<OwnerData> {
  if (cached) return cached;
  try {
    const raw = await readFile(OWNER_PATH, "utf8");
    const parsed = JSON.parse(raw);
    cached = {
      primary: String(parsed.primary ?? ""),
      additional: Array.isArray(parsed.additional)
        ? parsed.additional.map(String)
        : [],
      addedAt: parsed.addedAt ?? {},
    };
  } catch {
    cached = { ...EMPTY };
  }
  return cached;
}

export async function saveOwner(): Promise<void> {
  if (!cached) return;
  try {
    await mkdir(OWNER_DIR, { recursive: true });
    await writeFile(OWNER_PATH, JSON.stringify(cached, null, 2), "utf8");
  } catch (err) {
    log.error(
      `Gagal simpan owner.json: ${err instanceof Error ? err.message : err}`,
    );
  }
}

export function getOwner(): OwnerData {
  return cached ?? { ...EMPTY };
}

export function normalizePhone(input: string): string {
  return input.replace(/\D/g, "");
}

function extractJidDigits(jid: string): string {
  return jid.split("@")[0].replace(/\D/g, "");
}

export function isLid(jid: string): boolean {
  return isLidJid(jid);
}

export function resolvePhone(
  jid: string,
  altJid?: string | null,
): string {
  if (altJid && !isLidJid(altJid)) {
    return extractJidDigits(altJid);
  }

  if (!isLidJid(jid)) {
    return extractJidDigits(jid);
  }

  const cachedPhone = lidToPhone.get(jid);
  if (cachedPhone) return cachedPhone;

  return "";
}

export function isOwner(
  jid: string,
  altJid?: string | null,
): boolean {
  const phone = resolvePhone(jid, altJid);
  if (!phone) return false;
  const o = getOwner();
  return phone === o.primary || o.additional.includes(phone);
}

export function isPrimaryOwner(
  jid: string,
  altJid?: string | null,
): boolean {
  const phone = resolvePhone(jid, altJid);
  return phone === getOwner().primary;
}

export function isAdditionalOwner(
  jid: string,
  altJid?: string | null,
): boolean {
  const phone = resolvePhone(jid, altJid);
  return getOwner().additional.includes(phone);
}

export async function syncLidMappings(
  client: WaClient,
  phones: string[],
): Promise<void> {
  const unique = [...new Set(phones.map(normalizePhone).filter(Boolean))];
  if (unique.length === 0) return;

  try {
    log.info(`Sync LID untuk ${unique.length} nomor...`);
    const results = await client.profile.getLidsByPhoneNumbers(unique);

    let synced = 0;
    for (const r of results) {
      if (!r.lidJid) continue;
      const phone = extractJidDigits(r.phoneJid);
      const lid = r.lidJid;

      lidToPhone.set(lid, phone);
      phoneToLid.set(phone, lid);
      synced++;
    }

    log.success(`LID tersinkron: ${synced} dari ${unique.length}`);
  } catch (err) {
    log.warn(
      `Sync LID gagal: ${err instanceof Error ? err.message : err}`,
    );
  }
}

export function getLidForPhone(phone: string): string | undefined {
  return phoneToLid.get(normalizePhone(phone));
}

export function getPhoneForLid(lid: string): string | undefined {
  return lidToPhone.get(lid);
}

export async function setPrimaryOwner(phone: string): Promise<void> {
  const p = normalizePhone(phone);
  if (!p) return;
  const o = getOwner();
  if (o.primary === p) return;
  cached = {
    ...o,
    primary: p,
    addedAt: { ...o.addedAt, [p]: Date.now() },
  };
  await saveOwner();
  log.success(`Primary owner disimpan: ${p}`);
}

export async function addAdditionalOwners(
  phones: string[],
): Promise<string[]> {
  const o = getOwner();
  const normalized = phones
    .map(normalizePhone)
    .filter((p) => p && p !== o.primary && !o.additional.includes(p));

  if (normalized.length === 0) return [];

  const addedAt = { ...o.addedAt };
  for (const n of normalized) addedAt[n] = Date.now();

  cached = {
    ...o,
    additional: [...o.additional, ...normalized],
    addedAt,
  };
  await saveOwner();
  log.success(`Owner tambahan disimpan: ${normalized.join(", ")}`);
  return normalized;
}

export function getAllOwnerPhones(): string[] {
  const o = getOwner();
  return [o.primary, ...o.additional].filter(Boolean);
}
