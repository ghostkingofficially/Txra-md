import { log } from "../../connector/logger/index-logging.ts";
import { getConfig } from "../../connector/config.ts";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const USERS_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "../../db/usermanager");
const USERS_PATH = resolve(USERS_DIR, "users.json");
const USERS_TMP = resolve(USERS_DIR, "users.json.tmp");

export const OWNER_USERNAME = "owner";

export interface UserData {
  jid: string; 
  name: string;
  registered: boolean;
  registeredAt: number;
  limit: number;
  limitDay?: string; 
  premium: boolean;
  premiumUntil: number | null;
  level: number;
  exp: number;
  coins: number;
  banned: boolean;
  warned: number;
  lastSeen: number;
}

type UserStore = Record<string, UserData>;

const users: UserStore = ((globalThis as any).__botUsers ??= {});
let loaded = false;
let saveTimer: number | null = null;
let dirty = false;


export function toUserPhone(input?: string | null): string {
  if (!input) return "";
  const s = String(input).trim();
  if (/^\d{7,15}$/.test(s)) return s;

  const at = s.indexOf("@");
  if (at < 0) return "";

  const server = s.slice(at + 1);
  if (server !== "s.whatsapp.net" && server !== "c.us") return "";

  const user = s.slice(0, at).split(":")[0].split("_")[0];
  return /^\d{7,15}$/.test(user) ? user : "";
}

export function isValidUserJid(input?: string | null): boolean {
  return toUserPhone(input) !== "";
}

function todayKey(): string {
  return new Date(Date.now() + 7 * 3600_000).toISOString().slice(0, 10);
}


export async function loadUsers(): Promise<void> {
  if (loaded) return;
  let removed = 0;

  try {
    const raw = await readFile(USERS_PATH, "utf8");
    const parsed = JSON.parse(raw) as UserStore;

    for (const [key, value] of Object.entries(parsed ?? {})) {
    const phone = toUserPhone(value?.jid) || (value && !value.jid ? toUserPhone(key) : "");
      if (!phone || !value) {
        removed++;
        continue;
      }
      value.jid = `${phone}@s.whatsapp.net`;
      users[phone] = value;
    }

    log.success(`Users dimuat: ${Object.keys(users).length}`);
    if (removed > 0) {
      log.warn(`${removed} entri tidak valid (LID/grup/newsletter) dibuang dari users.json`);
      scheduleSave();
    }
  } catch {
    log.info("users.json belum ada, mulai dari kosong");
  }
  loaded = true;
}

function scheduleSave(): void {
  dirty = true;
  if (saveTimer !== null) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    if (!dirty) return;
    dirty = false;
    void flush();
  }, 500) as unknown as number;
}

async function flush(): Promise<void> {
  try {
    await mkdir(USERS_DIR, { recursive: true });
    await writeFile(USERS_TMP, JSON.stringify(users, null, 2), "utf8");
    await rename(USERS_TMP, USERS_PATH);
  } catch (err) {
    log.error(`Gagal simpan users.json: ${err instanceof Error ? err.message : err}`);
  }
}

export async function saveUsersNow(): Promise<void> {
  if (saveTimer !== null) {
    clearTimeout(saveTimer);
    saveTimer = null;
  }
  dirty = false;
  await flush();
}


function defaultLimitFor(user: UserData): number {
  const cfg = getConfig();
  const base = cfg.level?.baseLimit ?? 20;
  const perLevel = cfg.level?.limitPerLevel ?? 5;
  const multiplier = user.premium ? (cfg.level?.premiumLimitMultiplier ?? 3) : 1;
  return Math.floor((base + perLevel * (user.level - 1)) * multiplier);
}


export function getUser(jid: string): UserData | undefined {
  const phone = toUserPhone(jid);
  if (!phone) return undefined;
  return users[phone];
}

export function getOrCreateUser(jid: string, name?: string): UserData | undefined {
  const phone = toUserPhone(jid);
  if (!phone) return undefined;

  const existing = users[phone];

  if (!existing) {
    const cfg = getConfig();
    const user: UserData = {
      jid: `${phone}@s.whatsapp.net`,
      name: name ?? "",
      registered: false,
      registeredAt: 0,
      limit: cfg.level?.baseLimit ?? 20,
      limitDay: todayKey(),
      premium: false,
      premiumUntil: null,
      level: 1,
      exp: 0,
      coins: 0,
      banned: false,
      warned: 0,
      lastSeen: Date.now(),
    };
    users[phone] = user;
    scheduleSave();
    return user;
  }

  existing.lastSeen = Date.now();
  if (name && !existing.registered && name !== existing.name) {
    existing.name = name;
    scheduleSave();
  }
  return existing;
}

export function updateUser(jid: string, patch: Partial<UserData>): UserData | undefined {
  const user = getOrCreateUser(jid);
  if (!user) return undefined;
  const { jid: _ignored, ...safePatch } = patch; 
  Object.assign(user, safePatch);
  scheduleSave();
  return user;
}


export function registerBotOwner(jid: string): UserData | undefined {
  const phone = toUserPhone(jid);
  if (!phone) return undefined;

  const user = getOrCreateUser(phone);
  if (!user) return undefined;

  let changed = false;
  if (!user.registered) {
    user.registered = true;
    user.registeredAt = Date.now();
    changed = true;
  }
  if (user.name !== OWNER_USERNAME) {
    user.name = OWNER_USERNAME;
    changed = true;
  }
  if (changed) scheduleSave();
  return user;
}

// ─────────────────────────────────────────────────────────
// Premium
// ─────────────────────────────────────────────────────────

export function isPremium(jid: string): boolean {
  const user = getUser(jid);
  if (!user || !user.premium) return false;

  if (user.premiumUntil && Date.now() > user.premiumUntil) {
    user.premium = false;
    user.premiumUntil = null;
    scheduleSave();
    return false;
  }
  return true;
}

export function setPremium(jid: string, value: boolean, durationMs?: number): UserData | undefined {
  const user = getOrCreateUser(jid);
  if (!user) return undefined;

  user.premium = value;
  user.premiumUntil = value && durationMs ? Date.now() + durationMs : null;

  if (value) {
    user.limit = Math.max(user.limit, defaultLimitFor({ ...user, premium: true }));
  }

  scheduleSave();
  return user;
}


export function ensureDailyLimit(user: UserData): void {
  if ((getConfig().level as any)?.dailyReset === false) return;
  const today = todayKey();
  if (user.limitDay === today) return;
  user.limitDay = today;
  user.limit = Math.max(user.limit, defaultLimitFor(user));
  scheduleSave();
}

export function addLimit(jid: string, amount: number): number {
  const user = getOrCreateUser(jid);
  if (!user) return 0;
  user.limit += amount;
  scheduleSave();
  return user.limit;
}

export function removeLimit(jid: string, amount = 1): number {
  const user = getOrCreateUser(jid);
  if (!user) return 0;
  user.limit = Math.max(0, user.limit - amount);
  scheduleSave();
  return user.limit;
}

export function resetLimit(jid: string): number {
  const user = getOrCreateUser(jid);
  if (!user) return 0;
  user.limit = defaultLimitFor(user);
  user.limitDay = todayKey();
  scheduleSave();
  return user.limit;
}


export function register(jid: string, name: string): UserData | undefined {
  const user = getOrCreateUser(jid);
  if (!user) return undefined;
  if (!user.registered) {
    user.name = name;
    user.registered = true;
    user.registeredAt = Date.now();
    scheduleSave();
  }
  return user;
}

export function isRegistered(jid: string): boolean {
  return getUser(jid)?.registered === true;
}


export function getTotalUsers(): number {
  return Object.keys(users).length;
}

export function getAllUsers(): UserData[] {
  return Object.values(users);
}

export function getAllPremiumUsers(): UserData[] {
  return Object.values(users).filter((u) => {
    if (!u.premium) return false;
    if (u.premiumUntil && Date.now() > u.premiumUntil) return false;
    return true;
  });
}
