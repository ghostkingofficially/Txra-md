import type { WaClient } from "zapo-js";

import { toUserPhone } from "./users.ts";
import { getPhoneForLid } from "./owner.ts";
import {
  findParticipant,
  getGroupMetadata,
  peekGroupMetadata,
} from "../group-metadata/index.ts";
import type { SerializedMessage } from "../serialize/index.ts";

const lidToPn: Map<string, string> = ((globalThis as any).__botLidToPn ??= new Map());
const LID_MAP_MAX = 10_000;

function lidKey(jid: string): string {
  const at = jid.indexOf("@");
  if (at < 0) return jid;
  return jid.slice(0, at).split(":")[0] + jid.slice(at);
}

function isLid(jid?: string | null): jid is string {
  return !!jid && jid.endsWith("@lid");
}

function learn(lid: string, phone: string): void {
  if (!lid || !phone || lidToPn.get(lid) === phone) return;
  if (lidToPn.size >= LID_MAP_MAX) {
    const first = lidToPn.keys().next().value;
    if (first !== undefined) lidToPn.delete(first);
  }
  lidToPn.set(lid, phone);
}

export async function resolveSenderPhone(
  client: WaClient,
  m: SerializedMessage,
): Promise<string | undefined> {
  const key = m.key ?? {};

    if (m.fromMe) {
    try {
      const creds = (client as any).getCredentials?.() ?? {};
      const phone = toUserPhone(creds.meJid);
      if (phone) {
        if (isLid(creds.meLid)) learn(lidKey(creds.meLid), phone);
        return phone;
      }
    } catch { /* lanjut ke cara lain */ }
  }

  const lids = [key.participant, m.sender, !m.isGroup ? key.remoteJid : undefined]
    .filter(isLid)
    .map(lidKey);

  const pnCandidates = [
    key.participantAlt,
    key.participantPn,
    m.sender,
    !m.isGroup ? key.remoteJidAlt : undefined,
  ];
  for (const c of pnCandidates) {
    const phone = toUserPhone(c);
    if (phone) {
      for (const l of lids) learn(l, phone);
      return phone;
    }
  }

  for (const l of lids) {
    const known = lidToPn.get(l) ?? getPhoneForLid(l);
    if (known) return known;
  }

  if (m.isGroup && lids.length > 0) {
    const lookup = (): string => {
      for (const l of lids) {
        const phone = toUserPhone(findParticipant(m.chat, l)?.phoneNumber);
        if (phone) return phone;
      }
      return "";
    };

    let phone = lookup();
    if (!phone && !peekGroupMetadata(m.chat)) {
      await getGroupMetadata(client, m.chat);
      phone = lookup();
    }
    if (phone) {
      for (const l of lids) learn(l, phone);
      return phone;
    }
  }

  return undefined;
}