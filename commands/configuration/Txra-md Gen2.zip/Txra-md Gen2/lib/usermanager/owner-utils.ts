// lib/usermanager/owner-utils.ts — logika murni owner (tanpa runtime/zapo) supaya mudah dites

export interface OwnerData {
  /** daftar owner utama (di file lama berupa string — keduanya dibaca) */
  primary: string[];
  additional: string[];
  addedAt: Record<string, number>;
}

/** "0851-1326-3069" → "6285113263069" (0 diganti kode negara), "+62 851…" → "62851…", "00…" → buang 00. */
export function normalizePhone(input: unknown, countryCode = "62"): string {
  let d = String(input ?? "").replace(/\D/g, "");
  if (d.startsWith("00")) d = d.slice(2);
  const cc = String(countryCode ?? "").replace(/\D/g, "");
  if (cc && d.startsWith("0")) d = cc + d.slice(1);
  return d;
}

/** String "a, b" / array / number → daftar nomor valid (min 8 digit), unik, urutan dipertahankan. */
export function toPhoneList(value: unknown, countryCode = "62"): string[] {
  const raw = Array.isArray(value)
    ? value
    : typeof value === "string" || typeof value === "number"
    ? String(value).split(/[,;\n]+/)
    : [];
  const out: string[] = [];
  for (const item of raw) {
    const p = normalizePhone(item, countryCode);
    if (p.length >= 8 && !out.includes(p)) out.push(p);
  }
  return out;
}

/** Baca teks owner.json. primary boleh string ATAU array; nomor di primary dibuang dari additional. */
export function parseOwnerJson(text: string, countryCode = "62"): OwnerData {
  const parsed = JSON.parse(text);
  const primary = toPhoneList(parsed?.primary, countryCode);
  const additional = toPhoneList(parsed?.additional, countryCode).filter((p) => !primary.includes(p));
  const addedAt: Record<string, number> = {};
  if (parsed?.addedAt && typeof parsed.addedAt === "object") {
    for (const [k, v] of Object.entries(parsed.addedAt)) {
      const n = normalizePhone(k, countryCode);
      if (n && typeof v === "number") addedAt[n] = v;
    }
  }
  return { primary, additional, addedAt };
}

export const isPnJid = (jid?: string | null): jid is string => !!jid && jid.endsWith("@s.whatsapp.net");
export const isLidString = (jid?: string | null): jid is string => !!jid && jid.endsWith("@lid");

/** "1234:5@lid" → "1234@lid" (buang suffix device) */
export function lidKey(jid: string): string {
  const at = jid.indexOf("@");
  return at < 0 ? jid : jid.slice(0, at).split(":")[0] + jid.slice(at);
}

/**
 * Nomor dari JID. Hanya JID personal (@s.whatsapp.net) atau @lid yang ada di `lidLookup`.
 * JID grup (@g.us) dll TIDAK dianggap nomor — kesalahan itu yang membuat owner tak terdeteksi di grup.
 */
export function resolvePhoneCore(
  jid: string | null | undefined,
  altJid: string | null | undefined,
  lidLookup: (lid: string) => string | undefined,
  countryCode = "62",
): string {
  const pn = (j: string) => normalizePhone(j.split("@")[0].split(":")[0], countryCode);
  if (isPnJid(altJid)) return pn(altJid);
  if (isPnJid(jid)) return pn(jid);
  if (isLidString(jid)) return lidLookup(lidKey(jid)) ?? lidLookup(jid) ?? "";
  return "";
}
