// Satu-satunya tempat peta lid ↔ nomor (selain peta owner di owner.ts yang harus permanen).
// Dulu ada tiga salinan: lidToPnParticipants.ts, identity.ts, dan globalThis.__botLidToPn.
// Modul ini tanpa import apa pun supaya aman dipakai dari mana saja (tidak ada import melingkar).

export const LID_MAP_MAX = 10_000;

// globalThis: peta tidak hilang saat autoReloader memuat ulang modul.
const lidToPnMap: Map<string, string> = ((globalThis as any).__botLidToPn ??= new Map());
const pnToLidMap: Map<string, string> = ((globalThis as any).__botPnToLid ??= new Map());

/** "123:4@lid" → "123@lid" (buang bagian device). */
export function lidKey(jid: string): string {
  const at = jid.indexOf("@");
  if (at < 0) return jid;
  return jid.slice(0, at).split(":")[0] + jid.slice(at);
}

export const isLid = (jid?: string | null): jid is string => !!jid && jid.endsWith("@lid");

function evictOldest(map: Map<string, string>): void {
  if (map.size < LID_MAP_MAX) return;
  const first = map.keys().next().value;
  if (first !== undefined) map.delete(first);
}

/** Simpan pasangan. `lid` harus sudah lewat lidKey, `phone` hanya digit. Return true kalau ada yang berubah. */
export function setLidPn(lid: string, phone: string): boolean {
  if (!lid || !phone) return false;
  const changed = lidToPnMap.get(lid) !== phone;
  if (changed) {
    if (!lidToPnMap.has(lid)) evictOldest(lidToPnMap);
    lidToPnMap.set(lid, phone);
  }
  if (pnToLidMap.get(phone) !== lid) {
    if (!pnToLidMap.has(phone)) evictOldest(pnToLidMap);
    pnToLidMap.set(phone, lid);
  }
  return changed;
}

export const getPnByLid = (lid: string): string | undefined => lidToPnMap.get(lid);
export const getLidByPn = (phone: string): string | undefined => pnToLidMap.get(phone);

/** Cari lid dari peta terbalik lewat scan (dipakai kalau pnToLidMap belum terisi). */
export function findLidByScan(phone: string): string | undefined {
  for (const [lid, pn] of lidToPnMap) {
    if (pn === phone) {
      pnToLidMap.set(phone, lid);
      return lid;
    }
  }
  return undefined;
}

export const lidMapSize = (): number => lidToPnMap.size;
