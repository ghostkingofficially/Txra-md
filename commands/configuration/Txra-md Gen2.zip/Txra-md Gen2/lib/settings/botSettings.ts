import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { promises as fs } from "node:fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const SETTINGS_DIR = join(__dirname, "../../db/settings/");
const SETTINGS_PATH = join(SETTINGS_DIR, "bot-settings.json");

export const THUMB_LARGE_TYPES = ["location", "product", "linkpreview", "image", "catalog"];
export const isThumbLargeType = (v) =>
  typeof v === "string" && THUMB_LARGE_TYPES.includes(v);

export const DEFAULT_SETTINGS = Object.freeze({
  autoReload: Object.freeze({ enabled: true }),
  autoPtv: Object.freeze({ enabled: false, every: 50, source: "", counter: 0 }),
  thumbLarge: Object.freeze({ type: "linkpreview" }),
});

function cloneDefaults() {
  return {
    autoReload: { ...DEFAULT_SETTINGS.autoReload },
    autoPtv: { ...DEFAULT_SETTINGS.autoPtv },
    thumbLarge: { ...DEFAULT_SETTINGS.thumbLarge },
  };
}

function sanitizeEvery(n, fallback) {
  const v = Math.trunc(Number(n));
  return Number.isFinite(v) && v > 0 ? v : fallback;
}

function merge(base, patch) {
  const next = cloneDefaults();
  next.autoReload.enabled = typeof patch?.autoReload?.enabled === "boolean" ? patch.autoReload.enabled : base.autoReload.enabled;
  next.autoPtv.enabled = typeof patch?.autoPtv?.enabled === "boolean" ? patch.autoPtv.enabled : base.autoPtv.enabled;
  next.autoPtv.every = patch?.autoPtv?.every !== undefined ? sanitizeEvery(patch.autoPtv.every, base.autoPtv.every) : base.autoPtv.every;
  next.autoPtv.source = typeof patch?.autoPtv?.source === "string" ? patch.autoPtv.source : base.autoPtv.source;
  next.autoPtv.counter = Number.isFinite(patch?.autoPtv?.counter) ? Math.max(0, Math.trunc(patch.autoPtv.counter)) : base.autoPtv.counter;
  next.thumbLarge.type = isThumbLargeType(patch?.thumbLarge?.type) ? patch.thumbLarge.type : base.thumbLarge.type;
  return next;
}

let cached = null;
let saveTimer = null;
let savePending = null;

async function persistNow() {
  if (!cached) return;
  await fs.mkdir(SETTINGS_DIR, { recursive: true }).catch(() => {});
  const tmp = SETTINGS_PATH + ".tmp";
  await fs.writeFile(tmp, JSON.stringify(cached, null, 2), "utf8");
  await fs.rename(tmp, SETTINGS_PATH); 
}

export function saveSettings(immediate = false) {
  if (immediate) {
    if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
    savePending = persistNow();
    return savePending;
  }
  if (!saveTimer) {
    saveTimer = setTimeout(() => {
      saveTimer = null;
      savePending = persistNow();
    }, 300);
  }
  return savePending ?? Promise.resolve();
}

export async function flushSettings() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; await persistNow(); return; }
  if (savePending) await savePending;
}

export async function loadSettings() {
  if (cached) return cached;
  try {
    const raw = await fs.readFile(SETTINGS_PATH, "utf8");
    cached = merge(cloneDefaults(), JSON.parse(raw));
  } catch {
    cached = cloneDefaults();
  }
  return cached;
}

export function getSettings() {
  return cached ?? cloneDefaults();
}

export async function updateSettings(patch) {
  await loadSettings();
  cached = merge(cached, patch);
  await saveSettings(true);
  return cached;
}

export async function bumpAutoPtvCounter() {
  const s = await loadSettings();
  if (!s.autoPtv.enabled || !s.autoPtv.source) return { counter: s.autoPtv.counter, due: false };
  s.autoPtv.counter += 1;
  const due = s.autoPtv.counter >= Math.max(1, s.autoPtv.every);
  if (due) s.autoPtv.counter = 0;
  saveSettings(false); // debounce
  return { counter: s.autoPtv.counter, due };
}