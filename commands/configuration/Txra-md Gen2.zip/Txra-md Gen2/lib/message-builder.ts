// Central Zapo-JS MessageBuilder v4.7 export.
// This entry point intentionally does not import Baileys.
// All transport, media upload, message IDs, and relay operations use Zapo-JS.

export const VERSION = "4.7";

export {
  BaseBuilder,
  Button,
  ButtonV2,
  Carousel,
  newMessageId,
} from "../helpers/utils/button-messages/index.ts";

export {
  AIRich,
  AIRichError,
  ItemNotFoundError,
  DuplicateIdError,
  InvalidTargetError,
  ContentValidationError,
} from "../helpers/utils/rich-messages/index.ts";

export { Toolkit } from "../helpers/utils/toolkit.ts";
export type {
  SplitOptions,
  WAMessage,
} from "../helpers/utils/button-messages/index.ts";
export type {
  BuildOptions,
  SendOptions,
  NodeOptions,
} from "../helpers/utils/rich-messages/index.ts";
