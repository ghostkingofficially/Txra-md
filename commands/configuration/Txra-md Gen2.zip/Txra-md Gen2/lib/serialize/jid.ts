export const WAJIDDomains = {
  WHATSAPP: 0,
  LID: 1,
  HOSTED: 128,
  HOSTED_LID: 129,
};

export interface DecodedJid {
  server: string;
  user: string;
  domainType: number;
  device?: number;
  agent?: number;
}

export const jidEncode = (
  user: string | number | null | undefined,
  server: string,
  device?: number,
  agent?: number,
): string =>
  `${user || ""}${agent ? `_${agent}` : ""}${device ? `:${device}` : ""}@${server}`;

export const jidDecode = (jid: string): DecodedJid | undefined => {
  const sepIdx = typeof jid === "string" ? jid.indexOf("@") : -1;
  if (sepIdx < 0) return undefined;
  const server = jid.slice(sepIdx + 1);
  const userCombined = jid.slice(0, sepIdx);
  const parts = userCombined.split(":");
  const userAgent = parts[0];
  const device = parts[1];
  const ua = (userAgent || "").split("_");
  const user = ua[0];
  const agent = ua[1];

  let domainType = WAJIDDomains.WHATSAPP;
  if (server === "lid") domainType = WAJIDDomains.LID;
  else if (server === "hosted") domainType = WAJIDDomains.HOSTED;
  else if (server === "hosted.lid") domainType = WAJIDDomains.HOSTED_LID;
  else if (agent) domainType = parseInt(agent, 10);

  return {
    server,
    user,
    domainType,
    device: device ? Number(device) : undefined,
    agent: agent ? Number(agent) : undefined,
  };
};

export const jidNormalizedUser = (jid: string): string => {
  const result = jidDecode(jid);
  if (!result) return "";
  const { user, server } = result;
  return jidEncode(user, server === "c.us" ? "s.whatsapp.net" : server);
};

export const areJidsSameUser = (jid1: string, jid2: string): boolean => {
  const a = jidDecode(jid1);
  const b = jidDecode(jid2);
  return (a && a.user) === (b && b.user);
};


export const isLidJid = (jid: string): boolean => jid?.endsWith("@lid") ?? false;
export const isGroupJid = (jid: string): boolean => jid?.endsWith("@g.us") ?? false;
export const isNewsletterJid = (jid: string): boolean => jid?.endsWith("@newsletter") ?? false;
export const isStatusJid = (jid: string): boolean => jid === "status@broadcast";

export function extractPhoneFromJid(jid: string): string {
  if (!jid) return "";
  return jid.split("@")[0].split(":")[0].replace(/\D/g, "");
}

export function resolveJid(input: string | null | undefined): string | null {
  if (!input) return null;
  if (typeof input !== "string") return null;

  if (input.endsWith("@s.whatsapp.net") || input.endsWith("@lid")) return input;
  if (input.endsWith("@g.us")) return input;
  if (input.endsWith("@newsletter")) return input;
  if (/^\d+$/.test(input)) return `${input}@s.whatsapp.net`;
  if (/^\d+:\d+@lid$/.test(input)) return input;

  return null;
}