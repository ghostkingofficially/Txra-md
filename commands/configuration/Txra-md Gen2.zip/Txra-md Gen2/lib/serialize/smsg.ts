import type { WaClient } from "zapo-js";
import {
  areJidsSameUser,
  extractPhoneFromJid,
  isGroupJid,
  isNewsletterJid,
  jidNormalizedUser,
} from "./jid.ts";
import { extractMessageContent, getContentType, parseMessage } from "./content.ts";
import { escapeRegExp } from "./util.ts";
import { detectMedia, getTextBody } from "../func/parseMessages.ts";
import type { MediaDetection } from "../func/parseMessages.ts";

export interface SerializedMessage {
  key: Record<string, any>;
  message?: Record<string, any>;
  chat: string;
  sender: string;
  senderPn?: string;
  fromMe: boolean;
  isGroup: boolean;
  isNewsletter: boolean;
  id: string;
  device: string;
  isBaileys: boolean;
  name: string;
  pushName: string;
  mtype?: string;
  msg?: Record<string, any>;
  mentionedJid: string[];
  mentionedNumbers: string[];
  text: string;
  prefix: string;
  command: string;
  args: string[];
  input: string;
  expiration: number;
  timestamps: number;
  isMedia: boolean;
  /** Detail media (termasuk media di dalam rich response). null kalau bukan media. */
  media?: MediaDetection | null;
  isQuoted: boolean;
  isForwarded: boolean;
  isSampled: boolean;
  isQuestion: boolean;
  quoted?: Record<string, any>;
  location?: Record<string, any>;
  download?: (saveToFile?: boolean) => Promise<Uint8Array | string>;
  copy: () => SerializedMessage;
  forward: (jid: string, forceForward?: boolean) => Promise<any>;
  copyNForward: (jid: string, forceForward?: boolean, options?: any) => Promise<any>;
  cMod: (jid: string, text?: string, sender?: string, options?: any) => Promise<any>;
  delete: () => Promise<any>;
  react: (emoji: string) => Promise<any>;
  reply: (text: string | Record<string, any>, options?: any) => Promise<any>;
}

const SENT_IDS_MAX = 500;
const sentIds: Set<string> = ((globalThis as any).__botSentIds ??= new Set<string>());
type ReplyHook = (m: SerializedMessage, client: WaClient, text: string, options?: any) => Promise<any>;
let replyHook: ReplyHook | null = null;

export function setReplyHook(hook: ReplyHook | null): void {
  replyHook = hook;
}

export function rememberSentId(id?: string | null): void {
  if (!id) return;
  sentIds.add(id);
  if (sentIds.size > SENT_IDS_MAX) {
    const first = sentIds.values().next().value;
    if (first !== undefined) sentIds.delete(first);
  }
}

export function isBotSentId(id?: string | null): boolean {
  return !!id && sentIds.has(id);
}

type Credentials = {
  meJid?: string | null;
  meLid?: string | null;
  meDisplayName?: string | null;
  pushName?: string | null;
};

function getCreds(client: WaClient): Credentials {
  try {
    return ((client as any).getCredentials?.() ?? {}) as Credentials;
  } catch {
    return {};
  }
}

// Normalisasi JID yang aman: tidak pernah melempar error dan menerima undefined.
function safeJid(jid?: string | null): string {
  if (!jid) return "";
  try {
    return jidNormalizedUser(jid) || "";
  } catch {
    return String(jid);
  }
}

function extractRawText(message?: Record<string, any> | null): string {
  if (!message) return "";
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    message.ephemeralMessage?.message?.conversation ||
    message.ephemeralMessage?.message?.extendedTextMessage?.text ||
    message.viewOnceMessage?.message?.imageMessage?.caption ||
    message.documentWithCaptionMessage?.message?.documentMessage?.caption ||
    ""
  );
}

export function smsg(
  event: Record<string, any>,
  client: WaClient,
): SerializedMessage | undefined {
  if (!event?.message) return undefined;

  const creds = getCreds(client);
  const meJid = safeJid(creds.meJid);
  const meLid = safeJid(creds.meLid);
  const meName = creds.meDisplayName ?? creds.pushName ?? "";

  const m: Partial<SerializedMessage> = {};

  // ─── Key ───
  if (event.key) {
    const keys = event.key;
    const remoteJid: string = keys.remoteJid || meJid || "";
    const participant = keys.participant
      ? safeJid(keys.participant)
      : keys.fromMe
        ? meLid || meJid
        : undefined;

    m.key = {
      remoteJid,
      remoteJidAlt: keys.remoteJidAlt || keys.remoteJid || "",
      fromMe: keys.fromMe || false,
      id: keys.id,
      participant,
      participantPn: keys.participantAlt ? safeJid(keys.participantAlt) : undefined,
      participantAlt: keys.participantAlt ? safeJid(keys.participantAlt) : undefined,
      senderUsername: keys.senderUsername ?? undefined,
      recipientUsername: keys.recipientUsername ?? undefined,
      senderDevice: keys.senderDevice ?? 0,
      addressingMode: keys.addressingMode || "lid",
    };

    m.isGroup = isGroupJid(remoteJid);
    m.isNewsletter = isNewsletterJid(remoteJid);

    if (m.isNewsletter) {
      m.chat = remoteJid;
      m.sender = m.key.fromMe ? meJid : remoteJid;
    } else {
      m.chat = m.isGroup
        ? safeJid(remoteJid)
        : safeJid(keys.remoteJidAlt || remoteJid);
      m.sender = m.isGroup
        ? safeJid(keys.participantAlt || keys.participant || (keys.fromMe ? meJid : ""))
        : m.key.fromMe
          ? meJid
          : m.chat;
    }

    m.fromMe = !!m.key.fromMe;
    m.id = String(keys.id ?? "");
    m.device = /^3A/.test(m.id)
      ? "ios"
      : m.id.startsWith("3EB")
        ? "web"
        : /^.{21}/.test(m.id)
          ? "android"
          : /^.{18}/.test(m.id)
            ? "desktop"
            : "unknown";
    m.isBaileys =
      m.id.startsWith("7EPP") ||
      m.id.startsWith("3EB") ||
      !["android", "ios"].includes(m.device);
  } else {
    m.isGroup = false;
    m.isNewsletter = false;
    m.chat = "";
    m.sender = "";
    m.fromMe = false;
    m.id = "";
    m.device = "unknown";
    m.isBaileys = false;
    m.key = {};
  }

  // ─── Nama & push name ───
  m.pushName = event.pushName ?? "";
  m.name = m.key.fromMe ? meName : (event.pushName ?? "");

  m.message =
    parseMessage(event.message, extractMessageContent) ?? (event.message as Record<string, any>);
  if (!m.message || typeof m.message !== "object") return undefined;

  m.mtype = getContentType(m.message) || Object.keys(m.message)[0];
  if (!m.mtype) return undefined;

  m.msg =
    parseMessage(m.message[m.mtype], extractMessageContent) || m.message[m.mtype];

  // ─── Mentions ───
  const rawMentioned = [
    ...(m.msg?.contextInfo?.mentionedJid ?? []),
    ...(m.msg?.contextInfo?.groupMentions?.map((v: any) => v.groupJid) ?? []),
  ];
  m.mentionedJid = rawMentioned
    .map((jid: string) => {
      try {
        return jidNormalizedUser(jid);
      } catch {
        return null;
      }
    })
    .filter(Boolean) as string[];
  m.mentionedNumbers = m.mentionedJid;

  // ─── Text extraction ───
  let resolvedText: string =
    (typeof m.msg === "string" ? (m.msg as string) : "") ||
    m.msg?.text ||
    m.msg?.conversation ||
    m.msg?.caption ||
    m.message?.conversation ||
    m.msg?.selectedButtonId ||
    m.msg?.singleSelectReply?.selectedRowId ||
    m.msg?.selectedId ||
    m.msg?.contentText ||
    m.msg?.selectedDisplayText ||
    m.msg?.title ||
    m.msg?.name ||
    "";

    if (!resolvedText) resolvedText = extractRawText(m.message);
  if (!resolvedText) resolvedText = extractRawText(event.message);
    if (!resolvedText) resolvedText = getTextBody(m.message) || getTextBody(event.message);

  if (!resolvedText && (m.mtype === "locationMessage" || m.mtype === "liveLocationMessage")) {
    const loc = m.msg;
    if (loc?.degreesLatitude !== undefined) {
      resolvedText = `${loc.degreesLatitude},${loc.degreesLongitude}`;
    }
  }

  if (!resolvedText && m.mtype === "interactiveResponseMessage") {
    try {
      const nfr = m.msg?.nativeFlowResponseMessage;
      if (nfr?.paramsJson) {
        const parsed = JSON.parse(nfr.paramsJson);
        resolvedText = parsed?.id || parsed?.title || nfr.name || "";
      } else {
        resolvedText = nfr?.name || "";
      }
    } catch {
      resolvedText = m.msg?.nativeFlowResponseMessage?.name || "";
    }
  }

  if (!resolvedText && m.mtype === "buttonsResponseMessage") {
    resolvedText = m.msg?.selectedButtonId || m.msg?.selectedDisplayText || "";
  }
  if (!resolvedText && m.mtype === "listResponseMessage") {
    resolvedText = m.msg?.singleSelectReply?.selectedRowId || m.msg?.selectedDisplayText || "";
  }
  if (!resolvedText && m.mtype === "templateButtonReplyMessage") {
    resolvedText = m.msg?.selectedId || m.msg?.selectedDisplayText || "";
  }

  m.text = typeof resolvedText === "string" ? resolvedText : String(resolvedText ?? "");

  // ─── Location helper ───
  if (m.mtype === "locationMessage" || m.mtype === "liveLocationMessage") {
    m.location = {
      lat: m.msg?.degreesLatitude,
      lng: m.msg?.degreesLongitude,
      name: m.msg?.name || "",
      address: m.msg?.address || "",
      url: m.msg?.url || "",
    };
  }

  const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓=|/~!?@#%^&.©^]/i;
  m.prefix = "";
  m.command = "";
  m.args = [];
  m.input = "";

  m.expiration = m.msg?.contextInfo?.expiration || event.expirationSeconds || 0;
  m.timestamps =
    typeof event.timestampSeconds === "number"
      ? event.timestampSeconds * 1000
      : (m.msg?.timestampMs ?? Date.now());

  // ─── Media flags ───
  const mainMedia = detectMedia(m.message);
  m.media = mainMedia;
  m.isMedia = !!m.msg?.mimetype || !!m.msg?.thumbnailDirectPath || !!mainMedia;
  m.isQuoted = false;
  const ci = m.msg?.contextInfo || {};
  m.isForwarded = ci.isForwarded || false;
  m.isSampled = ci.isSampled || false;
  m.isQuestion = ci.isQuestion || false;

  if (m.isMedia && (mainMedia ? mainMedia.downloadable : true)) {
    m.download = async (saveToFile = false) => {
      try {
        if (saveToFile) {
          const path = `./media/download_${Date.now()}`;
          await client.message.downloadToFile(event as any, path);
          return path;
        }
        return await client.message.downloadBytes(event as any);
      } catch (err) {
        console.error("[smsg] download error:", (err as Error).message);
        throw err;
      }
    };
  }

  // ─── Quoted message ───
  if (m.msg?.contextInfo?.quotedMessage) {
    const ctx = m.msg.contextInfo;
    const quoted: Record<string, any> = {};
    quoted.message = parseMessage(ctx.quotedMessage, extractMessageContent);

    if (quoted.message && typeof quoted.message === "object") {
      m.isQuoted = true;
      quoted.mtype = getContentType(quoted.message) || Object.keys(quoted.message)[0];
      quoted.msg =
        parseMessage(quoted.message[quoted.mtype], extractMessageContent) ||
        quoted.message[quoted.mtype];

      const quotedParticipant = safeJid(ctx.participant);

      quoted.key = {
        remoteJid: ctx.remoteJid || m.chat,
        participant: quotedParticipant,
        fromMe: areJidsSameUser(quotedParticipant, meJid),
        id: ctx.stanzaId,
      };

      const qm = ctx.quotedMessage;
      const qt = Object.keys(qm)[0];
      const qMentioned = [
        ...(qm[qt]?.contextInfo?.mentionedJid ?? []),
        ...(qm[qt]?.contextInfo?.groupMentions?.map((v: any) => v.groupJid) ?? []),
      ];
      quoted.mentionedLid = qMentioned;
      quoted.mentionedJid = qMentioned
        .map((jid: string) => {
          try {
            return jidNormalizedUser(jid);
          } catch {
            return null;
          }
        })
        .filter(Boolean);
      quoted.sender = quoted.key.participant || quoted.key.remoteJid || null;
      quoted.chat = /g\.us|status/.test(ctx.remoteJid || "")
        ? quoted.key.participant
        : quoted.key.remoteJid;
      quoted.fromMe = quoted.key.fromMe;
      quoted.id = ctx.stanzaId;
      const qid = String(quoted.id ?? "");
      quoted.device = /^3A/.test(qid)
        ? "ios"
        : /^3E/.test(qid)
          ? "web"
          : /^.{21}/.test(qid)
            ? "android"
            : /^.{18}/.test(qid)
              ? "desktop"
              : "unknown";
      quoted.media = detectMedia(quoted.message);
      quoted.isMedia = !!quoted.msg?.mimetype || !!quoted.msg?.thumbnailDirectPath || !!quoted.media;
      quoted.isGroup = !!quoted.chat?.endsWith?.("@g.us");
      quoted.participant = quotedParticipant;
      quoted.text =
        (typeof quoted.msg === "string" ? quoted.msg : "") ||
        quoted.msg?.text ||
        quoted.msg?.caption ||
        quoted.message?.conversation ||
        quoted.msg?.selectedButtonId ||
        quoted.msg?.singleSelectReply?.selectedRowId ||
        quoted.msg?.selectedId ||
        quoted.msg?.contentText ||
        quoted.msg?.selectedDisplayText ||
        quoted.msg?.title ||
        quoted.msg?.name ||
        extractRawText(quoted.message) ||
        "";
      quoted.text = String(quoted.text);
      quoted.prefix = prefixRegex.test(quoted.text)
        ? (quoted.text.match(prefixRegex)?.[0] ?? "")
        : "";
      quoted.command =
        quoted.text && quoted.text.replace(quoted.prefix, "").trim().split(/ +/).shift();
      quoted.args =
        quoted.text
          .trim()
          .replace(new RegExp("^" + escapeRegExp(quoted.prefix), "i"), "")
          .replace(quoted.command ?? "", "")
          .split(/ +/)
          .filter((a: string) => a) ?? [];
      quoted.input = quoted.args.join(" ").trim() || quoted.text;

      quoted.react = async (emot: string) => {
        await client.message.send(m.chat!, {
          type: "reaction",
          emoji: emot,
          target: quoted.key,
        } as any);
      };

      if (quoted.isMedia && (quoted.media ? quoted.media.downloadable : true)) {
        quoted.download = async (saveToFile = false) => {
          const quotedEvent = {
            key: quoted.key,
            message: quoted.message,
          };
          if (saveToFile) {
            const path = `./media/quoted_${Date.now()}`;
            await client.message.downloadToFile(quotedEvent as any, path);
            return path;
          }
          return await client.message.downloadBytes(quotedEvent as any);
        };
      }

      quoted.reply = async (text: string, chatId?: string) => {
        const res: any = await client.message.send(chatId || m.chat!, text, {
          quote: quoted.key,
        } as any);
        rememberSentId(res?.id);
        return res;
      };

      quoted.copy = () => smsg(event, client);
      quoted.fakeObj = {
        key: {
          fromMe: quoted.fromMe,
          remoteJid: quoted.chat,
          id: quoted.id,
        },
        message: quoted.msg,
        ...(m.isGroup ? { participant: quoted.sender } : {}),
      };

      quoted.forward = async (jid: string) =>
        client.message.send(jid, quoted.msg, { forward: true } as any);

      quoted.copyNForward = async (jid: string) =>
        client.message.send(jid, quoted.message, { forward: true } as any);

      quoted.cMod = async (jid: string, text = "") => client.message.send(jid, text);

      quoted.delete = async () =>
        client.message.send(m.chat!, { type: "revoke", target: quoted.key } as any);

      m.quoted = quoted;
    }
  }

  // ─── Top-level helpers ───
  m.copy = () => smsg(event, client)!;
  m.forward = async (jid: string) =>
    client.message.send(jid, m.msg as any, { forward: true } as any);
  m.copyNForward = async (jid: string) =>
    client.message.send(jid, m.message as any, { forward: true } as any);
  m.cMod = async (jid: string, text = "") => client.message.send(jid, text);
  m.delete = async () =>
    client.message.send(m.chat!, { type: "revoke", target: m.key! } as any);
  m.react = async (emot: string) =>
    client.message.send(m.chat!, { type: "reaction", emoji: emot, target: m.key! } as any);

  m.reply = async (pesan: string | Record<string, any>, options?: any) => {
    const mentions = options?.mentions ?? [];
    const content: any =
      pesan && typeof pesan === "object"
        ? pesan
        : pesan
          ? String(pesan)
          : options && typeof options !== "object"
            ? String(options)
            : "";
    if (!content) return;

    if (replyHook && options?.fake !== false) {
      const hooked = await replyHook(
        m,
        client,
        typeof content === "string" ? content : String(content?.text ?? ""),
        options,
      );
      if (hooked !== undefined) return hooked;
    }
    try {
      const res: any = await client.message.send(m.chat!, content, {
        quote: event,
        mentions,
      } as any);
      rememberSentId(res?.id);
      return res;
    } catch (e) {
      console.error("[smsg] reply dengan quote gagal:", (e as Error).message);
      const res: any = await client.message.send(m.chat!, content, { mentions } as any);
      rememberSentId(res?.id);
      return res;
    }
  };

  return m as SerializedMessage;
}
