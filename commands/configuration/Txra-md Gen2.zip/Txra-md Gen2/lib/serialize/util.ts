
export function escapeRegExp(string: string): string {
  return string.replace(/[.*=+:\-?^${}()|[\]\\]|\s/g, "\\$&");
}

export function stringify(obj: unknown): string {
  return JSON.stringify(
    obj,
    (_key, value) => {
      if (value instanceof Uint8Array) {
        return `[Uint8Array ${value.length} bytes]`;
      }
      return value;
    },
    2,
  );
}

export function capitalize(str: string): string {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
}