
import { ALL_MESSAGE_TYPES, MESSAGE_MEDIA_TYPE } from "./constants.ts";

type AnyMessage = Record<string, any>;

const FUTURE_PROOF_KEYS = [
  "ephemeralMessage",
  "viewOnceMessage",
  "documentWithCaptionMessage",
  "deviceSentMessage", 
  "viewOnceMessageV2", 
  "viewOnceMessageV2Extension",
  "editedMessage",
  "associatedChildMessage",
  "groupStatusMessage",
  "groupStatusMessageV2", 
  "eventCoverImage", 
  "botInvokeMessage",
  "lottieStickerMessage", 
  "pollCreationOptionImageMessage",
  "groupMentionedMessage", 
  "statusMentionMessage", 
  "groupStatusMentionMessage",
  "pollCreationMessageV4",
  "statusAddYours",
  "limitSharingMessage",
  "botTaskMessage",
  "questionMessage", 
  "botForwardedMessage",
  "questionReplyMessage",
];


export function normalizeMessageContent(content: AnyMessage | undefined): AnyMessage | undefined {
  if (!content) return undefined;

  for (let i = 0; i < 5; i++) {
    let inner: AnyMessage | undefined;
    for (const key of FUTURE_PROOF_KEYS) {
      if (content[key]) {
        inner = content[key];
        break;
      }
    }
    if (!inner) break;
    content = inner.message;
    if (!content) return undefined;
  }
  return content;
}


export function extractMessageContent(content: AnyMessage | undefined): AnyMessage | undefined {
  const extractFromTemplate = (msg: AnyMessage): AnyMessage => {
    if (msg.imageMessage) return { imageMessage: msg.imageMessage };
    if (msg.documentMessage) return { documentMessage: msg.documentMessage };
    if (msg.videoMessage) return { videoMessage: msg.videoMessage };
    if (msg.locationMessage) return { locationMessage: msg.locationMessage };
    return {
      conversation:
        "contentText" in msg
          ? msg.contentText
          : "hydratedContentText" in msg
            ? msg.hydratedContentText
            : "",
    };
  };

  content = normalizeMessageContent(content);
  if (!content) return undefined;

  if (content.buttonsMessage) return extractFromTemplate(content.buttonsMessage);
  if (content.templateMessage?.hydratedFourRowTemplate)
    return extractFromTemplate(content.templateMessage.hydratedFourRowTemplate);
  if (content.templateMessage?.hydratedTemplate)
    return extractFromTemplate(content.templateMessage.hydratedTemplate);
  if (content.templateMessage?.fourRowTemplate)
    return extractFromTemplate(content.templateMessage.fourRowTemplate);

  return content;
}


export function getContentType(content: AnyMessage | undefined): string | null {
  if (!content) return null;
  const keys = Object.keys(content);
  for (const type of ALL_MESSAGE_TYPES) {
    if (keys.includes(type)) return type;
  }
  return (
    keys.find((k) => k.endsWith("Message") || k.endsWith("V2") || k.endsWith("V3")) ?? null
  );
}


export function parseMessage(
  content: AnyMessage,
  extractFn: (c: AnyMessage | undefined) => AnyMessage | undefined,
): AnyMessage {
  content = extractFn(content)!;

  if (content?.viewOnceMessageV2Extension) {
    content = content.viewOnceMessageV2Extension.message;
  }
  if (content?.protocolMessage && content.protocolMessage.type == 14) {
    content = content.protocolMessage[getContentType(content.protocolMessage)!];
  }
  if (content?.message) {
    content = content.message[getContentType(content.message)!];
  }
  return content;
}


export function getMediaTypeCode(message: AnyMessage): number {
  const mtype = getContentType(message);
  if (!mtype) return MESSAGE_MEDIA_TYPE.NONE;

  const upper = mtype.replace(/[A-Z]/g, (c) => "_" + c).toUpperCase();
  return (
    MESSAGE_MEDIA_TYPE[upper as keyof typeof MESSAGE_MEDIA_TYPE] ??
    MESSAGE_MEDIA_TYPE[mtype.toUpperCase() as keyof typeof MESSAGE_MEDIA_TYPE] ??
    MESSAGE_MEDIA_TYPE.NONE
  );
}