import { setGroupMaxWarnings } from "../../src/moderation/index.ts";

export default {
  name: "setmaxwarning",
  alias: ["setmaxwarn", "maxwarning"],
  category: "groupmenu",
  description: "Set the warning limit for the group",
  usage: ".setmaxwarning <number>",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const value = Number(ctx.args?.[0]);
    if (!Number.isInteger(value) || value < 1 || value > 100) {
      return m.reply(`Usage: ${ctx.prefix}setmaxwarning <1-100>`);
    }

    const maximum = await setGroupMaxWarnings(m.chat, value);
    return m.reply(`The group warning limit is now ${maximum}.`);
  },
};