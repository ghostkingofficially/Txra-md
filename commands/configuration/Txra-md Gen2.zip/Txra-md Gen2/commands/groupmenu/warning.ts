import { changeGroupWarning, getGroupModerationOptions } from "../../src/moderation/index.ts";

function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "warning",
  alias: ["warn"],
  category: "groupmenu",
  description: "Add a warning to a group member",
  usage: ".warning @user",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = getTarget(m);
    if (!target) return m.reply(`Usage: ${ctx.prefix}warning @user`);

    const count = await changeGroupWarning(m.chat, target, 1);
    const options = await getGroupModerationOptions(m.chat);
    const maximum = Math.max(1, Number(options.maxWarnings ?? 3));

    return m.reply({
      text: `@${target.split("@")[0]} now has ${count}/${maximum} warning(s).`,
      mentions: [target],
    });
  },
};
