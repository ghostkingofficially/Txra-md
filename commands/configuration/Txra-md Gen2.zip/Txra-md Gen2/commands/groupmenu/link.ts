export default {
  name: "link",
  alias: ["gclink", "grouplink"],
  category: "groupmenu",
  description: "Get the group invite link",
  usage: ".link",
  isGroup: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const groupApi = ctx.client.group;
      const getInviteCode =
        groupApi.inviteCode ||
        groupApi.getInviteCode ||
        groupApi.createInvite;

      if (typeof getInviteCode !== "function") {
        return m.reply("The group invite API is not available.");
      }

      const result = await getInviteCode.call(groupApi, m.chat);
      const code =
        typeof result === "string"
          ? result
          : result?.code ||
            result?.inviteCode ||
            result?.invite_code;

      if (!code) {
        return m.reply("Unable to retrieve the group invite code.");
      }

      const inviteCode = String(code)
        .replace(/^https?:\/\/chat\.whatsapp\.com\//i, "")
        .replace(/^chat\.whatsapp\.com\//i, "")
        .trim();

      return m.reply(`https://chat.whatsapp.com/${inviteCode}`);
    } catch (error) {
      return m.reply(
        `Failed to retrieve the group invite link: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
