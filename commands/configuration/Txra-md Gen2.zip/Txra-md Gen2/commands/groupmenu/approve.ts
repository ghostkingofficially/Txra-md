function requestJid(request: any): string {
  return request?.jid || request?.phoneJid || request?.id || "";
}

function normalizeTarget(value: unknown): string {
  const raw = String(value || "").trim();
  if (!raw) return "";
  if (raw.includes("@")) return raw;
  const digits = raw.replace(/\D/g, "");
  return digits ? `${digits}@s.whatsapp.net` : "";
}

function sameUser(first: string, second: string): boolean {
  return first.split("@")[0].split(":")[0] === second.split("@")[0].split(":")[0];
}

function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "approve",
  alias: ["approveall", "accept"],
  category: "groupmenu",
  description: "Approve pending group join requests",
  usage: ".approve @user | all",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const group = (ctx.client as any).group;
      if (typeof group?.queryMembershipApprovalRequests !== "function" || typeof group?.approveMembershipRequests !== "function") {
        throw new Error("Zapo membership request API is not available.");
      }
      const result = await group.queryMembershipApprovalRequests(m.chat);
      const pending = Array.isArray(result) ? result : result?.requests || result?.pending || result?.participants || [];
      if (!pending.length) return m.reply("There are no pending join requests.");

      if (String(ctx.args?.[0] || "").toLowerCase() === "all") {
        const jids = pending.map(requestJid).filter(Boolean);
        await group.approveMembershipRequests(m.chat, jids);
        return m.reply(`Approved ${jids.length} pending join request(s).`);
      }

      const target = normalizeTarget(getTarget(m) || ctx.args?.[0]);
      if (!target) return m.reply(`Usage: ${ctx.prefix}approve @user\nUse ${ctx.prefix}approve all to approve every pending request.`);
      const request = pending.find((item: any) => sameUser(requestJid(item), target));
      if (!request) return m.reply("That member is not in the pending request list.");
      const jid = requestJid(request);
      await group.approveMembershipRequests(m.chat, [jid]);
      return m.reply({ text: `Approved @${jid.split("@")[0]}.`, mentions: [jid] });
    } catch (error) {
      return m.reply(`Failed to approve join request: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
