import {
  getGroupModerationOptions,
  updateGroupModerationOption,
  type ModerationOption,
} from "../../src/moderation/index.ts";

const OPTION_META: Record<string, string> = {
  antiaudio: "Delete audio and voice messages",
  antidocument: "Delete document and file messages",
  antiimage: "Delete image and photo messages",
  antilink: "Block all detected links",
  antilinkgroup: "Block WhatsApp group invitation links",
  antispam: "Detect repeated messages sent too quickly",
  antisticker: "Delete sticker messages",
  antistatus: "Delete statuses that mention this group",
  antitoxic: "Block words listed in the toxic-word configuration",
  antivideo: "Delete video messages",
  autokick: "Remove a member after the warning limit is reached",
  goodbye: "Send a goodbye message when a member leaves",
  welcome: "Send a welcome message when a member joins",
};

function usage(prefix: string): string {
  return [
    "*Group Moderation Options*",
    "",
    `Usage: ${prefix}setoption <option>`,
    "",
    `• ${prefix}setoption list`,
    `• ${prefix}setoption status`,
    `• ${prefix}setoption antilink`,
    `• ${prefix}setoption antitoxic`,
    `• ${prefix}setoption antispam`,
  ].join("\n");
}

export default {
  name: "setoption",
  alias: ["setopt"],
  category: "groupmenu",
  description: "Enable or disable group moderation options",
  usage: ".setoption <option>",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const prefix = ctx.prefix || ".";
    const option = String(ctx.args?.[0] || "").toLowerCase();

    if (!option) return m.reply(usage(prefix));

    if (option === "list") {
      const lines = Object.entries(OPTION_META).map(
        ([name, description]) => `• ${name} — ${description}`,
      );
      return m.reply(`*Available Group Options*\n\n${lines.join("\n")}`);
    }

    const options = await getGroupModerationOptions(m.chat);

    if (option === "status") {
      const lines = Object.keys(OPTION_META).map(
        (name) => `• ${name}: ${options[name as ModerationOption] ? "Enabled" : "Disabled"}`,
      );
      return m.reply(`*Group Moderation Status*\n\n${lines.join("\n")}`);
    }

    if (!(option in OPTION_META)) {
      return m.reply(`Unknown option: ${option}\n\n${usage(prefix)}`);
    }

    const key = option as ModerationOption;
    const enabled = !Boolean(options[key]);
    await updateGroupModerationOption(m.chat, key, enabled);

    return m.reply(
      `${OPTION_META[option]} is now ${enabled ? "enabled" : "disabled"}.`,
    );
  },
};