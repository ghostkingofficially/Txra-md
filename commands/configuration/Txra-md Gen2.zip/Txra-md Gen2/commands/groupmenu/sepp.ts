export default {
  name: "setpp",
  alias: ["setgrouppp", "groupicon"],
  category: "groupmenu",
  description: "Change the group profile picture",
  usage: ".setpp with an image or reply to an image",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const source: any = m.isMedia ? m : m.quoted;
    if (!source?.download) return m.reply("Send an image with the command or reply to an image.");
    try {
      const profile = (ctx.client as any).profile;
      if (typeof profile?.setProfilePicture !== "function") throw new Error("Zapo profile.setProfilePicture() is not available.");
      const bytes = await source.download();
      await profile.setProfilePicture(bytes, m.chat);
      return m.reply("The group profile picture was updated.");
    } catch (error) {
      return m.reply(`Failed to update group profile picture: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
