export default {
  name: "setdesc",
  alias: ["setdescription"],
  category: "groupmenu",
  description: "Change the group description",
  usage: ".setdesc <description>",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const description = String(ctx.input || "").trim();
    if (!description) return m.reply(`Usage: ${ctx.prefix}setdesc <description>`);
    try {
      const group = (ctx.client as any).group;
      if (typeof group?.setDescription !== "function") throw new Error("Zapo group.setDescription() is not available.");
      await group.setDescription(m.chat, description);
      return m.reply("The group description was updated.");
    } catch (error) {
      return m.reply(`Failed to update group description: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
