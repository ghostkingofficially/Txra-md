const META_AI_JID = "867051314767696@bot";

export default {
  name: "addai",
  alias: ["addmetaai", "metaai"],
  category: "groupmenu",
  description: "Attempt to add Meta AI to the group",
  usage: ".addai",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const group = (ctx.client as any).group;
      if (typeof group?.addParticipants !== "function") {
        throw new Error("Zapo group.addParticipants() is not available.");
      }
      await group.addParticipants(m.chat, [META_AI_JID]);
      return m.reply("Meta AI was added to the group successfully.");
    } catch (error) {
      return m.reply(
        `Failed to add Meta AI: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
