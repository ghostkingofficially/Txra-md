import { toPtt } from "../../lib/func/converter.ts";

const COLOR_NAMES = new Set([
  "blue",
  "green",
  "yellow",
  "orange",
  "red",
  "purple",
  "gray",
  "black",
  "white",
  "cyan",
]);

const EMOJI_PATTERN = /^\p{Extended_Pictographic}/u;
const GROUP_ID_PATTERN = /^\d{10,20}@g\.us$/;

function cleanText(value: unknown): string {
  return String(value || "")
    .replace(/[^\S\n]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function getMime(message: any): string {
  return String(
    message?.media?.mimetype ||
      message?.mimetype ||
      message?.msg?.mimetype ||
      message?.message?.imageMessage?.mimetype ||
      message?.message?.videoMessage?.mimetype ||
      message?.message?.audioMessage?.mimetype ||
      message?.message?.stickerMessage?.mimetype ||
      "",
  );
}

function participantJid(participant: any): string {
  return participant?.jid || participant?.phoneNumber || participant?.id || "";
}

function isGroupId(value: string): boolean {
  return GROUP_ID_PATTERN.test(value);
}

function resolveGroupId(value: string, fallback: string): string {
  const normalized = value.trim();
  if (!normalized) return fallback;
  if (isGroupId(normalized)) return normalized;
  if (/^\d{10,20}$/.test(normalized)) return `${normalized}@g.us`;
  throw new Error("Invalid group ID. Use a group JID such as 120000000000000000@g.us.");
}

async function convertAudioToVoiceNote(source: Uint8Array): Promise<Uint8Array> {
  if (!source?.length) throw new Error("The audio file is empty.");

  const converted = await toPtt(source);
  if (!converted?.length) {
    throw new Error("Audio conversion returned an empty file.");
  }

  return new Uint8Array(converted);
}

function parseArguments(input: string, hasMedia: boolean) {
  const values = input
    .split(hasMedia ? /[|\s]+/ : "|")
    .map((value) => value.trim())
    .filter(Boolean);

  let text = "";
  let color = "";
  let emoji = "";
  let groupId = "";
  let statusName = "";

  for (const value of values) {
    if (isGroupId(value) || /^\d{10,20}$/.test(value)) {
      groupId = value;
    } else if (!color && COLOR_NAMES.has(value.toLowerCase())) {
      color = value.toLowerCase();
    } else if (!emoji && EMOJI_PATTERN.test(value)) {
      emoji = value;
    } else if (!text && !hasMedia) {
      text = value;
    } else if (!statusName) {
      statusName = value;
    }
  }

  return { text, color, emoji, groupId, statusName };
}

function getCaption(message: any, text: string): string {
  return cleanText(
    message?.text ||
      message?.caption ||
      message?.msg?.caption ||
      message?.quoted?.text ||
      message?.quoted?.caption ||
      text ||
      "",
  );
}

export default {
  name: "swgc",
  alias: ["up", "groupstatus"],
  category: "groupmenu",
  description: "Post text or media as a targeted group status",
  usage: ".swgc text | group-id | color | emoji | status-name",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const quoted = m.quoted || m;
      const mime = getMime(quoted);
      const hasMedia = Boolean(quoted?.isMedia || quoted?.media || mime);
      const input = String(m.input || ctx.args?.join(" ") || "").trim();
      const parsed = parseArguments(input, hasMedia);
      const targetGroup = resolveGroupId(parsed.groupId, m.chat);

      if (!targetGroup.endsWith("@g.us")) {
        return m.reply("This command requires a group chat or a valid group JID.");
      }

      if (typeof (ctx.client as any).group?.queryGroupMetadata !== "function") {
        throw new Error("Zapo group.queryGroupMetadata() is not available.");
      }
      const metadata: any = await (ctx.client as any).group.queryGroupMetadata(targetGroup);

      const recipients = (metadata?.participants || [])
        .map(participantJid)
        .filter(Boolean);

      if (!recipients.length) {
        return m.reply("No group recipients were found.");
      }

      const caption = getCaption(quoted, parsed.text);

      if (!caption && !hasMedia) {
        return m.reply(
          [
            "Usage examples:",
            "",
            `${ctx.prefix}swgc Hello everyone`,
            `${ctx.prefix}swgc Hello everyone | red`,
            `${ctx.prefix}swgc Hello everyone | red | 😂`,
            `${ctx.prefix}swgc Hello everyone | 120000000000000000@g.us`,
            "",
            "Reply to an image, video, audio, or sticker:",
            `${ctx.prefix}swgc`,
            `${ctx.prefix}swgc red | 😂`,
            `${ctx.prefix}swgc 120000000000000000@g.us`,
          ].join("\n"),
        );
      }

      let content: any;

      if (hasMedia) {
        if (typeof quoted.download !== "function") {
          throw new Error("The quoted media cannot be downloaded.");
        }

        const source = await quoted.download();

        if (/audio/i.test(mime)) {
          const audio = await convertAudioToVoiceNote(source);
          content = {
            type: "audio",
            media: audio,
            ptt: true,
            mimetype: "audio/ogg; codecs=opus",
          };
        } else if (/image/i.test(mime)) {
          content = {
            type: "image",
            media: source,
            caption,
            mimetype: mime || "image/jpeg",
          };
        } else if (/video/i.test(mime)) {
          content = {
            type: "video",
            media: source,
            caption,
            mimetype: mime || "video/mp4",
          };
        } else if (/sticker/i.test(mime)) {
          content = {
            type: "sticker",
            media: source,
            mimetype: mime || "image/webp",
          };
        } else {
          throw new Error("Only image, video, audio, and sticker media are supported.");
        }
      } else {
        content = {
          type: "text",
          text: caption,
        };
      }

      await ctx.client.status.send({
        content,
        recipients,
      });

      return m.reply(
        `Status uploaded successfully to ${targetGroup}.` +
          (parsed.color ? ` Color: ${parsed.color}.` : "") +
          (parsed.emoji ? ` Emoji: ${parsed.emoji}.` : "") +
          (parsed.statusName ? ` Name: ${parsed.statusName}.` : ""),
      );
    } catch (error) {
      return m.reply(
        `Status upload failed: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
