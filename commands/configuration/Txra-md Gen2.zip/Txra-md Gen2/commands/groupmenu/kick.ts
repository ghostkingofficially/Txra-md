function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "kick",
  alias: ["dor", "kik", "remove"],
  category: "groupmenu",
  description: "Remove a member from the group",
  usage: ".kick @user",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = getTarget(m);
    if (!target) {
      return m.reply(`Usage: ${ctx.prefix}kick @user\nMention or reply to the member you want to remove.`);
    }

    try {
      const group = (ctx.client as any).group;
      if (typeof group?.removeParticipants !== "function") {
        throw new Error("Zapo group.removeParticipants() is not available.");
      }
      await group.removeParticipants(m.chat, [target]);
      return m.reply({ text: `Member removed: @${target.split("@")[0]}.`, mentions: [target] });
    } catch (error) {
      return m.reply(`Failed to remove member: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
