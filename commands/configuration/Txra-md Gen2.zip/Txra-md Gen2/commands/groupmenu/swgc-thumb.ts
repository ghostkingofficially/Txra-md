import { toSquareJpeg } from "../../lib/func/image.ts";
import { getGroupMetadata } from "../../lib/group-metadata/index.ts";

const DEFAULT_URL = "https://about-trax.vercel.app";

const THEMES: Record<string, string> = {
  default: "65CBED",
  blue: "1E88E5",
  red: "E53935",
  green: "43A047",
  purple: "8E24AA",
  pink: "EC407A",
  orange: "FB8C00",
  yellow: "FDD835",
  turquoise: "00ACC1",
  black: "212121",
  white: "FAFAFA",
};

function hexToArgb(hex: string): number {
  return parseInt(`FF${hex.replace("#", "")}`, 16) >>> 0;
}

function isColor(value: string): boolean {
  const color = value.toLowerCase();
  return (
    color === "random" ||
    Boolean(THEMES[color]) ||
    /^#[0-9a-f]{6}$/i.test(color) ||
    /^\d{6,}$/.test(color)
  );
}

function parseColor(input: string): number {
  const color = input.trim().toLowerCase();
  if (!color) return hexToArgb(THEMES.default);

  if (color === "random") {
    const names = Object.keys(THEMES);
    const selected = names[Math.floor(Math.random() * names.length)];
    return hexToArgb(THEMES[selected]);
  }

  if (THEMES[color]) return hexToArgb(THEMES[color]);
  if (/^#[0-9a-f]{6}$/i.test(color)) return hexToArgb(color);
  if (/^\d+$/.test(color)) return Number(color) >>> 0;

  return hexToArgb(THEMES.default);
}

function parseExtras(fields: string[]) {
  let url = "";
  let imageUrl = "";
  let color = "";

  for (const field of fields) {
    if (!field) continue;

    if (/^https?:\/\/\S+\.(?:jpe?g|png|webp|gif)(?:\?\S*)?$/i.test(field)) {
      imageUrl = field;
    } else if (/^https?:\/\//i.test(field)) {
      url = field;
    } else if (isColor(field)) {
      color = field;
    }
  }

  return {
    url: url || DEFAULT_URL,
    imageUrl,
    color,
  };
}

function getMime(message: any): string {
  return String(
    message?.media?.mimetype ||
      message?.mimetype ||
      message?.msg?.mimetype ||
      message?.message?.imageMessage?.mimetype ||
      "",
  );
}

async function getThumbnail(message: any, imageUrl: string): Promise<Uint8Array | null> {
  const target = message?.quoted || message;
  const mime = getMime(target);

  if (/^image\//i.test(mime) && typeof target?.download === "function") {
    try {
      const bytes = await target.download();
      if (bytes?.length) return new Uint8Array(bytes);
    } catch {
      // Try the configured image URL below.
    }
  }

  if (!imageUrl) return null;

  try {
    const response = await fetch(imageUrl);
    if (!response.ok) throw new Error(`Thumbnail request failed: HTTP ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    return bytes.length ? bytes : null;
  } catch {
    return null;
  }
}

async function resizeThumbnail(bytes: Uint8Array | null): Promise<Uint8Array | null> {
  if (!bytes) return null;

  try {
    return new Uint8Array(await toSquareJpeg(bytes, 300));
  } catch {
    return bytes;
  }
}

export default {
  name: "swgcthumb",
  alias: ["swgc2", "suapabusa", "thumbnail"],
  category: "groupmenu",
  description: "Send a custom thumbnail link-preview message",
  usage: ".swgcthumb text|title|description|color|url|image-url",
  isGroup: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const input = String(m.input || ctx.args?.join(" ") || "").trim();

      if (input.toLowerCase() === "theme") {
        return m.reply([
          "Available themes:",
          ...Object.keys(THEMES).map((theme) => `• ${theme}`),
          "• random",
          "",
          "You can also use a hex color, for example: #ff5722",
        ].join("\n"));
      }

      if (!input) {
        return m.reply([
          "Usage:",
          `${ctx.prefix}swgcthumb text|title|description|color|url|image-url`,
          "",
          "Optional fields after description:",
          "• Theme or hex color",
          "• Website URL",
          "• Image URL",
          "",
          "You can also reply to an image for the thumbnail.",
          "",
          "Examples:",
          `${ctx.prefix}swgcthumb Hello everyone|Txra-md|Ghost King|blue`,
          `${ctx.prefix}swgcthumb Hello|Txra-md|Description|#ff5722`,
          `${ctx.prefix}swgcthumb theme`,
        ].join("\n"));
      }

      const [caption = "", title = "Txra-md", description = "", ...extraFields] = input
        .split("|")
        .map((value) => value.trim());

      const { url, imageUrl, color } = parseExtras(extraFields);
      const thumbnail = await resizeThumbnail(await getThumbnail(m, imageUrl));
      const text = `${caption}\n\n${url}`.trim();
      const backgroundArgb = parseColor(color);

      const content: any = {
        extendedTextMessage: {
          text,
          matchedText: url,
          canonicalUrl: url,
          description,
          title,
          backgroundArgb,
          previewType: 0,
          ...(thumbnail ? { jpegThumbnail: thumbnail } : {}),
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
          },
        },
      };

      const metadata: any = await getGroupMetadata(ctx.client, m.chat, { force: true });
      const recipients = (metadata?.participants || [])
        .map((participant: any) => participant?.jid || participant?.phoneNumber || participant?.id)
        .filter(Boolean);
      if (!recipients.length) return m.reply("No group recipients were found.");

      await ctx.client.status.send({ content, recipients });

      return m.reply("Thumbnail status sent successfully to the group.");
    } catch (error) {
      return m.reply(
        `Failed to send thumbnail message: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
