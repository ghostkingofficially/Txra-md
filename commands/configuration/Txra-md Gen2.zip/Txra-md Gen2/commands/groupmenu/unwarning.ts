import { changeGroupWarning } from "../../src/moderation/index.ts";

function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "unwarning",
  alias: ["unwarn", "clearwarning"],
  category: "groupmenu",
  description: "Remove one warning from a group member",
  usage: ".unwarning @user",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = getTarget(m);
    if (!target) return m.reply(`Usage: ${ctx.prefix}unwarning @user`);

    const count = await changeGroupWarning(m.chat, target, -1);

    return m.reply({
      text: `@${target.split("@")[0]} now has ${count} warning(s).`,
      mentions: [target],
    });
  },
};
