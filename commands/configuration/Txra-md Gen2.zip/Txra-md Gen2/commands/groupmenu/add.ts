function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "add",
  alias: ["addmember"],
  category: "groupmenu",
  description: "Add a member to the group",
  usage: ".add 255700000000",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = getTarget(m);
    if (!target) {
      return m.reply(
        `Usage: ${ctx.prefix}add 255700000000\nYou can also mention or reply to a member.`,
      );
    }

    try {
      const group = (ctx.client as any).group;
      if (typeof group?.addParticipants !== "function") {
        throw new Error("Zapo group.addParticipants() is not available.");
      }
      await group.addParticipants(m.chat, [target]);
      return m.reply({ text: `Member added: @${target.split("@")[0]}.`, mentions: [target] });
    } catch (error) {
      return m.reply(`Failed to add member: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
