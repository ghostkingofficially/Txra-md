function requestJid(request: any): string {
  return request?.jid || request?.phoneJid || request?.id || "";
}

export default {
  name: "listpendingmembers",
  alias: ["pendingmembers", "pending"],
  category: "groupmenu",
  description: "List pending group join requests",
  usage: ".listpendingmembers",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    try {
      const group = (ctx.client as any).group;
      if (typeof group?.queryMembershipApprovalRequests !== "function") {
        throw new Error("Zapo membership request API is not available.");
      }
      const result = await group.queryMembershipApprovalRequests(m.chat);
      const requests = Array.isArray(result) ? result : result?.requests || result?.pending || result?.participants || [];
      const jids = requests.map(requestJid).filter(Boolean);
      if (!jids.length) return m.reply("There are no pending join requests.");
      const text = ["*Pending Group Requests*", "", ...jids.map((jid: string) => `• @${jid.split("@")[0]}`)].join("\n");
      return m.reply({ text, mentions: jids });
    } catch (error) {
      return m.reply(`Failed to retrieve pending members: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
