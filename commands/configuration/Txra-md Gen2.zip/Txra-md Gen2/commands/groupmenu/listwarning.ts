import { listGroupWarnings } from "../../src/moderation/index.ts";

export default {
  name: "listwarning",
  alias: ["listwarn", "warnings"],
  category: "groupmenu",
  description: "List members with moderation warnings",
  usage: ".listwarning",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any) {
    try {
      const warnings = await listGroupWarnings(m.chat);

      if (!warnings.length) {
        return m.reply("There are no recorded warnings in this group.");
      }

      const text = [
        "*Group Warning List*",
        "",
        ...warnings.map(
          (warning) =>
            `• @${warning.jid.split("@")[0]} — ${warning.count} warning(s)`,
        ),
      ].join("\n");

      return m.reply({
        text,
        mentions: warnings.map((warning) => warning.jid),
      });
    } catch (error) {
      return m.reply(
        `Failed to retrieve warnings: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
