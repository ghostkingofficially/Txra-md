export default {
  name: "setname",
  alias: ["setsubject", "groupname"],
  category: "groupmenu",
  description: "Change the group name",
  usage: ".setname <name>",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const name = String(ctx.input || "").trim();
    if (!name) return m.reply(`Usage: ${ctx.prefix}setname <name>`);
    try {
      const group = (ctx.client as any).group;
      if (typeof group?.setSubject !== "function") throw new Error("Zapo group.setSubject() is not available.");
      await group.setSubject(m.chat, name);
      return m.reply("The group name was updated.");
    } catch (error) {
      return m.reply(`Failed to update group name: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
