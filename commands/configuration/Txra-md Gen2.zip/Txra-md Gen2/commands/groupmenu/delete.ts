export default {
  name: "del",
  alias: ["delete", "deleteMessage", "d"] ,
  category: "groupmenu",
  description: "Delete a quoted group message",
  usage: ".del while replying to a message",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any) {
    if (!m.quoted?.delete) {
      return m.reply("Reply to the message you want to delete.");
    }

    try {
      await m.quoted.delete();
    } catch (error) {
      return m.reply(
        `Failed to delete the message: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};