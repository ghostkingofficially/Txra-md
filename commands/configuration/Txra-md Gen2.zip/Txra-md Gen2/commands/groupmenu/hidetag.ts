export default {
  name: "hidetag",
  alias: ["ht"],
  category: "groupmenu",
  description: "Mention all group members without displaying the mention list",
  usage: ".hidetag [message]",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,
  needGroupMeta: true,

  async execute(m: any, ctx: any) {
    try {
      const participants = Array.isArray(
        ctx.groupMetadata?.participants,
      )
        ? ctx.groupMetadata.participants
        : [];

      const mentionedJid = participants
        .map((participant: any) => {
          return (
            participant.jid ||
            participant.phoneNumber ||
            participant.id ||
            participant.participant
          );
        })
        .filter(Boolean);

      if (!mentionedJid.length) {
        return m.reply("No group members were found.");
      }

      const input = String(ctx.input || m.quoted?.text || "").trim();

      const body = {
        albumMessage: {
          contextInfo: {
            mentionedJid,
          },
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
        },
      };

      await (ctx.client as any).message.send(m.chat, body, {
        quote: m.key,
      });

      if (input) {
        await m.reply(input);
      }
    } catch (error) {
      return m.reply(
        `Hidetag failed: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};
