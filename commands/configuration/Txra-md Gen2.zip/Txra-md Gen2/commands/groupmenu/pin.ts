export default {
  name: "pin",
  alias: ["p"],
  category: "groupmenu",
  description: "Pin a quoted message in the group",
  usage: ".pin [24h|7d|30d] while replying to a message",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = m.quoted?.key;
    if (!target) return m.reply("Reply to the message you want to pin.");

    const durationMap: Record<string, number> = {
      "24h": 86400,
      "7d": 604800,
      "30d": 2592000,
    };
    const durationSecs = durationMap[String(ctx.args?.[0] || "24h").toLowerCase()];
    if (!durationSecs) return m.reply("Use one of these durations: 24h, 7d, or 30d.");

    try {
      await ctx.client.message.send(m.chat, {
        type: "pin",
        target,
        durationSecs,
      });
      return m.reply("The message was pinned.");
    } catch (error) {
      return m.reply(`Failed to pin message: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};