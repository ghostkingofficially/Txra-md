function getTarget(m: any): string | null {
  if (m.mentionedJid?.length) return m.mentionedJid[0];
  if (m.quoted?.sender) return m.quoted.sender;
  const digits = String(m.args?.[0] || "").replace(/\D/g, "");
  return digits.length >= 8 && digits.length <= 15 ? `${digits}@s.whatsapp.net` : null;
}

export default {
  name: "promote",
  alias: ["makeadmin"],
  category: "groupmenu",
  description: "Promote a group member to administrator",
  usage: ".promote @user",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = getTarget(m);
    if (!target) return m.reply("Mention, reply to, or provide the number of a member.");

    try {
      const group = (ctx.client as any).group;
      if (typeof group?.promoteParticipants !== "function") {
        throw new Error("Zapo group.promoteParticipants() is not available.");
      }
      await group.promoteParticipants(m.chat, [target]);
      return m.reply({ text: `Administrator access granted to @${target.split("@")[0]}.`, mentions: [target] });
    } catch (error) {
      return m.reply(`Failed to promote member: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
