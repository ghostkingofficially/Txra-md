export default {
  name: "tagall",
  alias: ["everyone", "mentionall"],
  category: "groupmenu",
  description: "Mention all group members",
  usage: ".tagall [message]",
  isGroup: true,
  isAdmin: true,
  needGroupMeta: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const members = Array.isArray(ctx.groupMetadata?.participants)
      ? ctx.groupMetadata.participants
      : [];

    if (!members.length) {
      return m.reply("Unable to retrieve group members.");
    }

    const mentions = members
      .map((member: any) => member.id || member.jid || member.participant)
      .filter((jid: string | undefined): jid is string => Boolean(jid));

    if (!mentions.length) {
      return m.reply("No group members were found.");
    }

    const input = String(ctx.input || m.quoted?.text || "").trim();
    const message = input || "Hello, everyone!";

    const mentionText = mentions
      .map((jid) => `@${jid.split("@")[0]}`)
      .join(" ");

    return m.reply({
      text: `${message}\n\n${mentionText}`,
      mentions,
    });
  },
};
