const ACTIONS = ["open", "close", "lock", "unlock", "approve", "disapprove", "invite", "restrict", "schedule", "unschedule"];

function buildUsage(prefix: string): string {
  return [
    "*Group Settings*", "", `Usage: ${prefix}group <action>`, "", "*Available Actions*",
    `• ${prefix}group open`, `• ${prefix}group close`, `• ${prefix}group lock`, `• ${prefix}group unlock`,
    `• ${prefix}group approve`, `• ${prefix}group disapprove`, `• ${prefix}group invite`,
    `• ${prefix}group restrict`, `• ${prefix}group schedule`, `• ${prefix}group unschedule`,
  ].join("\n");
}

async function setting(client: any, groupJid: string, name: string, enabled: boolean): Promise<void> {
  if (typeof client.group?.setSetting !== "function") throw new Error("Zapo group.setSetting() is not available.");
  await client.group.setSetting(groupJid, name, enabled);
}

async function mode(client: any, groupJid: string, method: string, value: string): Promise<void> {
  if (typeof client.group?.[method] !== "function") throw new Error(`Zapo group.${method}() is not available.`);
  await client.group[method](groupJid, value);
}

export default {
  name: "group",
  alias: ["groupsettings", "gsettings"],
  category: "groupmenu",
  description: "Manage group settings",
  usage: ".group <action>",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const prefix = ctx.prefix || ".";
    const action = String(ctx.args?.[0] || "").toLowerCase();
    if (!action) return m.reply(buildUsage(prefix));
    if (!ACTIONS.includes(action)) return m.reply(`Invalid action: ${action}\n\n${buildUsage(prefix)}`);

    try {
      switch (action) {
        case "open": await setting(ctx.client, m.chat, "announcement", false); return m.reply("Group messages are now open to all members.");
        case "close": await setting(ctx.client, m.chat, "announcement", true); return m.reply("Group messages are now restricted to administrators.");
        case "lock": await setting(ctx.client, m.chat, "restrict", true); return m.reply("Group information editing is now restricted to administrators.");
        case "unlock": await setting(ctx.client, m.chat, "restrict", false); return m.reply("Group information editing is now open to all members.");
        case "invite":
          await mode(ctx.client, m.chat, "setMemberAddMode", "all_member_add");
          await mode(ctx.client, m.chat, "setMemberLinkMode", "all_member_link");
          return m.reply("All members can now add members and share the group link.");
        case "restrict":
          await mode(ctx.client, m.chat, "setMemberAddMode", "admin_add");
          await mode(ctx.client, m.chat, "setMemberLinkMode", "admin_link");
          return m.reply("Only administrators can now add members and share the group link.");
        case "approve": await setting(ctx.client, m.chat, "membership_approval_mode", true); return m.reply("New member approval has been enabled.");
        case "disapprove": await setting(ctx.client, m.chat, "membership_approval_mode", false); return m.reply("New member approval has been disabled.");
        case "schedule":
        case "unschedule": return m.reply("Automatic group scheduling is not configured in this project.");
        default: return m.reply(buildUsage(prefix));
      }
    } catch (error) {
      return m.reply(`Failed to update group settings: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
