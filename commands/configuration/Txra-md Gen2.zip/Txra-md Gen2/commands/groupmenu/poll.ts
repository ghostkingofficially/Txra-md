export default {
  name: "poll",
  alias: ["createpoll"],
  category: "groupmenu",
  description: "Create a poll in the group",
  usage: ".poll Question | Option 1 | Option 2",
  isGroup: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const parts = String(ctx.text || m.input || "")
      .split("|")
      .map((part: string) => part.trim())
      .filter(Boolean);

    if (parts.length < 3) {
      return m.reply(`Usage: ${ctx.prefix}poll Question | Option 1 | Option 2`);
    }

    const [name, ...options] = parts;
    if (options.length > 12) return m.reply("A poll can have at most 12 options.");

    try {
      await ctx.client.message.send(m.chat, {
        type: "poll",
        name,
        options,
        selectableCount: 1,
      });
      return;
    } catch (error) {
      return m.reply(`Failed to create poll: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};