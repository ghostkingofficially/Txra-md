export default {
  name: "unpin",
  alias: ["unp"],
  category: "groupmenu",
  description: "Unpin a quoted message in the group",
  usage: ".unpin while replying to a pinned message",
  isGroup: true,
  isAdmin: true,
  isBotAdmin: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const target = m.quoted?.key;
    if (!target) return m.reply("Reply to the message you want to unpin.");

    try {
      await ctx.client.message.send(m.chat, {
        type: "unpin",
        target,
      });
      return m.reply("The message was unpinned.");
    } catch (error) {
      return m.reply(`Failed to unpin message: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};