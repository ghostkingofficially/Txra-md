// commands/othermenu/menu.ts — tampilkan menu (main / kategori)
import { sendMenu } from "../../src/setmenu/index.ts";

export default {
  name: "menu",
  alias: ["help", "listmenu"],
  category: "othermenu",
  description: "Tampilkan menu bot",
  usage: ".menu [kategori]",
  isNoLimit: true,
  noRegister: true,
  async execute(m: any, ctx: any) {
    const category = String(ctx.args?.[0] ?? "").trim().toLowerCase() || undefined;
    const prefix = ctx.prefix ?? ".";
    await sendMenu(ctx.client, m, { mode: category ? "category" : "main", category, prefix });
  },
};
