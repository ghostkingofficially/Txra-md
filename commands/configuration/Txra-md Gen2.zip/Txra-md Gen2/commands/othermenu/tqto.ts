export default {
  name: "tqto",
  alias: ["thanksto"],
  category: "information",
  description: "Display the project acknowledgements",
  usage: ".tqto",
  isNoLimit: true,
  noRegister: true,

  async execute(m: any) {
    return m.reply(
      [
        "➛ Ghost King (Developer)",
        "➛ Faridesuwa (Base Creater)",
        "➛ Nixeon (Panel Provider)",
        "➛ Yogi (Best brother)",
        "➛ Rizky Pratama",
        "➛ Fan",
        "➛ Luki Zainur",
        "➛ Lorenzo",
        "➛ Cakra",
        "➛ Arsani Ariadeni (Donor)",
        "➛ Mahesa (Donor)",
        "➛ And to all parties who have helped in the development of this bot.",
      ].join("\n"),
    );
  },
};
