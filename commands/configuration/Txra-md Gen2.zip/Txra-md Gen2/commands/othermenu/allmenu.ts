// commands/othermenu/allmenu.ts — tampilkan semua menu
import { sendMenu } from "../../src/setmenu/index.ts";

export default {
  name: "allmenu",
  alias: ["all", "fullmenu"],
  category: "othermenu",
  description: "Tampilkan semua menu",
  usage: ".allmenu",
  isNoLimit: true,
  noRegister: true,
  async execute(m: any, ctx: any) {
    const prefix = ctx.prefix ?? ".";
    await sendMenu(ctx.client, m, { mode: "all", prefix });
  },
};
