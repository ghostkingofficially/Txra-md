import { formatUptime } from "../../lib/func/dateTime.ts";

export default {
  name: "uptime",
  alias: ["runtime"],
  category: "information",
  description: "Display how long the bot has been active",
  usage: ".uptime",
  isNoLimit: true,
  noRegister: true,

  async execute(m: any) {
    return m.reply(
      `The bot has been active for ${formatUptime(process.uptime())}.`,
    );
  },
};
