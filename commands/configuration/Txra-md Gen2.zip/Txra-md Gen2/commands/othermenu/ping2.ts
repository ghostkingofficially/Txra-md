import os from "node:os";
import { readdir, readFile } from "node:fs/promises";
import { performance } from "node:perf_hooks";
import { ButtonV2 } from "../../helpers/utils/button-messages/index.ts";
import { getConfig } from "../../connector/config.ts";

type CpuTimes = { user: number; nice: number; sys: number; idle: number; irq: number };

type ServerLocation = {
  country?: string;
  city?: string;
  isp?: string;
  timezone?: string;
};

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "0 B";
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(2)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(2)} KB`;
  return `${Math.round(bytes)} B`;
}

function formatDuration(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const days = Math.floor(safe / 86400);
  const hours = Math.floor((safe % 86400) / 3600);
  const minutes = Math.floor((safe % 3600) / 60);
  const secondsLeft = safe % 60;
  return `${days}d ${hours}h ${minutes}m ${secondsLeft}s`;
}

function readCpuTimes(): CpuTimes[] {
  return os.cpus().map((cpu) => ({ ...cpu.times }));
}

function calculateCpuUsage(before: CpuTimes[], after: CpuTimes[]) {
  return after.map((current, index) => {
    const previous = before[index] ?? current;
    const user = Math.max(0, current.user - previous.user);
    const nice = Math.max(0, current.nice - previous.nice);
    const sys = Math.max(0, current.sys - previous.sys);
    const idle = Math.max(0, current.idle - previous.idle);
    const irq = Math.max(0, current.irq - previous.irq);
    const total = user + nice + sys + idle + irq;
    const percentage = (value: number) => total > 0 ? (value / total) * 100 : 0;
    return {
      user: percentage(user),
      nice: percentage(nice),
      sys: percentage(sys),
      idle: percentage(idle),
      irq: percentage(irq),
    };
  });
}

async function readNetworkTotals(): Promise<{ upload: number; download: number }> {
  try {
    const text = await readFile("/proc/net/dev", "utf8");
    let upload = 0;
    let download = 0;
    for (const line of text.split("\n").slice(2)) {
      const separator = line.indexOf(":");
      if (separator < 0) continue;
      const interfaceName = line.slice(0, separator).trim();
      if (interfaceName === "lo") continue;
      const values = line.slice(separator + 1).trim().split(/\s+/).map(Number);
      if (values.length >= 9) {
        download += values[0] || 0;
        upload += values[8] || 0;
      }
    }
    return { upload, download };
  } catch {
    return { upload: 0, download: 0 };
  }
}

async function readCpuTemperature(): Promise<string> {
  try {
    const zones = await readdir("/sys/class/thermal");
    for (const zone of zones.filter((entry) => entry.startsWith("thermal_zone"))) {
      try {
        const raw = Number((await readFile(`/sys/class/thermal/${zone}/temp`, "utf8")).trim());
        if (Number.isFinite(raw) && raw > 0) return `${(raw > 1000 ? raw / 1000 : raw).toFixed(1)}°C`;
      } catch {
        continue;
      }
    }
  } catch {
    return "Unavailable";
  }
  return "Unavailable";
}

function getLocation(): ServerLocation {
  const config = getConfig() as any;
  return config.serverLocation ?? config.location ?? {
    country: process.env.SERVER_COUNTRY,
    city: process.env.SERVER_CITY,
    isp: process.env.SERVER_ISP,
    timezone: process.env.SERVER_TIMEZONE,
  };
}

function cpuBlock(label: string, usage: ReturnType<typeof calculateCpuUsage>[number]): string {
  return [
    `${label}`,
    `- user: ${usage.user.toFixed(2)}%`,
    `- nice: ${usage.nice.toFixed(2)}%`,
    `- sys: ${usage.sys.toFixed(2)}%`,
    `- idle: ${usage.idle.toFixed(2)}%`,
    `- irq: ${usage.irq.toFixed(2)}%`,
  ].join("\n");
}

export default {
  name: "ping2",
  alias: ["serverinfo", "sysinfo", "serverstats"],
  category: "othermenu",
  description: "Display detailed server and bot diagnostics.",
  usage: ".ping2",
  isNoLimit: true,
  noRegister: true,

  async execute(m: any, ctx: any) {
    try {
      const startedAt = performance.now();
      const beforeCpu = readCpuTimes();
      const beforeNetwork = await readNetworkTotals();
      await new Promise((resolve) => setTimeout(resolve, 100));
      const afterCpu = readCpuTimes();
      const afterNetwork = await readNetworkTotals();
      const responseMilliseconds = performance.now() - startedAt;
      const cpuUsage = calculateCpuUsage(beforeCpu, afterCpu);
      const firstCpu = cpuUsage[0] ?? { user: 0, nice: 0, sys: 0, idle: 100, irq: 0 };
      const totalCpu = cpuUsage.reduce((sum, cpu) => ({
        user: sum.user + cpu.user,
        nice: sum.nice + cpu.nice,
        sys: sum.sys + cpu.sys,
        idle: sum.idle + cpu.idle,
        irq: sum.irq + cpu.irq,
      }), { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 });
      const coreCount = Math.max(1, cpuUsage.length);
      const averageCpu = Object.fromEntries(Object.entries(totalCpu).map(([key, value]) => [key, value / coreCount])) as typeof firstCpu;
      const memory = process.memoryUsage();
      const totalRam = os.totalmem();
      const freeRam = os.freemem();
      const location = getLocation();
      const cpuModel = os.cpus()[0]?.model?.trim() || "Unknown";
      const cpuSpeed = os.cpus()[0]?.speed || 0;
      const body = [
        `*_⏳ Response Speed:_* ${(responseMilliseconds / 1000).toFixed(4)} seconds`,
        `${responseMilliseconds.toFixed(4)} milliseconds`,
        "",
        `> *🔄 Bot Uptime:* ${formatDuration(process.uptime())}`,
        `> *🖥️ Server Uptime:* ${formatDuration(os.uptime())}`,
        "",
        "`💻 Server Info`",
        `- *OS Type:* ${os.type()}`,
        `- *OS Platform:* ${os.platform()}`,
        `- *OS Release:* ${os.release()}`,
        `- *Architecture:* ${os.arch()}`,
        `- *Hostname:* ${os.hostname()}`,
        `- *RAM:* ${formatBytes(totalRam - freeRam)} / ${formatBytes(totalRam)}`,
        `- *Total RAM:* ${formatBytes(totalRam)}`,
        `- *Free RAM:* ${formatBytes(freeRam)}`,
        `- *CPU Model:* ${cpuModel}`,
        `- *CPU Speed:* ${cpuSpeed} MHz`,
        `- *CPU Cores:* ${coreCount}`,
        `- *CPU Temperature:* ${await readCpuTemperature()}`,
        `- *Upload:* ${formatBytes(afterNetwork.upload)}`,
        `- *Download:* ${formatBytes(afterNetwork.download)}`,
        `- *Node Version:* ${process.version}`,
        "",
        "`🌐 Server Location`",
        `> *Country:* ${location.country || "Unknown"}`,
        `> *City:* ${location.city || "Unknown"}`,
        `> *ISP:* ${location.isp || "Unknown"}`,
        `> *Timezone:* ${location.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown"}`,
        "",
        "`NodeJS Memory Usage`",
        `rss         : ${formatBytes(memory.rss)}`,
        `heapTotal   : ${formatBytes(memory.heapTotal)}`,
        `heapUsed    : ${formatBytes(memory.heapUsed)}`,
        `external    : ${formatBytes(memory.external)}`,
        `arrayBuffers: ${formatBytes(memory.arrayBuffers ?? 0)}`,
        "",
        "_Total CPU Usage_",
        `${cpuModel} (${cpuSpeed} MHz)`,
        `- user: ${averageCpu.user.toFixed(2)}%`,
        `- nice: ${averageCpu.nice.toFixed(2)}%`,
        `- sys: ${averageCpu.sys.toFixed(2)}%`,
        `- idle: ${averageCpu.idle.toFixed(2)}%`,
        `- irq: ${averageCpu.irq.toFixed(2)}%`,
        `_CPU Core Usage (${coreCount} cores)_`,
        ...cpuUsage.map((usage, index) => cpuBlock(`${index + 1}. ${cpuModel} (${cpuSpeed} MHz)`, usage)),
      ].join("\n");

      await new ButtonV2(ctx.client)
        .setTitle("Txra-md Server Diagnostics")
        .setSubtitle("Detailed system information")
        .setBody(body)
        .setFooter("Txra-md • ping2")
        .addButton("Menu", ".menu")
        .send(m.chat, { quoted: m.key && m.message ? { key: m.key, message: m.message } : undefined });
    } catch (error) {
      return m.reply(`Server diagnostics failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};