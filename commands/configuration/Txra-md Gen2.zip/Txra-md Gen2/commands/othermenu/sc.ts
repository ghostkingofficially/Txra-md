import { Carousel } from "../../helpers/utils/button-messages/index.ts";
import { getConfig } from "../../connector/config.ts";

const productImage =
  "https://x.xcute.workers.dev/f/images/abe592862f20.jpg";

function createQuotedMessage(message: any) {
  if (!message?.key || !message?.message) return undefined;

  return {
    key: message.key,
    message: message.message,
  };
}

export default {
  name: "sc",
  alias: ["script"],
  category: "information",
  description: "Show the SC Txra-md script advertisement",
  usage: ".sc",
  isNoLimit: true,
  noRegister: true,

  async execute(m: any, ctx: any) {
    try {
      const config = getConfig();
      const quoted = createQuotedMessage(m);

      const developerButtons = [
        {
          name: "cta_url",
          params: {
            display_text: "Developer 1",
            url: "https://wa.me/255719632816",
            webview_interaction: false,
          },
        },
        {
          name: "cta_url",
          params: {
            display_text: "Developer 2",
            url: "https://wa.me/255671205830",
            webview_interaction: false,
          },
        },
      ];

      const carousel = new Carousel(ctx.client)
        .setTitle("𝐓 𝐗 𝐑 𝐀 - 𝐌 𝐃 𝐆𝐞𝐧 𝟐")
        .setBody("Premium WhatsApp bot script - TR4SH-FINIX")
        .setFooter(config.bot?.footer || "Txra-md • Ghost King");

      carousel.addCard(
        await carousel.makeCard({
          image: productImage,
          title: "sc Txra-md",
          body: "Get this bot script for only Tsh 35,000.",
          footer: "Limited offer",
          buttons: developerButtons,
        })
      );

      carousel.addCard(
        await carousel.makeCard({
          image: productImage,
          title: "Included Features",
          body: [
            "• Simple and clean UI",
            "• Interactive buttons",
            "• Fast response",
            "• No encryption",
            "• Easy to customize",
            "• Free API key",
          ].join("\n"),
          footer: "Ready to customize",
          buttons: developerButtons,
        })
      );

      carousel.addCard(
        await carousel.makeCard({
          image: productImage,
          title: "Contact Developers",
          body: [
            "Purchase the SC Txra-md script.",
            "",
            "Price:",
            "• Regular price: Tsh 45,000",
            "• Sale price: Tsh 35,000",
          ].join("\n"),
          footer: "Contact us today",
          buttons: developerButtons,
        })
      );

      await carousel.send(m.chat, { quoted });

    } catch (error) {
      await m.reply(
        `SC information failed: ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  },
};