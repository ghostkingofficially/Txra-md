import { AIRich } from "../../helpers/utils/rich-messages/index.ts";
const A = {
  latex1: "https://cdn.ornzora.eu.cc/1ca0f9a4-a81f-498e-92e8-8a4c76abf1ef-FIORA.png",
  latex2: "https://cdn.ornzora.eu.cc/a3a756f2-6bb8-4814-a024-c325524a2308-FIORA.png",
  photo: "https://cdn.ornzora.eu.cc/f4ec8425-c846-4937-b838-9291bf0514e2-FIORA.jpg",
  img1: "https://cdn.ornzora.eu.cc/2a639cd2-5c33-49e3-982f-77f471c9313f-FIORA.jpg",
  img2: "https://cdn.ornzora.eu.cc/69551181-48c0-4466-b22d-235a93db8a63-FIORA.jpg",
  img3: "https://cdn.ornzora.eu.cc/6b1c1b29-9b80-4cfa-9c57-d008d60e18bc-FIORA.jpg",
  img4: "https://cdn.ornzora.eu.cc/6b07d572-8aeb-4bbe-9faa-f226bacd5c99-FIORA.jpg",
  avatar: "https://cdn.ornzora.eu.cc/bd0d65c6-8a44-4418-8d40-ae0ac00a2386-FIORA.jpg",
  video: "https://cdn.ornzora.eu.cc/3bb12237-2365-4a76-a4e2-635faea6d54c-FIORA.mp4",
  site: "https://nixel.dev/",
  channel: "https://whatsapp.com/channel/0029VbCV1ck8fewpdNb2TY2k",
  group: "https://chat.whatsapp.com/J7OzqKB7Bl2AGIcNEYsdch?s=cl&p=a&ilr=0",
};

const HTML_DEMO = `<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Demo HTML</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{background:transparent;color:#e9edef;font-family:-apple-system,Segoe UI,Roboto,sans-serif}
  .wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px}
  h1{font-size:18px}
  button{background:#00a884;color:#fff;border:none;border-radius:8px;padding:10px 18px;font-size:15px}
  #n{font-size:32px;font-weight:700}
</style></head><body><div class="wrap">
  <h1>🧪 Demo addHtml</h1>
  <div id="n">0</div>
  <button id="btn">Tambah</button>
</div>
<script>
  let n = 0;
  const el = document.getElementById("n");
  document.getElementById("btn").addEventListener("click", () => { n++; el.textContent = n; });
</script>
</body></html>`;

type Demo = (client: any, m: any) => Promise<unknown>;
type Fill = (rich: AIRich, client: any) => AIRich;
const q = (m: any) => ({ key: m.key, message: m.message });
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

const fillText: Fill = (r) => r
  .addFOAText("# Judul besar (FOA)")
  .addText("Teks **tebal**, _miring_, `kode inline`, dan [link Deno](https://deno.com).")
  .addText("Sitasi bernomor: sumber pertama[](https://deno.com) dan kedua[](https://github.com).")
  .addText("Link tidak tepercaya: [klik hati-hati](!https://example.com)")
  .addTip("Tip: ⓘ otomatis ditambahkan di depan teks ini.")
  .addMetadata("Metadata: teks kecil abu-abu di bawah konten.");

const fillLatex: Fill = (r) => r
  .addText(`Contoh latex:\n- Model 1: [NIXCODE|1279|825]<${A.latex1}>\n- Model 2: [NIXCODE|1429|1897]<${A.latex2}>`);

const fillCode: Fill = (r) => r
  .addText("Blok kode dengan highlight sintaks:")
  .addCode("javascript", 'const halo = (nama) => {\n  // sapa pengguna\n  return `Halo, ${nama}!`;\n};\nconsole.log(halo("dunia"), 42);')


const fillTable: Fill = (r) => r
  .addText("Tabel (sel mendukung link):")
  .addTable([
    ["Nama", "Peran", "Link"],
    ["[Nixel](https://nixel.dev/)", "Developer", "[situs](https://nixel.dev/)"],
    ["Fiora Sylvie", "Assistant", "-"],
    ["zapo-js", "Library", "[github](https://github.com/vinikjkkj/zapo)"],
  ]);

const fillImage: Fill = (r) => r
  .addText("Grid gambar (GenAIImaginePrimitive):")
  .addImage([A.img1, A.img2, A.img3]);

const fillPhoto: Fill = (r) => r
  .addFOAText("# Foto + teks")
  .addText("Foto di bawah memakai preview dan full image terpisah.")
  .addPhoto(A.photo)
  .addText("Teks penutup setelah foto.");

const fillVideo: Fill = (r) => r
  .addText("Video (durasi & thumbnail diisi otomatis):")
  .addVideo(A.video);

const products = [
  { title: "NIXCODE", brand: "Nixel", price: "Rp 150.000", sale_price: "Rp 99.000", url: A.site, image_url: A.img1, icon_url: A.avatar },
  { title: "FIORA Bot", brand: "Fiora", price: "Rp 200.000", url: A.site, image_url: A.img2, icon_url: A.avatar },
  { title: "Zapo Starter", brand: "zapo-js", price: "Gratis", url: "https://github.com/vinikjkkj/zapo", image_url: A.img3, icon_url: A.avatar },
  { title: "Sticker Pack", brand: "Nixel", price: "Rp 25.000", sale_price: "Rp 19.000", url: A.site, image_url: A.img4, icon_url: A.avatar },
  { title: "Premium Menu", brand: "Fiora", price: "Rp 75.000", url: A.site, image_url: A.photo, icon_url: A.avatar },
];
const fillProduct: Fill = (r) => r
  .addText("Satu produk:")
  .addProduct(products[0])
  .addText("Carousel produk (geser ke samping):")
  .addProduct(products);

const fillPost: Fill = (r) => r
  .addText("Kartu postingan:")
  .addPost([
    { profile: A.avatar, title: "Behind the build", username: "nixel.dev", verified: true, caption: "Dibangun terpisah lalu dicampur.", thumbnail: A.img2, url: A.site, source_app: "INSTAGRAM", like: 1200, comment: 48, share: 12 },
    { profile: A.avatar, title: "Rilis v4.7", username: "nixel.dev", verified: true, caption: "Fitur baru: insertAt, replace, delete.", thumbnail: A.img3, url: A.site, source_app: "INSTAGRAM", like: 860, comment: 31, share: 9 },
    { profile: A.avatar, title: "Tips cepat", username: "fiora.bot", caption: "Pakai id agar item mudah diedit.", thumbnail: A.img4, url: A.site, source_app: "INSTAGRAM", like: 420, comment: 7, share: 3 },
  ]);

const fillReels: Fill = (r) => r
  .addText("Reels:")
  .addReels([A.img1, A.img2, A.img3, A.img4].map((thumb, i) => ({
    profile: A.avatar, username: "nixel.dev", thumbnail: thumb, url: A.site, verified: true,
    title: `Reel ${i + 1}`, like: 1000 + i * 250, view: 20000 + i * 5000, share: 30 + i * 10,
  })));

const fillSource: Fill = (r) => r
  .addText("Jawaban dengan sumber:")
  .addSource([
    { icon: A.avatar, url: "https://deno.com", title: "Deno", subtitle: "Runtime · deno.com" },
    { icon: A.avatar, url: "https://github.com/vinikjkkj/zapo", title: "zapo-js", subtitle: "GitHub · vinikjkkj" },
  ]);


const act = (label: string, id: string) => ({ label, id, toast: { label: "NIX" } });
const fillWidget: Fill = (r) => r
  .addFOAText("# let me know~")
  .addText("im here~")
  .addPhoto(A.photo)
  .addWidget([
    { title: "LIST-X", actions: [act(".ping", ".ping"), act("profile", "01"), act("script", "02")] },
    { title: "NX-T", actions: [act("ping", "10"), act("NIXEL", "11"), act("FIORA", "12")] },
  ])
  .addWidget({ title: "Widget tunggal", actions: [act("Join Channel", "ch")] })
  .addFooterAction([
    { text: "WhatsApp Group", url: A.group },
    { text: "WhatsApp Channel", url: A.channel },
  ]);

const fillSuggest: Fill = (r) => r
  .addText("Pil saran lanjutan:")
  .addSuggest(["Apa itu AIRich?", "Contoh kode", "Tampilkan tabel", "Buka menu"])
  .addSuggest(["Ya", "Tidak"], { scroll: false })
  .addSuggest("Satu saran saja");

const fillFooter: Fill = (r) => r
  .addText("Tombol footer:")
  .addFooterAction([
    { text: "Buka Situs", url: A.site },
    { text: "WhatsApp Channel", url: A.channel },
  ]);

const fillMixed: Fill = (r, client) => {
  const items = new AIRich(client)
    .addProduct({ title: "NIXCODE", brand: "Nixel", price: "MessageBuilderV4.7", url: A.site, image_url: A.img1 })
    .addPost({ profile: A.avatar, title: "Behind the build", username: "nixel.dev", verified: true, caption: "Dibangun terpisah.", thumbnail: A.img2, url: A.site })
    .addReels({ profile: A.avatar, username: "nixel.dev", thumbnail: A.img3, url: A.site, verified: true }).items;

  return r
    .addText("Kartu di bawah berasal dari instance AIRich lain:")
    .addSection(AIRich.newLayout("HScroll", items))
    .addTip("Diambil dengan .items lalu disisipkan lewat .addSection().");
};

const fillHtml: Fill = (r) => r.addHtml(HTML_DEMO);

const fills: Record<string, Fill> = {
  text: fillText, latex: fillLatex, code: fillCode, table: fillTable, image: fillImage, photo: fillPhoto,
  video: fillVideo, product: fillProduct, post: fillPost, reels: fillReels, source: fillSource,
  widget: fillWidget, suggest: fillSuggest, footer: fillFooter, mixed: fillMixed,
  html: fillHtml,
};

const single = (name: string): Demo => (client, m) =>
  fills[name](new AIRich(client).setTitle(`Demo ${name}`), client)
    .setFooter(`richdemo • ${name}`)
    .send(m.chat, { quoted: q(m) });

const demoAll: Demo = (client, m) => {
  const rich = new AIRich(client).setTitle("RichDemo — semua jenis").addFOAText("# Semua jenis rich message");
  for (const [name, fill] of Object.entries(fills)) {
    if (name === "html") continue; 
    rich.addFOAText(`## ${name}`);
    fill(rich, client);
  }
  return rich.setFooter("richdemo • all (satu pesan)").send(m.chat, { quoted: q(m) });
};

const demoTyping: Demo = (client, m) =>
  new AIRich(client).typing(
    m.chat,
    "Halo! Ini contoh efek mengetik. Teks ditambah sedikit demi sedikit lewat edit pesan, sampai kalimat ini tampil penuh.",
    { step: 3, delayMs: 500, quoted: q(m) },
  );

const demoTour: Demo = async (client, m) => {
  const rich = new AIRich(client)
    .setTitle("RichDemo Tour")
    .addText("Halo! Selamat datang di [RichDemo](https://deno.com) 👋", { id: "intro" })
    .setFooter("Dibangun dengan AIRich (port zapo-js)");

  await rich.send(m.chat, { quoted: q(m) });
  await delay(1500);

  rich.addText("Ini tur langsung: semua yang muncul di bawah dibangun lewat edit pesan yang sama.", { insertAt: "intro", id: "welcome" });
  rich.addSuggest(["AIRich", "Dynamic edit", "NIXCODE"]);
  await rich.sendEdit();
  await delay(1800);

    rich.addText("Pertama, status loading. Item muncul dulu, lalu diganti saat kontennya siap.", { insertAt: "welcome", id: "loading_intro" });
  await rich.sendEdit();
  await delay(1500);

  rich.addImage("", { status: "GENERATING", update_text: "Membuat gambar...", insertAt: "loading_intro", id: "image1" });
  await rich.sendEdit();
  await delay(3000);

  rich.addImage(A.img1, { replace: "image1" });
  await rich.sendEdit();
  await delay(2000);

  rich.addText("Video memakai alur loading → replace yang sama.", { insertAt: "image1", id: "video_intro" });
  await rich.sendEdit();
  await delay(1500);

  rich.addVideo("", { status: "GENERATING", estimatedTime: 3000, insertAt: "video_intro", id: "video1" });
  await rich.sendEdit();
  await delay(4000);

  rich.addVideo(A.video, { replace: "video1" });
  await rich.sendEdit();
  await delay(2000);

  rich.addText("Blok kode dengan highlight sintaks.", { insertAt: "video1", id: "code_intro" });
  await rich.sendEdit();
  await delay(1200);

  rich.addCode("javascript", 'function greet(name) {\n  return `Hello, ${name}!`;\n}\n\ngreet("Nixel");', { insertAt: "code_intro", id: "code1" });
  await rich.sendEdit();
  await delay(2500);

  rich.addText("Tabel juga didukung.", { insertAt: "code1", id: "table_intro" });
  await rich.sendEdit();
  await delay(1200);

  rich.addTable([["Nama", "Peran"], ["[Nixel](https://nixel.dev/)", "Developer"], ["Fiora Sylvie", "Assistant"]], { insertAt: "table_intro", id: "table1" });
  await rich.sendEdit();
  await delay(2500);

  rich.addText("Konten bisa dibangun di instance AIRich lain lalu dipakai ulang.", { insertAt: "table1", id: "mix_intro" });
  await rich.sendEdit();
  await delay(1800);

  const items = new AIRich(client)
    .addProduct({ title: "NIXCODE", brand: "Nixel", price: "MessageBuilderV4.7", url: A.site, image_url: A.img1 })
    .addPost({ profile: A.avatar, title: "Behind the build", username: "nixel.dev", verified: true, caption: "Dibangun terpisah lalu dicampur.", thumbnail: A.img2, url: A.site })
    .addReels({ profile: A.avatar, username: "nixel.dev", thumbnail: A.img3, url: A.site, verified: true }).items;

  rich.addText("Kartu ini berasal dari instance AIRich yang benar-benar terpisah.", { insertAt: "mix_intro", id: "mix_note" });
  await rich.sendEdit();
  await delay(1500);

  rich.addSection(AIRich.newLayout("HScroll", items), { insertAt: "mix_note", id: "mixed_items" });
  await rich.sendEdit();
  await delay(3000);

  rich.addTip("Product, Post, dan Reels di atas dibuat terpisah, diambil dengan .items, lalu disisipkan lewat .addSection().", { insertAt: "mixed_items", id: "mix_explain" });
  await rich.sendEdit();
  await delay(2500);

  rich.addSource([{ icon: A.avatar, url: A.site, title: "Nixel", subtitle: "Situs · MessageBuilder" }], { insertAt: "mix_explain", id: "source1" });
  await rich.sendEdit();
  await delay(1800);

  rich.addReels(
    [A.img1, A.img2, A.img3, A.img4].map((thumb) => ({ profile: A.avatar, username: "nixel.dev", thumbnail: thumb, url: A.site, verified: true })),
    { insertAt: "source1", id: "reels1" },
  );
  await rich.sendEdit();
  await delay(2200);

  rich.addWidget(
    { title: "Aksi Cepat", actions: [{ label: "Gabung Channel", kind: "OTHER", state: "PENDING", id: "channel" }] },
    { insertAt: "reels1", id: "widget1" },
  );
  await rich.sendEdit();
  await delay(2000);

  rich.addFooterAction({ text: "Buka Channel", url: A.channel }, { id: "footer1" });
  await rich.sendEdit();
  await delay(2500);

    rich.addMetadata("Alur dasar: buat, sisipkan, ganti, campur, lalu terus bangun ke bawah.", { id: "cleanup_intro", insertAt: "reels1" });
  await rich.sendEdit();
  await delay(3000);

  rich.delete("cleanup_intro");
  await rich.sendEdit();
  await delay(400);

  rich.addText("Itu tur lengkapnya — dibangun langsung, diedit langsung, dan dicampur dari beberapa instance AIRich. 🚀", { insertAt: "widget1", id: "final" });
  return rich.sendEdit();
};

const demos: Record<string, Demo> = {
  ...Object.fromEntries(Object.keys(fills).map((k) => [k, single(k)])),
  all: demoAll,
  typing: demoTyping,
  tour: demoTour,
};
const USAGE = `Pakai: .richdemo ${Object.keys(demos).join(" | ")}`;

export default {
  name: "richdemo",
  alias: ["aidemo"],
  category: "othermenu",
  usage: `.richdemo ${Object.keys(demos).join(" | ")}`,

  async execute(m: any, ctx: any) {
    const mode = (ctx.args?.[0] ?? "").toLowerCase();
    if (!demos[mode]) return m.reply(USAGE);

    try {
      await demos[mode](ctx.client, m);
    } catch (e) {
      await m.reply(`Gagal kirim rich "${mode}": ${(e as Error).message}`);
    }
  },
};