// commands/othermenu/memory.js
import { formatDuration } from "../../lib/func/dateTime.ts";

function formatBytes(bytes, decimals = 2) {
  if (!Number.isFinite(bytes) || bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB"];
  const dm = decimals < 0 ? 0 : decimals;
  const i = Math.min(Math.floor(Math.log(Math.abs(bytes)) / Math.log(k)), sizes.length - 1);
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

export default {
  name: "memory",
  alias: ["mem", "ram", "rss"],
  category: "othermenu",
  description:
    "Menampilkan detail penggunaan memori bot (RSS, heap total, heap used, external, array buffers).\n\n" +
    "Contoh:\n" +
    "> `.memory`\n" +
    "> `.ram`",
  usage: ".memory",
  isLimit: false,

  async execute(m) {
    const mem = typeof Deno !== "undefined" && Deno.memoryUsage
      ? Deno.memoryUsage()
      : process.memoryUsage();

    const uptime = typeof Deno !== "undefined" && Deno.uptime
      ? Deno.uptime()
      : process.uptime();

    const runtime = typeof Deno !== "undefined"
      ? `Deno ${Deno.version.deno}`
      : `Node ${process.version}`;

    const lines = Object.entries(mem)
      .map(([key, value]) => `◦ *${key}:* ${formatBytes(value)}`)
      .join("\n");

    const footer = `◦ *runtime:* ${runtime}\n◦ *uptime:* ${formatDuration(uptime * 1000)}`;

    await m.reply(`*── 「 MEMORY USAGE 」 ──*\n\n${lines}\n${footer}`);
  },
};
