// .ping — ukur latensi dengan benar, dan pisahkan bagian yang bisa dioptimalkan dari yang tidak.
//
// Kenapa "umur pesan" tidak bisa dipakai sebagai patokan:
//   timestamp pesan WhatsApp hanya punya resolusi DETIK (event.timestampSeconds * 1000) dan diisi jam HP pengirim.
//   Date.now() - timestamp selalu bergeser acak 0–999 ms (rata-rata +500 ms) ditambah selisih jam HP/Termux,
//   apa pun kecepatan bot. Angka itu cuma cocok dibandingkan dengan angka dari rumus yang sama.
//
// Yang ditampilkan sekarang:
//   • Antre→handler : event diterima bot sampai handler mulai memproses (cek prefix, identitas, izin, limit).
//   • Handler→kirim : handler mulai sampai command ping dieksekusi.
//   • Kirim balasan : lama m.reply() sampai server WhatsApp menerima (ack). Tidak bisa ditaruh di pesan yang sama,
//                     jadi yang tampil adalah nilai ping SEBELUMNYA (juga dicatat di log).
//   • Umur pesan    : cara lama, sebagai pembanding saja.
import { log } from "../../connector/logger/index-logging.ts";
import { loopLagStats } from "../../lib/func/loopLag.ts";

let lastSendMs: number | null = null;

export default {
  name: "ping",
  alias: ["p", "pong"],
  category: "othermenu",
  usage: ".ping",
  isLimit: false,

  async execute(m: any) {
    const now = Date.now();
    const nowPerf = performance.now();
    const proses = m.receivedAt ? Math.max(0, now - m.receivedAt) : null;
    const total = typeof m.t0 === "number" ? Math.max(0, nowPerf - m.t0) : null;
    const umur = m.timestamps ? Math.max(0, now - m.timestamps) : null;

    const lines = ["Pong!"];
    if (total !== null) lines.push(`Proses bot : ${total.toFixed(0)} ms (event → eksekusi)`);
    else if (proses !== null) lines.push(`Proses bot : ${proses} ms`);
    lines.push(`Kirim balasan : ${lastSendMs !== null ? `${lastSendMs} ms (ping sebelumnya)` : "belum ada data, ping sekali lagi"}`);
    const lag = loopLagStats();
    if (lag.samples > 0) {
      lines.push(`Thread utama : normal ${lag.p50.toFixed(0)} ms · p95 ${lag.p95.toFixed(0)} ms · terburuk ${lag.max.toFixed(0)} ms (60 dtk)`);
    }
    if (umur !== null) lines.push(`Umur pesan : ±${umur} ms (resolusi 1 dtk, ikut jam HP)`);

    const t = performance.now();
    await m.reply(lines.join("\n"));
    lastSendMs = Math.round(performance.now() - t);
    log.info(`[ping] proses=${total !== null ? total.toFixed(0) : (proses ?? "-")}ms kirim=${lastSendMs}ms`);
  },
};