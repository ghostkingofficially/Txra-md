import { Button, ButtonV2, Carousel } from "../../helpers/utils/button-messages/index.ts";

const MODES = ["split", "split3", "native", "v2", "carousel", "carouselbtn", "carouselsplit"] as const;
type Mode = (typeof MODES)[number];
const USAGE = `Pakai: .btndemo ${MODES.join(" | ")} | all`;

const reply = (display_text: string, id: string) => ({ name: "quick_reply", params: { display_text, id } });
const link = (display_text: string, url: string) => ({ name: "cta_url", params: { display_text, url, webview_interaction: false } });

const demoImage = (n: number) => `https://picsum.photos/seed/btndemo${n}/600/400`;

async function demo(client: any, m: any, mode: Mode, img?: string) {
  const quoted = { key: m.key, message: m.message };

  // ── V2: buttonsMessage lama ──
  if (mode === "v2") {
    await new ButtonV2(client)
      .setTitle("Demo Button V2").setSubtitle("buttonsMessage")
      .setBody("Ini format tombol versi lama (buttonsMessage).").setFooter("btndemo • v2")
      .addButton("Ping", ".ping").addButton("Menu", ".menu")
      .send(m.chat, { quoted });
    return;
  }

    if (mode.startsWith("carousel")) {
    const buttonsFor = (card: number) => {
      if (mode === "carousel") return [];
      if (mode === "carouselbtn") return [reply(`Pilih ${card}`, ".ping"), link("Buka", "https://deno.com")];
      return card < 3
        ? Button.split([reply("Menu", ".menu"), reply("All Menu", ".allmenu")])
        : Button.split([reply("Menu", ".menu"), reply("Ping", ".ping"), link("Web", "https://deno.com")]);
    };
    const car = new Carousel(client).setTitle("Demo Carousel").setBody(`Demo ${mode}`).setFooter(`btndemo • ${mode}`);
    for (let i = 1; i <= 3; i++) {
      car.addCard(await car.makeCard({
        image: img ?? demoImage(i), title: `Kartu ${i}`, body: `Isi kartu nomor ${i}`, footer: "btndemo", buttons: buttonsFor(i),
      }));
    }
    await car.send(m.chat, { quoted });
    return;
  }

  // ── NATIVE FLOW (split, split3, native) ──
  const msg = new Button(client).setFooter(`btndemo • ${mode}`);
  if (mode === "split") {
    msg.setTitle("Demo Split").setBody("Dua tombol berdampingan.")
      .addReply("Menu", ".menu").addReply("All Menu", ".allmenu")
      .split();
  } else if (mode === "split3") {
        msg.setTitle("Demo Split 3").setBody("Tiga tombol sebaris.")
      .addReply("Menu", ".menu").addReply("Ping", ".ping").addUrl("Channel", "https://deno.com")
      .split();
  } else {
    msg.setTitle("Demo Native Flow").setSubtitle("interactiveMessage")
      .setBody("Campuran tombol native flow + daftar pilihan.")
      .addReply("Ping", ".ping")
      .addUrl("Buka Deno", "https://deno.com")
      .addCopy("Salin kode promo", "PROMO2026", "copy_promo")
      .addSelection("Pilih kategori")
      .makeSection("Umum", "Populer")
      .makeRow("", "Ping", "Cek bot online", ".ping")
      .makeRow("", "Menu", "Tampilkan menu", ".menu")
      .makeSection("Lainnya")
      .makeRow("", "Info", "Info bot", ".info")
      .setLimitedTimeOffer("Promo terbatas", "https://deno.com", "PROMO2026", Math.floor(Date.now() / 1000) + 3600)
      .setBottomSheet({ limit: 2, listTitle: "Semua opsi", buttonTitle: "Lihat semua" });
  }
  await msg.run(m.chat, client, quoted);
}

export default {
  name: "btndemo",
  alias: ["buttondemo"],
  category: "othermenu",
  description: "Contoh pesan button (split, native flow, v2, carousel)",
  usage: ".btndemo split | split3 | native | v2 | carousel | carouselbtn | carouselsplit | all",

  async execute(m: any, ctx: any) {
    const mode = (ctx.args?.[0] ?? "").toLowerCase();
    const img = /^https?:\/\//i.test(ctx.args?.[1] ?? "") ? String(ctx.args[1]) : undefined;

    if (mode === "all") {
           for (const name of MODES) {
        try { await demo(ctx.client, m, name, img); }
        catch (e) { await m.reply(`Demo ${name} gagal: ${(e as Error).message}`); }
      }
      return;
    }

    if (!(MODES as readonly string[]).includes(mode)) return m.reply(USAGE);
    try { await demo(ctx.client, m, mode as Mode, img); }
    catch (e) { await m.reply(`Gagal kirim button: ${(e as Error).message}`); }
  },
};