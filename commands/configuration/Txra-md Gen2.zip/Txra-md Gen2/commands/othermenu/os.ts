import os from "node:os";
import { performance } from "node:perf_hooks";
import { Button } from "../../helpers/utils/button-messages/index.ts";
import { getConfig } from "../../connector/config.ts";

function formatBytes(bytes: number): string {
  if (bytes < 1024 ** 2) {
    return `${(bytes / 1024).toFixed(2)}KB`;
  }

  if (bytes < 1024 ** 3) {
    return `${(bytes / 1024 ** 2).toFixed(2)}MB`;
  }

  return `${(bytes / 1024 ** 3).toFixed(2)}GB`;
}

function formatDuration(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = Math.floor(seconds % 60);

  const parts: string[] = [];

  if (days) parts.push(`${days}d`);
  if (hours || days) parts.push(`${hours}h`);
  if (minutes || hours || days) parts.push(`${minutes}m`);

  parts.push(`${remainingSeconds}s`);

  return parts.join(" ");
}

function getCpuUsage(): number {
  const loadAverage = os.loadavg()[0] || 0;
  const cpuCores = os.cpus().length || 1;

  return Math.min((loadAverage / cpuCores) * 100, 100);
}

function getCpuLabel(usage: number): string {
  if (usage < 30) return "Idle";
  if (usage < 60) return "Normal";
  if (usage < 85) return "Busy";
  return "Overload";
}

function getMemoryLabel(percentage: number): string {
  if (percentage < 50) return "Healthy";
  if (percentage < 75) return "Moderate";
  return "Critical";
}

function getPingLabel(milliseconds: number): string {
  if (milliseconds < 500) return "Excellent";
  if (milliseconds < 1000) return "Good";
  if (milliseconds < 2000) return "Average";
  return "Poor";
}

function getServerTime(): string {
  return new Intl.DateTimeFormat("en-GB", {
    dateStyle: "short",
    timeStyle: "medium",
    hour12: false,
  }).format(new Date());
}

function createQuotedMessage(message: any) {
  if (!message?.key || !message?.message) return undefined;

  return {
    key: message.key,
    message: message.message,
  };
}

export default {
  name: "os",
  alias: ["server", "system", "status"],
  category: "othermenu",
  description: "Display server and NodeJS performance information",
  usage: ".os",
  isNoLimit: true,
  noRegister: true,

  async execute(m: any, ctx: any) {
    try {
      const config = getConfig();
      const startTime = performance.now();

      const totalMemory = os.totalmem();
      const freeMemory = os.freemem();
      const usedMemory = totalMemory - freeMemory;
      const memoryPercentage = (usedMemory / totalMemory) * 100;

      const cpuModel = os.cpus()[0]?.model?.trim() || "Unknown";
      const cpuCores = os.cpus().length;
      const cpuSpeed = os.cpus()[0]?.speed || 0;
      const cpuUsage = getCpuUsage();

      const nodeMemory = process.memoryUsage();
      const responseTime = Number((performance.now() - startTime).toFixed(2));

      const bookingUrl =
        config.group?.url ||
        config.channel?.link ||
        config.bot?.url ||
        "https://example.com";

      const ownerNumber =
        String(config.owner?.primary || "").replace(/\D/g, "") ||
        "000000000000";

      const uptime = formatDuration(process.uptime());
      const serverUptime = formatDuration(os.uptime());

      const bodyText = [
        "*🔹 O S / S E R V E R*",
        "",
        "⏳ *Response Time*",
        `${responseTime} ms — ${getPingLabel(responseTime)}`,
        "",
        "🕒 *Bot Runtime*",
        uptime,
        "",
        "💻 *SERVER*",
        `🔴 Memory Usage: ${formatBytes(usedMemory)} / ${formatBytes(totalMemory)}`,
        `🔵 Free RAM: ${formatBytes(freeMemory)}`,
        `📊 Memory Status: ${getMemoryLabel(memoryPercentage)}`,
        `⚡ CPU Usage: ${cpuUsage.toFixed(2)}% — ${getCpuLabel(cpuUsage)}`,
        `🧠 CPU Cores: ${cpuCores}`,
        `🖥️ Platform: ${os.type()} ${os.release()} ${os.arch()}`,
        `⏰ Server Time: ${getServerTime()}`,
        "",
        "💾 *NodeJS Memory Usage*",
        `• RSS: ${formatBytes(nodeMemory.rss)}`,
        `• Heap Used: ${formatBytes(nodeMemory.heapUsed)}`,
        `• Heap Total: ${formatBytes(nodeMemory.heapTotal)}`,
        `• External: ${formatBytes(nodeMemory.external)}`,
        `• Array Buffers: ${formatBytes(nodeMemory.arrayBuffers)}`,
      ].join("\n");

      const specificationText = [
        `CPU: ${cpuModel}`,
        `Cores: ${cpuCores} @ ${cpuSpeed} MHz`,
        `Platform: ${os.platform()} ${os.arch()}`,
        `Kernel: ${os.release()}`,
        `NodeJS: ${process.version}`,
        `Server Uptime: ${serverUptime}`,
        `Hostname: ${os.hostname()}`,
      ].join("\n");

      const bookingPayload = {
        start_datetime: new Date().toISOString(),
        end_datetime: new Date(Date.now() + 600000).toISOString(),
        location: "Server Information",
        booking_url: bookingUrl,
        phone_number: ownerNumber,
        booking_management_url: bookingUrl,
        description: specificationText,
        email: "",
        display_text: "Detail Specifications",
        display_content: {
          display_language: "en",
          display_meeting_type: "Server Information",
          display_bottom_sheet_header: "Server Specifications",
          display_add_to_calendar_cta_text: "SERVER",
          display_view_on_maps_cta_text: "Server Location",
          display_manage_booking_cta_text: "Open Link",
          display_manage_booking_not_supported_text:
            "Server information only",
          display_read_more: "View Details",
        },
      };

      const quoted = createQuotedMessage(m);

      await new Button(ctx.client)
        .setTitle("Server Performance")
        .setBody(bodyText)
        .setFooter(config.bot?.footer || "Txra-md Server Information")
        .addButton("booking_confirmation", bookingPayload)
        .send(m.chat, { quoted });
    } catch (error) {
      await m.reply(
        `Server information failed: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  },
};