import { register, updateUser } from "../../lib/usermanager/users.ts";

const NAME_RE = /^[\p{L}\p{N} _.-]+$/u;

export default {
  name: "register",
  alias: ["daftar", "reg"],
  category: "usermenu",
  usage: ".register <nama>",
  suggest: ["menu"],

  noRegister: true,

  async execute(m: any, ctx: any) {
    if (!ctx.userPhone) {
      await m.reply(mess.unresolved);
      return;
    }

    const typed = ctx.args.join(" ").trim();
    const name = (typed || ctx.pushName || "").trim();

    const invalid = (): string | null => {
      if (name.length < 2 || name.length > 20) return `❌ *nama harus 2-20 karakter bre*\ncontoh: ${ctx.prefix}register Bocchi`;
      if (!NAME_RE.test(name)) return "❌ *nama cuma boleh huruf, angka, spasi, _ . -*";
      if (name.toLowerCase() === "owner" && !ctx.isOwner) return "❌ *nama itu dipake owner bre, cari nama lain*";
      return null;
    };

    if (ctx.isRegistered) {
      // Nomor didaftarkan otomatis oleh bot → boleh ganti username sekali lewat .register <nama>
      if (ctx.user?.autoRegistered && typed) {
        const err = invalid();
        if (err) return m.reply(err);
        updateUser(ctx.userPhone, { name, autoRegistered: false });
        return m.reply(`✅ *username diganti bre ^ ^*\nusername: ${name}`);
      }
      const hint = ctx.user?.autoRegistered ? `\n\nmau ganti username? ketik ${ctx.prefix}register <nama>` : "";
      return m.reply(`✅ *kamu udah terdaftar bre ^ ^*\nusername: ${ctx.user?.name ?? "-"}${hint}`);
    }

    const err = invalid();
    if (err) return m.reply(err);

    const user = register(ctx.userPhone, name);
    if (!user) {
      await m.reply(ctx.client ? "❌ *gagal daftar bre, coba lagi*" : "❌ *gagal daftar*");
      return;
    }

    await m.reply(
      `✅ *sip, berhasil daftar bre ^ ^*\nusername: ${user.name}\nlimit: ${user.limit}`,
    );
  },
};
