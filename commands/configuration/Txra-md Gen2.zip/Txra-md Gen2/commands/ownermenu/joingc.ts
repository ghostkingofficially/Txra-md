export default {
  name: "joingc",
  alias: ["joingroup", "join"],
  category: "ownermenu",
  description: "Join a group using an invite link or code.",
  usage: ".joingc https://chat.whatsapp.com/INVITE_CODE",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const input = String(ctx.args?.[0] ?? "").trim();
    if (!input) return m.reply("Usage: .joingc https://chat.whatsapp.com/INVITE_CODE");
    const code = input.replace(/^https?:\/\/chat\.whatsapp\.com\//i, "").split(/[?\s]/)[0].trim();
    if (!code) return m.reply("Invalid group invite link.");
    try {
      const groupApi = ctx.client.group;
      const join = groupApi?.join || groupApi?.joinGroup;
      if (typeof join !== "function") return m.reply("The group join API is not available.");
      const result = await join.call(groupApi, code);
      return m.reply(`Group join request sent successfully${result?.id ? `: ${result.id}` : "."}`);
    } catch (error) {
      return m.reply(`Failed to join the group: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};