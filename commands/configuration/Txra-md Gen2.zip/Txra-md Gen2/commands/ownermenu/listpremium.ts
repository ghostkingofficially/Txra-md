import { getAllPremiumUsers } from "../../lib/usermanager/users.ts";

export default {
  name: "listprem",
  alias: ["listpremium", "premiumlist"],
  category: "ownermenu",
  description: "List premium users.",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    const users = getAllPremiumUsers();
    if (!users.length) return m.reply("No premium users found.");
    const lines = users.map((user) => `${user.name || "User"} — ${user.jid}${user.premiumUntil ? ` — until ${new Date(user.premiumUntil).toISOString()}` : " — permanent"}`);
    return m.reply(`Premium users (${users.length}):\n${lines.join("\n")}`);
  },
};
