import { isAutoReloaderRunning, startAutoReloader, stopAutoReloader } from "../../lib/func/autoReloader.ts";
import { getSettings, loadSettings, updateSettings } from "../../lib/settings/botSettings.ts";

const COMMANDS_DIR = "./commands";

const statusText = () =>
  `*Auto-reload*\n` +
  `Status: ${getSettings().autoReload.enabled ? "✅ ON" : "⛔ OFF"}\n` +
  `Watcher: ${isAutoReloaderRunning() ? "berjalan" : "berhenti"}`;

export default {
  name: "autoreload",
  category: "ownermenu",
  description: "Hidupkan / matikan auto-reload command",
  usage: ".autoreload on | off | status",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const arg = String(ctx.args?.[0] ?? "").toLowerCase();

    if (arg === "on") {
      await updateSettings({ autoReload: { enabled: true } });
      startAutoReloader(COMMANDS_DIR); // no-op kalau sudah berjalan
      return m.reply(`${statusText()}\n\nCommand akan dimuat ulang otomatis setiap ada file yang berubah.`);
    }

    if (arg === "off") {
      await updateSettings({ autoReload: { enabled: false } });
      stopAutoReloader();
      return m.reply(`${statusText()}\n\nPerubahan file tidak lagi dipantau. Aktifkan lagi dengan .autoreload on`);
    }

    await loadSettings();
    return m.reply(`${statusText()}\n\nPakai: ${this.usage}`);
  },
};
