import { readdir } from "node:fs/promises";
import { rm } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const run = promisify(execFile);

export default {
  name: "cleartmp",
  alias: ["cleantmp", "cleartemp"],
  category: "ownermenu",
  description: "Clear temporary files from the server.",
  usage: ".cleartmp",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    try {
      const entries = await readdir("/tmp");
      let removed = 0;

      for (const entry of entries) {
        if (!entry || entry === "." || entry === "..") continue;
        try {
          await rm(`/tmp/${entry}`, { recursive: true, force: true });
          removed++;
        } catch {
          // Continue when a temporary file is locked or already removed.
        }
      }

      const { stdout } = await run("df", ["-h", "/tmp"]);
      await m.reply(`Temporary directory cleaned successfully.\n\nRemoved entries: ${removed}\n\n${stdout.trim()}`);
    } catch (error) {
      await m.reply(`Failed to clean temporary files: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
