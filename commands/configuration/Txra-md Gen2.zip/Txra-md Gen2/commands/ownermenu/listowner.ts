import { getOwner } from "../../lib/usermanager/owner.ts";

export default {
  name: "listowner",
  alias: ["owners"],
  category: "ownermenu",
  description: "List all configured owners.",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    const owner = getOwner();
    const lines = [owner.primary && `Primary: ${owner.primary}`, ...owner.additional.map((phone) => `Additional: ${phone}`)].filter(Boolean);
    return m.reply(lines.length ? lines.join("\n") : "No owner is configured.");
  },
};
