import { unlink } from "node:fs/promises";
import { extname, relative, resolve } from "node:path";

function pluginPath(input: string): string {
  const raw = input.trim().replace(/\\/g, "/");
  const safe = raw.replace(/[^a-zA-Z0-9_./-]/g, "");
  if (!safe) throw new Error("Provide a plugin filename.");
  const file = extname(safe) ? safe : `${safe}.ts`;
  const commandsDir = resolve(process.cwd(), "commands");
  const path = resolve(commandsDir, file);
  if (!path.startsWith(`${commandsDir}/`)) throw new Error("Invalid plugin path.");
  return path;
}

export default {
  name: "delplugin",
  alias: ["dlp"],
  category: "ownermenu",
  description: "Delete a command plugin.",
  usage: ".dlp path/name.ts",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const name = String(ctx.args?.[0] ?? "").trim();
    if (!name) return m.reply("Usage: .dlp path/name.ts");
    try {
      const filePath = pluginPath(name);
      await unlink(filePath);
      const displayPath = relative(resolve(process.cwd(), "commands"), filePath).replace(/\\/g, "/");
      return m.reply(`Plugin deleted: ${displayPath}`);
    } catch (error) {
      return m.reply(`Delete failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};
