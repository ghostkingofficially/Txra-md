import { addAdditionalOwners, normalizePhone } from "../../lib/usermanager/owner.ts";

export default {
  name: "addowner",
  alias: ["ado"],
  category: "ownermenu",
  description: "Add an additional bot owner.",
  usage: ".ado 255700000000",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phones = (ctx.args ?? []).map((value: string) => normalizePhone(value)).filter(Boolean);
    if (!phones.length) return m.reply("Usage: .ado 255700000000");
    const added = await addAdditionalOwners(phones);
    return m.reply(added.length ? `Owner added: ${added.join(", ")}` : "No new owner was added.");
  },
};
