import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";

const FILE = resolve(process.cwd(), "db/groupmeta/blacklist.json");

export default {
  name: "addbl",
  alias: ["blacklist"],
  category: "ownermenu",
  description: "Add a group to the persistent blacklist.",
  isOwner: true,
  isGroup: true,
  isNoLimit: true,
  async execute(m: any) {
    const groupId = String(m.chat ?? "");
    if (!groupId.endsWith("@g.us")) return m.reply("This command can only be used in a group.");
    let groups: string[] = [];
    try { groups = JSON.parse(await readFile(FILE, "utf8")); } catch { groups = []; }
    if (!groups.includes(groupId)) groups.push(groupId);
    await mkdir(dirname(FILE), { recursive: true });
    await writeFile(FILE, JSON.stringify([...new Set(groups)].sort(), null, 2));
    return m.reply("This group has been added to the blacklist.");
  },
};
