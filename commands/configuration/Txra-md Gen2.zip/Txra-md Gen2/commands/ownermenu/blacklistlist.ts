import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const FILE = resolve(process.cwd(), "db/groupmeta/blacklist.json");

export default {
  name: "listbl",
  alias: ["blacklistlist"],
  category: "ownermenu",
  description: "List all blacklisted groups.",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    let groups: string[] = [];
    try { groups = JSON.parse(await readFile(FILE, "utf8")); } catch { groups = []; }
    return m.reply(groups.length ? `Blacklisted groups (${groups.length}):\n${groups.join("\n")}` : "No groups are blacklisted.");
  },
};
