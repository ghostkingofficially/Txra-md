import { mkdir, writeFile } from "node:fs/promises";
import { dirname, extname, resolve } from "node:path";

function pluginPath(input: string): string {
  const raw = input.trim().replace(/\\/g, "/");
  const safe = raw.replace(/[^a-zA-Z0-9_./-]/g, "");
  if (!safe) throw new Error("Provide a plugin filename.");
  const file = extname(safe) ? safe : `${safe}.ts`;
  const commandsDir = resolve(process.cwd(), "commands");
  const path = resolve(commandsDir, file);
  if (!path.startsWith(`${commandsDir}/`)) throw new Error("Invalid plugin path.");
  return path;
}

export default {
  name: "saveplugin",
  alias: ["sp"],
  category: "ownermenu",
  description: "Save plugin source into the commands folder.",
  usage: ".sp path/name.ts <source> or reply to source text",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const input = String(ctx.text ?? "").trim();
    const firstSpace = input.indexOf(" ");
    const name = firstSpace < 0 ? input : input.slice(0, firstSpace);
    const inlineSource = firstSpace < 0 ? "" : input.slice(firstSpace + 1).trim();
    const source = inlineSource || String(m.quoted?.body ?? "").trim();
    if (!name || !source) return m.reply("Usage: .sp path/name.ts <source>, or reply to plugin source text.");
    try {
      const filePath = pluginPath(name);
      await mkdir(dirname(filePath), { recursive: true });
      await writeFile(filePath, source.endsWith("\n") ? source : `${source}\n`, "utf8");
      return m.reply(`Plugin saved: ${filePath}\nUse .rb or wait for auto-reload.`);
    } catch (error) {
      return m.reply(`Save failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};