import { readdir, readFile } from "node:fs/promises";
import { join, relative, resolve } from "node:path";
import { AIRich } from "../../helpers/utils/rich-messages/index.ts";

async function collectFiles(directory: string, root: string, result: string[]): Promise<void> {
  let entries;
  try { entries = await readdir(directory, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    if (entry.name.startsWith(".")) continue;
    const full = join(directory, entry.name);
    if (entry.isDirectory()) await collectFiles(full, root, result);
    else if (/\.(?:json|sqlite|db|txt)$/.test(entry.name)) result.push(relative(root, full).replace(/\\/g, "/"));
  }
}

export default {
  name: "getdb",
  alias: ["getdatabase"],
  category: "ownermenu",
  description: "Show a database file or list database files.",
  usage: ".getdb db/usermanager/users.json",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const root = resolve(process.cwd());
    const requested = String(ctx.args?.[0] ?? "").trim();
    try {
      if (!requested) {
        const files: string[] = [];
        await collectFiles(join(root, "db"), root, files);
        return m.reply(files.length ? `Database files:\n${files.sort().join("\n")}` : "No database files found.");
      }
      const safe = resolve(root, requested);
      if (!safe.startsWith(`${root}/`)) return m.reply("Invalid database path.");
      const content = await readFile(safe, "utf8");
      if (content.length <= 3500) return m.reply(`Database: ${relative(root, safe)}\n\n${content}`);
      return new AIRich(ctx.client).setTitle(`Database: ${relative(root, safe)}`).addCode("json", content.slice(0, 12000)).send(m.chat, { quoted: m });
    } catch (error) {
      return m.reply(`Get database failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};