export default {
  name: "stopbot",
  alias: ["sb"],
  category: "ownermenu",
  description: "Stop the bot process.",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    await m.reply("Bot is shutting down.");
    setTimeout(() => process.exit(0), 500);
  },
};
