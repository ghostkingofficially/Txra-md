import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const FILE = resolve(process.cwd(), "db/groupmeta/blacklist.json");

export default {
  name: "delbl",
  alias: ["unblacklist"],
  category: "ownermenu",
  description: "Remove the current group from the blacklist.",
  isOwner: true,
  isGroup: true,
  isNoLimit: true,
  async execute(m: any) {
    const groupId = String(m.chat ?? "");
    if (!groupId.endsWith("@g.us")) return m.reply("This command can only be used in a group.");
    let groups: string[] = [];
    try { groups = JSON.parse(await readFile(FILE, "utf8")); } catch { groups = []; }
    const next = groups.filter((value) => value !== groupId);
    await writeFile(FILE, JSON.stringify(next.sort(), null, 2));
    return m.reply(next.length === groups.length ? "This group was not blacklisted." : "This group has been removed from the blacklist.");
  },
};
