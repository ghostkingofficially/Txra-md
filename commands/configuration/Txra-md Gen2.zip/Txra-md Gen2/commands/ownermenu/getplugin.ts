import { readFile } from "node:fs/promises";
import { extname, resolve, relative } from "node:path";
import { AIRich } from "../../helpers/utils/rich-messages/index.ts";

function pluginPath(input: string): string {
  const raw = input.trim().replace(/\\/g, "/");
  const safe = raw.replace(/[^a-zA-Z0-9_./-]/g, "");
  if (!safe) throw new Error("Provide a plugin filename.");
  const file = extname(safe) ? safe : `${safe}.ts`;
  const commandsDir = resolve(process.cwd(), "commands");
  const path = resolve(commandsDir, file);
  if (!path.startsWith(`${commandsDir}/`)) throw new Error("Invalid plugin path.");
  return path;
}

export default {
  name: "getplugin",
  alias: ["gp"],
  category: "ownermenu",
  description: "Display a plugin source using an AIRich code block.",
  usage: ".gp path/name.ts",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const name = String(ctx.args?.[0] ?? "").trim();
    if (!name) return m.reply("Usage: .gp path/name.ts");
    try {
      const filePath = pluginPath(name);
      const source = await readFile(filePath, "utf8");
      const displayPath = relative(resolve(process.cwd(), "commands"), filePath).replace(/\\/g, "/");
      return new AIRich(ctx.client)
        .setTitle(`Plugin: ${displayPath}`)
        .addText("Plugin source")
        .addCode("typescript", source)
        .send(m.chat, { quoted: m });
    } catch (error) {
      return m.reply(`Get plugin failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};