export default {
  name: "leavgc",
  alias: ["leavegc", "leavegroup"],
  category: "ownermenu",
  description: "Remove the bot from the current group.",
  isGroup: true,
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    try {
      const groupApi = ctx.client.group;
      const leave = groupApi?.leave || groupApi?.leaveGroup;
      if (typeof leave !== "function") return m.reply("The group leave API is not available.");
      await leave.call(groupApi, m.chat);
    } catch (error) {
      return m.reply(`Failed to leave the group: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};