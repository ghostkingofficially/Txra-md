export default {
  name: "rb",
  alias: ["restart", "restarting", "reboot"],
  category: "ownermenu",
  description: "Restart the bot process through the hosting panel.",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any) {
    await m.reply("Restarting bot...");
    setTimeout(() => process.exit(0), 500);
  },
};