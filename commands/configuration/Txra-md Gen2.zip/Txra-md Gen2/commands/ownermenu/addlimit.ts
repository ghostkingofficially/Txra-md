import { addLimit, toUserPhone } from "../../lib/usermanager/users.ts";

function getTarget(m: any, ctx: any): string {
  const argument = String(ctx.args?.[0] ?? "").trim();
  const phone = toUserPhone(argument);
  if (phone) return `${phone}@s.whatsapp.net`;
  const mentioned = m.mentionedJid?.[0] ?? m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  if (mentioned && toUserPhone(mentioned)) return mentioned;
  const quoted = m.quoted?.sender ?? m.quoted?.key?.participant;
  return quoted && toUserPhone(quoted) ? quoted : "";
}

export default {
  name: "adl",
  alias: ["addlimit"],
  category: "ownermenu",
  description: "Add command limit to a user.",
  usage: ".adl 255700000000 10",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const jid = getTarget(m, ctx);
    const amountIndex = toUserPhone(String(ctx.args?.[0] ?? "")) ? 1 : 0;
    const amount = Number(ctx.args?.[amountIndex] ?? 0);
    if (!jid || !Number.isInteger(amount) || amount <= 0) return m.reply("Usage: .adl 255700000000 10, or reply/mention a user and use .adl 10");
    const total = addLimit(jid, amount);
    return m.reply(`Added ${amount} limit(s) to ${jid}. New balance: ${total}.`);
  },
};