import { getOwner, normalizePhone, saveOwner } from "../../lib/usermanager/owner.ts";

export default {
  name: "delowner",
  alias: ["slow"],
  category: "ownermenu",
  description: "Remove an additional bot owner.",
  usage: ".slow 255700000000",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone = normalizePhone(String(ctx.args?.[0] ?? ""));
    if (!phone) return m.reply("Usage: .slow 255700000000");
    const owner = getOwner();
    if (phone === owner.primary) return m.reply("The primary owner cannot be removed with this command.");
    if (!owner.additional.includes(phone)) return m.reply("That number is not an additional owner.");
    owner.additional = owner.additional.filter((value) => value !== phone);
    if (owner.addedAt) delete owner.addedAt[phone];
    await saveOwner();
    return m.reply(`Owner removed: ${phone}`);
  },
};