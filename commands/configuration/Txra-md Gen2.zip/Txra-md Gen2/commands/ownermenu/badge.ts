import { loadBadgeConfig, sendBadge, setBadgeEnabled, setBadgeFromBuffer } from "../../src/badge/index.ts";

function quotedSticker(m: any): any | null {
  const quoted = m?.quoted;
  if (quoted?.mtype === "stickerMessage" || quoted?.type === "stickerMessage") return quoted;
  if (quoted?.message?.stickerMessage) return quoted.message.stickerMessage;
  if (m?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage) {
    return m.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage;
  }
  return null;
}

export default {
  name: "badge",
  alias: ["autobadge", "setbadge"],
  category: "owner",
  description: "Set the sticker badge sent as a reaction to commands",
  usage: ".badge (quote a sticker) | on | off | status",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const sub = String(ctx.args?.[0] || "").toLowerCase();
    if (sub === "on" || sub === "off") {
      const config = await setBadgeEnabled(sub === "on");
      return m.reply(`Auto badge is now ${config.enabled ? "ON" : "OFF"}.`, { fake: false });
    }

    if (sub === "status" || !sub) {
      const config = await loadBadgeConfig();
      return m.reply(
        `Auto badge: ${config.enabled ? "ON" : "OFF"}\n` +
        `Sticker: ${config.sticker ? "configured" : "not configured"}\n\n` +
        `Quote a sticker and use .badge to replace it.`,
        { fake: false },
      );
    }

    const sticker = quotedSticker(m);
    if (!sticker || typeof m.quoted?.download !== "function") {
      return m.reply("Quote a sticker, then run .badge. Use .badge on, .badge off, or .badge status.", { fake: false });
    }

    const bytes = await m.quoted.download();
    if (!bytes || !bytes.length) throw new Error("The quoted sticker could not be downloaded.");
    const isAnimated = sticker.isAnimated === true || sticker.isLottie === true;
    const config = await setBadgeFromBuffer(ctx.client, bytes, isAnimated);
    await setBadgeEnabled(true);
    await sendBadge(ctx.client, m).catch(() => undefined);
    return m.reply(
      `Badge sticker saved and enabled.\nType: ${isAnimated ? "animated" : "static"}\nSize: ${(bytes.length / 1024).toFixed(1)} KB`,
      { fake: false },
    );
  },
};
