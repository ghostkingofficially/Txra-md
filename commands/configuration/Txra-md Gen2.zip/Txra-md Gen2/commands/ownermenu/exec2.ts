import { exec as runShell } from "node:child_process";
import { promisify } from "node:util";

const execAsync = promisify(runShell);

export default {
  name: "exec2",
  alias: ["shell2"],
  category: "owner",
  description: "Run a shell command using the $ prefix.",
  usage: "$ command",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const command = String(ctx.input || "").trim();
    if (!command) return m.reply("Usage: $ command");
    try {
      const result = await execAsync(command, { timeout: 120000, maxBuffer: 2 * 1024 * 1024 });
      const output = `${result.stdout || ""}${result.stderr || ""}`.trim();
      return m.reply(output ? `\u0060\u0060\u0060\n${output}\n\u0060\u0060\u0060` : "Command completed with no output.");
    } catch (error: any) {
      const output = `${error?.stdout || ""}${error?.stderr || ""}`.trim();
      return m.reply(`Command failed${output ? `:\n\u0060\u0060\u0060\n${output}\n\u0060\u0060\u0060` : ": " + String(error?.message || error)}`);
    }
  },
};
