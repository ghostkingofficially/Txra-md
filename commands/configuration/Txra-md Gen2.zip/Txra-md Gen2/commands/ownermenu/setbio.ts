export default {
  name: "setbio",
  alias: ["setstatus", "bio"],
  category: "ownermenu",
  description: "Update the bot profile bio.",
  usage: ".setbio Your new bio",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const text = String(ctx.args?.join(" ") ?? "").trim();
    if (!text) return m.reply("Usage: .setbio 🗿 Away, Leave Message");
    try {
      const profile = ctx.client.profile;
      const method = profile?.updateStatus || profile?.setStatus || profile?.updateBio;
      if (typeof method !== "function") return m.reply("The profile bio API is not available in this client.");
      await method.call(profile, text);
      return m.reply("Bot bio updated successfully.");
    } catch (error) {
      return m.reply(`Failed to update bot bio: ${error instanceof Error ? error.message : String(error)}`);
    }
  },
};