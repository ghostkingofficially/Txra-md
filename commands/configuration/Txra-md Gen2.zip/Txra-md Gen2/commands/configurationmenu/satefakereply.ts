// commands/configuration/setfakereply/setfakereply.ts — atur fake reply (owner)
// Fake reply = tipe pesan untuk SETIAP balasan bot.
//   .sfr                     → daftar tipe (nomor) + status
//   .sfr <nomor>             → ganti tipe balasan semua pesan (langsung berlaku)
//   .sfr on | off            → hidupkan / matikan
//   .sfr demo [nomor|all]    → kirim contoh tipe tertentu / semua, tanpa mengganti yang aktif
//   .sfr img <jenis> <url>   → gambar per jenis respon (hanya URL http/https)
//   .sfr img reset <jenis|all>
// Gaya kartu kutipan dipisah → .setfqq (setfqquoted).
// Jenis: default, success, error, owner, premium, admin, limit (kunci lain boleh ditambah)
import { getPresets, replyFake } from "../../src/setfakereply/index.ts";
import {
  FAKE_KINDS, loadFakeConfig, resetFakeImages, setFakeImage, updateFakeConfig,
} from "../../src/setfakereply/store.ts";
import { getFakeImageBytes } from "../../src/setfakereply/builder.ts";

const show = (v?: string) => (v ? (v.length > 48 ? v.slice(0, 45) + "..." : v) : "(kosong → pakai default)");
const KIND_OK = /^[a-z0-9_-]{1,20}$/i;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export default {
  name: "setfakereply",
  alias: ["sfr"],
  category: "configuration",
  description: "Atur tipe fake reply untuk semua balasan",
  usage: ".sfr | .sfr <nomor> | on | off | demo [nomor|all] | img <jenis> <url>",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const sub = String(ctx.args?.[0] ?? "").toLowerCase();
    const plain = { fake: false };

    // ── daftar + status ──
    if (!sub) {
      const c = await loadFakeConfig();
      const presets = await getPresets();
      const list = Object.entries(presets).map(([n, pr]) => `${Number(n) === c.active ? "▶" : "•"} ${n}. ${pr.name}`).join("\n");
      return m.reply(
        `*Fake reply* ${c.enabled ? "✅ ON" : "⛔ OFF"}\n\n${list}\n\n` +
        `Ganti tipe: ${p}sfr <nomor>\nContoh semua: ${p}sfr demo all\nLainnya: on|off · img <jenis> <url>\nKartu kutipan: ${p}setfqq`,
        plain,
      );
    }

    // ── ganti preset: .sfr <nomor> ──
    if (/^\d+$/.test(sub)) {
      const n = Number(sub);
      const presets = await getPresets();
      if (!presets[n]) return m.reply(`Nomor tidak ada. Pilih 1–${Object.keys(presets).length}.`, plain);
      await updateFakeConfig({ active: n });
      return m.reply(`✅ Semua balasan sekarang memakai tipe *${n}. ${presets[n].name}*`, { kind: "success" });
    }

    // ── on / off ──
    if (sub === "on" || sub === "off") {
      await updateFakeConfig({ enabled: sub === "on" });
      return m.reply(`Fake reply sekarang *${sub === "on" ? "ON" : "OFF"}*.`, plain);
    }

    // ── demo: kirim contoh tanpa mengganti preset aktif ──
    if (sub === "demo") {
      const presets = await getPresets();
      const arg = String(ctx.args?.[1] ?? "").toLowerCase();
      const nums = arg === "all" || !arg ? Object.keys(presets).map(Number) : [Number(arg)];
      if (nums.some((n) => !presets[n])) return m.reply(`Nomor tidak ada. Pilih 1–${Object.keys(presets).length} atau all.`, plain);
      for (const n of nums) {
        await replyFake(ctx.client, m, {
          preset: n,
          kind: "success",
          text: `Contoh tipe ${n}: ${presets[n].name}`,
          command: `${p}sfr`,
          user: { jid: m.sender, name: m.pushName },
          mentions: [m.sender],
        });
        if (nums.length > 1) await sleep(1500);
      }
      return;
    }

    // ── gaya kartu kutipan dipisah ke .setfqq ──
    if (sub === "q" || sub === "style") {
      return m.reply(`Kartu kutipan sudah dipisah → pakai *${p}setfqq* untuk ganti gaya kartu.`, plain);
    }

    // ── gambar per jenis respon ──
    if (sub === "img") {
      const a1 = String(ctx.args?.[1] ?? "").toLowerCase();

      if (!a1) {
        const c = await loadFakeConfig();
        const kinds = [...new Set([...FAKE_KINDS, ...Object.keys(c.images)])];
        return m.reply(`*Gambar per jenis respon*\n${kinds.map((k) => `• ${k}: ${show(c.images[k])}`).join("\n")}\n\nAtur: ${p}sfr img <jenis> <url>`, plain);
      }

      if (a1 === "reset") {
        const k = String(ctx.args?.[2] ?? "").toLowerCase();
        if (k === "all") { await resetFakeImages(); return m.reply("✅ Semua gambar dihapus (memakai bot.thumbnail).", { kind: "success" }); }
        if (!KIND_OK.test(k)) return m.reply(`Pakai: ${p}sfr img reset <jenis|all>`, plain);
        await setFakeImage(k, "");
        return m.reply(`✅ Gambar *${k}* dihapus (jatuh ke "default").`, { kind: "success" });
      }

      if (!KIND_OK.test(a1)) return m.reply(`Pakai: ${p}sfr img <jenis> <url>\nJenis: ${FAKE_KINDS.join(", ")}`, plain);
      const url = String(ctx.args?.[2] ?? "");
      if (!/^https?:\/\/\S+$/i.test(url)) return m.reply(`Sertakan URL gambar (http/https).\nContoh: ${p}sfr img ${a1} https://.../gambar.jpg`, plain);

      const before = (await loadFakeConfig()).images[a1] ?? "";
      try {
        await setFakeImage(a1, url);
        if (!(await getFakeImageBytes(a1))) {
          await setFakeImage(a1, before);
          return m.reply("❌ Gambar tidak bisa dimuat (URL salah / bukan gambar). Tidak diubah.", plain);
        }
        return m.reply(`✅ Gambar *${a1}* diperbarui.`, { kind: "success" });
      } catch (e) {
        await setFakeImage(a1, before).catch(() => {});
        return m.reply(`❌ Gagal mengatur gambar: ${(e as Error).message}`, { kind: "error" });
      }
    }

    return m.reply(`Perintah tidak dikenal. Ketik ${p}sfr untuk daftar tipe.`, plain);
  },
};
