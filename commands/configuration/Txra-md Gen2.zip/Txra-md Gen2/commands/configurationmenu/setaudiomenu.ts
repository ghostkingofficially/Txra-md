// commands/ownermenu/setaudiomenu.ts — atur audio (VN) yang dikirim bersama menu utama (owner), sumbernya URL.
//   .setaudiomenu                → status
//   .setaudiomenu <url>          → atur (dicek: bisa diunduh + bisa diubah ke VN)
//   .setaudiomenu test           → kirim audio menu sekarang
//   .setaudiomenu reset          → hapus audio menu
import { getMenuAudio, setMenuAudio } from "../../src/setmenu/store.ts";
import { isAudioUrl, menuAudioSource, renderMenuVoiceNote, sendMenuAudio } from "../../src/setmenu/audio.ts";

const show = (v: string) => (v ? (v.length > 70 ? v.slice(0, 67) + "..." : v) : "(belum diatur)");

export default {
  name: "setaudiomenu",
  alias: ["menuaudio", "setmenuaudio"],
  category: "ownermenu",
  description: "Atur audio (VN) menu dari URL",
  usage: ".setaudiomenu <url> | test | reset",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const plain = { fake: false };
    const arg = String(ctx.args?.[0] ?? "").trim();

    if (!arg) {
      return m.reply(`*Audio menu*\n${show(await menuAudioSource())}\n\nAtur  : ${p}setaudiomenu <url audio>\nUji   : ${p}setaudiomenu test\nHapus : ${p}setaudiomenu reset`, plain);
    }
    if (arg.toLowerCase() === "reset") {
      await setMenuAudio("");
      return m.reply("✅ Audio menu dihapus. Menu terkirim tanpa audio.", { kind: "success" });
    }
    if (arg.toLowerCase() === "test") {
      const ok = await sendMenuAudio(ctx.client, m.chat, m);
      return ok ? undefined : m.reply(`❌ Audio tidak terkirim — atur dulu: ${p}setaudiomenu <url>, atau lihat log bot.`, plain);
    }

    if (!isAudioUrl(arg)) return m.reply(`❌ Harus berupa URL (http/https).\nContoh: ${p}setaudiomenu https://example.com/menu.mp3`, plain);
    const before = await getMenuAudio();
    try {
      const { bytes, seconds } = await renderMenuVoiceNote(arg, { fresh: true }); // cek bisa diunduh + bisa jadi VN (lewati cache)
      await setMenuAudio(arg);
      return m.reply(`✅ Audio menu diperbarui.\nDurasi VN : ${seconds ? seconds + " detik" : "-"}\nUkuran VN  : ${(bytes.length / 1024).toFixed(0)} KB\n\nUji: ${p}setaudiomenu test`, { kind: "success" });
    } catch (e) {
      await setMenuAudio(before).catch(() => {});
      return m.reply(`❌ Gagal mengatur audio: ${(e as Error).message}\nAudio lama dipertahankan.`, plain);
    }
  },
};