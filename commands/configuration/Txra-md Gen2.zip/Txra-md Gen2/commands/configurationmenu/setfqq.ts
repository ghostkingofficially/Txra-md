// commands/configurationmenu/setfqq.ts — atur gaya KARTU KUTIPAN palsu (6 preset + subs, dua level)
import { loadFakeQuotedConfig, setActivePreset, setActiveSub } from "../../src/setfakequoted/store.ts";
import { buildFakeQuotedMessage } from "../../src/setfakequoted/builder.ts";

export default {
  name: "setfqq",
  alias: ["setfqq", "setfqquoted", "setfakequoted"],
  category: "configuration",
  description: "Atur gaya kartu kutipan — 6 preset (pakai sub untuk detail)",
  usage: ".setfqq | .setfqq <preset> | .setfqq <preset> <sub>",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const a0 = String(ctx.args?.[0] ?? "").toLowerCase();
    const a1 = String(ctx.args?.[1] ?? "").toLowerCase();
    const plain = { fake: false };

    const cfg = await loadFakeQuotedConfig();

    // daftar preset utama
    if (!a0) {
      const lines = Object.entries(cfg.presets).map(([k, pr]) => `${Number(k) === cfg.active ? "▶" : "•"} ${k}. ${pr.name}`).join("\n");
      return m.reply(`*Kartu kutipan*  aktif: *${cfg.active}. ${cfg.presets[String(cfg.active)]?.name ?? "-"}*\n\n${lines}\n\nLihat sub: ${p}setfqq <angka>\nPilih: ${p}setfqq <preset> <sub>`, plain);
    }

    const presetKey = Number(a0);
    if (!Number.isInteger(presetKey) || !cfg.presets[String(presetKey)]) {
      return m.reply(`Preset tidak ada. Pilih 1–${Object.keys(cfg.presets).length}.`, plain);
    }
    const preset = cfg.presets[String(presetKey)];
    const subKeys = Object.keys(preset.subs);

    // .setfqq <p> — list subs (atau langsung aktif kalau cuma 1 sub dan tanpa a1)
    if (!a1) {
      if (subKeys.length === 1) {
        await setActivePreset(presetKey);
        await setActiveSub(presetKey, Number(subKeys[0]));
        return m.reply(`✅ Kartu kutipan → *${preset.name}* (${preset.subs[subKeys[0]].name})`, { kind: "success" });
      }
      const lines = Object.entries(preset.subs).map(([k, s]) => `${Number(k) === preset.activeSub ? "▶" : "•"} ${k}. ${s.name}`).join("\n");
      return m.reply(`*${preset.name}* — pilih sub:\n\n${lines}\n\nPilih: ${p}setfqq ${presetKey} <angka>`, plain);
    }

    const subKey = Number(a1);
    if (!Number.isInteger(subKey) || !preset.subs[String(subKey)]) {
      return m.reply(`Sub tidak ada untuk ${preset.name}. Pilih ${subKeys.join(", ")}.`, plain);
    }
    await setActivePreset(presetKey);
    await setActiveSub(presetKey, subKey);
    // opsional: kirim contoh kecil tanpa ganti preset lalu kembalikan
    try {
      const quoted = await buildFakeQuotedMessage(null, { text: "Contoh kartu kutipan", jid: m.sender, name: m.pushName }, ctx.client);
      // kirim sebagai extendedText biar kelihatan kartu, tapi jangan ganggu reply hook
      const preview = quoted?.contactMessage ? `vCard ${quoted.contactMessage.displayName}` : quoted?.botForwardedMessage ? "Meta AI" : quoted?.orderMessage ? "Order" : quoted?.requestPaymentMessage ? "Payment" : "Kutipan";
      void preview;
    } catch {}
    return m.reply(`✅ Kartu kutipan → *${preset.name}* (${preset.subs[String(subKey)].name})`, { kind: "success" });
  },
};
