import { checkCustomNodesPatch } from "../../lib/func/zapoPatch.ts";
import { updateSettings } from "../../lib/settings/botSettings.ts";
import { getActiveThumbType, sendLarge, THUMB_LARGE_TYPES, type ThumbLargeType } from "../../src/setthumblarge/index.ts";

const ALIAS: Record<string, ThumbLargeType> = {
  linkpreview: "linkpreview", link: "linkpreview", preview: "linkpreview",
  location: "location", lokasi: "location",
  product: "product", produk: "product",
  image: "image", gambar: "image", foto: "image",
  catalog: "catalog", katalog: "catalog",
};

const DESC: Record<ThumbLargeType, string> = {
  linkpreview: "pratinjau link besar (tanpa tombol, saran command jadi teks)",
  location: "kartu lokasi + tombol (thumbnail kecil)",
  product: "kartu produk + tombol",
  image: "gambar biasa + caption",
  catalog: "kartu katalog + tombol (butuh `deno task patch`)",
};

async function patchWarning(): Promise<string> {
  const st = await checkCustomNodesPatch();
  if (st.state === "patched") return "";
  return st.state === "unpatched"
    ? "⚠ zapo-js BELUM ditambal → tipe *catalog* tidak akan tampil.\nJalankan: `deno task patch` lalu restart bot."
    : "⚠ node_modules/zapo-js tidak ditemukan, status tambalan tidak bisa dicek. Jalankan `deno install` lalu `deno task patch`.";
}

export default {
  name: "stl",
  alias: ["thumblarge"],
  category: "configuration",
  usage: ".setthumblarge | .setthumblarge <tipe> | .setthumblarge test [tipe]",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const arg = String(ctx.args?.[0] ?? "").toLowerCase();
    const prefix = ctx.prefix ?? ".";

    // ── status ──
    if (!arg) {
      const active = await getActiveThumbType();
      const list = THUMB_LARGE_TYPES.map((t) => `${t === active ? "▶" : "•"} ${t} — ${DESC[t]}`).join("\n");
      return m.reply(`*Thumbnail besar*\nTipe aktif: *${active}*\n\n${list}\n\nGanti: ${prefix}setthumblarge <tipe>\nContoh: ${prefix}setthumblarge test`);
    }

    // ── test ──
    if (arg === "test") {
      const wanted = ctx.args?.[1] ? ALIAS[String(ctx.args[1]).toLowerCase()] : undefined;
      if (ctx.args?.[1] && !wanted) return m.reply(`Tipe tidak dikenal. Pilihan: ${THUMB_LARGE_TYPES.join(", ")}`);
      const type = wanted ?? await getActiveThumbType();
      if (type === "catalog") { const w = await patchWarning(); if (w) await m.reply(w); }

      const res = await sendLarge(ctx.client, m, {
        type,
        prefix,
        title: "Contoh tampilan",
        subtitle: `tipe: ${type}`,
        text: `Ini contoh balasan bertipe *${type}*.`,
        footer: "setthumblarge test",
        suggest: [`${prefix}setthumblarge`, `${prefix}setthumb`],          // dipakai linkpreview
        buttons: [                                                          // dipakai tipe lain
          { name: "quick_reply", params: { display_text: "Setting", id: `${prefix}setthumblarge` } },
          { name: "quick_reply", params: { display_text: "Thumb", id: `${prefix}setthumb` } },
        ],
      });
      if (res.fallback) return m.reply(`⚠ Tipe *${type}* gagal dikirim, balasan dikirim sebagai teks.\nSebab: ${res.error}`);
      return;
    }

    // ── ganti tipe ──
    const type = ALIAS[arg];
    if (!type) return m.reply(`Tipe tidak dikenal: ${arg}\nPilihan: ${THUMB_LARGE_TYPES.join(", ")}`);
    await updateSettings({ thumbLarge: { type } });
    const warn = type === "catalog" ? await patchWarning() : "";
    return m.reply(`✅ Tipe thumbnail besar sekarang: *${type}*\n${DESC[type]}\n\nCoba: ${prefix}setthumblarge test${warn ? `\n\n${warn}` : ""}`);
  },
};