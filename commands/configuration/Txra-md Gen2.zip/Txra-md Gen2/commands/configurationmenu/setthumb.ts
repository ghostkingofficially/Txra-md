import {
  clearThumbCache, getThumbSource, saveThumbImage, setThumbSource, type ThumbKind,
} from "../../src/setthumblarge/index.ts";
import { getThumb } from "../../src/setthumblarge/thumb.ts";

const KIND: Record<string, ThumbKind> = {
  location: "location", lokasi: "location",
  default: "default", large: "default", besar: "default", biasa: "default",
};

const show = (v: string) => (v ? (v.length > 60 ? v.slice(0, 57) + "..." : v) : "(kosong → pakai bot.thumbnail di config.json)");

export default {
  name: "sethumb",
  category: "configuration",
  description: "Atur gambar thumbnail (location / default)",
  usage: ".setthumb <location|default> <url> | reply foto | .setthumb reset <location|default|all>",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const prefix = ctx.prefix ?? ".";
    const first = String(ctx.args?.[0] ?? "").toLowerCase();

    // ── status ──
    if (!first) {
      return m.reply(
        `*Thumbnail*\n• location: ${show(await getThumbSource("location"))}\n• default: ${show(await getThumbSource("default"))}\n\n` +
        `Atur: ${prefix}setthumb <location|default> <url>\nAtau reply / kirim foto dengan caption ${prefix}setthumb <location|default>`,
      );
    }

    // ── reset ──
    if (first === "reset") {
      const which = String(ctx.args?.[1] ?? "").toLowerCase();
      const kinds: ThumbKind[] = which === "all" ? ["location", "default"] : KIND[which] ? [KIND[which]] : [];
      if (!kinds.length) return m.reply(`Pakai: ${prefix}setthumb reset <location|default|all>`);
      for (const k of kinds) await setThumbSource(k, "");
      clearThumbCache();
      return m.reply(`✅ Thumbnail ${kinds.join(" & ")} dikembalikan ke bawaan (bot.thumbnail di config.json).`);
    }

    // ── set ──
    const kind = KIND[first];
    if (!kind) return m.reply(`Jenis tidak dikenal: ${first}\nPilihan: location, default`);

    const url = String(ctx.args?.[1] ?? "");
    const imageMsg = m.quoted?.mtype === "imageMessage" ? m.quoted : m.mtype === "imageMessage" ? m : null;
    if (!/^https?:\/\//i.test(url) && !imageMsg) {
      return m.reply(`Sertakan URL gambar, atau reply / kirim foto.\nContoh: ${prefix}setthumb ${kind} https://.../gambar.jpg`);
    }

    const previous = await getThumbSource(kind);
    try {
      if (imageMsg) {
        if (typeof imageMsg.download !== "function") return m.reply("Foto tidak bisa diunduh.");
        await saveThumbImage(kind, await imageMsg.download());
      } else {
        await setThumbSource(kind, url);
      }
      clearThumbCache();

            const thumb = await getThumb(kind === "location" ? "location" : "preview");
      if (!thumb) {
        await setThumbSource(kind, previous);
        clearThumbCache();
        return m.reply("❌ Gambar tidak bisa dimuat (URL salah / bukan gambar). Thumbnail tidak diubah.");
      }
      return m.reply(`✅ Thumbnail *${kind}* diperbarui (${thumb.width}x${thumb.height}).\nLihat hasilnya: ${prefix}setthumblarge test`);
    } catch (e) {
      await setThumbSource(kind, previous).catch(() => {});
      clearThumbCache();
      return m.reply(`❌ Gagal mengatur thumbnail: ${(e as Error).message}`);
    }
  },
};
