// commands/configurationmenu/setreaction.ts — atur reaction (owner)
import { loadReactionConfig, updateReactionConfig } from "../../src/reaction/store.ts";
import { DEFAULT_RANDOM } from "../../src/reaction/emojis.ts";

export default {
  name: "setreaction",
  alias: ["reaction", "sr"],
  category: "configuration",
  description: "Atur reaction bot (on/off + emoji)",
  usage: ".setreaction | on | off | loading <emoji> | success <emoji> | failed <emoji> | random <emoji...> | reset",
  isOwner: true,
  isNoLimit: true,

  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const sub = String(ctx.args?.[0] ?? "").toLowerCase();
    const plain = { fake: false };

    if (!sub) {
      const c = await loadReactionConfig();
      return m.reply(
        `*Reaction* ${c.enabled ? "✅ ON" : "⛔ OFF"}\n` +
        `Loading: ${c.loading}  Success: ${c.success}  Failed: ${c.failed}\n` +
        `Random: ${c.random.join(" ")}\n` +
        `UnknownCmd: ${c.unknownCommand ? "ON" : "OFF"}  Notify: ${c.notifyReact ? "ON" : "OFF"}  Stub: ${c.stubReact ? "ON" : "OFF"}  Ephemeral: ${c.ephemeralReact ? "ON" : "OFF"}\n\n` +
        `• ${p}sr on / off\n` +
        `• ${p}sr loading <emoji> | success <emoji> | failed <emoji>\n` +
        `• ${p}sr random <emoji...>\n` +
        `• ${p}sr unknown on/off | notify on/off | stub on/off | ephemeral on/off\n` +
        `• ${p}sr reset`,
        plain,
      );
    }

    if (sub === "on" || sub === "off") {
      const on = sub === "on";
      await updateReactionConfig({ enabled: on });
      return m.reply(`✅ Reaction sekarang *${on ? "ON" : "OFF"}*`, plain);
    }

    if (sub === "reset") {
      await updateReactionConfig({ loading: "⏳", success: "✅", failed: "❌", random: [...DEFAULT_RANDOM], unknownCommand: true, notifyReact: true, stubReact: true, ephemeralReact: true, enabled: true });
      return m.reply("✅ Reaction di-reset ke bawaan.", plain);
    }

    const toggleKeys: Record<string, keyof import("../../src/reaction/store.ts").ReactionConfig> = {
      unknown: "unknownCommand",
      notify: "notifyReact",
      stub: "stubReact",
      ephemeral: "ephemeralReact",
    };
    if (toggleKeys[sub]) {
      const v = String(ctx.args?.[1] ?? "").toLowerCase();
      if (v !== "on" && v !== "off") return m.reply(`Pakai: ${p}sr ${sub} on|off`, plain);
      await updateReactionConfig({ [toggleKeys[sub]!]: v === "on" } as any);
      return m.reply(`✅ ${sub} sekarang *${v.toUpperCase()}*`, plain);
    }

    if (sub === "loading" || sub === "success" || sub === "failed") {
      const emoji = String(ctx.args?.[1] ?? "").trim();
      if (!emoji) return m.reply(`Kirim emoji: ${p}sr ${sub} <emoji>`, plain);
      await updateReactionConfig({ [sub]: emoji } as any);
      return m.reply(`✅ ${sub} → ${emoji}`, plain);
    }

    if (sub === "random") {
      const list = ctx.args.slice(1).map((s: string) => s.trim()).filter(Boolean);
      if (!list.length) return m.reply(`Kirim daftar emoji: ${p}sr random 😍 🔥 ✨`, plain);
      await updateReactionConfig({ random: list.slice(0, 30) });
      return m.reply(`✅ Random → ${list.join(" ")}`, plain);
    }

    return m.reply(`Perintah tidak dikenal. Ketik ${p}sr untuk bantuan.`, plain);
  },
};
