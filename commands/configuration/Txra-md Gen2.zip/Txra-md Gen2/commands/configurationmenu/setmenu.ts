// commands/ownermenu/setmenu.ts — atur preset menu 13 (owner)
//   .setmenu                       → daftar preset + status video
//   .setmenu <angka 1-13>          → ganti tampilan menu
//   .setmenu video <url mp4>       → atur video untuk preset 7–11 (URL saja, tidak menyimpan file)
//   .setmenu video reset           → hapus video
import { loadMenuConfig, setActivePreset, setMenuVideo } from "../../src/setmenu/store.ts";
import { defaultPresets } from "../../src/setmenu/presets.ts";
import { menuVideoSource, readMenuVideo } from "../../src/setmenu/video.ts";

const VIDEO_TYPES = new Set(["motionphoto", "videogif", "videobutton", "videobottomsheet", "videosplit"]);
const MAX_VIDEO_BYTES = 30 * 1024 * 1024;
const show = (v: string) => (v ? (v.length > 60 ? v.slice(0, 57) + "..." : v) : "(belum diatur)");

export default {
  name: "setmenu",
  alias: ["menuconfig", "sm"],
  category: "ownermenu",
  description: "Ganti tampilan menu (13 preset) + atur video menu",
  usage: ".setmenu | .setmenu <angka 1-13> | .setmenu video <url|reset>",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const arg = String(ctx.args?.[0] ?? "").trim();
    const plain = { fake: false };
    const base = defaultPresets();
    const cfg = await loadMenuConfig();

    // ── video menu ──
    if (arg.toLowerCase() === "video") {
      const a1 = String(ctx.args?.[1] ?? "").trim();
      if (!a1) {
        const src = await menuVideoSource();
        return m.reply(
          `*Video menu* (preset 7–11)\n${show(src)}\n\nAtur: ${p}setmenu video <url mp4>\nHapus: ${p}setmenu video reset`,
          plain,
        );
      }
      if (a1.toLowerCase() === "reset") {
        await setMenuVideo("");
        return m.reply("✅ Video menu dihapus. Preset 8–11 akan terkirim sebagai teks biasa, preset 7 sebagai foto biasa.", { kind: "success" });
      }

      const before = cfg.video;
      try {
        if (!/^https?:\/\//i.test(a1)) return m.reply("❌ Video harus berupa URL http/https (.mp4).", plain);
        const bytes = await readMenuVideo(a1); // cek bisa diunduh + benar-benar MP4
        if (bytes.length > MAX_VIDEO_BYTES) return m.reply(`❌ Video terlalu besar (${(bytes.length / 1048576).toFixed(1)} MB). Maksimal ${MAX_VIDEO_BYTES / 1048576} MB.`, plain);
        await setMenuVideo(a1);
        return m.reply(`✅ Video menu diperbarui.\nCoba: ${p}setmenu 8 lalu ${p}menu`, { kind: "success" });
      } catch (e) {
        await setMenuVideo(before).catch(() => {});
        return m.reply(`❌ Gagal mengatur video: ${(e as Error).message}\nVideo lama dipertahankan.`, plain);
      }
    }

    // ── daftar ──
    if (!arg) {
      const lines = Object.entries(base).map(([k, pr]) => `${Number(k) === cfg.active ? "▶" : "•"} ${k}. ${pr.name} — \`${pr.type}\`${VIDEO_TYPES.has(pr.type) ? " 🎞" : ""}`).join("\n");
      return m.reply(
        `*Preset menu*  aktif: *${cfg.active}. ${base[cfg.active]?.name ?? "-"}*\n\n${lines}\n\n🎞 = butuh video (${p}setmenu video <url mp4>)\nVideo: ${show(await menuVideoSource())}\n\nGanti: ${p}setmenu <angka>`,
        plain,
      );
    }

    // ── ganti preset ──
    const n = Number(arg);
    if (!Number.isInteger(n) || !base[n]) return m.reply(`Nomor tidak ada. Pilih 1–13.`, plain);
    const ok = await setActivePreset(n);
    if (!ok) return m.reply("Gagal ganti preset.", plain);

    let warn = "";
    if (VIDEO_TYPES.has(base[n].type) && !(await menuVideoSource())) {
      warn = base[n].type === "motionphoto"
        ? `\n\n⚠ Video belum diatur — preset ini terkirim sebagai foto biasa. Atur: ${p}setmenu video <url mp4>`
        : `\n\n⚠ Video belum diatur — preset ini terkirim sebagai teks biasa sampai kamu atur: ${p}setmenu video <url mp4>`;
    }
    return m.reply(`✅ Menu sekarang preset *${n}. ${base[n].name}*${warn}`, { kind: "success" });
  },
};