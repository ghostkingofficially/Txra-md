// commands/configurationmenu/setfqr.ts — alias kompat lama setfq (reply presets 1..10)
import { getPresets } from "../../src/setfakereply/index.ts";
import { loadFakeConfig, updateFakeConfig } from "../../src/setfakereply/store.ts";

export default {
  name: "setfqr",
  alias: ["setfq", "setfqr"],
  category: "configuration",
  description: "Atur fake reply (alias sfr) — 1..10",
  usage: ".setfqr | .setfqr <nomor>",
  isOwner: true,
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const p = ctx.prefix ?? ".";
    const sub = String(ctx.args?.[0] ?? "").toLowerCase();
    const plain = { fake: false };
    if (!sub) {
      const c = await loadFakeConfig();
      const presets = await getPresets();
      const list = Object.entries(presets).map(([n, pr]) => `${Number(n) === c.active ? "▶" : "•"} ${n}. ${pr.name}`).join("\n");
      return m.reply(`*Fake reply* ${c.enabled ? "✅ ON" : "⛔ OFF"}\n\n${list}\n\nGanti: ${p}setfqr <nomor>  (alias ${p}sfr)`, plain);
    }
    if (/^\d+$/.test(sub)) {
      const n = Number(sub);
      const presets = await getPresets();
      if (!presets[n]) return m.reply(`Nomor tidak ada. Pilih 1–${Object.keys(presets).length}.`, plain);
      await updateFakeConfig({ active: n });
      return m.reply(`✅ Semua balasan sekarang memakai tipe *${n}. ${presets[n].name}*`, { kind: "success" });
    }
    return m.reply(`Pakai: ${p}setfqr <nomor>  (atau ${p}sfr)`, plain);
  },
};
