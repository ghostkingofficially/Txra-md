import { barEnter } from "../../src/rpg/engine.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "bar",
  alias: ["tavern"],
  category: "rpgmenu",
  description: "Masuk bar: HP, Stamina, Mana penuh",
  usage: ".bar",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const r = barEnter(phone);
    return replyResult(ctx.client, m, r, ASSET.loc("bar"));
  },
};
