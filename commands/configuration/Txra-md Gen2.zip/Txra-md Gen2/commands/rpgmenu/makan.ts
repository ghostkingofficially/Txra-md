import { eat, foodList } from "../../src/rpg/engine.ts";
import { RECIPES, resolveId } from "../../src/rpg/data/items.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "makan",
  alias: ["eat"],
  category: "rpgmenu",
  description: "Makan untuk pulihkan HP (bisa pakai nomor dari WARNING HP)",
  usage: ".makan <nama|nomor>",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const arg = ctx.args[0] ?? "";
    const foods = foodList(phone);
    const id = /^\d+$/.test(arg) ? foods[Number(arg) - 1]?.id : resolveId(RECIPES, arg);
    if (!id) return m.reply(foods.length ? `Pilih makanan:\n${foods.map((f, i) => `${i + 1}. ${f.name} x${f.qty}`).join("\n")}` : "Kamu tidak punya makanan. Tanam -> panen -> masak dulu.");
    const r = eat(phone, id);
    return replyResult(ctx.client, m, r, r.img ? ASSET.food(r.img) : undefined);
  },
};
