import { harvest } from "../../src/rpg/engine.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "panen",
  alias: ["harvest"],
  category: "rpgmenu",
  description: "Panen semua tanaman yang siap",
  usage: ".panen",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const r = harvest(phone);
    return replyResult(ctx.client, m, r, r.img ? ASSET.plant(r.img) : undefined);
  },
};