import { sell } from "../../src/rpg/engine.ts";
import { CROPS, RECIPES, resolveId } from "../../src/rpg/data/items.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "jual",
  alias: ["sell"],
  category: "rpgmenu",
  description: "Jual hasil panen / masakan",
  usage: ".jual <item> [jumlah]",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const q = ctx.args[0] ?? "";
    const id = resolveId(CROPS, q) ?? resolveId(RECIPES, q);
    if (!id) return m.reply(`contoh: ${ctx.prefix}jual coral 5 (kosongkan jumlah = jual semua)`);
    return replyResult(ctx.client, m, sell(phone, id, ctx.args[1] ? Number(ctx.args[1]) : undefined));
  },
};
