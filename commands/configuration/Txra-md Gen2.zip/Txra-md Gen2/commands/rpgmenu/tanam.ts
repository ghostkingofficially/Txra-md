import { plant } from "../../src/rpg/engine.ts";
import { CROPS, resolveId } from "../../src/rpg/data/items.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "tanam",
  alias: ["plant"],
  category: "rpgmenu",
  description: "Tanam benih di ladang",
  usage: ".tanam <coral|wintry|loach> [petak]",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const id = resolveId(CROPS, ctx.args[0] ?? "");
    if (!id) return m.reply(`Pilih tanaman: ${Object.keys(CROPS).join(", ")}\ncontoh: ${ctx.prefix}tanam coral`);
    const slot = ctx.args[1] ? Number(ctx.args[1]) : undefined;
    const r = plant(phone, id, Number.isFinite(slot) ? slot : undefined);
    return replyResult(ctx.client, m, r, r.img ? ASSET.plant(r.img) : undefined);
  },
};
