import { RECIPES, itemName } from "../../src/rpg/data/items.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "resep",
  alias: ["recipes"],
  category: "rpgmenu",
  description: "Daftar resep masakan",
  usage: ".resep",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const lines = Object.values(RECIPES).map((r) =>
      `${r.name} (${r.id})\n  Bahan: ${Object.entries(r.needs).map(([k, v]) => `${itemName(k)} x${v}`).join(", ")}\n  Heal ${r.healPct}%${r.staminaGain ? `, Stamina +${r.staminaGain}` : ""}`);
    return m.reply("RESEP\n" + lines.join("\n\n"));
  },
};
