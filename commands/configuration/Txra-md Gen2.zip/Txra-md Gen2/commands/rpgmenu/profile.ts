import { profileText } from "../../src/rpg/engine.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "profile",
  alias: ["rpg","tas","inventory"],
  category: "rpgmenu",
  description: "Profil RPG, status, dan isi tas",
  usage: ".profile",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    return m.reply(profileText(phone, ctx.user?.name || ctx.pushName || "Rover"));
  },
};
