import { cook } from "../../src/rpg/engine.ts";
import { RECIPES, resolveId } from "../../src/rpg/data/items.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "masak",
  alias: ["cook"],
  category: "rpgmenu",
  description: "Masak bahan jadi makanan",
  usage: ".masak <souffle|crownless> [jumlah]",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const id = resolveId(RECIPES, ctx.args[0] ?? "");
    if (!id) return m.reply(`Pilih resep: ${Object.keys(RECIPES).join(", ")}\nlihat bahan: ${ctx.prefix}resep`);
    const r = cook(phone, id, Number(ctx.args[1] ?? 1));
    return replyResult(ctx.client, m, r, r.img ? ASSET.food(r.img) : undefined);
  },
};