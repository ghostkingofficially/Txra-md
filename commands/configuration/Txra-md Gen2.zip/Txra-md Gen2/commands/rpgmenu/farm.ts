import { farmStatus } from "../../src/rpg/engine.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "farm",
  alias: ["ladang","kebun"],
  category: "rpgmenu",
  description: "Lihat status ladang",
  usage: ".farm",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    return m.reply("LADANG\n" + farmStatus(phone));
  },
};
