import { water } from "../../src/rpg/engine.ts";
import { replyResult } from "../../src/rpg/reply.ts";
import { ASSET } from "../../src/rpg/assets.ts";

export default {
  name: "siram",
  alias: ["water"],
  category: "rpgmenu",
  description: "Siram tanaman biar cepat tumbuh",
  usage: ".siram [petak]",
  isNoLimit: true,
  async execute(m: any, ctx: any) {
    const phone: string = ctx.userPhone;
    if (!phone) return m.reply(mess.unresolved);
    const slot = ctx.args[0] ? Number(ctx.args[0]) : undefined;
    return replyResult(ctx.client, m, water(phone, Number.isFinite(slot) ? slot : undefined));
  },
};
