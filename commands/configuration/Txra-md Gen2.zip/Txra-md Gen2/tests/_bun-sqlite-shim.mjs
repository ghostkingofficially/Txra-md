// Shim bun:sqlite -> node:sqlite, hanya untuk menjalankan test di Node. Bun asli tidak butuh file ini.
import { DatabaseSync } from "node:sqlite";
export class Database {
  constructor(path) { this.d = new DatabaseSync(path); this.depth = 0; }
  exec(sql) { return this.d.exec(sql); }
  query(sql) {
    const st = this.d.prepare(sql);
    return { run: (...a) => { const r = st.run(...a); return { changes: Number(r.changes) }; }, get: (...a) => st.get(...a), all: (...a) => st.all(...a) };
  }
  transaction(fn) {
    return () => { this.d.exec("BEGIN"); try { const r = fn(); this.d.exec("COMMIT"); return r; } catch (e) { this.d.exec("ROLLBACK"); throw e; } };
  }
}
