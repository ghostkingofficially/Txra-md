// Jalankan di Bun:  bun test tests/rpg.test.ts   (di Node: lihat tests/_register.mjs)
import { Database } from "bun:sqlite";
import { __setDb, getDb } from "../src/rpg/db.ts";
import * as E from "../src/rpg/engine.ts";

let fails = 0;
const t = (name: string, cond: boolean) => { console.log(`${cond ? "PASS" : "FAIL"}  ${name}`); if (!cond) fails++; };

process.env.RPG_DB_PATH = ":memory:";
__setDb(new Database(":memory:"));
const P = "6281000000001";
const setCred = (n: number) => getDb().query("UPDATE players SET credits = ? WHERE phone = ?").run(n, P);

E.getPlayer(P);
t("player baru 1000 credit, HP penuh", E.getPlayer(P).credits === 1000 && E.getPlayer(P).hp === 100);

// tanam
let r = E.plant(P, "coral");
t("tanam coral sukses & potong 40", r.ok && E.getPlayer(P).credits === 960);
t("tanam tidak ada → gagal", !E.plant(P, "xxx").ok);
t("slot terisi → gagal", !E.plant(P, "coral", 1).ok);
setCred(10);
t("credit kurang → gagal, tidak terpotong", !E.plant(P, "wintry").ok && E.getPlayer(P).credits === 10);
setCred(1000);
for (let i = 0; i < 3; i++) E.plant(P, "coral");
t("petak penuh (4) → gagal", !E.plant(P, "coral").ok);
t("belum siap panen → gagal", !E.harvest(P).ok);

// majukan waktu: planted_at mundur 11 menit
getDb().query("UPDATE plots SET planted_at = planted_at - ?").run(11 * 60_000);
r = E.harvest(P);
const coral = E.getItems(P).coral ?? 0;
t("panen sukses, dapat 8-16 coral", r.ok && coral >= 8 && coral <= 16);
t("petak kosong setelah panen", E.farmStatus(P).split("\n").every((l) => l.includes("kosong")));

// siram mempercepat
E.plant(P, "coral", 1);
t("siram sukses", E.water(P).ok);
t("siram dua kali → tidak ada target", !E.water(P).ok);
getDb().query("UPDATE plots SET planted_at = planted_at - ?").run(8.5 * 60_000); // 8.5 mnt > 10*0.8=8 mnt
t("disiram → siap setelah 8.5 menit", E.harvest(P).ok);

// masak
const before = E.getItems(P).coral ?? 0;
t("masak souffle sukses", E.cook(P, "souffle", 2).ok);
t("bahan berkurang 6", (E.getItems(P).coral ?? 0) === before - 6);
t("souffle x2 di tas", E.getItems(P).souffle === 2);
t("masak bahan kurang → gagal", !E.cook(P, "crownless").ok);

// makan
t("HP penuh → makan ditolak", !E.eat(P, "souffle").ok && E.getItems(P).souffle === 2);
getDb().query("UPDATE players SET hp = 10 WHERE phone = ?").run(P);
const w = E.lowHpWarning(P);
t("warning HP <20% muncul + daftar makanan", !!w && w.includes("HP 10%") && w.includes("Misty Souffle x2"));
r = E.eat(P, "souffle");
t("makan heal 50% → HP 60", r.ok && E.getPlayer(P).hp === 60 && E.getItems(P).souffle === 1);
t("makan tanpa stok → gagal", !E.eat(P, "crownless").ok);
t("HP 60% → tidak ada warning", E.lowHpWarning(P) === null);

// jual
const cBefore = E.getPlayer(P).credits; const nCoral = E.getItems(P).coral ?? 0;
r = E.sell(P, "coral");
t("jual semua coral", r.ok && E.getPlayer(P).credits === cBefore + nCoral * 30 && !(E.getItems(P).coral));
t("jual item kosong → gagal", !E.sell(P, "coral").ok);

// bar
t("bar: kondisi belum penuh → bayar 500, full", (() => {
  getDb().query("UPDATE players SET hp = 20, stamina = 5, mana = 0 WHERE phone = ?").run(P);
  const c = E.getPlayer(P).credits; const x = E.barEnter(P); const p = E.getPlayer(P);
  return x.ok && p.hp === 100 && p.stamina === 100 && p.mana === 100 && p.credits === c - 500;
})());
t("bar: sudah penuh → ditolak, gratis", (() => { const c = E.getPlayer(P).credits; return !E.barEnter(P).ok && E.getPlayer(P).credits === c; })());
setCred(100); getDb().query("UPDATE players SET hp = 1 WHERE phone = ?").run(P);
t("bar: credit kurang → ditolak, HP tetap", !E.barEnter(P).ok && E.getPlayer(P).hp === 1);

// stamina regen
getDb().query("UPDATE players SET stamina = 50, stamina_at = ? WHERE phone = ?").run(Date.now() - 31 * 60_000, P);
t("stamina regen +10 per 30 menit", E.getPlayer(P).stamina === 60);

// atomik: spend tidak boleh minus
setCred(30);
t("credit tidak pernah negatif", !E.plant(P, "loach").ok && E.getPlayer(P).credits === 30);

console.log(fails ? `\n${fails} GAGAL` : "\nSEMUA LULUS");
process.exit(fails ? 1 : 0);
