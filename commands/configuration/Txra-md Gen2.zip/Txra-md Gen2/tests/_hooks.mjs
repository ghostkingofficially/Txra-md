export async function resolve(spec, ctx, next) {
  if (spec === "bun:sqlite") return { url: new URL("./_bun-sqlite-shim.mjs", import.meta.url).href, shortCircuit: true };
  return next(spec, ctx);
}
