// scripts/build-native.ts — build mesin gambar Rust, lalu pasang ke SATU tempat: node_modules/mybes-image-engine/
//   bun run native:build
//
// Pembagian tempat (sengaja dibuat sederhana):
//   native/                              → HANYA kode sumber Rust (±30 KB). Ini yang ikut backup/git.
//   node_modules/mybes-image-engine/     → hasil build yang DIPAKAI bot (.node + package.json + index.js), seperti modul native npm lain.
//   native/prebuilt/<platform>-<arch>.node → salinan kecil (±1–2 MB) supaya restore backup TIDAK perlu Rust/cargo lagi.
//   ~/.cache/mybes-native-target/        → folder kerja cargo (ratusan MB). Di luar project, jadi tidak ikut backup.
//
// Butuh Rust (rustup / `pkg install rust` di Termux). Variabel opsional:
//   CARGO_TARGET_DIR=/path     pindahkan folder kerja cargo
//   KEEP_OLD_TARGET=1          jangan hapus native/target lama (sisa build versi sebelumnya)
import { copyFileSync, existsSync, mkdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const root = join(import.meta.dir, "..");
const dir = join(root, "native");
const targetDir = process.env.CARGO_TARGET_DIR || join(process.env.XDG_CACHE_HOME || join(homedir(), ".cache"), "mybes-native-target");
const t0 = Date.now();

console.log(`▶ cargo build --release (folder kerja: ${targetDir})`);
console.log("  pertama kali mengunduh crate; di HP bisa beberapa menit…");
const proc = Bun.spawnSync(["cargo", "build", "--release"], {
  cwd: dir,
  stdout: "inherit",
  stderr: "inherit",
  env: { ...process.env, CARGO_TARGET_DIR: targetDir },
});
if (proc.exitCode !== 0) {
  console.error("\n✖ build gagal. Kirim pesan error di atas supaya bisa diperbaiki. Bot tetap jalan lewat ffmpeg.");
  process.exit(proc.exitCode ?? 1);
}

const rel = join(targetDir, "release");
const built = ["libmybes_image_engine.so", "libmybes_image_engine.dylib", "mybes_image_engine.dll"].map((f) => join(rel, f)).find(existsSync);
if (!built) { console.error("✖ hasil build tidak ditemukan di", rel); process.exit(1); }

// 1) node_modules/mybes-image-engine — satu-satunya tempat yang dibaca bot saat runtime
const pkgDir = join(root, "node_modules", "mybes-image-engine");
mkdirSync(pkgDir, { recursive: true });
copyFileSync(built, join(pkgDir, "mybes_image_engine.node"));
writeFileSync(join(pkgDir, "index.js"), 'module.exports = require("./mybes_image_engine.node");\n');
writeFileSync(
  join(pkgDir, "package.json"),
  JSON.stringify({ name: "mybes-image-engine", version: "0.2.0", private: true, main: "index.js", description: "Mesin gambar Rust (N-API). Dibuat oleh scripts/build-native.ts" }, null, 2) + "\n",
);

// 2) salinan kecil untuk backup/restore tanpa Rust
const preDir = join(dir, "prebuilt");
mkdirSync(preDir, { recursive: true });
const pre = join(preDir, `${process.platform}-${process.arch}.node`);
copyFileSync(built, pre);

// 3) sisa build lama di dalam project (ini yang bikin backup berat) → buang
const old = join(dir, "target");
if (existsSync(old) && process.env.KEEP_OLD_TARGET !== "1") {
  rmSync(old, { recursive: true, force: true });
  console.log("  native/target lama dihapus (hasil build, bisa dibuat ulang kapan saja)");
}

const kb = (f: string) => (statSync(f).size / 1024).toFixed(0);
console.log(`✔ ${join(pkgDir, "mybes_image_engine.node")}  (${kb(join(pkgDir, "mybes_image_engine.node"))} KB, ${((Date.now() - t0) / 1000).toFixed(0)}s)`);
console.log(`✔ salinan backup: ${pre}`);
console.log("Lanjut: bun run native:test");