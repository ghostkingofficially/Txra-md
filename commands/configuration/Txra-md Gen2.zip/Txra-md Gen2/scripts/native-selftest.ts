// scripts/native-selftest.ts — uji + benchmark mesin Rust vs ffmpeg dengan gambar buatan sendiri (tanpa internet).
//   bun run native:test
import { spawnSync } from "node:child_process";
import { nativeStatus } from "../lib/func/native-image.ts";
import { imageSize, processImageFfmpeg, processImageMulti, processImageUncached } from "../lib/func/image.ts";

const st = nativeStatus();
console.log(st.active ? `native: AKTIF — ${st.info}` : `native: TIDAK aktif — ${st.reason}`);
if (!st.active) { console.log("Jalankan `bun run native:build` dulu."); process.exit(1); }

// gambar uji 3000x2000 (±foto kamera) dibuat dengan ffmpeg
const gen = spawnSync("ffmpeg", ["-v", "error", "-f", "lavfi", "-i", "testsrc2=size=3000x2000:rate=1", "-frames:v", "1", "-q:v", "2", "-f", "image2pipe", "-c:v", "mjpeg", "pipe:1"], { maxBuffer: 64 << 20 });
if (gen.status !== 0 || !gen.stdout.length) { console.error("ffmpeg tidak bisa membuat gambar uji"); process.exit(1); }
const src = new Uint8Array(gen.stdout);
console.log(`gambar uji: ${(src.length / 1024).toFixed(0)} KB`);

let fail = 0;
const check = (name: string, ok: boolean, extra = "") => { console.log(`${ok ? "✔" : "✖"} ${name} ${extra}`); if (!ok) fail++; };

const cases = [
  { name: "location 300x300 cover", o: { mode: "cover" as const, width: 300, height: 300, quality: 80 }, w: 300, h: 300 },
  { name: "preview 800x450 fit", o: { mode: "fit" as const, width: 800, height: 450, quality: 80 }, w: 675, h: 450 },
  { name: "inline 120 width", o: { mode: "width" as const, width: 120, quality: 40 }, w: 120, h: 80 },
  { name: "fake 160x160 cover", o: { mode: "cover" as const, width: 160, height: 160, quality: 70 }, w: 160, h: 160 },
  { name: "image 1280 fit", o: { mode: "fit" as const, width: 1280, height: 1280, quality: 85 }, w: 1280, h: 853 },
  { name: "png 128x128 cover", o: { mode: "cover" as const, width: 128, height: 128, format: "png" as const }, w: 128, h: 128 },
];
for (const c of cases) {
  const r = await processImageUncached(src, c.o);
  const sz = imageSize(r.buffer);
  check(c.name, r.width === c.w && r.height === c.h && sz?.width === c.w && sz?.height === c.h, `→ ${r.width}x${r.height}, ${(r.buffer.length / 1024).toFixed(1)} KB`);
}

const garbage = await processImageUncached(new Uint8Array([1, 2, 3, 4, 5]), { width: 100, height: 100 }).then(() => false, () => true);
check("input bukan gambar → error (tidak crash)", garbage);

const multi = await processImageMulti(src, cases.map((c) => ({ ...c.o, width: c.o.width + 1 }))); // +1 → lewati cache
check("processImageMulti (decode sekali)", multi.every((r) => r && r.width > 0));

// benchmark
const N = 8;
const time = async (fn: () => Promise<unknown>) => { const t = performance.now(); for (let i = 0; i < N; i++) await fn(); return (performance.now() - t) / N; };
const o = { mode: "cover" as const, width: 300, height: 300, quality: 80 };
const nativeMs = await time(() => processImageUncached(src, o));
const ffmpegMs = await time(() => processImageFfmpeg(src, o));
const t0 = performance.now();
await processImageMulti(src, cases.map((c) => ({ ...c.o, quality: 61 + Math.floor(Math.random() * 30) })));
const multiMs = performance.now() - t0;
console.log(`\nbenchmark 3000x2000 → 300x300: native ${nativeMs.toFixed(0)} ms | ffmpeg ${ffmpegMs.toFixed(0)} ms | ${(ffmpegMs / nativeMs).toFixed(1)}× lebih cepat`);
console.log(`5 varian sekaligus (decode sekali): ${multiMs.toFixed(0)} ms (ffmpeg sebelumnya ≈ ${(ffmpegMs * 5).toFixed(0)} ms)`);

// event loop tidak terblokir?
let maxGap = 0; let last = performance.now();
const iv = setInterval(() => { const n = performance.now(); maxGap = Math.max(maxGap, n - last - 5); last = n; }, 5);
await Promise.all(Array.from({ length: 6 }, () => processImageUncached(src, { ...o, quality: 50 + Math.floor(Math.random() * 40) })));
clearInterval(iv);
check("event loop tetap lega selama 6 gambar diolah", maxGap < 60, `(jeda terburuk ${maxGap.toFixed(0)} ms)`);

process.exit(fail ? 1 : 0);
