// scripts/patch.ts — jalankan SEKALI setelah `bun install` / setiap zapo-js di-install ulang:
//   bun run patch
// Lalu restart bot.
import { applyCustomNodesPatch } from "../lib/func/zapoPatch.ts";

const icon = { patched: "✅ ditambal", already: "ℹ️  sudah ditambal", "no-match": "⚠️  pola tidak cocok (versi zapo-js berbeda?)", missing: "⏭️  zapo-js tidak ditemukan di node_modules" } as const;
const results = await applyCustomNodesPatch();
for (const r of results) console.log(`${icon[r.state]}  ${r.file}`);
if (results.some((r) => r.state === "missing")) console.log("\nJalankan `bun install` dulu supaya node_modules ada, lalu ulangi.");
if (results.some((r) => r.state === "no-match")) process.exit(1);