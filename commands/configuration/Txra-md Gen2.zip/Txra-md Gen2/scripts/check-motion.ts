// scripts/check-motion.ts — diagnosa motion photo di zapo-js. Jalankan di folder bot:  bun scripts/check-motion.ts
// 1) mencari penanganan associatedChildMessage / messageAssociation / pairedMediaType di dist zapo-js
// 2) tes encode→decode proto lokal: memastikan nama field kita (pairedMediaType, messageAssociation, ...) memang ada di proto zapo
//    (field yang namanya salah DIBUANG DIAM-DIAM saat encode → itu bisa jadi penyebab hasilnya cuma foto).
import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";

const root = join(process.cwd(), "node_modules", "zapo-js");
const PATTERN = /associatedChildMessage|messageAssociation|motionPhoto|pairedMediaType|MOTION_PHOTO|resolveMessageTypeAttrFrom|resolveEncMediaTypeFrom/;

async function* walk(dir: string): AsyncGenerator<string> {
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) yield* walk(p);
    else if (p.endsWith(".js")) yield p;
  }
}

console.log("══ 1) grep dist/esm/message ══");
try {
  const pkg = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
  console.log("zapo-js versi:", pkg.version);
  for await (const f of walk(join(root, "dist", "esm", "message"))) {
    const lines = (await readFile(f, "utf8")).split("\n");
    lines.forEach((l, i) => { if (PATTERN.test(l)) console.log(`${f.replace(root, "")}:${i + 1}: ${l.trim().slice(0, 140)}`); });
  }
} catch (e) { console.log("gagal membaca dist:", (e as Error).message); }

console.log("\n══ 2) tes proto encode/decode ══");
try {
  const { proto } = await import("zapo-js");
  const P: any = proto;
  console.log("enum PairedMediaType :", JSON.stringify(P.ContextInfo?.PairedMediaType ?? "TIDAK ADA"));
  console.log("enum AssociationType :", JSON.stringify(P.MessageAssociation?.AssociationType ?? "TIDAK ADA"));
  const msg = {
    videoMessage: {
      mimetype: "video/mp4", seconds: 2, width: 640, height: 360, motionPhotoPresentationOffsetMs: 500,
      contextInfo: { pairedMediaType: 6, statusSourceType: 0 },
    },
    messageContextInfo: {
      messageAssociation: { associationType: 12, parentMessageKey: { remoteJid: "1@s.whatsapp.net", fromMe: true, id: "3EB0TEST" } },
    },
  };
  const back = P.Message.decode(P.Message.encode(P.Message.create(msg)).finish());
  const obj = P.Message.toObject(back, { longs: String, enums: Number, bytes: String });
  console.log(JSON.stringify(obj, null, 1));
  const ok = obj?.messageContextInfo?.messageAssociation?.associationType === 12
    && obj?.videoMessage?.contextInfo?.pairedMediaType === 6
    && obj?.videoMessage?.width === 640;
  console.log(ok ? "✅ field motion photo lolos encode/decode" : "❌ ada field yang hilang — lihat JSON di atas");
} catch (e) { console.log("tes proto gagal (API proto zapo berbeda?):", (e as Error).message); }
