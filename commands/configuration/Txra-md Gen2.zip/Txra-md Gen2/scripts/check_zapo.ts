import { access, readFile } from "node:fs/promises";
async function main(){
  const roots = ["/data/data/com.termux/files/home/bot/node_modules/zapo-js/dist/esm/client/WaClient.js"];
  for(const p of roots){
    try{ const t=await readFile(p,"utf8"); 
      const m=t.match(/get profile\(\) \{[^}]+}/s);
      console.log(m?.[0]?.slice(0,500));
      const hasProfilePicture = t.includes("getProfilePicture");
      console.log("has getProfilePicture:",hasProfilePicture);
      // list client properties
      const props=[...t.matchAll(/get (\w+)\(\) \{/g)].map(x=>x[1]);
      console.log("client props:",props.slice(0,30));
    }catch(e){ console.log("err",e) }
  }
}
main();
