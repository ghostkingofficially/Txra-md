import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import type { WaClient } from "zapo-js";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const STORE_PATH = resolve(ROOT, "db", "configuration", "badge.json");

export interface BadgeConfig {
  enabled: boolean;
  sticker?: Record<string, any>;
  updatedAt?: number;
}

const DEFAULT_CONFIG: BadgeConfig = { enabled: false };
const BINARY_FIELDS = ["fileSha256", "fileEncSha256", "mediaKey"] as const;

function encodeBinary(value: any): string | undefined {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "string") return value;
  return Buffer.from(value).toString("base64");
}

function restoreBinary(value: any): Buffer | undefined {
  if (!value) return undefined;
  if (Buffer.isBuffer(value)) return value;
  if (typeof value === "string") return Buffer.from(value, "base64");
  return Buffer.from(value);
}

export async function loadBadgeConfig(): Promise<BadgeConfig> {
  try {
    const parsed = JSON.parse(await readFile(STORE_PATH, "utf8"));
    return {
      enabled: parsed?.enabled === true,
      sticker: parsed?.sticker && typeof parsed.sticker === "object" ? parsed.sticker : undefined,
      updatedAt: Number(parsed?.updatedAt || 0),
    };
  } catch {
    return { ...DEFAULT_CONFIG };
  }
}

export async function saveBadgeConfig(config: BadgeConfig): Promise<void> {
  await mkdir(dirname(STORE_PATH), { recursive: true });
  await writeFile(STORE_PATH, JSON.stringify(config, null, 2), "utf8");
}

export async function setBadgeEnabled(enabled: boolean): Promise<BadgeConfig> {
  const current = await loadBadgeConfig();
  const next = { ...current, enabled };
  await saveBadgeConfig(next);
  return next;
}

export async function setBadgeFromBuffer(
  client: WaClient,
  bytes: Uint8Array,
  isAnimated = false,
): Promise<BadgeConfig> {
  const uploaded: any = await (client as any).message.upload(bytes, {
    type: "sticker",
    mimetype: isAnimated ? "image/webp" : "image/webp",
  });
  const current = await loadBadgeConfig();
  const sticker: Record<string, any> = {
    ...uploaded,
    mimetype: uploaded?.mimetype || "image/webp",
    isAnimated,
    buffer: Buffer.from(bytes).toString("base64"),
  };
  for (const field of BINARY_FIELDS) sticker[field] = encodeBinary(sticker[field]);
  const next = { enabled: current.enabled, sticker, updatedAt: Date.now() };
  await saveBadgeConfig(next);
  return next;
}

export async function sendBadge(client: WaClient, m: any): Promise<boolean> {
  const config = await loadBadgeConfig();
  if (!config.enabled || !config.sticker || !m?.chat || !m?.key) return false;

  let sticker = { ...config.sticker };
  if (!sticker.url && sticker.buffer) {
    const bytes = Buffer.from(sticker.buffer, "base64");
    const uploaded: any = await (client as any).message.upload(bytes, {
      type: "sticker",
      mimetype: sticker.mimetype || "image/webp",
    });
    sticker = { ...sticker, ...uploaded };
    for (const field of BINARY_FIELDS) sticker[field] = encodeBinary(sticker[field]);
    await saveBadgeConfig({ ...config, sticker });
  }

  const { buffer: _buffer, ...stickerMessage } = sticker;
  for (const field of BINARY_FIELDS) {
    const binary = restoreBinary(stickerMessage[field]);
    if (binary) stickerMessage[field] = binary;
  }
  await (client as any).message.send(
    m.chat,
    {
      messageContextInfo: {
        messageAssociation: {
          associationType: 11,
          parentMessageKey: m.key,
        },
      },
      stickerMessage,
    },
    { id: `BADGE${Date.now().toString(36).toUpperCase()}` },
  );
  return true;
}

export { STORE_PATH as BADGE_STORE_PATH };
