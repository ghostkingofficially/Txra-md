// src/reaction/auto.ts — registerReactionHooks: react on ALL message types (stub/ephemeral/notify)
import type { WaClient } from "zapo-js";
import { isBotSentId, smsg } from "../../lib/serialize/smsg.ts";
import { reactEphemeral, reactNotify, reactStub } from "./react.ts";
import { loadReactionConfig } from "./store.ts";

function isStubEvent(ev: any): boolean {
  return !!ev?.messageStubType || !!ev?.messageStubParameters || ev?.message == null;
}

function isEphemeralEvent(ev: any): boolean {
  const msg = ev?.message;
  if (!msg) return false;
  return !!msg.ephemeralMessage || !!msg.viewOnceMessage || !!msg.viewOnceMessageV2 || !!ev?.ephemeralOutOfSync;
}

function isNotifyEvent(ev: any): boolean {
  if (!ev?.message) return false;
  const mtype = Object.keys(ev.message)[0] ?? "";
  return ["protocolMessage", "notificationMessage", "groupStatusMessage", "groupStatusMessageV2"].some((k) => mtype.includes(k));
}

// Di grup ramai dengan pesan sementara (ephemeral), SETIAP pesan lolos filter → bot menembak reaksi ke semua orang;
// kiriman itu berebut antrean enkripsi/socket dengan balasan command. Batas: satu reaksi otomatis per chat per jendela ini.
const AUTO_REACT_WINDOW_MS = 20_000;
const lastAutoReact = new Map<string, number>();

export function registerReactionHooks(client: WaClient): void {
  client.on("message" as any, async (event: any) => {
    try {
      const cfg = await loadReactionConfig();
      if (!cfg.enabled) return;
      const key = event?.key;
      if (!key?.id || key.fromMe || isBotSentId(key.id)) return;

      const stub = isStubEvent(event);
      const eph = isEphemeralEvent(event);
      const notify = isNotifyEvent(event);

      if (!stub && !eph && !notify) return;

      const chat: string = key.remoteJid ?? "";
      const now = Date.now();
      if (now - (lastAutoReact.get(chat) ?? 0) < AUTO_REACT_WINDOW_MS) return;
      lastAutoReact.set(chat, now);
      if (lastAutoReact.size > 500) lastAutoReact.delete(lastAutoReact.keys().next().value as string);

      const m = smsg(event, client);
      if (!m) return;

      if (stub && cfg.stubReact) void reactStub(m);
      else if (eph && cfg.ephemeralReact) void reactEphemeral(m);
      else if (notify && cfg.notifyReact) void reactNotify(m);
    } catch { /* silent */ }
  });
}