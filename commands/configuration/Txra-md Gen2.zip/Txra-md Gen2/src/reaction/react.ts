// src/reaction/react.ts — core reaction helpers (fire-and-forget safe)
import { getReactionCache } from "./cache.ts";
import { pickRandom } from "./emojis.ts";
import { loadReactionConfig } from "./store.ts";

const DEDUP_TTL = 3;
const COOLDOWN_TTL = 2;

function dedupKey(id: string): string { return `react:sent:${id}`; }
function cooldownKey(chat: string): string { return `react:cooldown:${chat}`; }

/** replace = true → timpa reaksi sebelumnya di pesan yang sama (⏳ → ✅): lewati dedup & cooldown. */
async function tryReact(m: any, emoji: string, replace = false): Promise<boolean> {
  if (!m || typeof m.react !== "function") return false;
  const cache = getReactionCache();
  const id: string = m.id ?? m.key?.id ?? "";
  const chat: string = m.chat ?? m.key?.remoteJid ?? "";
  if (!replace) {
    if (id && cache.get(dedupKey(id))) return false;
    if (chat && cache.get(cooldownKey(chat))) return false;
  }
  try {
    await m.react(emoji);
    if (id) cache.set(dedupKey(id), 1, DEDUP_TTL);
    if (chat) cache.set(cooldownKey(chat), 1, COOLDOWN_TTL);
    return true;
  } catch { return false; }
}

export async function reactLoading(m: any): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled) return false;
  return tryReact(m, cfg.loading);
}

export async function reactSuccess(m: any, replace = false): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled) return false;
  return tryReact(m, cfg.success, replace);
}

export async function reactFailed(m: any): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled) return false;
  return tryReact(m, cfg.failed, true);
}

export async function reactRandom(m: any): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled || !cfg.unknownCommand || !cfg.random.length) return false;
  return tryReact(m, pickRandom(cfg.random));
}

export async function reactByKind(m: any, kind: "loading" | "success" | "failed" | "random"): Promise<boolean> {
  switch (kind) {
    case "loading": return reactLoading(m);
    case "success": return reactSuccess(m);
    case "failed": return reactFailed(m);
    case "random": return reactRandom(m);
  }
}

export async function reactNotify(m: any, emoji?: string): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled || !cfg.notifyReact) return false;
  const list = emoji ? [emoji] : cfg.random;
  return tryReact(m, pickRandom(list));
}

export async function reactStub(m: any, emoji?: string): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled || !cfg.stubReact) return false;
  return tryReact(m, emoji ?? pickRandom(cfg.random));
}

export async function reactEphemeral(m: any, emoji?: string): Promise<boolean> {
  const cfg = await loadReactionConfig();
  if (!cfg.enabled || !cfg.ephemeralReact) return false;
  return tryReact(m, emoji ?? pickRandom(cfg.random));
}