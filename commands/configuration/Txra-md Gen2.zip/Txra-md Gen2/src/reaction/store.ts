// src/reaction/store.ts — db/configuration/reaction.json + NodeCache (TTL 30s)
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { PROJECT_ROOT } from "../setthumblarge/store.ts";
import NodeCache from "node-cache";
import { DEFAULT_FAILED, DEFAULT_LOADING, DEFAULT_RANDOM, DEFAULT_SUCCESS, sanitizeEmojiList } from "./emojis.ts";

export interface ReactionConfig {
  enabled: boolean;
  loading: string;
  success: string;
  failed: string;
  random: string[];
  unknownCommand: boolean;
  notifyReact: boolean;
  stubReact: boolean;
  ephemeralReact: boolean;
}

const PATH = join(PROJECT_ROOT, "db", "configuration", "reaction.json");
const CACHE_KEY = "reaction:config";
const cache = new NodeCache({ stdTTL: 30, checkperiod: 0, useClones: false });

const DEFAULTS: ReactionConfig = {
  enabled: true,
  loading: DEFAULT_LOADING,
  success: DEFAULT_SUCCESS,
  failed: DEFAULT_FAILED,
  random: [...DEFAULT_RANDOM],
  unknownCommand: true,
  notifyReact: true,
  stubReact: true,
  ephemeralReact: true,
};

function normalize(raw: any): ReactionConfig {
  return {
    enabled: raw?.enabled !== false,
    loading: typeof raw?.loading === "string" && raw.loading.trim() ? raw.loading.trim() : DEFAULTS.loading,
    success: typeof raw?.success === "string" && raw.success.trim() ? raw.success.trim() : DEFAULTS.success,
    failed: typeof raw?.failed === "string" && raw.failed.trim() ? raw.failed.trim() : DEFAULTS.failed,
    random: sanitizeEmojiList(raw?.random),
    unknownCommand: raw?.unknownCommand !== false,
    notifyReact: raw?.notifyReact !== false,
    stubReact: raw?.stubReact !== false,
    ephemeralReact: raw?.ephemeralReact !== false,
  };
}

export async function loadReactionConfig(force = false): Promise<ReactionConfig> {
  if (!force) {
    const hit = cache.get<ReactionConfig>(CACHE_KEY);
    if (hit) return hit;
  }
  let cfg: ReactionConfig;
  try {
    cfg = normalize(JSON.parse(await readFile(PATH, "utf8")));
  } catch {
    cfg = { ...DEFAULTS, random: [...DEFAULTS.random] };
  }
  cache.set(CACHE_KEY, cfg);
  return cfg;
}

async function persist(cfg: ReactionConfig): Promise<void> {
  await mkdir(dirname(PATH), { recursive: true });
  const tmp = PATH + ".tmp";
  await writeFile(tmp, JSON.stringify(cfg, null, 2));
  await rename(tmp, PATH);
  cache.set(CACHE_KEY, cfg);
}

export async function updateReactionConfig(patch: Partial<ReactionConfig>): Promise<ReactionConfig> {
  const cur = await loadReactionConfig(true);
  const next = normalize({ ...cur, ...patch });
  await persist(next);
  return next;
}

export async function setReactionEnabled(v: boolean): Promise<ReactionConfig> {
  return updateReactionConfig({ enabled: v });
}

export function invalidateReactionCache(): void {
  cache.del(CACHE_KEY);
}
