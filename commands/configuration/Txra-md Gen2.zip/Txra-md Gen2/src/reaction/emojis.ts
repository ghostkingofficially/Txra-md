export const DEFAULT_LOADING = "⏳";
export const DEFAULT_SUCCESS = "✅";
export const DEFAULT_FAILED = "❌";
export const DEFAULT_RANDOM: string[] = ["🤖", "✨", "🔥", "❤️", "😂", "👍", "🥳", "💯"];

export function pickRandom(list: string[]): string {
  if (!list.length) return DEFAULT_RANDOM[0]!;
  return list[Math.floor(Math.random() * list.length)]!;
}

export function sanitizeEmojiList(raw: unknown): string[] {
  if (!Array.isArray(raw)) return [...DEFAULT_RANDOM];
  const out = raw.map(String).map((s) => s.trim()).filter(Boolean);
  return out.length ? out.slice(0, 30) : [...DEFAULT_RANDOM];
}
