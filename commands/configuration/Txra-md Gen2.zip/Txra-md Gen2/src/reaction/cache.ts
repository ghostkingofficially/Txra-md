import NodeCache from "node-cache";

let _cache: NodeCache | null = null;

export function getReactionCache(): NodeCache {
  if (_cache) return _cache;
  _cache = new NodeCache({ stdTTL: 60, checkperiod: 0, useClones: false });
  return _cache;
}

export function getReactionDedupCache(): NodeCache {
  const c = getReactionCache();
  return c;
}
