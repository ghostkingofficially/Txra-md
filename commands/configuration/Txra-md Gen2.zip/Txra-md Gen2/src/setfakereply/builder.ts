// src/setfakereply/builder.ts — membangun pesan kutipan palsu (fake quoted)
// Dipakai sebagai "quoted" di balasan bot, jadi tiap balasan punya kartu kecil di atasnya.
// Bedanya dengan setthumblarge: ini kartu KECIL (thumbnail 160px) untuk respon sehari-hari.
import { getConfig } from "../../connector/config.ts";
import { getThumbForSource } from "../setthumblarge/thumb.ts";
import { loadFakeConfig, type FakeStyle } from "./store.ts";

type Obj = Record<string, any>;

export interface FakeUser { jid?: string; name?: string }

export interface FakeOptions {
  /** Jenis respon → menentukan gambar (owner, premium, admin, limit, error, success, default, ...). */
  kind?: string;
  /** Gambar khusus (URL / path) — menimpa gambar dari `kind`. */
  image?: string;
  /** Teks yang tampil di kartu kutipan. */
  text?: string;
  /** Judul kartu, biasanya command (mis. ".ping"). */
  command?: string;
  /** Siapa pengirim kutipan: namanya tampil di atas kartu. */
  user?: FakeUser;
  /** Paksa gaya tertentu (default: dari setfakereply.json). */
  style?: FakeStyle;
}

export interface FakeQuoted {
  key: { remoteJid: string; fromMe: boolean; id: string; participant: string };
  message: Obj;
}

/** Sumber gambar untuk satu jenis respon: gambar khusus → images[kind] → images.default → bot.thumbnail ("" = tidak ada). */
export async function getFakeImageSource(kind = "default", image?: string): Promise<string> {
  const cfg = await loadFakeConfig();
  let source = image || cfg.images[kind] || cfg.images.default || "";
  if (!source) { try { source = String(getConfig().bot?.thumbnail ?? ""); } catch { /* tanpa gambar */ } }
  return source;
}

/** Thumbnail kecil (160px JPEG) untuk satu jenis respon. */
export async function getFakeImageBytes(kind = "default", image?: string): Promise<Uint8Array | null> {
  const source = await getFakeImageSource(kind, image);
  const thumb = source ? await getThumbForSource("fake", source) : null;
  return thumb ? new Uint8Array(thumb.jpeg) : null;
}

const phone = (jid: string) => jid.split("@")[0].split(":")[0];

export async function buildFakeQuoted(o: FakeOptions = {}): Promise<FakeQuoted> {
  const cfg = await loadFakeConfig();
  const botName = (() => { try { return String(getConfig().bot?.name ?? "Bot"); } catch { return "Bot"; } })();
  const style = o.style ?? cfg.style;
  const text = o.text ?? " ";
  const participant = o.user?.jid || cfg.fakeJid;
  const id = "FakeQuotedId_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  let message: Obj;
  switch (style) {
    case "contact": {
      const name = o.user?.name || botName;
      message = {
        contactMessage: {
          displayName: name,
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL;waid=${phone(participant)}:${phone(participant)}\nEND:VCARD`,
        },
      };
      break;
    }
    case "requestpayment":
      message = {
        requestPaymentMessage: {
          currencyCodeIso4217: "IDR",
          amount1000: cfg.orderAmount1000,
          requestFrom: participant,
          noteMessage: { extendedTextMessage: { text } },
          expiryTimestamp: 0,
        },
      };
      break;
    case "metaai": {
      const botJid = "13135550002@s.whatsapp.net";
      message = {
        botForwardedMessage: {
          message: {
            richResponseMessage: {
              messageType: 1,
              submessages: [{ messageType: 2, messageText: text.trim() || "Meta AI" }],
              contextInfo: { forwardingScore: 1, isForwarded: true, forwardedAiBotMessageInfo: { botJid }, forwardOrigin: 4, participant: botJid, remoteJid: botJid },
            },
          },
        },
      };
      break;
    }
    case "extended":
      message = { extendedTextMessage: { text } };
      break;
    case "plain":
      message = { conversation: text };
      break;
    case "order":
    default: {
      const thumb = await getFakeImageBytes(o.kind, o.image);
      message = {
        orderMessage: {
          orderId: "FQ" + Date.now(),
          ...(thumb ? { thumbnail: thumb } : {}),
          itemCount: 1,
          status: 1,   // INQUIRY
          surface: 1,  // CATALOG
          message: text,
          orderTitle: o.command || botName,
          sellerJid: participant,
          totalAmount1000: cfg.orderAmount1000,
          totalCurrencyCode: "IDR",
        },
      };
    }
  }

  return { key: { remoteJid: participant, fromMe: false, id, participant }, message };
}
