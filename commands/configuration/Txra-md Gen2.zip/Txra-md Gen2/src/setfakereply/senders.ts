// src/setfakereply/senders.ts — satu pengirim per tipe balasan. Semuanya membawa kartu kutipan palsu (ctx.quoted).
// Semua tipe memakai thumbnail kecil (160px) — tidak ada lagi yang lewat pengirim setthumblarge.
import { getAdditionalNodes } from "../../helpers/utils/additional-nodes.ts";
import { AIRich } from "../../helpers/utils/rich-messages/index.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay } from "../../helpers/utils/button-messages/transport.ts";
import { cachedUpload } from "../setthumblarge/cache.ts";
import { getThumbForSource } from "../setthumblarge/thumb.ts";
import { getFakeImageBytes, getFakeImageSource, type FakeQuoted } from "./builder.ts";
import type { FakeConfig } from "./store.ts";
import type { Preset, PresetType } from "./presets.ts";

type Obj = Record<string, any>;

export interface FakeCtx {
  client: any;
  m: any;
  /** Isi balasan. */
  text: string;
  quoted: FakeQuoted;
  kind: string;
  /** Gambar khusus (menimpa gambar dari `kind`). */
  image?: string;
  mentions?: string[];
  preset: Preset;
  cfg: FakeConfig;
}

// ── util ──
/** contextInfo tambahan di luar stanzaId/participant/quotedMessage (yang diisi buildWAMessage). */
const extraCtx = (c: FakeCtx): Obj => ({
  ...(c.quoted.key.remoteJid !== c.m.chat ? { remoteJid: c.quoted.key.remoteJid } : {}),
  ...(c.mentions?.length ? { mentionedJid: c.mentions } : {}),
});

/** contextInfo lengkap — untuk pesan yang kutipannya harus ditaruh manual (mis. di dalam noteMessage). */
const fullCtx = (c: FakeCtx): Obj => ({
  stanzaId: c.quoted.key.id,
  participant: c.quoted.key.participant,
  quotedMessage: c.quoted.message,
  ...extraCtx(c),
});

async function put(c: FakeCtx, content: Obj, nodes: readonly any[] = [], quote = true) {
  const wa = buildWAMessage(c.m.chat, content, { messageId: newMessageId(), quoted: quote ? c.quoted : undefined });
  return await relay(c.client, c.m.chat, wa.message, { messageId: wa.key.id, additionalNodes: nodes });
}

const interactive = (c: FakeCtx, header: Obj, body: string, footer: string | undefined, buttons: Obj[], params: string, ctxExtra: Obj = {}) => ({
  interactiveMessage: {
    header,
    body: { text: body || " " },
    ...(footer !== undefined ? { footer: { text: footer } } : {}),
    nativeFlowMessage: { buttons, messageParamsJson: params },
    contextInfo: { ...extraCtx(c), ...ctxExtra },
  },
});

const refId = () => "REF" + Date.now().toString(36).toUpperCase();
const thumb = (c: FakeCtx) => getFakeImageBytes(c.kind, c.image);

// ── 8) PLAIN TEXT (juga cadangan bila tipe lain gagal) ──
export const sendText = (c: FakeCtx) =>
  put(c, { extendedTextMessage: { text: c.text, contextInfo: extraCtx(c) } });

// ── 1) DOCUMENT — isi dokumen = gambar jenis respon ini; ukuran file dipalsukan ──
async function sendDocument(c: FakeCtx) {
  const source = await getFakeImageSource(c.kind, c.image);
  const big = source ? await getThumbForSource("image", source) : null;
  if (!big) throw new Error("tipe document butuh gambar — atur dengan .sfr img default <url>");
  const mimetype = c.preset.mimetype ?? "image/jpeg";
  const media: Obj = await cachedUpload(`doc|${big.key}`, () => prepareMedia(c.client, "document", big.jpeg, { mimetype }) as Promise<Obj>);
  const small = await thumb(c);
  return await put(c, {
    documentMessage: {
      ...media.documentMessage,
      mimetype,
      fileName: c.preset.fileName,
      fileLength: c.preset.fileLength ?? 99999999999999,
      caption: c.text,
      ...(small ? { jpegThumbnail: small, thumbnailHeight: 160, thumbnailWidth: 160 } : {}),
      contextInfo: extraCtx(c),
    },
  });
}

// ── 3) INAPP SIGNUP ──
const sendInapp = (c: FakeCtx) =>
  put(
    c,
    interactive(c, { title: c.preset.title ?? "", hasMediaAttachment: false }, c.text || c.preset.body || " ", c.preset.footer ?? "",
      [{ name: "inapp_signup", buttonParamsJson: "{}" }], "{}"),
    getAdditionalNodes("mixed"),
  );

// ── 4) AI RICH PRODUCT ──
async function sendAiRich(c: FakeCtx) {
  const source = await getFakeImageSource(c.kind, c.image);
  const img = /^https?:\/\//i.test(source) ? source : (await getThumbForSource("image", source))?.jpeg;
  if (!img) throw new Error("tipe airich_product butuh gambar — atur dengan .sfr img default <url>");
  const p = c.preset.product ?? {};
  const rich = new AIRich(c.client).addProduct({
    title: p.title, brand: p.brand, price: p.price, sale_price: p.sale_price, url: p.url, image: img, icon: img,
  });
  const body = c.text || c.preset.body;
  if (body) rich.addText(body);
  if (c.preset.footer) rich.addTip(c.preset.footer);
  return await rich.send(c.m.chat, {
    forwarded: true, notification: true, includesUnifiedResponse: true, includesSubmessages: true,
    quoted: c.quoted, quotedParticipant: c.quoted.key.participant,
  });
}

// ── 5) GROUP INVITE ──
async function sendGroupInvite(c: FakeCtx) {
  const small = await thumb(c);
  const p = c.preset;
  return await put(c, {
    groupInviteMessage: {
      groupJid: p.groupJid, inviteCode: p.inviteCode, inviteExpiration: p.inviteExpiration, groupName: p.groupName,
      ...(small ? { jpegThumbnail: small } : {}),
      caption: c.text,
      contextInfo: extraCtx(c),
    },
  });
}

// ── 6) REVIEW & PAY ──
async function sendReviewAndPay(c: FakeCtx) {
  const small = await thumb(c);
  const p = c.preset;
  const items = (p.items ?? [{ name: p.itemName ?? "Pesanan", amount: p.amount, quantity: "1" }]).map((it: Obj) => ({
    retailer_id: it.retailer_id || "your_retailer_id",
    name: it.name || "Pesanan",
    amount: { value: it.amount ?? p.amount, offset: p.offset },
    quantity: it.quantity || "1",
  }));
  const params = JSON.stringify({
    currency: p.currency,
    payment_configuration: "",
    payment_type: "",
    total_amount: { value: p.amount, offset: p.offset },
    reference_id: refId(),
    type: "physical-goods",
    payment_method: "confirm",
    payment_status: "captured",
    payment_timestamp: Math.floor(Date.now() / 1000),
    order: { status: "completed", description: "", subtotal: { value: "0", offset: p.offset }, order_type: "PAYMENT_REQUEST", items },
    additional_note: p.additional_note || "",
    native_payment_methods: [],
    share_payment_status: false,
  });
  return await put(
    c,
    interactive(c, { title: p.title ?? "", hasMediaAttachment: true, ...(small ? { jpegThumbnail: small } : {}) }, c.text || "Konfirmasi pembayaran",
      p.footer ?? "", [{ name: "review_and_pay", buttonParamsJson: params }], "{}"),
    getAdditionalNodes("order_details"),
  );
}

// ── 7) ORDER MESSAGE ──
async function sendOrderMessage(c: FakeCtx) {
  const small = await thumb(c);
  const p = c.preset;
  return await put(c, {
    orderMessage: {
      orderId: "ORDER_" + Date.now().toString(36).toUpperCase(),
      ...(small ? { thumbnail: small } : {}),
      itemCount: p.itemCount, status: p.status, surface: p.surface,
      message: c.text, orderTitle: p.title, sellerJid: p.sellerJid,
      token: "TOKEN_" + Date.now().toString(36).toUpperCase(),
      totalAmount1000: p.totalAmount, totalCurrencyCode: p.currency,
      messageVersion: 1,
      contextInfo: extraCtx(c),
    },
  });
}

// ── 9) REQUEST PAYMENT — kutipan ditaruh di dalam noteMessage (requestPaymentMessage tidak punya contextInfo) ──
// Isi pesan sengaja SAMA dengan versi Baileys yang jalan (amount1000 = amount * 1000, requestFrom = peserta kutipan palsu).
// Kalau pesan ini terkirim tapi tidak muncul, penyebabnya ada di klasifikasi stanza zapo (lihat catatan di balasan), bukan di isi pesan.
const sendRequestPayment = (c: FakeCtx) => {
  const p = c.preset;
  const amount = Math.round(Number(p.amount) || 0);
  return put(c, {
    requestPaymentMessage: {
      currencyCodeIso4217: p.currency,
      amount1000: amount * 1000,
      requestFrom: c.quoted.key.participant,
      noteMessage: { extendedTextMessage: { text: c.text, contextInfo: fullCtx(c) } },
      expiryTimestamp: Number(p.expiry) || 0,
      amount: { value: amount, offset: Number(p.offset) || 1000, currencyCode: p.currency },
    },
  }, [], false);
};

// ── 10) ORDER STATUS ──
async function sendOrderStatus(c: FakeCtx) {
  const small = await thumb(c);
  const p = c.preset;
  const params = JSON.stringify({
    reference_id: refId(),
    order: {
      status: p.status || "PROCESSING",
      subtotal: { value: p.subtotal, offset: 100 },
      tax: { value: p.tax || 0, offset: 100 },
      currency: p.currency || "IDR",
    },
  });
  return await put(
    c,
    interactive(c, { title: p.title ?? "Order Status", hasMediaAttachment: true, ...(small ? { jpegThumbnail: small } : {}) },
      c.text || "Status pesanan Anda", undefined, [{ name: "order_status", buttonParamsJson: params }], "",
      { forwardingScore: 999, isForwarded: true, forwardOrigin: 0 }),
    getAdditionalNodes("mixed"),
  );
}

// ── 2) LINK PREVIEW KECIL — hanya jpegThumbnail 160px, TANPA upload thumbnail HQ → kartu tampil kecil/ringkas ──
const safeUrl = (u?: string) => {
  try {
    const x = new URL(String(u ?? ""));
    return /^https?:$/.test(x.protocol) && /^[a-z0-9.-]+$/i.test(x.hostname) ? String(u) : "https://wa.me";
  } catch { return "https://wa.me"; }
};

async function sendLinkPreview(c: FakeCtx) {
  const p = c.preset;
  const url = safeUrl(p.matchedText);
  const small = await thumb(c);
  return await put(c, {
    extendedTextMessage: {
      text: `${url}\n\n${c.text}`,
      matchedText: url,
      title: p.title ?? "",
      description: p.description ?? "",
      previewType: 0,
      ...(small ? { jpegThumbnail: small } : {}),
      contextInfo: extraCtx(c),
    },
  });
}

export const SENDERS: Record<PresetType, (c: FakeCtx) => Promise<unknown>> = {
  document: sendDocument,
  linkpreview: sendLinkPreview,
  inapp_signup: sendInapp,
  airich_product: sendAiRich,
  group_invite: sendGroupInvite,
  review_and_pay: sendReviewAndPay,
  order_message: sendOrderMessage,
  text: sendText,
  request_payment: sendRequestPayment,
  order_status: sendOrderStatus,
};