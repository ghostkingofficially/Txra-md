// src/setfakereply/index.ts — fake reply: setiap balasan bot dikirim dengan tipe preset aktif + kartu kutipan palsu.
//
//   .sfr <nomor>   → ganti tipe balasan SEMUA pesan (1–10, lihat presets.ts)
//
//   Otomatis: semua m.reply("teks") di command ikut fake reply (hook dipasang oleh registerFakeReply()).
//     m.reply("teks")                                  → gambar sesuai peran pengirim (owner / premium / admin / default)
//     m.reply("teks", { kind: "success" })             → gambar "success"   (juga: "error", "limit", "owner", "premium", ...)
//     m.reply("teks", { fake: false })                 → tanpa fake reply
//
//   Lengkap (atur sendiri tiap bagian):
//     await replyFake(client, m, {
//       image: "https://.../x.jpg",     // mana gambarnya (menimpa kind)
//       text: "Berhasil!",              // mana teksnya (isi balasan)
//       quote: "Ping berhasil",         // teks di kartu kutipan (default: sama dengan text)
//       command: ".ping",               // mana commandnya (judul kartu)
//       user: { jid, name },            // mana usernya (nama pengirim di atas kartu)
//       mentions: [jid],                // siapa yang di-tag
//       kind: "success",
//       preset: 4,                      // (opsional) paksa tipe balasan tertentu
//     });
import { setReplyHook } from "../../lib/serialize/smsg.ts";
import { buildFakeQuoted, type FakeOptions } from "./builder.ts";
import { buildFakeQuotedFromConfig } from "../setfakequoted/builder.ts";
import { loadFakeQuotedConfig, isPolosQuoted } from "../setfakequoted/store.ts";
import { getPresets } from "./presets.ts";
import { sendText, SENDERS, type FakeCtx } from "./senders.ts";
import { loadFakeConfig } from "./store.ts";

export { buildFakeQuoted, getFakeImageBytes } from "./builder.ts";
export type { FakeOptions, FakeQuoted, FakeUser } from "./builder.ts";
export { getPresets } from "./presets.ts";
export { FAKE_KINDS, FAKE_STYLES } from "./store.ts";

export interface ReplyFakeOptions extends FakeOptions {
  /** Isi balasan. */
  text: string;
  /** Teks di kartu kutipan. Default: sama dengan `text` (dipotong). */
  quote?: string;
  /** JID yang di-tag di balasan. */
  mentions?: string[];
  /** Paksa nomor preset tertentu (default: preset aktif dari .sfr). */
  preset?: number;
}

const preview = (s: string) => (s.length > 60 ? s.slice(0, 57) + "..." : s);

/** Kirim balasan teks dengan fake reply (tipe sesuai preset aktif). */
export async function replyFake(client: any, m: any, o: ReplyFakeOptions): Promise<any> {
  if (!o.text || !String(o.text).trim()) return;
  const cfg = await loadFakeConfig();
  const presets = await getPresets();
  const preset = presets[o.preset ?? cfg.active] ?? presets[8];

  const kind = o.kind ?? m.fakeKind ?? "default";
  // Priority: if setfakequoted (setfqq) is not polos, use its quoted as the global quoted for all replies
  let quoted: any = null;
  try {
    const fqq = await loadFakeQuotedConfig();
    if (!isPolosQuoted(fqq)) {
      quoted = await buildFakeQuotedFromConfig(
        { text: o.quote ?? preview(String(o.text).replace(/\s+/g, " ")), jid: o.user?.jid ?? m.sender, name: o.user?.name ?? m.pushName },
        client
      );
    }
  } catch {}
  if (!quoted) {
    quoted = await buildFakeQuoted({
      kind,
      image: o.image,
      text: o.quote ?? preview(String(o.text).replace(/\s+/g, " ")),
      command: o.command ?? m.fakeCommand,
      user: o.user ?? { jid: m.sender, name: m.pushName },
      style: o.style,
    });
  }

  const ctx: FakeCtx = { client, m, text: String(o.text), quoted, kind, image: o.image, mentions: o.mentions, preset, cfg };

  try {
    return (await SENDERS[preset.type](ctx)) ?? true;
  } catch (e) {
    // Tipe khusus gagal (gambar tidak ada, ditolak server, dst) → tetap kirim sebagai teks + kartu kutipan.
    console.warn(`[fakereply] preset ${o.preset ?? cfg.active} (${preset.type}) gagal: ${(e as Error).message} — kirim sebagai teks`, e);
    return (await sendText(ctx)) ?? true;
  }
}

/** Pasang hook ke m.reply. Panggil sekali saat bot start. */
export function registerFakeReply(): void {
  setReplyHook(async (m, client, text, options) => {
    const cfg = await loadFakeConfig();
    if (!cfg.enabled) return undefined; // nonaktif → m.reply mengirim biasa
    return await replyFake(client, m, {
      text,
      kind: options?.kind,
      image: options?.image,
      quote: options?.quote,
      command: options?.command,
      user: options?.user,
      mentions: options?.mentions,
      preset: options?.preset,
    });
  });
}