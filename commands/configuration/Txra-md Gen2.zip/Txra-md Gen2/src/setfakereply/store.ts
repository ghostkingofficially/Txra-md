// src/setfakereply/store.ts — pengaturan fake reply: db/configuration/setfakereply.json
//   enabled   : fake reply aktif / tidak
//   style     : bentuk quote palsu (order | contact | requestpayment | metaai | extended | plain)
//   images    : gambar per jenis respon (default, success, error, owner, premium, admin, limit, + jenis lain bebas)
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import NodeCache from "node-cache";
import { PROJECT_ROOT } from "../setthumblarge/store.ts";
import { emitConfigChange } from "../../helpers/utils/config-events.ts";

export const FAKE_STYLES = ["order", "contact", "requestpayment", "metaai", "extended", "plain"] as const;
export type FakeStyle = (typeof FAKE_STYLES)[number];
export const isFakeStyle = (v: unknown): v is FakeStyle => (FAKE_STYLES as readonly string[]).includes(String(v));

/** Jenis respon bawaan. Kunci lain boleh ditambah di images (mis. "wait", "warning"). */
export const FAKE_KINDS = ["default", "success", "error", "owner", "premium", "admin", "limit"] as const;

export interface FakeConfig {
  enabled: boolean;
  /** Nomor preset TIPE BALASAN yang aktif (1..14) — lihat presets.ts. */
  active: number;
  /** Gaya kartu kutipan palsu di atas balasan (order | contact | ...). */
  style: FakeStyle;
  /** Ubahan per preset, mis. { "6": { "amount": "5000" } } — digabung dengan bawaan di presets.ts. */
  presets: Record<string, Record<string, any>>;
  fakeJid: string;
  orderAmount1000: number;
  images: Record<string, string>;
}

const PATH = join(PROJECT_ROOT, "db", "configuration", "setfakereply.json");

const DEFAULTS: FakeConfig = { enabled: true, active: 8, presets: {}, style: "order", fakeJid: "0@s.whatsapp.net", orderAmount1000: 10_000_000, images: {} };
const CACHE_KEY = "fakereply:config";
const cache = new NodeCache({ stdTTL: 30, checkperiod: 0, useClones: false });

function normalize(raw: any): FakeConfig {
  const images: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw?.images ?? {})) if (typeof v === "string" && /^https?:\/\/\S+$/i.test(v.trim())) images[k] = v.trim(); // hanya URL
  return {
    enabled: raw?.enabled !== false,
    active: Number.isInteger(Number(raw?.active)) && Number(raw.active) > 0 ? Number(raw.active) : DEFAULTS.active,
    presets: raw?.presets && typeof raw.presets === "object" ? raw.presets : {},
    style: isFakeStyle(raw?.style) ? raw.style : DEFAULTS.style,
    fakeJid: typeof raw?.fakeJid === "string" && raw.fakeJid ? raw.fakeJid : DEFAULTS.fakeJid,
    orderAmount1000: Number.isFinite(Number(raw?.orderAmount1000)) ? Number(raw.orderAmount1000) : DEFAULTS.orderAmount1000,
    images,
  };
}

export async function loadFakeConfig(force = false): Promise<FakeConfig> {
  if (!force) {
    const hit = cache.get<FakeConfig>(CACHE_KEY);
    if (hit) return hit;
  }
  let cfg: FakeConfig;
  try { cfg = normalize(JSON.parse(await readFile(PATH, "utf8"))); }
  catch { cfg = normalize({}); }
  cache.set(CACHE_KEY, cfg);
  return cfg;
}

async function persist(cfg: FakeConfig): Promise<void> {
  await mkdir(dirname(PATH), { recursive: true });
  const tmp = PATH + ".tmp";
  await writeFile(tmp, JSON.stringify(cfg, null, 2));
  await rename(tmp, PATH); // atomik
  cache.set(CACHE_KEY, cfg);
  await emitConfigChange(); // prewarm menyiapkan cache SEKARANG; balasan perintah menunggu sampai hangat (maks. beberapa detik)
}

export async function updateFakeConfig(patch: Partial<Omit<FakeConfig, "images" | "presets">>): Promise<FakeConfig> {
  const c = await loadFakeConfig(true);
  const next = normalize({ ...c, ...patch, images: c.images, presets: c.presets });
  await persist(next);
  return next;
}

/** Atur gambar satu jenis respon. Sumber kosong = hapus (jatuh ke gambar "default"). */
export async function setFakeImage(kind: string, source: string): Promise<void> {
  const c = await loadFakeConfig(true);
  const s = source.trim();
  if (s && !/^https?:\/\/\S+$/i.test(s)) throw new Error("gambar harus URL http/https");
  if (s) c.images[kind] = s; else delete c.images[kind];
  const next = normalize({ ...c });
  await persist(next);
}

export async function resetFakeImages(): Promise<void> {
  const c = await loadFakeConfig(true);
  c.images = {};
  const next = normalize({ ...c });
  await persist(next);
}

export function invalidateFakeCache(): void {
  cache.del(CACHE_KEY);
}