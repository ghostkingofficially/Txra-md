// src/setfakereply/presets.ts — 10 tipe balasan (nomor = argumen `.sfr <nomor>`).
// Semuanya bergaya KECIL (thumbnail 160px). Tipe thumbnail besar (catalog/product/location/image) sudah dibuang.
// Ubah isi preset lewat "presets" di db/configuration/setfakereply.json, mis. { "6": { "amount": "5000" } }.
import { getConfig } from "../../connector/config.ts";
import { loadFakeConfig } from "./store.ts";

export type PresetType =
  | "document" | "linkpreview" | "inapp_signup" | "airich_product" | "group_invite" | "review_and_pay"
  | "order_message" | "text" | "request_payment" | "order_status";

export interface Preset { name: string; type: PresetType; [k: string]: any }

export function defaultPresets(): Record<number, Preset> {
  let name = "Bot", footer = "";
  try { const b = getConfig().bot; name = String(b?.name ?? name); footer = String(b?.footer ?? ""); } catch { /* bawaan */ }
  const title = `✨ ${name}`;
  return {
    1: { name: "Document", type: "document", fileName: name, mimetype: "image/jpeg", fileLength: 99999999999999 },
    2: { name: "Preview Link (kecil)", type: "linkpreview", matchedText: "https://wa.me", title, description: "" },
    3: { name: "InApp Signup", type: "inapp_signup", title, footer: "" },
    4: {
      name: "AI Rich Product", type: "airich_product", footer, body: "",
      product: { title: name, brand: title, price: "Rp 0", sale_price: "Rp 0", url: "https://wa.me" },
    },
    5: { name: "Group Invite", type: "group_invite", groupJid: "120363398395207191@g.us", inviteCode: "Eh3alUCgmvdCMDIo4UhP95", inviteExpiration: 9999999999, groupName: title },
    6: { name: "Review & Pay", type: "review_and_pay", title, footer: `${footer} • Payment`.trim(), currency: "IDR", amount: "999999999", offset: "100", itemName: "Pesanan", additional_note: "" },
    7: { name: "Order Message", type: "order_message", title: `${name} Response`, totalAmount: 10000000, currency: "IDR", sellerJid: "119722834194622@lid", itemCount: 1, status: 2, surface: 1 },
    8: { name: "Plain Text", type: "text" },
    9: { name: "Request Payment", type: "request_payment", currency: "IDR", amount: 20000000, offset: 1000, expiry: 0 },
    10: { name: "Order Status", type: "order_status", title: "📦 Status Pesanan", subtotal: 10000, tax: 0, status: title, currency: "IDR" },
  };
}

/** Bawaan + ubahan dari setfakereply.json. */
export async function getPresets(): Promise<Record<number, Preset>> {
  const base = defaultPresets();
  const over = (await loadFakeConfig()).presets;
  for (const [k, v] of Object.entries(over)) {
    const n = Number(k);
    if (base[n] && v && typeof v === "object") base[n] = { ...base[n], ...v, type: base[n].type };
  }
  return base;
}