// src/rpg/db.ts — Node.js SQLite storage for RPG data.
import { DatabaseSync } from "node:sqlite";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

type SqlValue = string | number | bigint | Uint8Array | null;
type SqlStatement = {
  run(...params: SqlValue[]): { changes: number; lastInsertRowid: number | bigint };
  get(...params: SqlValue[]): unknown;
  all(...params: SqlValue[]): unknown[];
};

class NodeSqliteDatabase {
  constructor(private readonly native: DatabaseSync) {}

  exec(sql: string): void {
    this.native.exec(sql);
  }

  query(sql: string): SqlStatement {
    const statement = this.native.prepare(sql);
    return {
      run: (...params) => statement.run(...params),
      get: (...params) => statement.get(...params),
      all: (...params) => statement.all(...params),
    };
  }

  begin(): void {
    this.native.exec("BEGIN");
  }

  commit(): void {
    this.native.exec("COMMIT");
  }

  rollback(): void {
    this.native.exec("ROLLBACK");
  }
}

const DB_PATH = process.env.RPG_DB_PATH ?? new URL("../../db/rpg/rpg.sqlite", import.meta.url).pathname;

let db: NodeSqliteDatabase | null = null;

export function getDb(): NodeSqliteDatabase {
  if (db) return db;
  if (DB_PATH !== ":memory:") mkdirSync(dirname(DB_PATH), { recursive: true });
  db = new NodeSqliteDatabase(new DatabaseSync(DB_PATH));
  db.exec("PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;");
  migrate(db);
  return db;
}

export function __setDb(d: NodeSqliteDatabase | null): void { db = d; if (d) migrate(d); }

function migrate(d: NodeSqliteDatabase): void {
  d.exec(`
    CREATE TABLE IF NOT EXISTS players (
      phone       TEXT PRIMARY KEY,
      credits     INTEGER NOT NULL DEFAULT 1000,
      hp          INTEGER NOT NULL DEFAULT 100,
      max_hp      INTEGER NOT NULL DEFAULT 100,
      stamina     INTEGER NOT NULL DEFAULT 100,
      mana        INTEGER NOT NULL DEFAULT 100,
      stamina_at  INTEGER NOT NULL DEFAULT 0,
      created_at  INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS inventory (
      phone  TEXT NOT NULL,
      item   TEXT NOT NULL,
      qty    INTEGER NOT NULL CHECK (qty >= 0),
      PRIMARY KEY (phone, item)
    );
    CREATE TABLE IF NOT EXISTS plots (
      phone      TEXT NOT NULL,
      slot       INTEGER NOT NULL,
      crop       TEXT NOT NULL,
      planted_at INTEGER NOT NULL,
      watered_at INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (phone, slot)
    );
    CREATE TABLE IF NOT EXISTS cooldowns (
      phone TEXT NOT NULL,
      key   TEXT NOT NULL,
      until INTEGER NOT NULL,
      PRIMARY KEY (phone, key)
    );
  `);
}

export function tx<T>(fn: () => T): T {
  const database = getDb();
  database.begin();
  try {
    const result = fn();
    database.commit();
    return result;
  } catch (error) {
    try {
      database.rollback();
    } catch {
      // Preserve the original transaction error.
    }
    throw error;
  }
}
