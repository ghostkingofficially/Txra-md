// src/rpg/assets.ts — satu-satunya tempat URL gambar sparepart-wuwa didefinisikan.
// Pindah hosting (GitHub -> R2 dll) cukup ubah ASSET_BASE_URL di .env, tanpa sentuh command.
const BASE = (process.env.ASSET_BASE_URL
  ?? "https://raw.githubusercontent.com/USER/sparepart-wuwa/main").replace(/\/+$/, "");

const pick = <T>(a: readonly T[]): T => a[Math.floor(Math.random() * a.length)]!;

/** Variasi gambar: base.webp, base-2.webp, base-3.webp. Bot memilih acak supaya tidak monoton. */
const variants = (path: string, n = 1): string => {
  if (n <= 1) return `${BASE}/${path}.webp`;
  const i = 1 + Math.floor(Math.random() * n);
  return `${BASE}/${path}${i === 1 ? "" : `-${i}`}.webp`;
};

export const ASSET = {
  base: BASE,
  char: (name: string, variantCount = 1) => variants(`characters/${name}/base`, variantCount),
  skill: (name: string, skill: string) => `${BASE}/characters/${name}/skills/${skill}.webp`,
  skin: (name: string, skin: string) => `${BASE}/characters/${name}/skins/${skin}.webp`,
  echo: (name: string) => `${BASE}/echoes/${name}/base.webp`,
  food: (id: string) => `${BASE}/items/foods/${id}.webp`,
  plant: (id: string) => `${BASE}/items/plants/${id}.webp`,
  material: (id: string) => `${BASE}/items/materials/${id}.webp`,
  loc: (name: string, variantCount = 1) => variants(`locations/${name}/base`, variantCount),
  icon: (name: string) => `${BASE}/ui/icons/${name}.webp`,
  banner: (name: string) => `${BASE}/ui/banners/${name}.webp`,
  pick,
};
