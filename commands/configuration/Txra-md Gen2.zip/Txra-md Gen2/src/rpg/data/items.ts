// src/rpg/data/items.ts — semua data game berupa tabel. Tambah item = tambah baris, bukan tambah kode.
export interface Crop {
  id: string; name: string; seedCost: number;
  growMs: number;           // waktu tumbuh
  yield: [number, number];  // jumlah panen min..max
  sell: number;             // harga jual per unit
  img: string;              // id gambar di items/plants/
}
export interface Recipe {
  id: string; name: string;
  needs: Record<string, number>;  // bahan (id crop/material -> jumlah)
  healPct: number;                // heal % dari max HP
  staminaGain?: number;
  sell: number;
  img: string;                    // id gambar di items/foods/
}

const MIN = 60_000;

export const CROPS: Record<string, Crop> = {
  coral:  { id: "coral",  name: "Coral Fungus", seedCost: 40, growMs: 10 * MIN, yield: [2, 4], sell: 30, img: "coral-fungus" },
  wintry: { id: "wintry", name: "Wintry Bell",  seedCost: 60, growMs: 20 * MIN, yield: [2, 3], sell: 55, img: "wintry-bell" },
  loach:  { id: "loach",  name: "Loach Pearl",  seedCost: 90, growMs: 40 * MIN, yield: [1, 3], sell: 120, img: "wintry-bell" },
};

export const RECIPES: Record<string, Recipe> = {
  souffle:   { id: "souffle",   name: "Misty Souffle",     needs: { coral: 3 },              healPct: 50, sell: 150, img: "misty-souffle" },
  crownless: { id: "crownless", name: "Grilled Crownless", needs: { wintry: 2, coral: 2 },   healPct: 80, staminaGain: 20, sell: 320, img: "grilled-crownless" },
};

export const BAR_COST = 500;
export const MAX_PLOTS = 4;
export const WATER_BOOST = 0.8; // siram = waktu tumbuh x0.8 (sekali per tanaman)

export const itemName = (id: string): string =>
  CROPS[id]?.name ?? RECIPES[id]?.name ?? (id === "seed" ? "Benih" : id);

/** Cocokkan input user ("coral", "misty", "Coral Fungus") ke id; undefined kalau tidak ada. */
export function resolveId(table: Record<string, { id: string; name: string }>, input: string): string | undefined {
  const q = input.trim().toLowerCase();
  if (!q) return undefined;
  if (table[q]) return q;
  return Object.values(table).find((x) => x.name.toLowerCase().startsWith(q) || x.name.toLowerCase().split(" ").includes(q))?.id;
}