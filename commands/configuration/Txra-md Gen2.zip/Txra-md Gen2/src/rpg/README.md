# Modul RPG (tahap 1)

Loop: `.tanam` -> `.siram` -> `.panen` -> `.masak` -> `.makan` -> `.bar` (+ `.jual`, `.resep`, `.farm`, `.profile`).

- `data/items.ts`  : semua angka game (tanaman, resep, harga). Tambah konten = tambah baris di sini.
- `engine.ts`      : logika murni, transaksional (SQLite), dites di `tests/rpg.test.ts`.
- `db.ts`          : `bun:sqlite`, file di `db/rpg/rpg.sqlite` (otomatis dibuat).
- `assets.ts`      : satu-satunya tempat URL gambar. Isi `ASSET_BASE_URL` di `.env`:
  `ASSET_BASE_URL=https://raw.githubusercontent.com/<user>/sparepart-wuwa/main`
  Selama masih placeholder, bot membalas teks saja (tidak error).
- `reply.ts`       : kirim gambar+caption lewat pipeline bot yang sudah ada; gagal -> teks.

Test (Bun):  `bun test tests/rpg.test.ts`
