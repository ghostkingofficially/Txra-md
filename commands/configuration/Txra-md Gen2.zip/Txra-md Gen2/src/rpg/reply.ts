// src/rpg/reply.ts — kirim balasan RPG: gambar + caption kalau gambar tersedia, selain itu teks biasa.
// Memakai pipeline gambar bot yang sudah ada (unduh -> ffmpeg -> cache upload), jadi 1 gambar dipakai ulang tanpa upload berulang.
import type { Result } from "./engine.ts";
import { ASSET } from "./assets.ts";
import { getThumbForSource } from "../setthumblarge/thumb.ts";
import { cachedUpload } from "../setthumblarge/cache.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay } from "../../helpers/utils/button-messages/transport.ts";

/** Gambar nonaktif selama ASSET_BASE_URL belum diisi (masih placeholder) atau RPG_IMAGES=off. */
const imagesEnabled = () => process.env.RPG_IMAGES !== "off" && !ASSET.base.includes("/USER/");

function cleanQuoted(q?: { key: any; message: any }) {
  if (!q?.message || typeof q.message !== "object") return q;
  const type = Object.keys(q.message)[0];
  const inner = type ? q.message[type] : undefined;
  if (inner && typeof inner === "object" && inner.contextInfo) {
    const { contextInfo: _drop, ...rest } = inner;
    return { ...q, message: { [type]: rest } };
  }
  return q;
}

export async function sendImageCaption(client: any, m: any, imageUrl: string, caption: string): Promise<boolean> {
  try {
    const thumb = await getThumbForSource("image", imageUrl);
    if (!thumb) return false;
    const media: any = await cachedUpload(`img|${thumb.key}`, () => prepareMedia(client, "image", thumb.jpeg, { mimetype: "image/jpeg" }) as Promise<any>);
    const quoted = m?.key && m?.message ? cleanQuoted({ key: m.key, message: m.message }) : undefined;
    const wa = buildWAMessage(m.chat, { imageMessage: { ...media.imageMessage, caption } }, { messageId: newMessageId(), quoted });
    await relay(client, m.chat, wa.message, { messageId: wa.key.id });
    return true;
  } catch {
    return false; // gagal kirim gambar -> jatuh ke teks, command tidak ikut gagal
  }
}

/** Kirim Result dari engine. `imageUrl` opsional; kalau kosong/gagal, kirim teks saja. */
export async function replyResult(client: any, m: any, r: Result, imageUrl?: string): Promise<void> {
  const text = r.ok ? r.msg : `❌ ${r.msg}`;
  if (r.ok && imageUrl && imagesEnabled() && (await sendImageCaption(client, m, imageUrl, text))) return;
  await m.reply(text);
}
