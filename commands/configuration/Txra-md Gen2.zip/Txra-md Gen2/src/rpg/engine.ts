// src/rpg/engine.ts — logika game murni (tanpa WhatsApp). Setiap fungsi return { ok, msg, ... } agar mudah dites.
import { getDb, tx } from "./db.ts";
import { BAR_COST, CROPS, MAX_PLOTS, RECIPES, WATER_BOOST, itemName } from "./data/items.ts";

export interface Player { phone: string; credits: number; hp: number; max_hp: number; stamina: number; mana: number; stamina_at: number; created_at: number }
export interface Result { ok: boolean; msg: string; img?: string }

const STAMINA_REGEN_MS = 3 * 60_000; // +1 stamina / 3 menit
const now = () => Date.now();
const fmtTime = (ms: number) => { const s = Math.ceil(ms / 1000); return s >= 60 ? `${Math.ceil(s / 60)} menit` : `${s} detik`; };

export function getPlayer(phone: string): Player {
  const d = getDb();
  d.query("INSERT OR IGNORE INTO players (phone, created_at) VALUES (?, ?)").run(phone, now());
  const p = d.query("SELECT * FROM players WHERE phone = ?").get(phone) as Player;
  return regenStamina(p);
}

function regenStamina(p: Player): Player {
  if (p.stamina >= 100) { if (!p.stamina_at) return p; }
  const t = now();
  if (!p.stamina_at) { p.stamina_at = t; return p; }
  const gain = Math.floor((t - p.stamina_at) / STAMINA_REGEN_MS);
  if (gain > 0) {
    p.stamina = Math.min(100, p.stamina + gain);
    p.stamina_at = p.stamina >= 100 ? 0 : p.stamina_at + gain * STAMINA_REGEN_MS;
    getDb().query("UPDATE players SET stamina = ?, stamina_at = ? WHERE phone = ?").run(p.stamina, p.stamina_at, p.phone);
  }
  return p;
}

export function getItems(phone: string): Record<string, number> {
  const rows = getDb().query("SELECT item, qty FROM inventory WHERE phone = ? AND qty > 0").all(phone) as { item: string; qty: number }[];
  return Object.fromEntries(rows.map((r) => [r.item, r.qty]));
}

export function addItem(phone: string, item: string, n: number): void {
  getDb().query(
    "INSERT INTO inventory (phone, item, qty) VALUES (?, ?, ?) ON CONFLICT(phone, item) DO UPDATE SET qty = qty + excluded.qty",
  ).run(phone, item, n);
}

/** Kurangi item; false kalau tidak cukup (tidak ada yang berubah). */
export function takeItem(phone: string, item: string, n: number): boolean {
  const r = getDb().query("UPDATE inventory SET qty = qty - ? WHERE phone = ? AND item = ? AND qty >= ?").run(n, phone, item, n);
  return r.changes > 0;
}

function spend(phone: string, credits: number): boolean {
  return getDb().query("UPDATE players SET credits = credits - ? WHERE phone = ? AND credits >= ?").run(credits, phone, credits).changes > 0;
}

// ───────────── Tanam ─────────────
export function plant(phone: string, cropId: string, slot?: number): Result {
  const crop = CROPS[cropId];
  if (!crop) return { ok: false, msg: `Tanaman "${cropId}" tidak ada. Pilihan: ${Object.keys(CROPS).join(", ")}` };
  getPlayer(phone);
  return tx(() => {
    const used = new Set((getDb().query("SELECT slot FROM plots WHERE phone = ?").all(phone) as { slot: number }[]).map((r) => r.slot));
    let s = slot;
    if (s == null) { for (let i = 1; i <= MAX_PLOTS; i++) if (!used.has(i)) { s = i; break; } }
    if (s == null) return { ok: false, msg: `Semua ${MAX_PLOTS} petak penuh. Panen dulu.` };
    if (s < 1 || s > MAX_PLOTS) return { ok: false, msg: `Petak harus 1-${MAX_PLOTS}.` };
    if (used.has(s)) return { ok: false, msg: `Petak ${s} sudah terisi.` };
    if (!spend(phone, crop.seedCost)) return { ok: false, msg: `Credit kurang. Benih ${crop.name} butuh ${crop.seedCost}.` };
    getDb().query("INSERT INTO plots (phone, slot, crop, planted_at) VALUES (?, ?, ?, ?)").run(phone, s, cropId, now());
    return { ok: true, msg: `Menanam ${crop.name} di petak ${s} (-${crop.seedCost} Credit). Siap dalam ${fmtTime(crop.growMs)}.`, img: crop.img };
  });
}

interface PlotRow { slot: number; crop: string; planted_at: number; watered_at: number }
const readyAt = (r: PlotRow) => r.planted_at + CROPS[r.crop]!.growMs * (r.watered_at ? WATER_BOOST : 1);

export function water(phone: string, slot?: number): Result {
  const rows = getDb().query("SELECT * FROM plots WHERE phone = ? ORDER BY slot").all(phone) as PlotRow[];
  const targets = rows.filter((r) => !r.watered_at && readyAt(r) > now() && (slot == null || r.slot === slot));
  if (!targets.length) return { ok: false, msg: "Tidak ada tanaman yang perlu disiram." };
  for (const r of targets) getDb().query("UPDATE plots SET watered_at = ? WHERE phone = ? AND slot = ?").run(now(), phone, r.slot);
  return { ok: true, msg: `Menyiram ${targets.length} petak. Waktu tumbuh dipercepat ${Math.round((1 - WATER_BOOST) * 100)}%.` };
}

export function farmStatus(phone: string): string {
  const rows = getDb().query("SELECT * FROM plots WHERE phone = ? ORDER BY slot").all(phone) as PlotRow[];
  const lines: string[] = [];
  for (let i = 1; i <= MAX_PLOTS; i++) {
    const r = rows.find((x) => x.slot === i);
    if (!r) { lines.push(`${i}. (kosong)`); continue; }
    const left = readyAt(r) - now();
    lines.push(`${i}. ${CROPS[r.crop]!.name} — ${left <= 0 ? "SIAP PANEN" : `${fmtTime(left)} lagi`}${r.watered_at ? " (disiram)" : ""}`);
  }
  return lines.join("\n");
}

export function harvest(phone: string): Result {
  getPlayer(phone);
  return tx(() => {
    const rows = getDb().query("SELECT * FROM plots WHERE phone = ? ORDER BY slot").all(phone) as PlotRow[];
    const ready = rows.filter((r) => readyAt(r) <= now());
    if (!ready.length) return { ok: false, msg: "Belum ada yang siap panen.\n" + farmStatus(phone) };
    const got: Record<string, number> = {};
    for (const r of ready) {
      const c = CROPS[r.crop]!;
      const n = c.yield[0] + Math.floor(Math.random() * (c.yield[1] - c.yield[0] + 1));
      addItem(phone, c.id, n);
      got[c.id] = (got[c.id] ?? 0) + n;
      getDb().query("DELETE FROM plots WHERE phone = ? AND slot = ?").run(phone, r.slot);
    }
    const first = CROPS[ready[0]!.crop]!;
    return { ok: true, msg: "Panen: " + Object.entries(got).map(([k, v]) => `${itemName(k)} x${v}`).join(", "), img: first.img };
  });
}

// ───────────── Masak & makan ─────────────
export function cook(phone: string, recipeId: string, times = 1): Result {
  const rc = RECIPES[recipeId];
  if (!rc) return { ok: false, msg: `Resep "${recipeId}" tidak ada. Pilihan: ${Object.keys(RECIPES).join(", ")}` };
  const n = Math.max(1, Math.min(20, Math.floor(times) || 1));
  getPlayer(phone);
  return tx(() => {
    const inv = getItems(phone);
    for (const [k, v] of Object.entries(rc.needs)) {
      if ((inv[k] ?? 0) < v * n) return { ok: false, msg: `Bahan kurang: butuh ${itemName(k)} x${v * n}, punya ${inv[k] ?? 0}.` };
    }
    for (const [k, v] of Object.entries(rc.needs)) takeItem(phone, k, v * n);
    addItem(phone, rc.id, n);
    return { ok: true, msg: `Memasak ${rc.name} x${n}. Masuk tas.`, img: rc.img };
  });
}

export function eat(phone: string, recipeId: string): Result {
  const rc = RECIPES[recipeId];
  if (!rc) return { ok: false, msg: `Makanan "${recipeId}" tidak ada.` };
  const p = getPlayer(phone);
  if (p.hp >= p.max_hp && !rc.staminaGain) return { ok: false, msg: "HP sudah penuh." };
  return tx(() => {
    if (!takeItem(phone, rc.id, 1)) return { ok: false, msg: `Kamu tidak punya ${rc.name}.` };
    const hp = Math.min(p.max_hp, p.hp + Math.ceil((p.max_hp * rc.healPct) / 100));
    const st = Math.min(100, p.stamina + (rc.staminaGain ?? 0));
    getDb().query("UPDATE players SET hp = ?, stamina = ? WHERE phone = ?").run(hp, st, phone);
    return { ok: true, msg: `Makan ${rc.name}. HP ${p.hp} -> ${hp}${rc.staminaGain ? `, Stamina ${p.stamina} -> ${st}` : ""}.`, img: rc.img };
  });
}

/** Daftar makanan di tas, untuk notif HP kritis. */
export function foodList(phone: string): { id: string; name: string; qty: number; healPct: number }[] {
  const inv = getItems(phone);
  return Object.values(RECIPES).filter((r) => (inv[r.id] ?? 0) > 0).map((r) => ({ id: r.id, name: r.name, qty: inv[r.id]!, healPct: r.healPct }));
}

// ───────────── Jual & Bar ─────────────
export function sell(phone: string, itemId: string, qty?: number): Result {
  const price = CROPS[itemId]?.sell ?? RECIPES[itemId]?.sell;
  if (price == null) return { ok: false, msg: `Item "${itemId}" tidak bisa dijual.` };
  getPlayer(phone);
  return tx(() => {
    const have = getItems(phone)[itemId] ?? 0;
    const n = qty == null || qty <= 0 ? have : Math.min(have, Math.floor(qty));
    if (n <= 0) return { ok: false, msg: `Kamu tidak punya ${itemName(itemId)}.` };
    takeItem(phone, itemId, n);
    const total = n * price;
    getDb().query("UPDATE players SET credits = credits + ? WHERE phone = ?").run(total, phone);
    return { ok: true, msg: `Menjual ${itemName(itemId)} x${n} = ${total} Credit.` };
  });
}

export function barEnter(phone: string): Result {
  const p = getPlayer(phone);
  if (p.hp >= p.max_hp && p.stamina >= 100 && p.mana >= 100) return { ok: false, msg: "Kondisimu sudah penuh, tidak perlu ke bar." };
  return tx(() => {
    if (!spend(phone, BAR_COST)) return { ok: false, msg: `Credit kurang. Masuk bar butuh ${BAR_COST} Credit.` };
    getDb().query("UPDATE players SET hp = max_hp, stamina = 100, mana = 100, stamina_at = 0 WHERE phone = ?").run(phone);
    return { ok: true, msg: `Masuk bar (-${BAR_COST} Credit). HP, Stamina, dan Mana kembali penuh.` };
  });
}

export function profileText(phone: string, name: string): string {
  const p = getPlayer(phone);
  const items = Object.entries(getItems(phone)).map(([k, v]) => `${itemName(k)} x${v}`).join(", ") || "-";
  return `PROFIL ${name}\nCredit: ${p.credits}\nHP: ${p.hp}/${p.max_hp}  Stamina: ${p.stamina}/100  Mana: ${p.mana}/100\nTas: ${items}`;
}

/** Peringatan HP kritis (<20%), dipakai di dungeon nanti. null kalau aman. */
export function lowHpWarning(phone: string): string | null {
  const p = getPlayer(phone);
  if (p.hp / p.max_hp >= 0.2) return null;
  const foods = foodList(phone);
  const list = foods.length ? foods.map((f, i) => `${i + 1}. ${f.name} x${f.qty} [Heal ${f.healPct}%]`).join("\n") : "(tidak punya makanan)";
  return `WARNING: HP ${Math.round((p.hp / p.max_hp) * 100)}%\n${list}`;
}
