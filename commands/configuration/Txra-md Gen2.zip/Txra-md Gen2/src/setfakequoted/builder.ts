// src/setfakequoted/builder.ts — quoted palsu global (dipakai semua m.reply, bukan cuma menu)
// Zapo-compatible: semua type sudah diverifikasi via setfakereply builder/senders
// Profil bot & user: dipetakan ke NOMOR TELEPON (LID → nomor), foto profil diambil lewat client.profile.getProfilePicture
// dan diunduh dengan header WhatsApp (tanpa header CDN menolak → foto "tidak terambil").
import NodeCache from "node-cache";
import { processImage } from "../../lib/func/image.ts";
import { getConfig } from "../../connector/config.ts";
import { Toolkit } from "../../helpers/utils/toolkit.ts";
import { getThumbForSource } from "../setthumblarge/thumb.ts";
import { getPnByLid } from "../../lib/usermanager/lidmap.ts";
import { loadFakeQuotedConfig, getActivePreset, getActiveSub } from "./store.ts";

type Obj = Record<string, any>;

export interface FakeQuotedMsg {
  key: { remoteJid: string; fromMe: boolean; id: string; participant: string };
  message: Obj;
  _resolvedJid?: string;
  _resolvedRemoteJid?: string;
}

const phone = (jid: string) => jid.split("@")[0].split(":")[0];

function normalizeStatus(s: unknown): number {
  if (typeof s === "number") return s;
  const m: Record<string, number> = { PAID: 2, INQUIRY: 1, ACCEPTED: 2, PENDING: 0 };
  return m[String(s).toUpperCase()] ?? 2;
}
function normalizeSurface(s: unknown): number {
  if (typeof s === "number") return s;
  const m: Record<string, number> = { CATALOG: 1, PRODUCT: 0 };
  return m[String(s).toUpperCase()] ?? 1;
}

// ── identitas bot & user ──
const userOf = (jid: string) => jid.split("@")[0].split(":")[0];
const lidKey = (jid: string) => `${userOf(jid)}@lid`;
const LEGACY_BOT_JID = /^6283142110522@/; // nomor bot lama (Baileys) yang tertanam di konfigurasi lama

/** JID → bentuk nomor telepon (xxxx@s.whatsapp.net). LID dipetakan lewat peta yang dipelajari handler pesan
 *  (lib/usermanager/identity.ts) dan daftar owner. Tidak ketemu → dikembalikan apa adanya. */
export async function toPnJid(jid?: string | null): Promise<string | undefined> {
  if (!jid) return undefined;
  const s = String(jid);
  if (/@(s\.whatsapp\.net|c\.us)$/.test(s)) {
    const u = userOf(s);
    return /^\d{5,}$/.test(u) ? `${u}@s.whatsapp.net` : s;
  }
  if (s.endsWith("@lid")) {
    let phone = getPnByLid(lidKey(s)) ?? getPnByLid(s);
    if (!phone) {
      try { phone = (await import("../../lib/usermanager/owner.ts")).getPhoneForLid(s); } catch { /* tanpa peta owner */ }
    }
    if (phone && /^\d{5,}$/.test(phone)) return `${phone}@s.whatsapp.net`;
  }
  return s;
}

/** Nomor bot sendiri (dari kredensial login), tanpa bagian device. */
function botJidOf(sock: any): string | undefined {
  try {
    const u = userOf(String(sock?.getCredentials?.()?.meJid ?? ""));
    return /^\d{5,}$/.test(u) ? `${u}@s.whatsapp.net` : undefined;
  } catch { return undefined; }
}

function botNameOf(): string {
  try { return String(getConfig().bot?.name ?? "Bot"); } catch { return "Bot"; }
}

const WA_HEADERS = { "User-Agent": "WhatsApp/2.2413.51 A", Origin: "https://web.whatsapp.com", Referer: "https://web.whatsapp.com/" };

// Foto profil (getpp): stale-while-revalidate. Segar 15 mnt; lewat itu (sampai 24 jam) tetap dipakai SEKETIKA sambil diperbarui
// di latar belakang — jadi pesan tidak pernah menunggu unduh + olah gambar. Tidak ada/gagal → di-cache pendek (2 mnt).
// Permintaan yang sama digabung (inflight); hasil dikecilkan ke 128x128 JPEG q70 (mesin native; cadangan ffmpeg).
// Sentinel ppMiss = jid tidak punya foto / disembunyikan (supaya server tidak ditembak tiap pesan).
const PP_SIZE = 128;
const PP_FRESH_MS = 15 * 60_000;
interface PpEntry { buf: Uint8Array; at: number }
const ppCache = new NodeCache({ stdTTL: 86_400, checkperiod: 0, useClones: false, maxKeys: 500 });
const ppMiss = new NodeCache({ stdTTL: 120, checkperiod: 0, useClones: false, maxKeys: 500 });
const ppInflight = new Map<string, Promise<Uint8Array | null>>();

async function fetchProfilePic(sock: any, jid: string): Promise<Uint8Array | null> {
  try {
    const res: any = sock.profile?.getProfilePicture
      ? await sock.profile.getProfilePicture(jid, "preview") // "preview" = versi kecil, jauh lebih ringan dari "image"
      : await sock.profilePictureUrl?.(jid, "preview");
    let url = typeof res === "string" ? res : String(res?.url ?? "");
    if (!url && res?.directPath) url = `https://mmg.whatsapp.net${res.directPath}`;
    if (!url) return null;
    const raw = await Toolkit.fetchBuffer(url, { headers: WA_HEADERS, timeout: 8_000, maxContentLength: 2 * 1024 * 1024 }, { silent: true });
    if (!raw.length) return null;
    try {
      return new Uint8Array((await processImage(raw, { mode: "cover", width: PP_SIZE, height: PP_SIZE, quality: 70 })).buffer);
    } catch {
      return new Uint8Array(raw); // tidak bisa diolah → pakai apa adanya
    }
  } catch (e) {
    console.warn(`[fakequoted] foto profil ${jid} tidak terambil: ${(e as Error).message}`);
    return null;
  }
}

/** Ambil ulang di latar belakang (digabung bila sudah berjalan). Gagal → entri lama dipertahankan. */
function refreshProfilePic(sock: any, jid: string): Promise<Uint8Array | null> {
  let p = ppInflight.get(jid);
  if (!p) {
    p = fetchProfilePic(sock, jid)
      .then((buf) => {
        if (buf) { ppCache.set(jid, { buf, at: Date.now() } satisfies PpEntry); ppMiss.del(jid); }
        else if (!ppCache.has(jid)) ppMiss.set(jid, 1);
        return buf;
      })
      .finally(() => ppInflight.delete(jid));
    ppInflight.set(jid, p);
  }
  return p;
}

/** Foto profil (JPEG kecil) milik `jid`, atau null (tidak ada / disembunyikan / gagal). */
async function profilePicBytes(sock: any, jid: string): Promise<Uint8Array | null> {
  if (!sock || !jid) return null;
  const hit = ppCache.get<PpEntry>(jid);
  if (hit) {
    if (Date.now() - hit.at > PP_FRESH_MS) void refreshProfilePic(sock, jid); // basi → pakai dulu, perbarui diam-diam
    return hit.buf;
  }
  if (ppMiss.has(jid)) return null;
  return await refreshProfilePic(sock, jid);
}

/** Pemanasan: ambil + olah foto profil `jid` (mis. nomor bot sendiri) sebelum ada yang memintanya. Tidak pernah melempar. */
export async function warmProfilePic(sock: any, jid?: string | null): Promise<boolean> {
  try {
    const target = jid || botJidOf(sock);
    if (!target) return false;
    const hit = ppCache.get<PpEntry>(target);
    if (hit && Date.now() - hit.at < PP_FRESH_MS) return true;
    return !!(await refreshProfilePic(sock, target));
  } catch { return false; }
}

async function thumbFake(image: string | undefined): Promise<Uint8Array | null> {
  const src = image ?? "";
  if (!src) return null;
  const t = await getThumbForSource("fake", src);
  return t ? new Uint8Array(t.jpeg) : null;
}

async function readLocalFallback(): Promise<Uint8Array | null> {
  try {
    const { getConfig } = await import("../../connector/config.ts");
    const src = String((getConfig() as any)?.bot?.thumbnail ?? "");
    if (src) {
      const th = await getThumbForSource("fake", src);
      if (th) return new Uint8Array(th.jpeg);
    }
  } catch {}
  return null; // tidak ada gambar bawaan di disk — atur bot.thumbnail (URL) di config.json



}
export async function buildFakeQuotedMessage(
  presetKey: number | string | null = null,
  dynamicData: { text?: string; jid?: string; name?: string } = {},
  sock: any = null,
): Promise<Obj> {
  const cfg = await loadFakeQuotedConfig();
  const preset = presetKey != null ? cfg.presets[String(presetKey)] : getActivePreset(cfg);
  if (!preset) return { conversation: "Preset tidak ditemukan" };
  const sub = presetKey != null && String(presetKey) in cfg.presets
    ? (cfg.presets[String(presetKey)].subs[String(cfg.presets[String(presetKey)].activeSub)] ?? getActiveSub(preset))
    : getActiveSub(preset);
  if (!sub) return { conversation: "Sub-preset tidak ditemukan" };

  const type = sub.type || "conversation";
  const quotedText = dynamicData.text ?? " ";
  const dynJid = dynamicData.jid ?? "0@s.whatsapp.net";

  switch (type) {
    case "contact": {
      const isDynamic = sub.dynamic === true;
      // kontak BOT: bendera `bot: true`, atau konfigurasi lama yang masih memakai nomor bot Baileys
      const isBot = !isDynamic && ((sub as any).bot === true || LEGACY_BOT_JID.test(String(sub.jid ?? "")));
      let name: string;
      let jid: string;
      if (isDynamic) {
        // USER: nomor telepon pengirim (LID dipetakan), nama = pushName
        jid = (await toPnJid(dynamicData.jid)) || sub.jid || "0@s.whatsapp.net";
        name = dynamicData.name || sub.nameDisplay || "User";
      } else if (isBot) {
        // BOT: nomor yang sedang login, nama dari config.bot.name (kecuali nameDisplay sudah diubah dari bawaan lama)
        jid = botJidOf(sock) ?? sub.jid ?? "0@s.whatsapp.net";
        name = sub.nameDisplay && sub.nameDisplay !== "Bocchi Bot" ? sub.nameDisplay : botNameOf();
      } else {
        jid = sub.jid || "0@s.whatsapp.net";
        name = sub.nameDisplay || "Contact";
      }
      const previewText = (sub as any).quotedLabel ?? quotedText;
      const isStatus = (sub as any).statusMode === true;
      return {
        contactMessage: {
          displayName: name,
          vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${name}\nTEL;waid=${phone(jid)}:${phone(jid)}\nEND:VCARD`,
          contextInfo: {
            participant: jid,
            quotedMessage: { conversation: previewText },
          },
        },
        _resolvedJid: jid,
        _resolvedRemoteJid: isStatus ? "status@broadcast" : jid,
      };
    }

    case "requestPayment": {
      const noteText = quotedText || " ";
      const fromJid = (sub as any).requestFrom || dynJid;
      // sub.amount1000 sudah *1000 (mis 20000000000). Untuk amount.value butuh nilai sebelum *1000.
      const rawAmt = String((sub as any).amount1000 ?? "20000000");
      const amt1000 = String(rawAmt);
      const amtVal = String(Math.trunc(Number(amt1000) / 1000) || 20000000);
      const cur = (sub as any).currencyCodeIso4217 ?? "IDR";
      const expiry = (sub as any).expiryTimestamp ?? "0";
      return {
        requestPaymentMessage: {
          currencyCodeIso4217: cur,
          amount1000: amt1000,
          requestFrom: fromJid,
          noteMessage: { extendedTextMessage: { text: noteText } },
          expiryTimestamp: String(expiry),
          amount: { value: amtVal, offset: 1000, currencyCode: cur },
        },
        _resolvedJid: fromJid,
      };
    }

    case "metaAiResponse": {
      const botJid = (sub as any).botJid || "13135550002@s.whatsapp.net";
      const statusMode = (sub as any).statusMode === true;
      return {
        botForwardedMessage: {
          message: {
            richResponseMessage: {
              messageType: 1,
              submessages: [{ messageType: 2, messageText: quotedText.trim() || "Meta AI" }],
              contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedAiBotMessageInfo: { botJid },
                forwardOrigin: 4,
                participant: botJid,
                remoteJid: statusMode ? "status@broadcast" : botJid,
              },
            },
          },
        },
        _resolvedJid: botJid,
        _resolvedRemoteJid: statusMode ? "status@broadcast" : botJid,
      };
    }

    case "extendedTextMessage": {
      const ctx = (sub as any).contextInfo ?? {};
      const t = quotedText || " ";
      return {
        extendedTextMessage: {
          text: t,
          contextInfo: {
            participant: ctx.participant || "0@s.whatsapp.net",
            remoteJid: ctx.remoteJid || "0@s.whatsapp.net",
            quotedMessage: { conversation: t },
          },
        },
        _resolvedJid: ctx.participant || "0@s.whatsapp.net",
        _resolvedRemoteJid: ctx.remoteJid || "0@s.whatsapp.net",
      };
    }

    case "product":
    case "catalog":
    case "previewOrder":
    case "order": {
      const thumbType = (sub as any).thumbnailType ?? "custom";
      let thumb: Uint8Array | null = null;
      try {
        if (thumbType === "bot") {
          // foto profil BOT (nomor yang sedang login)
          const jid = botJidOf(sock);
          if (jid) thumb = await profilePicBytes(sock, jid);
        } else if (thumbType === "user") {
          // foto profil USER pengirim — coba nomor telepon dulu, baru JID asli (LID)
          const pn = await toPnJid(dynamicData.jid);
          for (const j of [...new Set([pn, dynamicData.jid].filter(Boolean) as string[])]) {
            thumb = await profilePicBytes(sock, j);
            if (thumb) break;
          }
        } else if (thumbType === "custom") {
          const customSrc = (sub as any).image as string | undefined;
          if (customSrc) thumb = await thumbFake(customSrc);
          if (!thumb) thumb = await readLocalFallback();
        } else {
          thumb = await readLocalFallback(); // thumbnailType tidak dikenal
        }
      } catch (e) {
        console.warn("[fakequoted] gagal menyiapkan thumbnail order:", (e as Error).message);
      }
      if (!thumb) thumb = await readLocalFallback();
      // pipeline fake juga dicoba untuk pastikan ukuran 160
      if (!thumb) thumb = await thumbFake(undefined);
      const status = normalizeStatus((sub as any).status);
      const surface = normalizeSurface((sub as any).surface);
      return {
        orderMessage: {
          orderId: ((sub as any).orderId || "PAYMENT_") + Date.now(),
          ...(thumb ? { thumbnail: thumb } : {}),
          itemCount: (sub as any).itemCount ?? 1,
          status,
          surface,
          message: (sub as any).message ?? quotedText,
          orderTitle: (sub as any).orderTitle ?? "Bocchi-MD Response",
          sellerJid: (sub as any).sellerJid ?? "119722834194622@lid",
          totalAmount1000: String((sub as any).totalAmount1000 ?? "10000000"),
          totalCurrencyCode: (sub as any).totalCurrencyCode ?? "IDR",
        },
        _resolvedJid: (sub as any).sellerJid ?? "119722834194622@lid",
      };
    }

    case "conversation":
    default:
      return { conversation: quotedText };
  }
}

export async function buildFakeQuotedFromConfig(
  dynamicData: { text?: string; jid?: string; name?: string } = {},
  sock: any = null,
): Promise<FakeQuotedMsg | null> {
  const cfg = await loadFakeQuotedConfig();
  const preset = getActivePreset(cfg);
  if (!preset) return null;
  const sub = getActiveSub(preset);
  if (!sub || sub.type === "conversation") return null; // polos = tanpa quoted (handled caller)
  const raw: any = await buildFakeQuotedMessage(null, dynamicData, sock);
  if (!raw || raw.conversation) return null;
  const id = "FQ" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const participant = raw._resolvedJid ?? raw._resolvedRemoteJid ?? dynamicData.jid ?? "0@s.whatsapp.net";
  const remoteJid = raw._resolvedRemoteJid ?? raw._resolvedJid ?? participant;
  const { _resolvedJid, _resolvedRemoteJid, ...message } = raw;
  return { key: { remoteJid, fromMe: false, id, participant }, message };
}