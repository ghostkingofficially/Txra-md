// src/setfakequoted/store.ts — db/configuration/setfakequoted.json + NodeCache (TTL 30s, checkperiod 0)
// Fix: default activeSub 2→1 (real metaAiResponse, bukan contact fake-Meta)
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import NodeCache from "node-cache";
import { PROJECT_ROOT } from "../setthumblarge/store.ts";
import type { FakeQuotedConfig, QuotedPreset } from "./types.ts";
import { emitConfigChange } from "../../helpers/utils/config-events.ts";

const PATH = join(PROJECT_ROOT, "db", "configuration", "setfakequoted.json");
const CACHE_KEY = "fakequoted:config";
const cache = new NodeCache({ stdTTL: 30, checkperiod: 0, useClones: false });

function defaultPresets(): Record<string, QuotedPreset> {
  return {
    "1": {
      name: "VCard Contact", activeSub: 1,
      subs: {
        "1": { name: "Contact User (dynamic)", type: "contact", dynamic: true, nameDisplay: "User", jid: "0@s.whatsapp.net" },
        "2": { name: "Contact Bot (fixed)", type: "contact", dynamic: false, nameDisplay: "Bocchi Bot", jid: "6283142110522@s.whatsapp.net" },
      },
    },
    "2": {
      name: "Meta AI", activeSub: 1,
      subs: {
        "1": { name: "Meta AI (Chat)", type: "metaAiResponse", botJid: "13135550002@s.whatsapp.net", statusMode: false },
        "2": { name: "Meta AI • Status", type: "metaAiResponse", botJid: "13135550002@s.whatsapp.net", statusMode: true },
        "3": { name: "Kontak Meta (Quoted: Meta)", type: "contact", dynamic: false, nameDisplay: "Meta", jid: "13135550002@s.whatsapp.net", quotedLabel: "Meta", statusMode: false },
        "4": { name: "Kontak Meta • Status (Quoted: Meta • Status)", type: "contact", dynamic: false, nameDisplay: "Meta", jid: "13135550002@s.whatsapp.net", quotedLabel: "Meta • Status", statusMode: true },
      },
    },
    "3": {
      name: "Order Message", activeSub: 1,
      subs: {
        "1": { name: "Order with Bot PP", type: "order", thumbnailType: "bot", orderId: "PAYMENT_", itemCount: 1, status: "PAID", surface: "CATALOG", message: "faridesuwa ><", orderTitle: "Bocchi-MD Response", sellerJid: "119722834194622@lid", totalAmount1000: "10000000", totalCurrencyCode: "IDR" },
        "2": { name: "Order with User PP", type: "order", thumbnailType: "user", orderId: "PAYMENT_", itemCount: 1, status: "PAID", surface: "CATALOG", message: "faridesuwa ><", orderTitle: "Bocchi-MD Response", sellerJid: "119722834194622@lid", totalAmount1000: "10000000", totalCurrencyCode: "IDR" },
        "3": { name: "Order with Custom Image", type: "order", thumbnailType: "custom", orderId: "PAYMENT_", itemCount: 1, status: "PAID", surface: "CATALOG", message: "faridesuwa ><", orderTitle: "Bocchi-MD Response", sellerJid: "119722834194622@lid", totalAmount1000: "10000000", totalCurrencyCode: "IDR" },
      },
    },
    "4": {
      name: "Request Payment", activeSub: 1,
      subs: { "1": { name: "Request Payment (dynamic)", type: "requestPayment", currencyCodeIso4217: "IDR", amount1000: "20000000000", requestFrom: "106893800382647@lid", expiryTimestamp: "0" } },
    },
    "5": {
      name: "WhatsApp Official", activeSub: 1,
      subs: { "1": { name: "WA + Status", type: "extendedTextMessage", contextInfo: { participant: "0@s.whatsapp.net", remoteJid: "status@broadcast", quotedMessage: { conversation: " " } } } },
    },
    "6": {
      name: "Plain Reply", activeSub: 1,
      subs: { "1": { name: "Polos", type: "conversation" } },
    },
  };
}

const DEFAULTS: FakeQuotedConfig = { active: 2, presets: defaultPresets() };

function normalize(raw: any): FakeQuotedConfig {
  const base = defaultPresets();
  const pr: Record<string, QuotedPreset> = {};
  for (const [k, v] of Object.entries(base)) {
    const ov = raw?.presets?.[k];
    if (ov && typeof ov === "object" && (ov as any).subs && typeof (ov as any).subs === "object") {
      const subs = (ov as any).subs as Record<string, any>;
      const activeSub = Number.isInteger(Number((ov as any).activeSub)) ? Number((ov as any).activeSub) : v.activeSub;
      const safe = subs[String(activeSub)] ? activeSub : Number(Object.keys(subs)[0]) || v.activeSub;
      pr[k] = { ...(v as any), ...(ov as any), subs, activeSub: safe };
    } else {
      const wantActive = Number.isInteger(Number(raw?.presets?.[k]?.activeSub)) ? Number(raw.presets[k].activeSub) : v.activeSub;
      const safe = (v.subs as any)[String(wantActive)] ? wantActive : v.activeSub;
      pr[k] = { ...v, activeSub: safe };
    }
  }
  let active = Number.isInteger(Number(raw?.active)) ? Number(raw.active) : DEFAULTS.active;
  if (!pr[String(active)]) active = DEFAULTS.active;
  return { active, presets: pr };
}

export async function loadFakeQuotedConfig(force = false): Promise<FakeQuotedConfig> {
  if (!force) {
    const hit = cache.get<FakeQuotedConfig>(CACHE_KEY);
    if (hit) return hit;
  }
  let cfg: FakeQuotedConfig;
  try { cfg = normalize(JSON.parse(await readFile(PATH, "utf8"))); }
  catch { cfg = normalize({}); }
  cache.set(CACHE_KEY, cfg);
  return cfg;
}

async function persist(cfg: FakeQuotedConfig): Promise<void> {
  await mkdir(dirname(PATH), { recursive: true });
  const tmp = PATH + ".tmp";
  await writeFile(tmp, JSON.stringify(cfg, null, 2));
  await rename(tmp, PATH);
  cache.set(CACHE_KEY, cfg);
  await emitConfigChange(); // prewarm menyiapkan cache SEKARANG; balasan perintah menunggu sampai hangat (maks. beberapa detik)
}

export function getActivePreset(cfg: FakeQuotedConfig): QuotedPreset | undefined { return cfg.presets[String(cfg.active)]; }
export function getActiveSub(preset: QuotedPreset): any { return preset.subs[String(preset.activeSub)] ?? Object.values(preset.subs)[0]; }
export function isPolosQuoted(cfg: FakeQuotedConfig): boolean {
  const p = getActivePreset(cfg);
  if (!p) return false;
  const s = getActiveSub(p);
  return s?.type === "conversation";
}
export function isPolosQuotedSync(): boolean {
  const hit = cache.get<FakeQuotedConfig>(CACHE_KEY);
  if (!hit) return false;
  return isPolosQuoted(hit);
}

export async function setActivePreset(n: number): Promise<boolean> {
  const cfg = await loadFakeQuotedConfig(true);
  if (!cfg.presets[String(n)]) return false;
  const next = normalize({ ...cfg, active: n });
  await persist(next);
  return true;
}

export async function setActiveSub(presetKey: number, subKey: number): Promise<boolean> {
  const cfg = await loadFakeQuotedConfig(true);
  const pr = cfg.presets[String(presetKey)];
  if (!pr || !pr.subs[String(subKey)]) return false;
  pr.activeSub = subKey;
  const next = normalize(cfg);
  await persist(next);
  return true;
}

export function invalidateFakeQuotedCache(): void { cache.del(CACHE_KEY); }