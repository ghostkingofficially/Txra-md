export type QuotedPresetType = "contact" | "metaAiResponse" | "order" | "product" | "catalog" | "previewOrder" | "requestPayment" | "extendedTextMessage" | "conversation";
export type ThumbType = "bot" | "user" | "custom";

export interface QuotedSub {
  name: string;
  type: QuotedPresetType;
  [k: string]: any;
}

export interface QuotedPreset {
  name: string;
  activeSub: number;
  subs: Record<string, QuotedSub>;
}

export interface FakeQuotedConfig {
  active: number;
  presets: Record<string, QuotedPreset>;
}
