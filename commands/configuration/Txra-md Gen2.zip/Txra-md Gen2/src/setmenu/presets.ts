// src/setmenu/presets.ts — 13 preset menu (mirror bocchi-v1 menuconfig.json)
import { loadMenuConfig } from "./store.ts";
import type { MenuPreset, MenuType } from "./types.ts";

export function defaultPresets(): Record<number, MenuPreset> {
  return {
    1: { name: "Extended Text", type: "extendedTextMessage" as MenuType, title: "Bocchi-MD V2", description: "Bot Multi Device", matchedText: "Bocchi-MD Menu", sourceUrl: "https://github.com/faridesu" },
    2: { name: "Button Location", type: "location" as MenuType, address: "Jl. Sakura No. 1" },
    3: { name: "Interactive Product", type: "interactive" as MenuType },
    4: { name: "Split Button", type: "splitbutton" as MenuType, address: "Jl. Sakura No. 1" },
    5: { name: "Plain Text", type: "plain" as MenuType },
    6: { name: "Bottom Sheet", type: "bottomsheet" as MenuType },
    7: { name: "Motion Photo", type: "motionphoto" as MenuType },
    8: { name: "Video GIF (Polos)", type: "videogif" as MenuType },
    9: { name: "Video GIF + Button", type: "videobutton" as MenuType },
    10: { name: "Video GIF + Bottom Sheet", type: "videobottomsheet" as MenuType },
    11: { name: "Video GIF + Split", type: "videosplit" as MenuType },
    12: { name: "Catalog Message", type: "catalog" as MenuType },
    13: { name: "Catalog + Split Button", type: "catalogbutton" as MenuType },
  };
}

export async function getPresets(): Promise<Record<number, MenuPreset>> {
  const base = defaultPresets();
  const over = (await loadMenuConfig()).presets;
  for (const [k, v] of Object.entries(over)) {
    const n = Number(k);
    if (base[n] && v && typeof v === "object") base[n] = { ...base[n], ...v, type: base[n].type };
  }
  return base;
}

export async function getActivePreset(): Promise<MenuPreset> {
  const cfg = await loadMenuConfig();
  const pr = await getPresets();
  return pr[cfg.active] ?? pr[7];
}


/** Preset yang memuat tombol (list menu ada di dalam tombol) — preset lain harus menampilkan daftar wilayah di teks. */
const BUTTON_TYPES = new Set<string>(["location", "splitbutton", "interactive", "bottomsheet", "videobutton", "videobottomsheet", "videosplit", "catalogbutton"]);
export const presetHasButtons = (type: string): boolean => BUTTON_TYPES.has(type);