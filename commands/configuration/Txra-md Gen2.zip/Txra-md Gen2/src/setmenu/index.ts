// src/setmenu/index.ts — build + send menu (mirror bocchi handlemenu buildMenu+sendMenu)
import { getConfig } from "../../connector/config.ts";
import { getAllCommands } from "../../helpers/handling-plugins.ts";
import { formatUptime, getGreetingText, processUptimeSeconds } from "../../lib/func/dateTime.ts";
import { getSettings, loadSettings } from "../../lib/settings/botSettings.ts";
import { loadMenuConfig } from "./store.ts";
import { getPresets, presetHasButtons } from "./presets.ts";
import { buildBaseContent, buildAllMenuText, buildCategoryListText, getCategoryCommands, buildCategorySections } from "./helpers.ts";
import { readFile } from "node:fs/promises";
import { PROJECT_ROOT } from "../setthumblarge/store.ts";
import { sendByType } from "./senders.ts";
import { sendMenuAudio } from "./audio.ts";
import { buildFakeQuotedFromConfig } from "../setfakequoted/builder.ts";
import { loadFakeQuotedConfig, isPolosQuoted } from "../setfakequoted/store.ts";

/** Versi bot + library dibaca SEKALI dari package.json (bukan tiap menu dipanggil). */
let metaPromise: Promise<{ version: string; library: string }> | null = null;
function botMeta(): Promise<{ version: string; library: string }> {
  return (metaPromise ??= (async () => {
    try {
      const pj = JSON.parse(await readFile(`${PROJECT_ROOT}package.json`, "utf8"));
      let lib = String(pj?.dependencies?.["zapo-js"] ?? "").replace(/^npm:zapo-js@/, "").replace(/^[\^~]/, "");
      try { lib = JSON.parse(await readFile(`${PROJECT_ROOT}node_modules/zapo-js/package.json`, "utf8")).version ?? lib; } catch {}
      return { version: String(pj?.version ?? "1.0.0"), library: `zapo-js${lib ? " " + lib : ""}` };
    } catch {
      return { version: "1.0.0", library: "zapo-js" };
    }
  })());
}

const runtimeLabel = (): string => {
  const g: any = globalThis;
  return g.Bun?.version ? `Bun ${g.Bun.version}` : `Node ${process.versions.node}`;
};

async function buildMenuData(m: any, mode: "main" | "category" | "all", category?: string, prefix = "."): Promise<{ text: string; preset: any; sections: any }> {
  const cfg = await loadMenuConfig();
  const presets = await getPresets();
  const preset = presets[cfg.active] ?? presets[7];
  await loadSettings();
  const meta = await botMeta();

  const base = buildBaseContent({
    greeting: getGreetingText(),
    botName: getConfig().bot.name,
    library: meta.library,
    version: meta.version,
    runtime: runtimeLabel(),
    uptime: formatUptime(processUptimeSeconds()),
    totalFitur: getAllCommands().length,
    database: "SQLite",
    moduleType: "ESM",
    status: getSettings().mode === "self" ? "Self" : "Public",
  });

  let text: string;
  let sections: any = buildCategorySections(prefix);
  if (mode === "all") text = buildAllMenuText(base, prefix);
  else if (mode === "category" && category) text = `${base}\n\n╭─❖ *${category.toUpperCase()}*\n${getCategoryCommands(category, prefix)}\n╰───────✦`;
  // preset dengan tombol: daftar wilayah ada di tombol (teks singkat). Tanpa tombol: daftar wilayah tetap ditulis di teks.
  else text = presetHasButtons(preset.type) ? base : base + buildCategoryListText(prefix);

  return { text, preset, sections };
}

export async function sendMenu(client: any, m: any, opts: { mode?: "main" | "category" | "all"; category?: string; prefix?: string } = {}): Promise<any> {
  const mode = opts.mode ?? "main";
  const prefix = opts.prefix ?? m.prefix ?? ".";
  const { text, preset } = await buildMenuData(m, mode, opts.category, prefix);

  let quoted: any = null;
  try {
    const fq = await loadFakeQuotedConfig();
    if (!isPolosQuoted(fq)) {
      quoted = await buildFakeQuotedFromConfig({ text: text.slice(0, 60), jid: m.sender, name: m.pushName }, client);
    }
  } catch {}

  const sent = await sendByType(client, m.chat, text, preset, quoted, prefix, mode);
  if (mode === "main") {
    sendMenuAudio(client, m.chat, quoted ?? m).catch(() => {});
  }
  return sent;
}

export { loadMenuConfig, buildMenuData };