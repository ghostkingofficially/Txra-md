// src/setmenu/helpers.ts — Teyvat Guild themed menu text. Decorations use text symbols (✦ ✧ ❖ ◈), not emoji.
import { getAllCommands, getCommandsByCategory, commandCount } from "../../helpers/handling-plugins.ts";
import type { Command } from "../../helpers/handling-plugins.ts";

/** Badge behind command name. */
export function getBadge(cmd: Command): string {
  if ((cmd as any).isOwner || (cmd as any).ownerOnly) return " ✪";
  if ((cmd as any).isAdmin || (cmd as any).adminOnly) return " ◆";
  if ((cmd as any).isPremium || (cmd as any).premium) return " ★";
  const lim = (cmd as any).isLimit ?? (cmd as any).limit;
  // default limited = true when not defined (parity bocchi)
  if (lim === false || (cmd as any).isNoLimit === true) return "";
  return " ◈";
}

const GLYPHS = ["✦", "✧", "❖", "✺", "❂", "✶", "❈"];
const glyphOf = (i: number) => GLYPHS[i % GLYPHS.length];
const LINE = "✦━━━━━━━━━━━━━━━━━━✦";
const LEGEND = "✪ Owner  ◆ Admin  ★ Premium  ◈ Limit";

export function getCategoryList(): string[] {
  const by = getCommandsByCategory();
  return Object.keys(by).sort();
}

export function countTotalFitur(): number { return commandCount(); }

/** Command list content for one category (line "│ ✧ .name") — header/footer handled by caller. */
export function getCategoryCommands(category: string, prefix = "."): string {
  const by = getCommandsByCategory();
  const list = by[category] ?? [];
  if (list.length === 0) return "│ (empty)";
  return list.map((c) => `│ ✧ ${prefix}${c.name}${getBadge(c)}`).join("\n");
}

export function getAllCommandsWithLabels(prefix = "."): string {
  const by = getCommandsByCategory();
  let out = "";
  let i = 0;
  for (const [cat, list] of Object.entries(by)) {
    out += `\n╭─${glyphOf(i++)} *${cat.toUpperCase()}*\n`;
    for (const cmd of list) out += `│ ✧ ${prefix}${cmd.name}${getBadge(cmd)}\n`;
    out += "╰───────✦\n";
  }
  return out.trim();
}

export function buildCategorySections(prefix = "."): Array<{ title: string; highlight_label: string; rows: Array<{ header: string; title: string; description: string; id: string }> }> {
  const cats = getCategoryList();
  const by = getCommandsByCategory();
  const rows = cats.map((cat) => {
    const has = (by[cat]?.length ?? 0) > 0;
    return { header: "", title: cat.toUpperCase(), description: has ? `Explore ${cat} region` : "Empty region", id: has ? `${prefix}menu ${cat}` : "#" };
  });
  rows.push(
    { header: "", title: "✦ ALLMENU", description: "Open the entire Teyvat map", id: `${prefix}allmenu` },
    { header: "", title: "✧ LISTMENU", description: "Back to main menu", id: `${prefix}menu` },
  );
  return [{ title: "✦ Select Region", highlight_label: "", rows }];
}

/** List of regions (categories) in text — used for preset WITHOUT buttons. */
export function buildCategoryListText(prefix = "."): string {
  const cats = getCategoryList();
  let out = "\n\n╭─❖ 𝗥𝗘𝗚𝗜𝗢𝗡𝗦\n";
  cats.forEach((cat, i) => { out += `│ ${glyphOf(i)} ${cat.toUpperCase()}\n`; });
  out += "╰───────✦\n";
  out += `\n✧ ${prefix}menu <region>  ✧ ${prefix}allmenu`;
  return out;
}

export function buildAllMenuText(base: string, prefix = "."): string {
  return `${base}\n\n${getAllCommandsWithLabels(prefix)}`;
}

/** Bot info for menu header — all from bot data, no user data. */
export interface BotInfo {
  greeting: string;      // time-based greeting (lib/func/dateTime)
  botName: string;
  library: string;       // e.g. "zapo-js 1.9.0"
  version: string;       // bot version (package.json)
  runtime: string;       // e.g. "Bun 1.2.0"
  uptime: string;        // HH:MM:SS (lib/func/dateTime)
  totalFitur: number;
  database: string;
  moduleType: string;    // ESM / CJS
  status: string;        // Public / Self
}

/** Teyvat Guild style menu, plain text view: only bot info + usage instructions. */
export function buildBaseContent(o: BotInfo): string {
  return `${LINE}
  > 𝐓 𝐗 𝐑 𝐀 - 𝐌 𝐃 𝐆𝐄𝐍 𝟐
${LINE}

❖ ${o.greeting}, Traveler.
  Welcome to *${o.botName}* ✧ the adventure begins.

╭─❖ 𝗕𝗢𝗧 𝗜𝗡𝗙𝗢
│ ✦ Name     : *${o.botName}*
│ ✧ Library  : *${o.library}*
│ ✧ Version  : *${o.version}*
│ ✧ Runtime  : *${o.runtime}*
│ ✧ Uptime   : *${o.uptime}*
│ ✧ Features : *${o.totalFitur}*
│ ✧ Database : *${o.database}*
│ ✧ Type     : *${o.moduleType}*
│ ✧ Status   : *${o.status}*
╰───────✦

╭─❖ 𝗜𝗡𝗦𝗧𝗥𝗨𝗖𝗧𝗜𝗢𝗡𝗦
│ ✧ This menu is grouped by region.
│ ✧ Type the command listed below
│   to open the skill list.
│ ✧ The mark behind the command = usage requirement.
╰───────✦

${LEGEND}`;
}