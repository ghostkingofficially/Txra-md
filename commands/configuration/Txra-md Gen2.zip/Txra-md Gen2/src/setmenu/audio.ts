// src/setmenu/audio.ts — audio menu (voice note) dari URL. Tidak menyimpan media mentah di disk:
//   URL → unduh → toPtt (lib/func/converter, ogg/opus) → upload SEKALI (cache 6 jam, sama dengan video/thumbnail) → kirim sebagai VN.
// Sumber: .setaudiomenu <url>  →  bot.audio di config.json. Kosong = menu tanpa audio.
import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { diskGet, diskSet } from "../../helpers/utils/disk-cache.ts";
import { getConfig } from "../../connector/config.ts";
import { Toolkit } from "../../helpers/utils/toolkit.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay } from "../../helpers/utils/button-messages/transport.ts";
import { toPtt } from "../../lib/func/converter.ts";
import { cachedUpload } from "../setthumblarge/cache.ts";
import { getMenuAudio } from "./store.ts";

type Obj = Record<string, any>;

export const MAX_AUDIO_BYTES = 15 * 1024 * 1024;
export const isAudioUrl = (s: string) => /^https?:\/\/\S+$/i.test(s);

/** Sumber audio efektif: .setaudiomenu → bot.audio di config.json. "" = belum ada. */
export async function menuAudioSource(): Promise<string> {
  const stored = await getMenuAudio();
  if (stored) return stored;
  try { return String((getConfig() as any).bot?.audio ?? "").trim(); } catch { return ""; }
}

/** Durasi ogg/opus (detik, dibulatkan ke atas) dari granule position halaman OggS terakhir. 0 = tidak terbaca. */
export function oggOpusSeconds(b: Uint8Array): number {
  const buf = Buffer.from(b.buffer, b.byteOffset, b.byteLength);
  const i = buf.lastIndexOf("OggS");
  if (i < 0 || i + 14 > buf.length) return 0;
  const gp = Number(buf.readBigUInt64LE(i + 6));
  return gp > 0 ? Math.max(1, Math.ceil(gp / 48000)) : 0;
}

/** Ogg Opus MONO? (sudah berbentuk VN WhatsApp → tidak perlu ffmpeg sama sekali). Header "OpusHead": byte ke-9 = jumlah channel. */
export function isMonoOggOpus(b: Uint8Array): boolean {
  if (b.length < 64 || b[0] !== 0x4f || b[1] !== 0x67 || b[2] !== 0x67 || b[3] !== 0x53) return false; // "OggS"
  const buf = Buffer.from(b.buffer, b.byteOffset, Math.min(b.length, 256));
  const i = buf.indexOf("OpusHead");
  return i >= 0 && i + 10 <= buf.length && buf[i + 9] === 1;
}

const VN_DISK_TTL_MS = 7 * 24 * 3600_000;
const vnKey = (url: string) => createHash("sha1").update(`vn-v1|${url}`).digest("hex");

/**
 * Unduh URL audio lalu ubah ke VN (ogg/opus). Melempar error yang jelas kalau gagal.
 * Urutan terhemat: cache disk (tanpa unduh, tanpa ffmpeg) → sumber sudah ogg/opus mono (dipakai apa adanya) → ffmpeg.
 * `fresh: true` melewati cache disk (dipakai saat .setaudiomenu memvalidasi URL baru).
 */
export async function renderMenuVoiceNote(url: string, opts: { fresh?: boolean } = {}): Promise<{ bytes: Uint8Array; seconds: number }> {
  if (!isAudioUrl(url)) throw new Error("sumber audio harus berupa URL http/https");
  const key = vnKey(url);
  if (!opts.fresh) {
    const hit = await diskGet("vn", key, VN_DISK_TTL_MS);
    if (hit?.length) return { bytes: new Uint8Array(hit), seconds: oggOpusSeconds(hit) };
  }
  const raw = await Toolkit.fetchBuffer(url, { timeout: 60_000, maxContentLength: MAX_AUDIO_BYTES, maxBodyLength: MAX_AUDIO_BYTES }, { silent: false });
  if (!raw?.length) throw new Error("audio kosong / gagal diunduh");
  if (raw.length > MAX_AUDIO_BYTES) throw new Error(`audio terlalu besar (${(raw.length / 1048576).toFixed(1)} MB, maks ${MAX_AUDIO_BYTES / 1048576} MB)`);
  const bytes = isMonoOggOpus(raw) ? new Uint8Array(raw) : new Uint8Array(await toPtt(raw)); // ffmpeg gagal (bukan audio) → melempar
  if (!bytes.length) throw new Error("konversi ke VN menghasilkan file kosong — pastikan URL berisi audio");
  diskSet("vn", key, bytes);
  return { bytes, seconds: oggOpusSeconds(bytes) };
}

/** Upload VN SEKALI lalu dipakai ulang → { audioMessage }. null = audio belum diatur. */
export async function uploadMenuAudio(client: any): Promise<Obj | null> {
  const url = await menuAudioSource();
  if (!url) return null;
  return await cachedUpload<Obj>(`menu-audio-v1|${url}`, async () => {
    const { bytes, seconds } = await renderMenuVoiceNote(url);
    return await prepareMedia(client, "audio", bytes, {
      mimetype: "audio/ogg; codecs=opus", ptt: true, ...(seconds ? { seconds } : {}),
    }) as Obj;
  });
}

/** Kirim audio menu (VN). Tidak pernah melempar — audio hanya pemanis, menu tetap harus terkirim. */
export async function sendMenuAudio(client: any, jid: string, quoted?: any): Promise<boolean> {
  try {
    const media = await uploadMenuAudio(client);
    if (!media) return false;
    const id = newMessageId();
    const wa = buildWAMessage(jid, { audioMessage: { ...media.audioMessage, ptt: true } }, { messageId: id, quoted: quoted ?? undefined });
    await relay(client, jid, wa.message, { messageId: id });
    return true;
  } catch (e) {
    console.warn("[setmenu] audio gagal:", (e as Error).message);
    return false;
  }
}