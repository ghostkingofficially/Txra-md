// src/setmenu/senders.ts — 13 preset menu via Zapo.
// Preset 1, 2, 4, 5 : Button / extendedText (tidak diubah).
// Preset 3, 6, 7–13 : disusun LANGSUNG (header produk / video / lokasi + tombol native flow), meniru pengirim yang terbukti jalan
//                     di src/setthumblarge/senders.ts dan menu Baileys lama — TIDAK lewat Button.setMedia (yang meng-upload ulang media jadi).
import { getThumb, getThumbForSource } from "../setthumblarge/thumb.ts";
import { getConfig } from "../../connector/config.ts";
import { expiresIn, HOUR_MS } from "../../lib/func/dateTime.ts";
import { Button } from "../../helpers/utils/button-messages/button.ts";
import { ButtonV2 } from "../../helpers/utils/button-messages/buttonV2.ts";
import { sendMotionPhoto as sendMotionPhotoMsg } from "../../helpers/utils/button-messages/motion-photo.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay } from "../../helpers/utils/button-messages/transport.ts";
import { getAdditionalNodes } from "../../helpers/utils/additional-nodes.ts";
import { buildCategorySections } from "./helpers.ts";
import { cachedUpload } from "../setthumblarge/cache.ts";
import { NoVideoError, uploadMenuVideo } from "./video.ts";
import type { MenuPreset } from "./types.ts";

type Obj = Record<string, any>;

const LTO = () => ({
  text: "✦ Limited Offer",
  url: "",
  copy_code: "",
  expiration_time: expiresIn(HOUR_MS),
});

function botThumb(): string {
  try { return String(getConfig().bot?.thumbnail ?? ""); } catch { return ""; }
}
function botName(): string {
  try { return String(getConfig().bot?.name ?? "Bocchi"); } catch { return "Bocchi"; }
}
function botFooter(): string {
  try { return String(getConfig().bot?.footer ?? ""); } catch { return ""; }
}

async function thumbBytes(source: string, variant: "fake" | "preview" | "inline" | "image" | "location" = "preview"): Promise<Uint8Array | null> {
  if (!source) return null;
  const t = await getThumbForSource(variant as any, source);
  return t ? new Uint8Array(t.jpeg) : null;
}
async function thumbLargeBytes(source: string): Promise<{ inline: Uint8Array | null; previewPath?: any }> {
  if (!source) return { inline: null };
  const inline = await thumbBytes(source, "inline");
  return { inline };
}

function sectionsFor(prefix: string) { return buildCategorySections(prefix); }

// single_select + quick_reply All Menu (main) atau Back Menu (category/all)
// mode null = auto: dianggap main (All Menu); biar caller bisa override
function addMenuButtons(b: Button, prefix: string, mode: string) {
  const secs = sectionsFor(prefix);
  b.addButton("single_select", { title: "✦ Lihat Menu", sections: secs });
  if (mode === "category" || mode === "all") {
    b.addButton("quick_reply", { display_text: "✧ Back Menu", id: `${prefix}menu` });
  } else {
    b.addButton("quick_reply", { display_text: "✦ All Menu", id: `${prefix}allmenu` });
  }
}

async function put(client: any, jid: string, content: Obj, quoted: any, nodes: readonly any[] = []) {
  const wa = buildWAMessage(jid, content, { messageId: newMessageId(), quoted: quoted ?? undefined });
  return await relay(client, jid, wa.message, { messageId: wa.key.id, additionalNodes: nodes as any });
}

// ── 1) PLAIN ───────────────────────────────────────────────────────────────
export async function sendPlain(client: any, jid: string, text: string, quoted: any) {
  try {
    return await put(client, jid, { extendedTextMessage: { text } }, quoted);
  } catch (e) {
    console.warn("[setmenu] plain gagal:", (e as Error).message);
    const wa = buildWAMessage(jid, { extendedTextMessage: { text } } as any, { messageId: newMessageId() });
    return await relay(client, jid, wa.message, { messageId: wa.key.id });
  }
}

/** Upload thumbnail link-preview 800x450 (cache 6 jam). null = tidak ada gambar. Dipakai pengirim + prewarm. */
async function uploadMenuPreview(client: any, src: string): Promise<Obj | null> {
  const big = await getThumb("preview", src);
  if (!big) return null;
  return await cachedUpload<Obj>(`menu-preview|${big.key}`, async () => {
    const r: any = await (client as any).message.upload(big.jpeg, { type: "thumbnail-link", mimetype: "image/jpeg" });
    if (!r?.directPath || !r?.mediaKey) throw new Error("upload incomplete");
    return { directPath: r.directPath, mediaKey: r.mediaKey, fileSha256: r.fileSha256 ?? r.sha256, fileEncSha256: r.fileEncSha256 ?? r.encSha256, mediaKeyTimestamp: r.mediaKeyTimestamp ?? Math.floor(Date.now() / 1000), width: big.width, height: big.height };
  });
}

// ── 2) EXTENDED TEXT (link preview BESAR) ──────────────────────────────────
// Mirip setthumblarge: pakai preview 800x450 yang diupload sebagai thumbnail-link + inline kecil
export async function sendExtendedText(client: any, jid: string, text: string, preset: MenuPreset, quoted: any) {
  try {
    const src = preset.thumbnail ?? preset.image ?? botThumb();
    const url = preset.sourceUrl ?? preset.matchedText ?? getConfig().bot?.url ?? "https://wa.me";
    const safe = (() => { try { const u = new URL(String(url)); return /^https?:$/.test(u.protocol) ? String(url) : "https://wa.me"; } catch { return "https://wa.me"; }})();
    // inline kecil + upload preview besar (cache 6 jam) seperti setthumblarge
    const { getThumb } = await import("../setthumblarge/thumb.ts");
    const { cachedUpload } = await import("../setthumblarge/cache.ts");
    const inline = src ? await thumbBytes(src, "inline") : null;
    let up: any = null;
    try { up = await uploadMenuPreview(client, src); } catch {}
    return await put(client, jid, {
      extendedTextMessage: {
        text: `${safe}\n\n${text}`,
        matchedText: safe,
        title: preset.title ?? botName(),
        description: preset.description ?? botFooter(),
        previewType: 0,
        renderLargerThumbnail: true,
        ...(inline ? { jpegThumbnail: inline } : {}),
        ...(up ? { thumbnailDirectPath: up.directPath, thumbnailSha256: up.fileSha256, thumbnailEncSha256: up.fileEncSha256, mediaKey: up.mediaKey, mediaKeyTimestamp: up.mediaKeyTimestamp, thumbnailWidth: up.width, thumbnailHeight: up.height } : {}),
      },
    }, quoted);
  } catch (e) {
    console.warn("[setmenu] extendedText fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 3) LOCATION — ButtonV2 (buttonsMessage, headerType 6 + locationMessage) ──
// Thumbnail 300x300 dari cache setthumblarge ("location"); tombol: list kategori (native flow single_select) + quick reply.
export async function sendLocation(client: any, jid: string, text: string, preset: MenuPreset, quoted: any, prefix: string, mode = "main") {
  try {
    const b = new ButtonV2(client);
    b.setTitle(botName());
    b.setSubtitle(preset.address ?? "");
    b.setBody(text);
    b.setFooter(botFooter());
    const thumb = await getThumb("location", presetImage(preset));
    if (thumb) b.setRawThumbnail(new Uint8Array(thumb.jpeg));
    const back = mode === "category" || mode === "all";
    b.addNativeFlow("single_select", { title: "✦ Lihat Menu", sections: sectionsFor(prefix) });
    b.addButton(back ? "✧ Back Menu" : "✦ All Menu", back ? `${prefix}menu` : `${prefix}allmenu`);
    return await b.send(jid, { flowType: "mixed", quoted: quoted ? { key: quoted.key, message: quoted.message } : undefined });
  } catch (e) {
    console.warn("[setmenu] location fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 4) SPLIT BUTTON (location + split 2-3 tombol dipendekkan) ──────────────
export async function sendSplitButton(client: any, jid: string, text: string, _preset: MenuPreset, quoted: any, prefix: string, mode = "main") {
  try {
    const b = new Button(client);
    b.setTitle(text.slice(0, 80));
    b.setSubtitle(_preset.address ?? "");
    b.setBody(text);
    b.setFooter(botFooter());
    const thumb = botThumb();
    if (thumb) b.setLocationHeader(thumb);
    const secs = sectionsFor(prefix);
    b.addButton("single_select", { title: "✦ Lihat Menu", sections: secs });
    b.addButton("quick_reply", { display_text: mode === "category" || mode === "all" ? "✧ Back Menu" : "✦ All Menu", id: mode === "category" || mode === "all" ? `${prefix}menu` : `${prefix}allmenu` });
    // tambah satu quick_reply lagi biar split terpicu (minimal 2)
    if (!quoted) {} // no-op jaga tree-shake
    b.split({ blank: false });
    return await b.run(jid, client, quoted ? { key: quoted.key, message: quoted.message } as any : undefined, { flowType: "mixed" as any });
  } catch (e) {
    console.warn("[setmenu] splitbutton fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// Pembangun pesan interaktif (tanpa Button) — dipakai preset 3, 6, 7–13
// ═════════════════════════════════════════════════════════════════════════════
const nb = (name: string, params: Obj) => ({ name, buttonParamsJson: JSON.stringify(params) });
const SPACER = { name: "", buttonParamsJson: "{}" };

/** Tombol menu: daftar kategori (single_select) + quick reply All Menu (menu utama) / Back Menu (kategori & allmenu). */
function menuNativeButtons(prefix: string, mode: string): Obj[] {
  const back = mode === "category" || mode === "all";
  return [
    nb("single_select", { title: "✦ List Menu", icon: "DOCUMENT", sections: sectionsFor(prefix) }),
    nb("quick_reply", back
      ? { display_text: "✧ Back Menu", id: `${prefix}menu`, icon: "DEFAULT" }
      : { display_text: "✦ All Menu", id: `${prefix}allmenu`, icon: "REVIEW" }),
  ];
}

/** Parameter bottom sheet: limit 0 = SEMUA tombol (list + quick reply) masuk ke dalam sheet. */
const bottomSheetParams = () => ({ in_thread_buttons_limit: 0, list_title: "✦ Teyvat Guild ✦", button_title: "✦ Buka Peta Teyvat" });

const interactive = (header: Obj, o: { body?: string; footer?: string; buttons: Obj[]; params?: Obj; contextInfo?: Obj }) => ({
  interactiveMessage: {
    header,
    body: { text: o.body ?? " " },
    footer: { text: o.footer ?? "" },
    nativeFlowMessage: { buttons: o.buttons, messageParamsJson: JSON.stringify(o.params ?? {}) },
    ...(o.contextInfo ? { contextInfo: o.contextInfo } : {}),
  },
});

/** Nomor bot tanpa bagian device ("628..:12@s.whatsapp.net" → "628..@s.whatsapp.net"). */
function ownerJid(client: any): string {
  try {
    const raw = String(client?.getCredentials?.()?.meJid ?? "");
    const user = raw.split("@")[0].split(":")[0];
    return user ? `${user}@s.whatsapp.net` : "0@s.whatsapp.net";
  } catch { return "0@s.whatsapp.net"; }
}

/** Sumber gambar preset (opsional) — kalau kosong, getThumb memakai .setthumb default / bot.thumbnail. */
const presetImage = (p: MenuPreset): string | undefined => (p.thumbnail || p.image || undefined);

/** Gambar produk / foto di-upload SEKALI (cache yang sama dengan setthumblarge). */
async function imageMedia(client: any, preset: MenuPreset): Promise<Obj> {
  const thumb = await getThumb("image", presetImage(preset));
  if (!thumb) throw new Error("thumbnail kosong — atur .setthumb default <url> atau isi bot.thumbnail di config.json");
  return await cachedUpload<Obj>(`img|${thumb.key}`, () => prepareMedia(client, "image", thumb.jpeg, { mimetype: "image/jpeg" }) as Promise<Obj>);
}

/** Header "product message" (kartu produk dengan thumbnail) — sama dengan setthumblarge/sendProduct. */
async function productHeader(client: any, preset: MenuPreset): Promise<Obj> {
  const media = await imageMedia(client, preset);
  return {
    hasMediaAttachment: true,
    productMessage: {
      product: {
        productImage: media.imageMessage,
        productId: "bocchi-" + Date.now(),
        title: "Menu",
        description: " ",
        retailerId: botName(),
        productImageCount: 1,
      },
      businessOwnerJid: ownerJid(client),
    },
  };
}

/** Header video GIF: video MP4 sungguhan + gifPlayback. width/height/seconds + jpegThumbnail (rasio video) sudah ikut dari uploadMenuVideo. */
async function videoHeader(client: any, preset: MenuPreset): Promise<Obj> {
  const media = await uploadMenuVideo(client, preset);
  return { hasMediaAttachment: true, videoMessage: { ...media.videoMessage, gifPlayback: true } };
}

// ── 3) INTERACTIVE PRODUCT — kartu produk + list menu + quick reply ─────────
export async function sendInteractive(client: any, jid: string, text: string, preset: MenuPreset, quoted: any, prefix: string, mode = "main") {
  try {
    const header = await productHeader(client, preset);
    return await put(client, jid, interactive(header, { body: " ", footer: text, buttons: menuNativeButtons(prefix, mode) }), quoted, getAdditionalNodes("mixed"));
  } catch (e) {
    console.warn("[setmenu] interactive product fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 6) BOTTOM SHEET — kartu produk + sheet berisi list menu & quick reply ───
export async function sendBottomSheet(client: any, jid: string, text: string, preset: MenuPreset, quoted: any, prefix: string, mode = "main") {
  try {
    const header = await productHeader(client, preset);
    return await put(client, jid, interactive(header, {
      body: " ", footer: text, buttons: menuNativeButtons(prefix, mode), params: { bottom_sheet: bottomSheetParams() },
    }), quoted, getAdditionalNodes("mixed"));
  } catch (e) {
    console.warn("[setmenu] bottomsheet fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 7) MOTION PHOTO — foto + caption, lalu video pendampingnya (builder: helpers/utils/button-messages/motion-photo.ts) ──
// Video belum diatur / gagal → tetap terkirim sebagai foto + caption biasa.
export async function sendMotionPhoto(client: any, jid: string, text: string, preset: MenuPreset, quoted: any, _prefix: string, _mode = "main") {
  try {
    const imageMessage = (await imageMedia(client, preset)).imageMessage;
    let videoMessage: Obj | undefined;
    try { videoMessage = (await uploadMenuVideo(client, preset)).videoMessage; }
    catch (e) { console.warn(`[setmenu] motion photo tanpa video (${(e as Error).message}) — dikirim sebagai foto biasa`); }
    return (await sendMotionPhotoMsg(client, jid, { imageMessage, videoMessage, caption: text, quoted })).photo;
  } catch (e) {
    console.warn("[setmenu] motionphoto fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 8–11) VIDEO GIF — gif | button | bottomsheet | split ────────────────────
export async function sendVideoMenu(
  client: any, jid: string, text: string, preset: MenuPreset, quoted: any, prefix: string, mode = "main",
  variant: "gif" | "button" | "bottomsheet" | "split" = "gif",
) {
  try {
    const header = await videoHeader(client, preset);
    let buttons: Obj[] = [];
    let params: Obj = { limited_time_offer: LTO() };
    if (variant === "button") buttons = menuNativeButtons(prefix, mode);
    else if (variant === "split") buttons = [SPACER, ...menuNativeButtons(prefix, mode)];
    else if (variant === "bottomsheet") {
      buttons = menuNativeButtons(prefix, mode);
      params = { bottom_sheet: bottomSheetParams(), limited_time_offer: LTO() };
    }
    return await put(client, jid, interactive(header, { body: " ", footer: text, buttons, params }), quoted, getAdditionalNodes("mixed"));
  } catch (e) {
    console.warn(`[setmenu] video (${variant}) fallback plain:`, e instanceof NoVideoError ? e.message : (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

// ── 12–13) CATALOG — header lokasi (thumbnail 300x300) + tombol catalog_message ─
// Persis setthumblarge/sendCatalog: hasMediaAttachment TRUE, tanpa name/address (kalau tidak, gambar tidak muncul),
// node <biz native_flow_name="catalog_message">. Wajib zapo-js yang sudah ditambal (`bun run patch`).
export async function sendCatalog(client: any, jid: string, text: string, preset: MenuPreset, quoted: any, prefix: string, mode = "main", withButtons = false) {
  try {
    const thumb = await getThumb("location", presetImage(preset));
    if (!thumb) console.warn("[setmenu] catalog: thumbnail location kosong — pesan terkirim tanpa gambar (atur .setthumb location <url>)");
    const header = {
      locationMessage: { degreesLatitude: 0, degreesLongitude: 0, ...(thumb ? { jpegThumbnail: thumb.jpeg } : {}) },
      hasMediaAttachment: true,
    };
    const buttons: Obj[] = [nb("catalog_message", {}), ...(withButtons ? [SPACER, ...menuNativeButtons(prefix, mode)] : [])];
    return await put(client, jid, interactive(header, {
      body: " ", footer: text, buttons, params: { limited_time_offer: LTO() },
      contextInfo: { participant: jid, mentionedJid: ["0@s.whatsapp.net"] },
    }), quoted, getAdditionalNodes("catalog_message"));
  } catch (e) {
    console.warn("[setmenu] catalog fallback plain:", (e as Error).message);
    return await sendPlain(client, jid, text, quoted);
  }
}

const MAP: Record<string, (c: any, j: string, t: string, p: MenuPreset, q: any, pf: string, mode?: string) => Promise<any>> = {
  plain: (c, j, t, _p, q) => sendPlain(c, j, t, q),
  extendedTextMessage: (c, j, t, p, q) => sendExtendedText(c, j, t, p, q),
  location: (c, j, t, p, q, pf, mode) => sendLocation(c, j, t, p, q, pf, mode),
  splitbutton: (c, j, t, p, q, pf, mode) => sendSplitButton(c, j, t, p, q, pf, mode),
  interactive: (c, j, t, p, q, pf, mode) => sendInteractive(c, j, t, p, q, pf, mode),
  bottomsheet: (c, j, t, p, q, pf, mode) => sendBottomSheet(c, j, t, p, q, pf, mode),
  motionphoto: (c, j, t, p, q, pf, mode) => sendMotionPhoto(c, j, t, p, q, pf, mode),
  videogif: (c, j, t, p, q, pf, mode) => sendVideoMenu(c, j, t, p, q, pf, mode, "gif"),
  videobutton: (c, j, t, p, q, pf, mode) => sendVideoMenu(c, j, t, p, q, pf, mode, "button"),
  videobottomsheet: (c, j, t, p, q, pf, mode) => sendVideoMenu(c, j, t, p, q, pf, mode, "bottomsheet"),
  videosplit: (c, j, t, p, q, pf, mode) => sendVideoMenu(c, j, t, p, q, pf, mode, "split"),
  catalog: (c, j, t, p, q, pf, mode) => sendCatalog(c, j, t, p, q, pf, mode, false),
  catalogbutton: (c, j, t, p, q, pf, mode) => sendCatalog(c, j, t, p, q, pf, mode, true),
};

export async function sendByType(
  client: any,
  jid: string,
  text: string,
  preset: MenuPreset,
  quoted: any,
  prefix: string,
  mode = "main",
): Promise<any> {
  const fn = MAP[preset.type] ?? sendPlain;
  // MAP ada yang 6 arg, ada yang 7 arg (mode). Kirim 7 arg aman — yang ignore mode tetap jalan.
  return await (fn as any)(client, jid, text, preset, quoted, prefix, mode);
}

/** Pemanasan satu preset: semua thumbnail + upload yang akan dipakai pengirimnya, supaya menu pertama langsung cepat. Tidak melempar. */
export async function warmMenuPreset(client: any, preset: MenuPreset): Promise<void> {
  const step = async (fn: () => Promise<unknown>) => { try { await fn(); } catch { /* sumber belum diatur / gagal → pengirim punya fallback sendiri */ } };
  switch (preset.type) {
    case "extendedTextMessage": {
      const src = preset.thumbnail ?? preset.image ?? botThumb();
      if (src) { await step(() => thumbBytes(src, "inline")); await step(() => uploadMenuPreview(client, src)); }
      break;
    }
    case "location": case "splitbutton": case "catalog": case "catalogbutton":
      await step(() => getThumb("location", presetImage(preset)));
      break;
    case "interactive": case "bottomsheet": case "motionphoto":
      await step(() => imageMedia(client, preset));
      if (preset.type === "motionphoto") await step(() => uploadMenuVideo(client, preset));
      break;
    case "videogif": case "videobutton": case "videobottomsheet": case "videosplit":
      await step(() => uploadMenuVideo(client, preset));
      break;
  }
}
