export type MenuType =
  | "extendedTextMessage"
  | "location"
  | "interactive"
  | "splitbutton"
  | "plain"
  | "bottomsheet"
  | "motionphoto"
  | "videogif"
  | "videobutton"
  | "videobottomsheet"
  | "videosplit"
  | "catalog"
  | "catalogbutton";

export interface MenuPreset {
  name: string;
  type: MenuType;
  [k: string]: any;
}

export interface MenuConfig {
  active: number;
  presets: Record<string, Record<string, any>>;
  /** Sumber video menu (URL mp4) untuk preset 7–11. Kosong = belum diatur (.setmenu video <url>). */
  video: string;
  /** Sumber audio menu (URL http/https). Kosong = tanpa audio (.setaudiomenu <url>). */
  audio: string;
}