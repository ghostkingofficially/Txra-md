// src/setmenu/video.ts — sumber + upload video untuk menu preset 7–11.
// Dulu preset video memakai bot.thumbnail (sebuah GAMBAR .jpg) sebagai "video" → WhatsApp: "versi tidak mendukung".
// Sekarang video harus MP4 sungguhan, diatur lewat `.setmenu video <url>` (atau reply video), dan di-upload sekali lalu di-cache.
import { Buffer } from "node:buffer";
import { getConfig } from "../../connector/config.ts";
import { Toolkit } from "../../helpers/utils/toolkit.ts";
import { processImage } from "../../lib/func/image.ts";
import { prepareMedia } from "../../helpers/utils/button-messages/transport.ts";
import { readMp4Info, type Mp4Info } from "../../helpers/utils/mp4.ts";
import { getThumb } from "../setthumblarge/thumb.ts";
import { cachedUpload } from "../setthumblarge/cache.ts";
import { getMenuVideo } from "./store.ts";

type Obj = Record<string, any>;

export class NoVideoError extends Error {
  constructor() { super("video menu belum diatur — pakai .setmenu video <url mp4> atau reply sebuah video"); }
}

const isUrl = (s: string) => /^https?:\/\//i.test(s);

/** MP4/MOV punya tanda "ftyp" di byte 4–7. */
export const isMp4 = (b: Uint8Array): boolean =>
  b.length > 12 && b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70;

/** Sumber video efektif (URL): preset.video → .setmenu video → bot.video di config.json. "" = belum ada. */
export async function menuVideoSource(preset?: Obj): Promise<string> {
  const own = typeof preset?.video === "string" ? preset.video.trim() : "";
  if (own) return own;
  const stored = await getMenuVideo();
  if (stored) return stored;
  try { return String((getConfig() as any).bot?.video ?? "").trim(); } catch { return ""; }
}

/** Unduh video dari URL, lalu pastikan benar-benar MP4. Gagal → melempar error yang jelas. */
export async function readMenuVideo(source: string): Promise<Uint8Array> {
  if (!isUrl(source)) throw new Error("sumber video harus URL http/https (.mp4)");
  const bytes: Uint8Array = await Toolkit.fetchBuffer(source, { timeout: 60_000, maxContentLength: 64 * 1024 * 1024, maxBodyLength: 64 * 1024 * 1024 }, { silent: false });
  if (!bytes?.length) throw new Error("video kosong / gagal diunduh");
  if (!isMp4(bytes)) throw new Error(`sumber video bukan MP4 (${source.slice(0, 60)}) — pakai file .mp4 (H.264), bukan gambar`);
  return bytes;
}

/** Thumbnail JPEG yang MENGIKUTI rasio video (landscape → 320x180). Frame video dulu, fallback ke gambar bot (di-crop ke rasio video).
 *  Penyebab video "berdiri" dulu: jpegThumbnail memakai gambar bot yang portrait + videoMessage tanpa width/height. */
async function videoThumb(bytes: Uint8Array, info: Mp4Info, preset?: Obj): Promise<Uint8Array | null> {
  const w = 320;
  const h = info.width && info.height ? Math.max(1, Math.round((w * info.height) / info.width)) : 180;
  let src: Uint8Array | null = null;
  try {
    const frame = (await Toolkit.getMp4Preview(bytes, { resize: false, silent: true })) as Uint8Array;
    if (frame?.length) src = frame;
  } catch { /* ffmpeg tidak ada / gagal → fallback */ }
  if (!src) {
    const t = await getThumb("image", preset?.thumbnail || preset?.image || undefined).catch(() => null);
    if (t) src = t.jpeg;
  }
  if (!src) return null;
  try {
    return new Uint8Array((await processImage(src, { mode: "cover", width: w, height: h, quality: 60 })).buffer);
  } catch { return null; }
}

/** Upload video SEKALI lalu dipakai ulang (cache 6 jam) → { videoMessage } lengkap dengan width/height/seconds + jpegThumbnail sesuai rasio.
 *  Melempar NoVideoError kalau belum diatur. */
export async function uploadMenuVideo(client: any, preset?: Obj): Promise<Obj> {
  const source = await menuVideoSource(preset);
  if (!source) throw new NoVideoError();
  // "-v2": entri cache lama (tanpa width/height) otomatis tidak dipakai lagi.
  const key = `menu-video-v3|${source}`;
  return await cachedUpload<Obj>(key, async () => {
    const bytes = await readMenuVideo(source);
    const info = readMp4Info(bytes);
    const media = await prepareMedia(client, "video", bytes, {
      mimetype: "video/mp4",
      ...(info.width && info.height ? { width: info.width, height: info.height } : {}),
      ...(info.seconds ? { seconds: info.seconds } : {}),
    }) as Obj;
    const thumb = await videoThumb(bytes, info, preset);
    if (thumb) media.videoMessage.jpegThumbnail = thumb;
    return media;
  });
}
