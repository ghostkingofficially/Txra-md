// src/setmenu/store.ts — db/configuration/setmenu.json + NodeCache (TTL 30s, checkperiod 0)
//   active = nomor preset aktif · presets = ubahan per preset · video = sumber video menu (preset 7–11)
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import NodeCache from "node-cache";
import { PROJECT_ROOT } from "../setthumblarge/store.ts";
import type { MenuConfig } from "./types.ts";
import { emitConfigChange } from "../../helpers/utils/config-events.ts";

const PATH = join(PROJECT_ROOT, "db", "configuration", "setmenu.json");
const CACHE_KEY = "menu:config";
const cache = new NodeCache({ stdTTL: 30, checkperiod: 0, useClones: false });

const DEFAULTS: MenuConfig = { active: 7, presets: {}, video: "", audio: "" };

function normalize(raw: any): MenuConfig {
  return {
    active: Number.isInteger(Number(raw?.active)) && Number(raw.active) >= 1 && Number(raw.active) <= 13 ? Number(raw.active) : DEFAULTS.active,
    presets: raw?.presets && typeof raw.presets === "object" && !Array.isArray(raw.presets) ? raw.presets : {},
    video: typeof raw?.video === "string" ? raw.video.trim() : "",
    audio: typeof raw?.audio === "string" ? raw.audio.trim() : "",
  };
}

export async function loadMenuConfig(force = false): Promise<MenuConfig> {
  if (!force) {
    const hit = cache.get<MenuConfig>(CACHE_KEY);
    if (hit) return hit;
  }
  let cfg: MenuConfig;
  try { cfg = normalize(JSON.parse(await readFile(PATH, "utf8"))); }
  catch { cfg = normalize({}); }
  cache.set(CACHE_KEY, cfg);
  return cfg;
}

async function persist(cfg: MenuConfig): Promise<void> {
  await mkdir(dirname(PATH), { recursive: true });
  const tmp = PATH + ".tmp";
  await writeFile(tmp, JSON.stringify(cfg, null, 2));
  await rename(tmp, PATH);
  cache.set(CACHE_KEY, cfg);
  await emitConfigChange(); // prewarm menyiapkan cache SEKARANG; balasan perintah menunggu sampai hangat (maks. beberapa detik)
}

export async function setActivePreset(n: number): Promise<boolean> {
  if (!Number.isInteger(n) || n < 1 || n > 13) return false;
  const cur = await loadMenuConfig(true);
  const next: MenuConfig = normalize({ ...cur, active: n });
  await persist(next);
  return true;
}

/** Sumber video menu yang tersimpan ("" = belum diatur). */
export async function getMenuVideo(): Promise<string> { return (await loadMenuConfig()).video; }

/** Simpan sumber video (URL mp4). String kosong = hapus. */
export async function setMenuVideo(source: string): Promise<void> {
  if (source && !/^https?:\/\/\S+$/i.test(source)) throw new Error("video harus URL http/https");
  const cur = await loadMenuConfig(true);
  await persist(normalize({ ...cur, video: source }));
}

/** Sumber audio menu yang tersimpan (URL, "" = belum diatur). */
export async function getMenuAudio(): Promise<string> { return (await loadMenuConfig()).audio; }

/** Simpan URL audio menu. String kosong = hapus. */
export async function setMenuAudio(url: string): Promise<void> {
  const cur = await loadMenuConfig(true);
  await persist(normalize({ ...cur, audio: url }));
}

export function invalidateMenuCache(): void { cache.del(CACHE_KEY); }