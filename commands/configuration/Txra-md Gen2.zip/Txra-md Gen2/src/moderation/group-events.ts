import type { WaClient } from "zapo-js";
import { getGroupModerationOptions } from "./index.ts";

function participantJid(participant: any): string {
  return participant?.jid || participant?.phoneJid || participant?.lidJid || "";
}

function participantLabel(participant: any): string {
  const jid = participantJid(participant);
  return participant?.displayName || (jid ? `@${jid.split("@")[0]}` : "member");
}

export function registerGroupEvents(client: WaClient): void {
  client.on("group", async (event: any) => {
    const groupId = event?.groupJid || event?.chatJid || "";
    const action = event?.action;

    if (!groupId || !["add", "remove"].includes(action)) return;

    const options = await getGroupModerationOptions(groupId);
    const enabled = action === "add" ? options.welcome : options.goodbye;
    if (!enabled) return;

    const participants = Array.isArray(event?.participants)
      ? event.participants
      : [];
    const validParticipants = participants.filter((participant: any) => participantJid(participant));
    if (!validParticipants.length) return;

    const mentions = validParticipants.map(participantJid);
    const names = validParticipants
      .map((participant: any) => `@${participantJid(participant).split("@")[0]}`)
      .join(" ");

    const text = action === "add"
      ? `Welcome ${names} to the group.`
      : `Goodbye ${names}.`;

    try {
      await (client as any).message.send(groupId, { text, mentions });
    } catch (error) {
      console.error(
        `[group-events] failed to send ${action} message:`,
        error instanceof Error ? error.message : String(error),
      );
    }
  });
}

export { participantLabel };