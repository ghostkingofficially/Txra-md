import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import type { WaClient } from "zapo-js";
import { isAdmin, isBotAdmin } from "../../lib/group-metadata/index.ts";
import type { SerializedMessage } from "../../lib/serialize/index.ts";
import { log } from "../../connector/logger/index-logging.ts";

export type ModerationOption =
  | "antiaudio"
  | "antidocument"
  | "antiimage"
  | "antilink"
  | "antilinkgroup"
  | "antispam"
  | "antisticker"
  | "antistatus"
  | "antitoxic"
  | "antivideo"
  | "autokick"
  | "goodbye"
  | "welcome";

export interface GroupModerationOptions {
  antiaudio?: boolean;
  antidocument?: boolean;
  antiimage?: boolean;
  antilink?: boolean;
  antilinkgroup?: boolean;
  antispam?: boolean;
  antisticker?: boolean;
  antistatus?: boolean;
  antitoxic?: boolean;
  antivideo?: boolean;
  autokick?: boolean;
  goodbye?: boolean;
  welcome?: boolean;
  maxWarnings?: number;
}

interface ModerationDatabase {
  groups: Record<string, GroupModerationOptions>;
  warnings: Record<string, Record<string, number>>;
}

const DATABASE_PATH = join(process.cwd(), "db", "moderation", "groups.json");
const TOXIC_WORDS_PATH = join(process.cwd(), "db", "moderation", "toxic-words.json");
const SPAM_WINDOW_MS = 5_000;
const SPAM_LIMIT = 5;

const spamTracker = new Map<string, number[]>();
let databaseCache: ModerationDatabase | null = null;
let toxicWordsCache: string[] | null = null;

async function loadDatabase(): Promise<ModerationDatabase> {
  if (databaseCache) return databaseCache;
  try {
    const raw = await readFile(DATABASE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    databaseCache = {
      groups: parsed?.groups ?? {},
      warnings: parsed?.warnings ?? {},
    };
  } catch {
    databaseCache = { groups: {}, warnings: {} };
  }
  return databaseCache;
}

async function saveDatabase(): Promise<void> {
  const database = await loadDatabase();
  await mkdir(dirname(DATABASE_PATH), { recursive: true });
  const temporaryPath = `${DATABASE_PATH}.tmp`;
  await writeFile(temporaryPath, JSON.stringify(database, null, 2), "utf8");
  await rename(temporaryPath, DATABASE_PATH);
}

async function loadToxicWords(): Promise<string[]> {
  if (toxicWordsCache) return toxicWordsCache;
  let loadedWords: string[] = [];
  try {
    const raw = await readFile(TOXIC_WORDS_PATH, "utf8");
    const parsed = JSON.parse(raw);
    loadedWords = Array.isArray(parsed?.words)
      ? parsed.words.map((word: unknown) => String(word).toLowerCase()).filter(Boolean)
      : [];
  } catch {
    loadedWords = [];
  }
  toxicWordsCache = loadedWords;
  return loadedWords;
}

export async function getGroupModerationOptions(groupId: string): Promise<GroupModerationOptions> {
  const database = await loadDatabase();
  return (database.groups[groupId] ??= {});
}

export async function updateGroupModerationOption(
  groupId: string,
  option: ModerationOption,
  value: boolean,
): Promise<GroupModerationOptions> {
  const options = await getGroupModerationOptions(groupId);
  options[option] = value;
  await saveDatabase();
  return options;
}

export async function getGroupWarnings(groupId: string, sender: string): Promise<number> {
  const database = await loadDatabase();
  return database.warnings[groupId]?.[sender] ?? 0;
}

export async function listGroupWarnings(
  groupId: string,
): Promise<Array<{ jid: string; count: number }>> {
  const database = await loadDatabase();
  return Object.entries(database.warnings[groupId] ?? {})
    .map(([jid, count]) => ({ jid, count: Number(count) }))
    .filter((entry) => entry.count > 0)
    .sort((a, b) => b.count - a.count);
}

export async function changeGroupWarning(
  groupId: string,
  sender: string,
  amount: number,
): Promise<number> {
  const database = await loadDatabase();
  const groupWarnings = (database.warnings[groupId] ??= {});
  const next = Math.max(0, (groupWarnings[sender] ?? 0) + amount);
  if (next === 0) delete groupWarnings[sender];
  else groupWarnings[sender] = next;
  await saveDatabase();
  return next;
}

export async function setGroupMaxWarnings(groupId: string, value: number): Promise<number> {
  const options = await getGroupModerationOptions(groupId);
  options.maxWarnings = Math.max(1, Math.floor(value));
  await saveDatabase();
  return options.maxWarnings;
}

async function addWarning(groupId: string, sender: string): Promise<number> {
  const database = await loadDatabase();
  const groupWarnings = (database.warnings[groupId] ??= {});
  groupWarnings[sender] = (groupWarnings[sender] ?? 0) + 1;
  await saveDatabase();
  return groupWarnings[sender];
}

function normalizeText(text: string): string {
  return text.toLowerCase().normalize("NFKC").replace(/[\u200b-\u200d\ufeff]/g, "");
}

function containsAnyLink(text: string): boolean {
  return /(?:https?:\/\/|www\.|wa\.me\/|chat\.whatsapp\.com\/|whatsapp\.com\/)/i.test(text);
}

function containsGroupLink(text: string): boolean {
  return /(?:https?:\/\/)?(?:chat\.whatsapp\.com|wa\.me)\/\S+/i.test(text);
}

function isSpam(groupId: string, sender: string): boolean {
  const key = `${groupId}:${sender}`;
  const now = Date.now();
  const timestamps = (spamTracker.get(key) ?? []).filter((time) => now - time <= SPAM_WINDOW_MS);
  timestamps.push(now);
  spamTracker.set(key, timestamps);
  return timestamps.length >= SPAM_LIMIT;
}

function getMediaOption(message: SerializedMessage): ModerationOption | null {
  const kind = message.media?.kind;
  if (kind === "audio" || kind === "ptt") return "antiaudio";
  if (kind === "document") return "antidocument";
  if (kind === "image") return "antiimage";
  if (kind === "sticker" || kind === "animated_sticker" || kind === "lottie_sticker") return "antisticker";
  if (kind === "video" || kind === "gif" || kind === "ptv") return "antivideo";
  return null;
}

async function deleteMessage(message: SerializedMessage): Promise<boolean> {
  try {
    await message.delete();
    return true;
  } catch (error) {
    log.warn(`[moderation] message deletion failed: ${error instanceof Error ? error.message : String(error)}`);
    return false;
  }
}

async function enforceViolation(
  client: WaClient,
  message: SerializedMessage,
  reason: string,
): Promise<boolean> {
  const groupId = message.chat;
  const sender = message.sender;
  const deleted = await deleteMessage(message);
  const warningCount = await addWarning(groupId, sender);
  const options = await getGroupModerationOptions(groupId);
  const maxWarnings = Math.max(1, Number(options.maxWarnings ?? 3));
  const mention = sender ? `@${sender.split("@")[0]}` : "member";

  if (options.autokick && warningCount >= maxWarnings) {
    try {
      if (await isBotAdmin(client, groupId)) {
        await (client as any).group.removeParticipants(groupId, [sender]);
        await message.reply({
          text: `${reason}\n${mention} was removed after ${warningCount} warnings.`,
          mentions: sender ? [sender] : [],
        });
        return true;
      }
    } catch (error) {
      log.warn(`[moderation] automatic removal failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  await message.reply({
    text: `${reason}\nWarning ${warningCount}/${maxWarnings}.`,
    mentions: sender ? [sender] : [],
  });

  return deleted;
}

export async function moderateIncomingMessage(
  client: WaClient,
  message: SerializedMessage,
): Promise<boolean> {
  if (!message.isGroup || !message.sender || message.fromMe) return false;

  const options = await getGroupModerationOptions(message.chat);
  const botIsAdmin = await isBotAdmin(client, message.chat).catch(() => false);
  if (!botIsAdmin) return false;

  const senderIsAdmin = await isAdmin(client, message.chat, message.sender).catch(() => false);
  if (senderIsAdmin) return false;

  const text = normalizeText(message.text || "");

  if (options.antilink && containsAnyLink(text)) {
    return enforceViolation(client, message, "Links are not allowed in this group.");
  }

  if (options.antilinkgroup && containsGroupLink(text)) {
    return enforceViolation(client, message, "WhatsApp group invitation links are not allowed.");
  }

  if (options.antitoxic && text) {
    const toxicWords = await loadToxicWords();
    const matchedWord = toxicWords.find((word) => text.includes(word));
    if (matchedWord) {
      return enforceViolation(client, message, "This message contains a blocked word.");
    }
  }

  if (options.antispam && isSpam(message.chat, message.sender)) {
    return enforceViolation(client, message, "Please slow down. Spam is not allowed.");
  }

  const mediaOption = getMediaOption(message);
  if (mediaOption && options[mediaOption]) {
    return enforceViolation(client, message, "This media type is not allowed in this group.");
  }

  return false;
}

export async function moderateIncomingStatus(
  message: SerializedMessage,
): Promise<boolean> {
  if (message.chat !== "status@broadcast" || !message.mentionedJid?.length) return false;

  const database = await loadDatabase();
  const mentionedGroups = message.mentionedJid.filter((jid) => jid.endsWith("@g.us"));

  for (const groupId of mentionedGroups) {
    if (!database.groups[groupId]?.antistatus) continue;

    try {
      await message.delete();
      log.info(`[moderation] removed a status mentioning group ${groupId}`);
      return true;
    } catch (error) {
      log.warn(`[moderation] status deletion failed: ${error instanceof Error ? error.message : String(error)}`);
      return false;
    }
  }

  return false;
}

export function clearToxicWordsCache(): void {
  toxicWordsCache = null;
}