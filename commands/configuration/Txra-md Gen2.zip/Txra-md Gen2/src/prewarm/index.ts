// src/prewarm/index.ts — pemanasan cache di latar belakang, supaya TIDAK ADA pengguna yang menemui "jalur dingin".
//
// Jalur dingin = unduh gambar/audio/video → olah (Rust/ffmpeg) → upload ke WhatsApp. Di HP itu bisa beberapa detik dan
// menaikkan CPU tepat saat bot sedang melayani pesan. Modul ini memindahkannya ke waktu senggang:
//   1. saat bot terhubung        → semua thumbnail (menu, fake reply, fake quoted, bot), upload menu (gambar/video/audio), foto profil bot
//   2. saat pengaturan berubah   → hanya yang baru (didebounce; .setmenu / .setthumb / .sfr / .setaudiomenu dll.)
//   3. tiap 10 menit             → refresh-ahead: upload yang sudah >75% umurnya diperbarui SEBELUM kedaluwarsa (TTL 6 jam)
// Berjalan berurutan, satu pekerjaan per waktu, dengan jeda antar langkah; kegagalan satu langkah tidak menghentikan yang lain.
// Matikan dengan "prewarm": false di config.json → features (atau env PREWARM=0).
import { getConfig } from "../../connector/config.ts";
import { onConfigChange } from "../../helpers/utils/config-events.ts";
import { refreshAhead, flushUploadCache } from "../setthumblarge/cache.ts";
import { loadThumbStore } from "../setthumblarge/store.ts";
import { ALL_THUMB_VARIANTS, warmThumbVariants, type ThumbVariant } from "../setthumblarge/thumb.ts";
import { warmThumbLarge } from "../setthumblarge/index.ts";
import { loadFakeConfig } from "../setfakereply/store.ts";
import { loadFakeQuotedConfig } from "../setfakequoted/store.ts";
import { warmProfilePic } from "../setfakequoted/builder.ts";
import { loadMenuConfig } from "../setmenu/store.ts";
import { getPresets } from "../setmenu/presets.ts";
import { warmMenuPreset } from "../setmenu/senders.ts";
import { uploadMenuAudio } from "../setmenu/audio.ts";
import { warmAllGroups } from "../../lib/group-metadata/warm.ts";

const GAP_MS = 120;     // jeda antar langkah → event loop bot tetap lega (dilewati kalau langkah itu instan atau ada yang menunggu)
const DEBOUNCE_MS = 150; // hanya menggabung emit beruntun dari SATU perintah; dulu 2,5 dtk → perintah berikutnya kena jalur dingin
const GROUP_WARM_MIN_GAP_MS = 5 * 60_000;
const GROUP_WARM_EVERY_MS = 40 * 60_000;
const REFRESH_EVERY_MS = 10 * 60_000;

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const isUrl = (s: unknown): s is string => typeof s === "string" && /^https?:\/\/\S+$/i.test(s.trim());

let client: any = null;
let running: Promise<void> | null = null;
let again = false;
let debounce: ReturnType<typeof setTimeout> | null = null;
let started = false;
let urgent = false;          // ada perintah .setxxx yang menunggu → tanpa jeda antar langkah
let lastGroupWarm = 0;

const enabled = (): boolean => {
  if (process.env.PREWARM === "0" || process.env.PREWARM === "false") return false;
  try { return (getConfig() as any).features?.prewarm !== false; } catch { return true; }
};

/** Kumpulkan sumber gambar → varian yang dibutuhkan. Satu URL = satu unduhan + satu decode, berapa pun variannya. */
async function collectSources(): Promise<Map<string, Set<ThumbVariant>>> {
  const want = new Map<string, Set<ThumbVariant>>();
  const add = (src: unknown, variants: readonly ThumbVariant[]) => {
    if (!isUrl(src)) return;
    const k = src.trim();
    const set = want.get(k) ?? new Set<ThumbVariant>();
    variants.forEach((v) => set.add(v));
    want.set(k, set);
  };

  // gambar bot + .setthumb → dipakai semua tipe thumbnail besar & menu
  try { add((getConfig() as any).bot?.thumbnail, ALL_THUMB_VARIANTS); } catch { /* tanpa config */ }
  try { const t = await loadThumbStore(); add(t.default, ALL_THUMB_VARIANTS); add(t.location, ["location"]); } catch { /* abaikan */ }

  // fake reply: kartu kecil (fake) + isi dokumen (image)
  try {
    const f = await loadFakeConfig();
    for (const src of Object.values(f.images)) add(src, ["fake", "image"]);
  } catch { /* abaikan */ }

  // fake quoted: order dengan gambar kustom
  try {
    const q = await loadFakeQuotedConfig();
    for (const p of Object.values(q.presets)) for (const sub of Object.values((p as any).subs ?? {})) add((sub as any)?.image, ["fake"]);
  } catch { /* abaikan */ }

  // gambar khusus per preset menu
  try {
    for (const p of Object.values(await getPresets())) add((p as any).thumbnail ?? (p as any).image, ["inline", "location", "preview", "image"]);
  } catch { /* abaikan */ }

  return want;
}

async function step(label: string, fn: () => Promise<unknown>): Promise<void> {
  const t0 = Date.now();
  try {
    await fn();
    const ms = Date.now() - t0;
    if (ms > 1500) console.log(`[prewarm] ${label} (${(ms / 1000).toFixed(1)}s)`);
    if (ms > 80 && !urgent) await sleep(GAP_MS); // langkah yang cuma "sudah hangat" tidak perlu jeda
  } catch (e) {
    console.warn(`[prewarm] ${label} gagal: ${(e as Error).message}`);
    if (!urgent) await sleep(GAP_MS);
  }
}

const groupWarmEnabled = (): boolean => {
  try { return (getConfig() as any).features?.warmAllGroups !== false; } catch { return true; }
};

/** Isi cache metadata SEMUA grup yang diikuti bot (1 request). Yang sudah ada di cache tidak ditimpa. */
async function warmGroupsIfDue(): Promise<void> {
  if (!client || !groupWarmEnabled() || Date.now() - lastGroupWarm < GROUP_WARM_MIN_GAP_MS) return;
  lastGroupWarm = Date.now();
  const n = await warmAllGroups(client);
  if (n > 0) console.log(`[prewarm] ${n} grup dimasukkan ke cache`);
}

async function runOnce(): Promise<void> {
  if (!client) return;
  const t0 = Date.now();

  // 0) metadata semua grup → balasan pertama di grup lama/sepi tidak perlu menunggu query ke WhatsApp
  await step("grup", warmGroupsIfDue);

  // 1) thumbnail: satu unduhan + satu decode per sumber
  for (const [src, variants] of await collectSources()) {
    await step(`thumb ${src.slice(0, 48)}`, () => warmThumbVariants(src, [...variants]));
  }

  // 2) upload yang dipakai tipe thumbnail besar aktif (.setthumblarge)
  await step("thumblarge", () => warmThumbLarge(client));

  // 3) menu aktif: gambar/video/preview terupload
  await step("menu", async () => {
    const cfg = await loadMenuConfig();
    const presets = await getPresets();
    const preset = presets[cfg.active] ?? presets[7];
    if (preset) await warmMenuPreset(client, preset);
  });

  // 4) audio menu: unduh + konversi (cache disk) + upload
  await step("audio menu", () => uploadMenuAudio(client));

  // 5) foto profil bot (dipakai fake quoted "Order with Bot PP")
  await step("foto profil bot", () => warmProfilePic(client));

  console.log(`[prewarm] selesai dalam ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

/** Jalankan satu putaran; permintaan yang datang saat berjalan digabung jadi satu putaran lanjutan. */
function run(): Promise<void> {
  if (running) { again = true; return running; }
  running = (async () => {
    do {
      again = false;
      await runOnce();
    } while (again);
  })().catch((e) => console.warn("[prewarm] error:", (e as Error).message)).finally(() => { running = null; });
  return running;
}

/**
 * Siapkan SEKARANG dan tunggu selesai (maks. `maxWaitMs`; sisanya lanjut di latar belakang).
 * Dipakai lewat onConfigChange → perintah .setmenu/.setfq/.sfr/.setthumb dst. baru membalas setelah cache hangat.
 */
export async function prewarmNow(maxWaitMs = 6_000): Promise<void> {
  if (!client || !enabled()) return;
  if (debounce) { clearTimeout(debounce); debounce = null; }
  urgent = true;
  const job = run().finally(() => { urgent = false; });
  let timer: ReturnType<typeof setTimeout>;
  await Promise.race([job, new Promise<void>((r) => { timer = setTimeout(r, maxWaitMs); })]).finally(() => clearTimeout(timer));
}

/** Pengaturan berubah (tanpa menunggu) → siapkan ulang sebentar lagi (beberapa perubahan beruntun = satu putaran). */
export function schedulePrewarm(delay = DEBOUNCE_MS): void {
  if (!client || !enabled()) return;
  if (debounce) clearTimeout(debounce);
  debounce = setTimeout(() => { debounce = null; void run(); }, delay);
  (debounce as any).unref?.();
}

/** Dipanggil tiap koneksi WhatsApp terbuka. Aman dipanggil berulang (reconnect): yang sudah hangat dilewati. */
export function startPrewarm(c: any): void {
  client = c;
  if (!enabled()) return;
  if (!started) {
    started = true;
    onConfigChange(() => prewarmNow());
    const timer = setInterval(() => {
      // grup baru yang dimasuki bot ikut masuk cache (yang sudah ada tidak ditimpa)
      if (Date.now() - lastGroupWarm > GROUP_WARM_EVERY_MS) void warmGroupsIfDue().catch(() => {});
      if (running) return;
      refreshAhead().then((n) => { if (n) console.log(`[prewarm] ${n} upload diperbarui sebelum kedaluwarsa`); }).catch(() => {});
    }, REFRESH_EVERY_MS);
    (timer as any).unref?.();
  }
  // beri bot waktu menyelesaikan sinkronisasi awal dulu
  schedulePrewarm(4_000);
}

export { flushUploadCache };