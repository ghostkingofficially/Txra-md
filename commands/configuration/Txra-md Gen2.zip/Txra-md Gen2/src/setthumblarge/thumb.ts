import { Buffer } from "node:buffer";
import { readFile } from "node:fs/promises";
import { isAbsolute, join } from "node:path";
import Jimp from "jimp";
import { getConfig } from "../../connector/config.ts";
import { Toolkit } from "../../helpers/utils/toolkit.ts";
import { getThumbSource, PROJECT_ROOT } from "./store.ts";

export type ThumbVariant = "location" | "preview" | "inline" | "image" | "fake";

export interface Thumb {
  key: string;
  jpeg: Buffer;
  width: number;
  height: number;
  source: string;
}

const TTL_MS = 10 * 60_000;
const cache = new Map<string, { at: number; thumb: Thumb | null }>();

export const clearThumbCache = () => cache.clear();

async function effectiveSource(variant: ThumbVariant): Promise<string> {
  const stored = await getThumbSource(variant === "location" ? "location" : "default");
  if (stored) return stored;
  try { return String(getConfig().bot?.thumbnail ?? ""); } catch { return ""; }
}

async function readSource(src: string): Promise<Buffer | null> {
  try {
    if (/^https?:\/\//i.test(src)) {
      const buf = await Toolkit.fetchBuffer(src); // silent: kosong kalau gagal
      return buf.length ? buf : null;
    }
    const path = isAbsolute(src) ? src : join(PROJECT_ROOT, src);
    return Buffer.from(await readFile(path));
  } catch {
    return null;
  }
}

async function process(variant: ThumbVariant, raw: Buffer): Promise<{ jpeg: Buffer; width: number; height: number }> {
  const img = await Jimp.read(raw);
  if (variant === "location") img.cover(300, 300).quality(80);
  else if (variant === "preview") img.scaleToFit(1024, 576).quality(90);
  else if (variant === "inline") img.scaleToFit(320, 180).quality(70);
  else img.scaleToFit(1280, 1280).quality(85);
  const jpeg = await img.getBufferAsync(Jimp.MIME_JPEG);
  return { jpeg, width: img.bitmap.width, height: img.bitmap.height };
}

export async function getThumb(variant: ThumbVariant): Promise<Thumb | null> {
  const source = await effectiveSource(variant);
  if (!source) return null;

  const key = `${variant}|${source}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.thumb;

  let thumb: Thumb | null = null;
  try {
    const raw = await readSource(source);
    if (raw) thumb = { key, ...(await process(variant, raw)), source };
  } catch (e) {
    console.warn(`[thumblarge] gagal memproses thumbnail "${source}":`, (e as Error).message);
  }
    cache.set(key, { at: thumb ? Date.now() : Date.now() - TTL_MS + 15_000, thumb });
  return thumb;
}

export async function getThumbForSource(variant: ThumbVariant, source: string): Promise<Thumb | null> {
  const normalized = String(source ?? "").trim();
  if (!normalized) return null;

  const key = `${variant}|${normalized}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.thumb;

  let thumb: Thumb | null = null;
  try {
    const raw = await readSource(normalized);
    if (raw) thumb = { key, ...(await process(variant, raw)), source: normalized };
  } catch (error) {
    console.warn(`[thumblarge] failed to process source "${normalized}":`, (error as Error).message);
  }
  cache.set(key, { at: thumb ? Date.now() : Date.now() - TTL_MS + 15_000, thumb });
  return thumb;
}
