import type { WaClient } from "zapo-js";
import { getAdditionalNodes } from "../../helpers/utils/additional-nodes.ts";
import { buildWAMessage, newMessageId, prepareMedia, relay } from "../../helpers/utils/button-messages/transport.ts";
import { getConfig } from "../../connector/config.ts";
import { getThumb } from "./thumb.ts";
import type { ButtonSpec, LargeOptions } from "./types.ts";

type Obj = Record<string, any>;

export interface SendCtx {
  client: WaClient;
  jid: string;
  o: LargeOptions;
  quoted?: { key: any; message: any };
  prefix: string;
}

const LINK_RENDER_LARGER = false;

// ── util ──
const ensureCommand = (s: string, prefix: string) => {
  const t = s.trim();
  return /^[^\w\s]/.test(t) ? t : prefix + t; 
};

export function suggestText(suggest: string[] | undefined, prefix = ".", title = "💡 Coba juga:"): string {
  const list = (suggest ?? []).map((s) => String(s).trim()).filter(Boolean);
  if (!list.length) return "";
  return `${title}\n${list.map((s) => `• ${ensureCommand(s, prefix)}`).join("\n")}`;
}

const toNativeButtons = (specs: readonly ButtonSpec[]): Obj[] =>
  specs.map((b) => ({
    name: b.name,
    buttonParamsJson: typeof b.params === "string" ? b.params : JSON.stringify(b.params ?? {}),
  }));

const buttonsOrDefault = (c: SendCtx): Obj[] => {
  const own = toNativeButtons(c.o.buttons ?? []);
  return own.length ? own : toNativeButtons([{ name: "quick_reply", params: { display_text: "Menu", id: `${c.prefix}menu` } }]);
};

function ownerJid(client: WaClient): string {
  try {
    const raw = String((client as any).getCredentials?.()?.meJid ?? "");
    const user = raw.split("@")[0].split(":")[0];
    return user ? `${user}@s.whatsapp.net` : "0@s.whatsapp.net";
  } catch {
    return "0@s.whatsapp.net";
  }
}

function cleanQuoted(q?: { key: any; message: any }) {
  if (!q?.message || typeof q.message !== "object") return q;
  const type = Object.keys(q.message)[0];
  const inner = type ? q.message[type] : undefined;
  if (inner && typeof inner === "object" && inner.contextInfo) {
    const { contextInfo: _drop, ...rest } = inner;
    return { ...q, message: { [type]: rest } };
  }
  return q;
}

async function send(c: SendCtx, content: Obj, nodes: readonly any[] = []) {
  const wa = buildWAMessage(c.jid, content, { messageId: newMessageId(), quoted: cleanQuoted(c.quoted) });
  return await relay(c.client, c.jid, wa.message, { messageId: wa.key.id, additionalNodes: nodes });
}

const interactive = (header: Obj, c: SendCtx, buttons: Obj[], extra: { params?: Obj; contextInfo?: Obj } = {}) => ({
  interactiveMessage: {
    header,
    body: { text: c.o.text || " " },
    footer: { text: c.o.footer ?? "© " + (getConfig().bot?.name ?? "") },
    nativeFlowMessage: { buttons, messageParamsJson: JSON.stringify(extra.params ?? {}) },
    ...(extra.contextInfo ? { contextInfo: extra.contextInfo } : {}),
  },
});

const FALLBACK_URL = "https://chat.whatsapp.com";
function safeUrl(u?: string): string {
  try {
    const x = new URL(String(u ?? ""));
    return /^https?:$/.test(x.protocol) && /^[a-z0-9.-]+$/i.test(x.hostname) ? String(u) : FALLBACK_URL;
  } catch {
    return FALLBACK_URL;
  }
}

interface LinkThumb {
  directPath: string; mediaKey: any; fileSha256: any; fileEncSha256: any; mediaKeyTimestamp: any;
  width: number; height: number;
}
const LINK_THUMB_TTL = 10 * 60_000;
const LINK_THUMB_RETRY = 60_000;
let linkThumbCache: { source: string; at: number; data: LinkThumb | null } | null = null;

async function uploadLinkThumb(client: WaClient): Promise<LinkThumb | null> {
  const big = await getThumb("preview");
  if (!big) return null;

  const c = linkThumbCache;
  if (c && c.source === big.source) {
    const age = Date.now() - c.at;
    if (c.data && age < LINK_THUMB_TTL) return c.data;
    if (!c.data && age < LINK_THUMB_RETRY) return null; 
  }

  try {
    const up: any = await (client as any).message.upload(big.jpeg, { type: "thumbnail-link", mimetype: "image/jpeg" });
    if (!up?.directPath || !up?.mediaKey) throw new Error("hasil upload tidak lengkap (directPath/mediaKey kosong)");
    const data: LinkThumb = {
      directPath: up.directPath,
      mediaKey: up.mediaKey,
      fileSha256: up.fileSha256 ?? up.sha256,
      fileEncSha256: up.fileEncSha256 ?? up.encSha256,
      mediaKeyTimestamp: up.mediaKeyTimestamp ?? Math.floor(Date.now() / 1000),
      width: big.width,
      height: big.height,
    };
    linkThumbCache = { source: big.source, at: Date.now(), data };
    return data;
  } catch (e) {
    console.warn(`[thumblarge] upload thumbnail-link gagal (${(e as Error).message}) — link preview dikirim tanpa gambar besar`);
    linkThumbCache = { source: big.source, at: Date.now(), data: null };
    return null;
  }
}

export async function sendLinkPreview(c: SendCtx) {
  const cfg = getConfig();
  const url = safeUrl(c.o.sourceUrl || cfg.bot?.url);
  const body = [c.o.text, suggestText(c.o.suggest, c.prefix, c.o.suggestTitle)].filter(Boolean).join("\n\n");
  const [up, inline] = await Promise.all([uploadLinkThumb(c.client), getThumb("inline")]);

  return await send(c, {
    extendedTextMessage: {
      title: c.o.title ?? cfg.bot?.name ?? "",
      description: c.o.subtitle ?? cfg.bot?.footer ?? "",
      text: `${url}\n\n${body}`,
      matchedText: url,
      previewType: 0,
      inviteLinkGroupTypeV2: 0,
      ...(LINK_RENDER_LARGER ? { renderLargerThumbnail: true } : {}),
      ...(inline ? { jpegThumbnail: inline.jpeg } : {}),
      ...(up
        ? {
            thumbnailDirectPath: up.directPath,
            thumbnailSha256: up.fileSha256,
            thumbnailEncSha256: up.fileEncSha256,
            mediaKey: up.mediaKey,
            mediaKeyTimestamp: up.mediaKeyTimestamp,
            thumbnailWidth: up.width || 1024,
            thumbnailHeight: up.height || 576,
          }
        : {}),
    },
  });
}

export async function sendLocation(c: SendCtx) {
  const thumb = await getThumb("location");
  const header = {
    hasMediaAttachment: false,
    locationMessage: {
      degreesLatitude: 0,
      degreesLongitude: 0,
      name: c.o.title ?? "",
      address: c.o.subtitle ?? "",
      ...(thumb ? { jpegThumbnail: thumb.jpeg } : {}),
    },
  };
  return await send(c, interactive(header, c, buttonsOrDefault(c)), getAdditionalNodes("mixed"));
}

export async function sendProduct(c: SendCtx) {
  const thumb = await getThumb("image");
  if (!thumb) throw new Error("tipe product butuh thumbnail — atur dengan .setthumb default <url> atau isi bot.thumbnail di config.json");
  const media = await prepareMedia(c.client, "image", thumb.jpeg, { mimetype: "image/jpeg" });
  const header = {
    hasMediaAttachment: true,
    productMessage: {
      product: {
        productImage: media.imageMessage,
        productId: "bocchi-" + Date.now(),
        title: c.o.title ?? "",
        description: " ",
        retailerId: getConfig().bot?.name || "Bocchi",
        productImageCount: 1,
      },
      businessOwnerJid: ownerJid(c.client),
    },
  };
  return await send(c, interactive(header, c, buttonsOrDefault(c)), getAdditionalNodes("mixed"));
}

const buildLTO = () => ({
  text: "🔥 Limited Offer!",
  url: "",
  copy_code: "",
  expiration_time: Date.now() + 3_600_000,
});

export async function sendCatalog(c: SendCtx) {
  const thumb = await getThumb("location");
  const header = {
    locationMessage: { degreesLatitude: 0, degreesLongitude: 0, ...(thumb ? { jpegThumbnail: thumb.jpeg } : {}) },
    hasMediaAttachment: true,
  };
  const own = toNativeButtons(c.o.buttons ?? []);
  const buttons: Obj[] = [
    { name: "catalog_message", buttonParamsJson: "{}" },
    ...(own.length ? [{ name: "", buttonParamsJson: "{}" }, ...own] : []), // spacer sebelum tombol tambahan
  ];
  return await send(
    c,
    interactive(header, c, buttons, {
      params: { limited_time_offer: buildLTO() },
      contextInfo: { participant: c.jid, mentionedJid: ["0@s.whatsapp.net"] },
    }),
    getAdditionalNodes("catalog_message"),
  );
}

export async function sendImage(c: SendCtx) {
  const thumb = await getThumb("image");
  if (!thumb) throw new Error("tipe image butuh thumbnail — atur dengan .setthumb default <url> atau isi bot.thumbnail di config.json");
  const media = await prepareMedia(c.client, "image", thumb.jpeg, { mimetype: "image/jpeg" });

  if (c.o.buttons?.length) {
    const header = { title: c.o.title ?? "", subtitle: c.o.subtitle ?? "", hasMediaAttachment: true, ...media };
    return await send(c, interactive(header, c, toNativeButtons(c.o.buttons)), getAdditionalNodes("mixed"));
  }
  return await send(c, { imageMessage: { ...media.imageMessage, caption: c.o.text } });
}