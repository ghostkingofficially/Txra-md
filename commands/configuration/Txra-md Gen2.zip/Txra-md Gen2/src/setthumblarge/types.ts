export { THUMB_LARGE_TYPES, isThumbLargeType, type ThumbLargeType } from "../../lib/settings/botSettings.ts";
import type { ThumbLargeType } from "../../lib/settings/botSettings.ts";

export type ThumbKind = "location" | "default";

export interface ButtonSpec {
  name: string;
  params?: unknown;
}

export interface LargeOptions {
  text: string;
  title?: string;
  subtitle?: string;
  footer?: string;
  suggest?: string[];
  buttons?: ButtonSpec[];
  type?: ThumbLargeType;
  quoted?: { key: any; message: any };
  prefix?: string;
  sourceUrl?: string;
  suggestTitle?: string;
}

export interface LargeResult {
  type: ThumbLargeType;
  fallback: boolean;
}
