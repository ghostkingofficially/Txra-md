// src/setthumblarge/index.ts
// Satu pintu untuk semua balasan yang memakai thumbnail besar. Tipe tampilannya diatur owner lewat
// `.setthumblarge <tipe>`, jadi command tidak perlu tahu tipe apa yang sedang aktif.
//
//   import { sendLarge } from "../../src/setthumblarge/index.ts";
//   await sendLarge(ctx.client, m, {
//     title: "Profil", text: "Nama: ...",
//     suggest: [".setprofile", ".setumur"],            // hanya muncul di tipe linkpreview (teks di bawah isi)
//     buttons: [{ name: "quick_reply", params: { display_text: "Edit", id: ".setprofile" } }], // tipe lain
//   });
import { getSettings, loadSettings } from "../../lib/settings/botSettings.ts";
import { clearThumbCache } from "./thumb.ts";
import {
  sendCatalog, sendImage, sendLinkPreview, sendLocation, sendProduct, suggestText, type SendCtx,
} from "./senders.ts";
import type { LargeOptions, LargeResult, ThumbLargeType } from "./types.ts";

export { clearThumbCache, suggestText };
export { THUMB_LARGE_TYPES, isThumbLargeType } from "./types.ts";
export type { ButtonSpec, LargeOptions, LargeResult, ThumbKind, ThumbLargeType } from "./types.ts";
export { getThumbSource, loadThumbStore, saveThumbImage, setThumbSource } from "./store.ts";

const SENDERS: Record<ThumbLargeType, (c: SendCtx) => Promise<unknown>> = {
  linkpreview: sendLinkPreview,
  location: sendLocation,
  product: sendProduct,
  catalog: sendCatalog,
  image: sendImage,
};

/** Tipe yang sedang aktif (dari .setthumblarge). */
export async function getActiveThumbType(): Promise<ThumbLargeType> {
  await loadSettings();
  return getSettings().thumbLarge.type;
}

/**
 * Kirim balasan sesuai tipe aktif. Kalau tipe itu gagal dikirim (mis. thumbnail belum diatur, ditolak server),
 * balasan tetap dikirim sebagai teks biasa supaya pengguna tidak dibiarkan tanpa jawaban.
 */
export async function sendLarge(client: any, m: any, o: LargeOptions): Promise<LargeResult> {
  const type = o.type ?? (await getActiveThumbType());
  const prefix = o.prefix ?? ".";
  const quoted = o.quoted ?? (m?.key && m?.message ? { key: m.key, message: m.message } : undefined);
  const ctx: SendCtx = { client, jid: m.chat, o, quoted, prefix };

  try {
    await SENDERS[type](ctx);
    return { type, fallback: false };
  } catch (e) {
    console.error(`[thumblarge] tipe "${type}" gagal:`, (e as Error).message);
    // Fallback teks: sertakan saran command supaya informasinya tidak hilang.
    const text = [o.text, suggestText(o.suggest, prefix, o.suggestTitle)].filter(Boolean).join("\n\n");
    await m.reply(text);
    return { type, fallback: true };
  }
}
