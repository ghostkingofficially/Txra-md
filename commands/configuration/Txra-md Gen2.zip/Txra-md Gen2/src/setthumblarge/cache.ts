type CacheEntry = { value: unknown; createdAt: number };
const uploads = new Map<string, Promise<unknown>>();
const TTL_MS = 30 * 60_000;

export async function cachedUpload<T>(key: string, factory: () => Promise<T>): Promise<T> {
  const existing = uploads.get(key);
  if (existing) return existing as Promise<T>;
  const task = factory().then((value) => value).finally(() => {
    setTimeout(() => uploads.delete(key), TTL_MS).unref?.();
  });
  uploads.set(key, task);
  return task;
}

export async function refreshAhead<T>(key: string, factory: () => Promise<T>): Promise<T> {
  uploads.delete(key);
  return cachedUpload(key, factory);
}

export function flushUploadCache(): void {
  uploads.clear();
}

export function getUploadCacheSize(): number {
  return uploads.size;
}