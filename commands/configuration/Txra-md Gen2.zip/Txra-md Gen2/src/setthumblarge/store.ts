import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import type { ThumbKind } from "./types.ts";

export const PROJECT_ROOT = fileURLToPath(new URL("../../", import.meta.url));
const STORE_PATH = join(PROJECT_ROOT, "db", "configuration", "setthumb.json");
const THUMB_DIR = join(PROJECT_ROOT, "db", "configuration", "thumbs");

export interface ThumbStore {
  location: string;
  default: string;
}

let cached: ThumbStore | null = null;

const clean = (v: unknown) => (typeof v === "string" ? v.trim() : "");

export async function loadThumbStore(force = false): Promise<ThumbStore> {
  if (cached && !force) return cached;
  try {
    const raw = JSON.parse(await readFile(STORE_PATH, "utf8"));
    cached = { location: clean(raw?.location), default: clean(raw?.default) };
  } catch {
    cached = { location: "", default: "" };
  }
  return cached;
}

async function persist(): Promise<void> {
  await mkdir(dirname(STORE_PATH), { recursive: true });
  const tmp = STORE_PATH + ".tmp";
  await writeFile(tmp, JSON.stringify(cached, null, 2), "utf8");
  await rename(tmp, STORE_PATH);
}

export async function getThumbSource(kind: ThumbKind): Promise<string> {
  return (await loadThumbStore())[kind];
}

export async function setThumbSource(kind: ThumbKind, source: string): Promise<void> {
  const s = await loadThumbStore();
  s[kind] = clean(source);
  await persist();
}

export async function saveThumbImage(kind: ThumbKind, bytes: Uint8Array): Promise<string> {
  await mkdir(THUMB_DIR, { recursive: true });
  const rel = `db/configuration/thumbs/${kind}.img`;
  await writeFile(join(PROJECT_ROOT, rel), bytes);
  await setThumbSource(kind, rel);
  return rel;
}
