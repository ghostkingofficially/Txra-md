export { createSocket, hasRegisteredSession } from "./socket.ts";
export type { CreateSocketOptions } from "./socket.ts";
export { CONNECTOR_DEFAULTS } from "./constanta.ts";