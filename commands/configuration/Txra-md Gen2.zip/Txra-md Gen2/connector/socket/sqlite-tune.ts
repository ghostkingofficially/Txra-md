// connector/socket/sqlite-tune.ts — optimize the session SQLite database for Node.js.

import { DatabaseSync } from "node:sqlite";
import { log } from "../logger/index-logging.ts";

const PRAGMAS = [
  "PRAGMA journal_mode=WAL",
  "PRAGMA synchronous=NORMAL",
  "PRAGMA temp_store=MEMORY",
  "PRAGMA cache_size=-8000",
  "PRAGMA busy_timeout=5000",
] as const;

let tunedDatabasePath = "";

/**
 * Apply safe SQLite performance settings to the session database.
 *
 * This implementation is Node.js compatible and must not import bun:sqlite.
 * WAL mode persists for future connections; connection-local settings are
 * applied to this tuning connection without affecting the database schema.
 */
export function tuneSessionSqlite(sessionDbPath: string): void {
  if (!sessionDbPath) return;
  if (tunedDatabasePath === sessionDbPath) return;

  let database: DatabaseSync | undefined;

  try {
    database = new DatabaseSync(sessionDbPath);

    const applied: string[] = [];

    for (const pragma of PRAGMAS) {
      try {
        database.exec(pragma);
        applied.push(pragma.replace(/^PRAGMA\s+/i, ""));
      } catch (error) {
        log.warn(
          `SQLite pragma skipped (${pragma}): ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    }

    tunedDatabasePath = sessionDbPath;
    log.success(`SQLite session tuned: ${applied.join(", ")}`);
  } catch (error) {
    log.warn(
      `SQLite tuning skipped: ${
        error instanceof Error ? error.message : String(error)
      }`,
    );
  } finally {
    try {
      database?.close();
    } catch {
      // The tuning connection is already closed or unavailable.
    }
  }
}
