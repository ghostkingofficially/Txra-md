import type { WaClient } from "zapo-js";

import { getConfig } from "../config.ts";
import { log } from "../logger/index-logging.ts";
import { isBotSentId, smsg } from "../../lib/serialize/smsg.ts";
import { handleIncomingMessage } from "../../helpers/handling-message.ts";
import { markRead } from "../../lib/func/presence.ts";
import { hasQuotedInteractive } from "../../lib/func/richReply.ts";
import { moderateIncomingMessage } from "../../src/moderation/index.ts";

const WRAPPERS = [
  "ephemeralMessage",
  "viewOnceMessage",
  "viewOnceMessageV2",
  "documentWithCaptionMessage",
  "deviceSentMessage",
  "editedMessage",
];

const RESPONSE_KEYS = [
  "buttonsResponseMessage",
  "listResponseMessage",
  "templateButtonReplyMessage",
  "interactiveResponseMessage",
];

function quickText(message: any, depth = 0): string {
  if (!message || depth > 3) return "";
  const direct =
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption;
  if (direct) return String(direct);

  for (const w of WRAPPERS) {
    const inner = message[w]?.message;
    if (inner) {
      const t = quickText(inner, depth + 1);
      if (t) return t;
    }
  }
  return "";
}

function mightBeCommand(message: any, prefixes: string[]): boolean {
  if (!message) return false;
  for (const k of RESPONSE_KEYS) if (message[k]) return true;
  if (hasQuotedInteractive(message)) return true; // balasan teks ke pesan rich

  const text = quickText(message).trimStart();
  if (!text) return false;
  for (const p of prefixes) if (text.startsWith(p)) return true;
  return false;
}

function scopeOf(m: { isNewsletter: boolean; isGroup: boolean; chat: string }): string {
  if (m.isNewsletter) return "NEWSLETTER";
  if (m.isGroup) return "GROUP";
  if (m.chat === "status@broadcast") return "STATUS";
  return "PRIVATE";
}

export function registerMessageUpsert(client: WaClient): void {
  client.on("message", async (event) => {
    const t0 = performance.now();
    try {
      const cfg = getConfig();
      const key = (event as any).key;
      const remote: string = key?.remoteJid ?? "";

      if (remote === "status@broadcast") return;
      if (remote.endsWith("@newsletter") && !key?.fromMe) return;
      if (isBotSentId(key?.id)) return;

      const m = smsg(event as any, client);
      if (!m) return;
      // Dipakai .ping & log timing: waktu event diterima bot (bukan timestamp WhatsApp yang resolusinya 1 detik).
      (m as any).receivedAt = Date.now();
      (m as any).t0 = t0;

      if (await moderateIncomingMessage(client, m)) return;

      const prefixes = Array.isArray(cfg.prefix) ? cfg.prefix : [String(cfg.prefix ?? "")];
      if (!mightBeCommand((event as any).message, prefixes)) return;
      if (cfg.features?.autoRead) void markRead(client, event);

      if (cfg.features?.verboseLog) {
        // Log lengkap hanya kalau verboseLog dinyalakan
        let lid: string | undefined;
        if (m.key?.participant?.endsWith("@lid")) lid = m.key.participant.split("@")[0];
        else if (m.key?.remoteJid?.endsWith("@lid")) lid = m.key.remoteJid.split("@")[0];
        log.incoming({
          scope: scopeOf(m),
          mtype: m.mtype,
          from: m.sender.split("@")[0] || m.sender,
          fromName: m.pushName || undefined,
          lid,
          chatId: m.isGroup || m.isNewsletter ? m.chat : undefined,
          stanzaId: m.id,
          timestamp: m.timestamps,
          text: m.text?.trim() || undefined,
          isQuoted: m.isQuoted,
        });
      } else {
        log.info(
          `[${scopeOf(m)}] ${m.sender.split("@")[0]}: ${(m.text ?? "").trim().slice(0, 60)}`,
        );
      }

      await handleIncomingMessage(client, m);

      if (cfg.features?.verboseLog) {
        log.info(`⏱ total ${(performance.now() - t0).toFixed(1)}ms (event → selesai)`);
      }
    } catch (err) {
      log.error(
        `[message] Handler error: ${err instanceof Error ? err.message : String(err)}`,
      );
      if (err instanceof Error && err.stack) log.debug(err.stack);
    }
  });
}