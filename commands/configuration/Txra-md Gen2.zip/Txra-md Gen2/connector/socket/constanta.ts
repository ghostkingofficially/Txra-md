export type LoginMethod = "qr" | "pairing";

function resolveLoginMethod(): LoginMethod {
  const v = (process.env.LOGIN_METHOD ?? "qr").toLowerCase();
  return v === "pairing" ? "pairing" : "qr";
}

export const CONNECTOR_DEFAULTS = {
  sessionId: process.env.BOT_SESSION_ID ?? "default",
  loginMethod: resolveLoginMethod(),
  pairingPhoneNumber: process.env.PAIRING_PHONE ?? "",

  redis: {
    host: process.env.REDIS_HOST ?? "127.0.0.1",
    port: Number(process.env.REDIS_PORT ?? "6379"),
    password: process.env.REDIS_PASSWORD,
    keyPrefix: process.env.REDIS_KEY_PREFIX ?? "wa:",
  },

  deviceBrowser: "Chrome" as const,
  deviceOsDisplayName: "Windows" as const,

  connectTimeoutMs: 15_000,
  nodeQueryTimeoutMs: 30_000,

  history: {
    enabled: true,
    requireFullSync: false,
  },
};