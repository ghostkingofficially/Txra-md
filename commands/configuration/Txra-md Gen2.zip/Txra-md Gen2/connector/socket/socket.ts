import { mkdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { createSqliteStore } from "@zapo-js/store-sqlite";
import { createStore, WaClient } from "zapo-js";
import qrcode from "qrcode-terminal";
import { DatabaseSync } from "node:sqlite";
import { getConfig, PROJECT_ROOT } from "../config.ts";
import { getInternalLogger, log } from "../logger/index-logging.ts";
import { registerMessageUpsert } from "./message-upsert.ts";
import { registerGroupEvents } from "../../src/moderation/group-events.ts";
import { tuneSessionSqlite } from "./sqlite-tune.ts";
import { deleteSessionFiles } from "../../lib/func/sessionCleanup.ts";
import { HOUR_MS, MINUTE_MS } from "../../lib/func/dateTime.ts";

export interface CreateSocketOptions {
  usePairing?: boolean;
  pairingPhone?: string;
  skipAuthUI?: boolean;
}

export async function hasRegisteredSession(
  sqlitePath: string,
  sessionId: string,
): Promise<boolean> {
  try {
    const db = new DatabaseSync(sqlitePath);
    try {
      const row = db
        .prepare("SELECT me_jid FROM auth_credentials WHERE session_id = ?")
        .get(sessionId) as { me_jid?: string } | null;
      return !!row?.me_jid;
    } finally {
      db.close();
    }
  } catch {
    return false;
  }
}

export async function createSocket(
  options: CreateSocketOptions = {},
): Promise<WaClient> {
  const cfg = getConfig();
  const usePairing = options.usePairing ?? cfg.pairing.usePairingCode;
  const pairingPhone = (options.pairingPhone ?? cfg.owner.primary)
    .replace(/\D/g, "");
  const skipAuthUI = options.skipAuthUI ?? false;

  const internalLogger = await getInternalLogger();

  const sqlitePath = resolve(
    PROJECT_ROOT,
    cfg.session.sqlitePath ?? "./db/sqljs/session.db",
  );
  await mkdir(dirname(sqlitePath), { recursive: true });

  log.info(`Session DB: ${sqlitePath}`);

  if (cfg.features?.sqliteTune !== false) tuneSessionSqlite(sqlitePath);

  const cacheTtlMs = {
    groupMetadata: 6 * HOUR_MS,
    deviceList: 6 * HOUR_MS,
    retry: 5 * MINUTE_MS,
    messageSecret: HOUR_MS,
  };

  const buildStore = (memoryCache: boolean) =>
    createStore({
      backends: { sqlite: createSqliteStore({ path: sqlitePath, driver: "node", cacheTtlMs }) },
      providers: {
        auth: "sqlite", signal: "sqlite", preKey: "sqlite", session: "sqlite", identity: "sqlite", senderKey: "sqlite",
        appState: "sqlite", privacyToken: "sqlite", messages: "sqlite", threads: "sqlite", contacts: "sqlite",
      },
      cacheProviders: (memoryCache
        ? { groupMetadata: "memory", deviceList: "memory", retry: "memory", messageSecret: "sqlite" }
        : { groupMetadata: "sqlite", deviceList: "sqlite", retry: "sqlite", messageSecret: "sqlite" }) as any,
    });

  let store: ReturnType<typeof buildStore>;
  if ((cfg.features as any)?.memoryCache === true) {
    try {
      store = buildStore(true);
      log.info("Group/device list cache in RAM (features.memoryCache)");
    } catch (err) {
      log.warn(`memoryCache rejected by zapo-js (${err instanceof Error ? err.message : err}) -> using SQLite`);
      store = buildStore(false);
    }
  } else {
    store = buildStore(false);
  }

  const client = new WaClient(
    {
      store,
      sessionId: cfg.session.id,
      connectTimeoutMs: 15_000,
      deviceBrowser: "Chrome",
      deviceOsDisplayName: "Windows",
      history: { enabled: true, requireFullSync: false },
      nodeQueryTimeoutMs: 30_000,
    },
    internalLogger,
  );

  registerConnectorEvents(client, { usePairing, pairingPhone, skipAuthUI, sqlitePath });
  registerMessageUpsert(client);
  registerGroupEvents(client);
  // FIXED: bindCrmStore was not defined in V3 - removed

  return client;
}

interface EventOptions {
  usePairing: boolean;
  pairingPhone: string;
  skipAuthUI: boolean;
  sqlitePath: string;
}

const MAX_RECONNECT_ATTEMPTS = 10;

function createReconnector(client: WaClient) {
  let attempt = 0;
  let isReconnecting = false;

  async function reconnect(reason = ""): Promise<void> {
    if (isReconnecting) return;
    isReconnecting = true;

    try {
      while (attempt < MAX_RECONNECT_ATTEMPTS) {
        let delayMs: number;

        if (reason.includes("replaced")) {
          delayMs = 60_000;
        } else if (reason.includes("service_unavailable")) {
          delayMs = 30_000;
        } else {
          delayMs = Math.min(30_000, 1_000 * 2 ** attempt);
        }

        attempt += 1;
        log.warn(
          `Reconnecting in ${delayMs / 1000}s (attempt ${attempt}/${MAX_RECONNECT_ATTEMPTS})`,
        );
        await new Promise((r) => setTimeout(r, delayMs));

        try {
          await client.connect();
          return;
        } catch (err) {
          log.error(
            `Reconnect failed: ${err instanceof Error ? err.message : err}`,
          );
        }
      }

      log.error(
        `Giving up after ${MAX_RECONNECT_ATTEMPTS}x reconnect attempts.`,
      );
    } finally {
      isReconnecting = false;
    }
  }

  return {
    reconnect,
    resetAttempts: () => {
      attempt = 0;
    },
  };
}

function registerConnectorEvents(
  client: WaClient,
  { usePairing, pairingPhone, skipAuthUI, sqlitePath }: EventOptions,
): void {
  let pairingRequested = false;
  let loggingOut = false;
  const { reconnect, resetAttempts } = createReconnector(client);

  const requestPairing = async () => {
    if (skipAuthUI) return;
    if (pairingRequested || !pairingPhone) return;
    pairingRequested = true;

    const customCode = getConfig().pairing.customCode?.trim() || undefined;

    try {
      log.info(`Requesting pairing code for ${pairingPhone}...`);
      if (customCode) log.info(`Custom code: ${customCode}`);

      const code = customCode
        ? await client.auth.requestPairingCode(pairingPhone, true, customCode)
        : await client.auth.requestPairingCode(pairingPhone);

      const formatted = code?.match(/.{1,4}/g)?.join("-") ?? code;
      log.pairing(formatted);
    } catch (err) {
      pairingRequested = false;
      const msg = err instanceof Error ? err.message : String(err);
      log.error(`Failed to request pairing code: ${msg}`);
    }
  };

  client.on("connection", async (event) => {
    if (event.status === "open") {
      resetAttempts();
      pairingRequested = false;
      log.success("Bot connected to WhatsApp");

      try {
        const creds = (client as any).getCredentials?.() ?? {};
        const { registerBotOwner } = await import("../../lib/usermanager/users.ts");
        const botUser = registerBotOwner(creds.meJid ?? "");
        if (botUser) {
          log.success(`Bot number ${botUser.jid.split("@")[0]} registered as "${botUser.name}"`);
        }
      } catch (err) {
        log.warn(`Failed to register bot number: ${err instanceof Error ? err.message : err}`);
      }

      try {
        const { getAllOwnerPhones, syncLidMappings } = await import(
          "../../lib/usermanager/owner.ts"
        );
        const owners = getAllOwnerPhones();
        if (owners.length > 0) {
          await syncLidMappings(client, owners);
        }
      } catch (err) {
        log.warn(`LID sync error: ${err instanceof Error ? err.message : err}`);
      }

      import("../../src/prewarm/index.ts").then((m) => m.startPrewarm(client)).catch(() => {});
      return;
    }

    if (event.isLogout || /logged[_ ]?out/i.test(event.reason ?? "")) {
      if (loggingOut) return;
      loggingOut = true;
      log.warn("Device logged out from phone. Session is no longer valid.");

      if (getConfig().features?.autoDeleteSession === false) {
        log.warn("autoDeleteSession is disabled. Delete session.db (+ -wal, -shm) manually and restart bot for pairing.");
        return;
      }

      void (async () => {
        try {
          await client.disconnect();
        } catch { }
        const removed = await deleteSessionFiles(sqlitePath);
        log.success(`Session auto-deleted (${removed.length} files checked). Restart bot for new pairing.`);
        process.exit(0);
      })();
      return;
    }

    const reason = event.reason ?? "unknown";
    log.warn(`Connection closed: ${reason} (code: ${event.code ?? "-"})`);
    void reconnect(reason);
  });

  client.on("auth_qr", ({ qr, ttlMs }) => {
    if (skipAuthUI) return;
    if (usePairing) {
      void requestPairing();
      return;
    }
    log.info(`New QR (valid for ${Math.round(ttlMs / 1000)} seconds)`);
    qrcode.generate(qr, { small: true }, (rendered) => log.qr(rendered));
  });

  client.on("auth_pairing_required", () => {
    if (skipAuthUI) return;
    if (usePairing) void requestPairing();
  });

  client.on("auth_pairing_code", ({ code }) => {
    if (skipAuthUI) return;
    const formatted = code?.match(/.{1,4}/g)?.join("-") ?? code;
    log.pairing(formatted);
  });

  client.on("auth_paired", ({ credentials }) => {
    log.success(`Logged in as ${credentials.meJid ?? "unknown"}`);
  });
}