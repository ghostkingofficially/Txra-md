import { log } from "./logger/index-logging.ts";
import { readFile } from "node:fs/promises";
import { watch } from "node:fs";
import { fileURLToPath } from "node:url";

export const PROJECT_ROOT = fileURLToPath(new URL("../", import.meta.url));

const CONFIG_PATH = new URL("../config.json", import.meta.url);

export interface BotConfig {
  bot: { name: string; title: string; footer: string; url: string; favicon: string; thumbnail: string; };
  group: { name: string; url: string; id: string };
  channel: { name: string; id: string; link: string };
  owner: { primary: string; additional: string[] };
  prefix: string[];
  pairing: { usePairingCode: boolean; customCode: string };
  session: { id: string; backend: string; sqlitePath: string; };
  redis: { host: string; port: number; password: string | null; keyPrefix: string };
  level: Record<string, number>;
  jadibot: { max: number; sessionDir: string };
  features: Record<string, boolean>;
  messages: Record<string, any>;
}

declare global { var mess: Record<string, string>; }

const DEFAULT_MESS: Record<string, string> = {
  unresolved: "⚠️ *nomor kamu belum bisa dikenali bot bre*\ncoba lagi sebentar atau chat bot lewat pm",
  registered: "❌ *kamu belum terdaftar bre*\nketik .register dulu",
  error: "❌ Terjadi error",
};

function syncGlobalMess(messages: Record<string, any> | undefined): void {
  const built: Record<string, string> = { ...DEFAULT_MESS };
  for (const group of ["permission", "reply", "system"]) {
    const obj = messages?.[group];
    if (!obj || typeof obj !== "object") continue;
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v === "string") built[k] = v;
    }
  }
  for (const [k, v] of Object.entries(messages ?? {})) {
    if (typeof v === "string") built[k] = v;
  }
  const target: Record<string, string> = ((globalThis as any).mess ??= {});
  for (const k of Object.keys(target)) delete target[k];
  Object.assign(target, built);
  (globalThis as any).global ??= globalThis;
}

let config: BotConfig = JSON.parse(
  await readFile(CONFIG_PATH, "utf-8"),
) as BotConfig;
syncGlobalMess(config.messages);

const listeners: Array<(c: BotConfig) => void> = [];

export function getConfig(): BotConfig { return config; }
export function onConfigChange(fn: (c: BotConfig) => void): void { listeners.push(fn); }

export async function reloadConfig(): Promise<void> {
  try {
    const next = JSON.parse(await readFile(CONFIG_PATH, "utf-8")) as BotConfig;
    config = next;
    syncGlobalMess(config.messages);
    log.info("config.json dimuat ulang");
    for (const fn of listeners) {
      try { fn(config); } catch (err) {
        log.error(`config listener error: ${err instanceof Error ? err.message : err}`);
      }
    }
  } catch (err) {
    log.error(`Gagal reload config.json: ${err instanceof Error ? err.message : err}`);
  }
}

export function watchConfig(): void {
  try {
    const watcher = watch(CONFIG_PATH.pathname, async (event) => {
      if (event === "change") {
        await new Promise((r) => setTimeout(r, 200));
        await reloadConfig();
      }
    });
    watcher.on("error", (err) => {
      log.error(`watchConfig error: ${err instanceof Error ? err.message : err}`);
    });
  } catch (err) {
    log.error(`watchConfig error: ${err instanceof Error ? err.message : err}`);
  }
}