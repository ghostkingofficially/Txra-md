import { createInterface } from "node:readline";
import { stdin, stdout } from "node:process";

const C = {
  reset: "\x1b[0m",
  gray: "\x1b[90m",
  green: "\x1b[32m",
  cyan: "\x1b[36m",
  yellow: "\x1b[33m",
  red: "\x1b[31m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
};

export async function ask(question: string): Promise<string> {
  const rl = createInterface({
    input: stdin,
    output: stdout,
  });
  
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

export async function promptLoginMethod(): Promise<"qr" | "pairing"> {
  console.log(`${C.cyan}${C.bold}Choose login method:${C.reset}`);
  console.log(`  ${C.green}[1]${C.reset} QR Code  ${C.dim}(scan with WhatsApp)${C.reset}`);
  console.log(`  ${C.green}[2]${C.reset} Pairing  ${C.dim}(enter 8 digit code in WhatsApp)${C.reset}`);
  console.log("");

  while (true) {
    const answer = await ask(`${C.yellow}Choice [1/2]: ${C.reset}`);
    const v = answer.toLowerCase();
    if (v === "1" || v === "qr") return "qr";
    if (v === "2" || v === "pairing" || v === "pair") return "pairing";
    console.log(`${C.gray}  Enter 1 or 2.${C.reset}`);
  }
}

export async function promptPhoneNumber(): Promise<string> {
  while (true) {
    const answer = await ask(
      `${C.yellow}WhatsApp number (format 628xxx, without +): ${C.reset}`,
    );
    const digits = answer.replace(/\D/g, "");
    if (digits.length >= 8) return digits;
    console.log(`${C.gray}  Invalid number, try again.${C.reset}`);
  }
}

export async function promptConfirm(
  question: string,
  defaultYes = true,
): Promise<boolean> {
  const hint = defaultYes ? "Y/n" : "y/N";
  const answer = await ask(`${C.yellow}${question} [${hint}]: ${C.reset}`);
  const v = answer.toLowerCase().trim();
  if (v === "") return defaultYes;
  return v === "y" || v === "ya" || v === "yes";
}

export async function promptAdditionalOwners(): Promise<string[]> {
  console.log("");
  const mauTambah = await promptConfirm(
    "Add another number as owner?",
    false,
  );
  if (!mauTambah) return [];

  const input = await ask(
    `${C.yellow}Other owner numbers (comma separated): ${C.reset}`,
  );
  const list = input
    .split(",")
    .map((s) => s.replace(/\D/g, ""))
    .filter((s) => s.length >= 8);

  if (list.length === 0) {
    console.log(`${C.gray}  No valid number, skipped.${C.reset}`);
    return [];
  }
  return list;
}