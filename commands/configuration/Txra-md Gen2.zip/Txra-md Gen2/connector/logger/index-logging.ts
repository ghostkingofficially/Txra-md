import { createPinoLogger, type LogLevel, type Logger } from "zapo-js";

const C = {
  reset: "\x1b[0m",
  gray: "\x1b[90m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
  bold: "\x1b[1m",
  dim: "\x1b[2m",
};

const MESSAGE_TYPE_LABELS: Record<string, string> = {
  conversation: "TEXT",
  extendedTextMessage: "TEXT",
  imageMessage: "IMAGE",
  videoMessage: "VIDEO",
  ptvMessage: "VIDEO NOTE",
  audioMessage: "AUDIO",
  stickerMessage: "STICKER",
  documentMessage: "DOCUMENT",
  documentWithCaptionMessage: "DOCUMENT",
  locationMessage: "LOCATION",
  liveLocationMessage: "LIVE LOC",
  contactMessage: "CONTACT",
  contactsArrayMessage: "CONTACT ARRAY",
  pollCreationMessage: "POLL",
  pollCreationMessageV2: "POLL",
  pollCreationMessageV3: "POLL",
  pollCreationMessageV4: "POLL",
  pollCreationMessageV5: "POLL",
  pollUpdateMessage: "POLL VOTE",
  pollResultSnapshotMessage: "POLL RESULT",
  reactionMessage: "REACTION",
  protocolMessage: "SYSTEM",
  buttonsMessage: "BUTTONS",
  buttonsResponseMessage: "BTN REPLY",
  listMessage: "LIST",
  listResponseMessage: "LIST REPLY",
  templateMessage: "TEMPLATE",
  templateButtonReplyMessage: "TPL REPLY",
  interactiveMessage: "INTERACTIVE",
  interactiveResponseMessage: "INT REPLY",
  viewOnceMessage: "VIEW ONCE",
  viewOnceMessageV2: "VIEW ONCE",
  viewOnceMessageV2Extension: "VIEW ONCE",
  ephemeralMessage: "EPHEMERAL",
  editedMessage: "EDITED",
  eventMessage: "EVENT",
  orderMessage: "ORDER",
  productMessage: "PRODUCT",
  requestPhoneNumberMessage: "REQ PHONE",
  groupInviteMessage: "GRP INVITE",
  newsletterAdminInviteMessage: "NEWS INVITE",
  scheduledCallCreationMessage: "CALL SCHED",
  groupStatusMessage: "GRP STATUS",
  groupStatusMessageV2: "GRP STATUS",
  statusMentionMessage: "STATUS MENTION",
};

function messageTypeLabel(mtype: string | undefined): string {
  if (!mtype) return "UNKNOWN";
  if (MESSAGE_TYPE_LABELS[mtype]) return MESSAGE_TYPE_LABELS[mtype];
  return mtype
    .replace(/Message$/, "")
    .replace(/([A-Z])/g, " $1")
    .trim()
    .toUpperCase();
}

function colorForScope(scope: string): string {
  switch (scope) {
    case "GROUP": return C.magenta;
    case "PRIVATE": return C.cyan;
    case "NEWSLETTER": return C.blue;
    case "STATUS": return C.yellow;
    default: return C.gray;
  }
}

function colorForType(type: string): string {
  if (type === "TEXT") return C.green;
  if (type.includes("IMAGE")) return C.blue;
  if (type.includes("VIDEO")) return C.magenta;
  if (type.includes("AUDIO")) return C.yellow;
  if (type.includes("DOCUMENT")) return C.cyan;
  if (type.includes("STICKER")) return C.magenta;
  if (type.includes("POLL")) return C.blue;
  if (type.includes("REACTION")) return C.yellow;
  if (type === "SYSTEM") return C.gray;
  return C.gray;
}

function ts(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function line(level: string, color: string, msg: string, args: unknown[]): void {
  const head = `${C.gray}[${ts()}]${C.reset} ${color}${C.bold}${level}${C.reset}`;
  console.log(`${head} ${msg}`, ...args);
}

export const log = {
  info(msg: string, ...args: unknown[]): void {
    line("INFO", C.cyan, msg, args);
  },
  success(msg: string, ...args: unknown[]): void {
    line(" OK ", C.green, msg, args);
  },
  warn(msg: string, ...args: unknown[]): void {
    line("WARN", C.yellow, msg, args);
  },
  error(msg: string, ...args: unknown[]): void {
    line("ERR ", C.red, msg, args);
  },
  debug(msg: string, ...args: unknown[]): void {
    if (process.env.DEBUG === "1") {
      line("DBG ", C.magenta, msg, args);
    }
  },
  raw(msg = ""): void {
    console.log(msg);
  },
  incoming(info: {
    scope: string;
    mtype?: string;
    from: string;
    fromName?: string;
    lid?: string;
    chatName?: string;
    chatId?: string;
    stanzaId?: string;
    timestamp?: number;
    text?: string;
    isQuoted?: boolean;
  }): void {
    const time = info.timestamp
      ? new Date(info.timestamp).toLocaleTimeString("en-US", { hour12: false })
      : ts();

    const scopeColor = colorForScope(info.scope);
    const type = messageTypeLabel(info.mtype);
    const typeColor = colorForType(type);

    const fromDisplay = info.fromName
      ? `${info.from} ${C.dim}(${info.fromName})${C.reset}`
      : info.from;

    const chatDisplay = info.chatName
      ? `${info.chatName} ${info.chatId ? C.dim + "(" + info.chatId + ")" + C.reset : ""}`
      : info.chatId ?? info.from;

    const border = `${C.gray}│${C.reset}`;

    console.log("");
    console.log(`${C.gray}┌${C.reset} ${scopeColor}${C.bold}INCOMING [${info.scope}]${C.reset} ${C.gray}${time}${C.reset}`);
    console.log(`${border} ${C.gray}From   :${C.reset} ${fromDisplay}`);
    if (info.lid) {
      console.log(`${border} ${C.gray}LID    :${C.reset} ${info.lid}`);
    }
    console.log(`${border} ${C.gray}Chat   :${C.reset} ${chatDisplay}`);
    console.log(`${border} ${C.gray}Type   :${C.reset} ${typeColor}${C.bold}${type}${C.reset}`);
    if (info.stanzaId) {
      console.log(`${border} ${C.gray}Stanza :${C.reset} ${C.dim}${info.stanzaId}${C.reset}`);
    }
    if (info.isQuoted) {
      console.log(`${border} ${C.gray}Quote  :${C.reset} ${C.dim}yes${C.reset}`);
    }
    if (info.text) {
      console.log(`${border}`);
      const lines = info.text.split("\n");
      for (const l of lines) {
        console.log(`${border}  ${l}`);
      }
    }
    console.log(`${C.gray}└────────────────────────────────────────${C.reset}`);
    console.log("");
  },
  banner(title: string, subtitle?: string): void {
    const width = 56;
    console.log("");
    console.log(`${C.magenta}${C.bold}${"═".repeat(width)}${C.reset}`);
    console.log(`${C.magenta}${C.bold}  ${title}${C.reset}`);
    if (subtitle) {
      console.log(`${C.dim}  ${subtitle}${C.reset}`);
    }
    console.log(`${C.magenta}${C.bold}${"═".repeat(width)}${C.reset}`);
    console.log("");
  },
  box(title: string, rows: [string, string][]): void {
    const keyW = Math.max(...rows.map(([k]) => k.length), title.length);
    const valW = Math.max(...rows.map(([, v]) => v.length), 10);
    const inner = keyW + valW + 5;
    console.log("");
    console.log(`${C.cyan}┌${"─".repeat(inner)}┐${C.reset}`);
    console.log(`${C.cyan}│${C.reset} ${C.bold}${title.padEnd(inner - 1)}${C.reset}${C.cyan}│${C.reset}`);
    console.log(`${C.cyan}├${"─".repeat(inner)}┤${C.reset}`);
    for (const [k, v] of rows) {
      console.log(`${C.cyan}│${C.reset} ${C.gray}${k.padEnd(keyW)}${C.reset} : ${v.padEnd(valW)}${C.cyan}│${C.reset}`);
    }
    console.log(`${C.cyan}└${"─".repeat(inner)}┘${C.reset}`);
    console.log("");
  },
  qr(text: string): void {
    console.log("");
    console.log(`${C.green}${C.bold}SCAN QR IN WHATSAPP:${C.reset}`);
    console.log(text);
    console.log("");
  },
  pairing(code: string): void {
    const spaced = code.split("").join(" ");
    console.log("");
    console.log(`${C.green}${C.bold}════════════════════════════════════════${C.reset}`);
    console.log(`${C.green}${C.bold}  PAIRING CODE${C.reset}`);
    console.log(`${C.green}${C.bold}════════════════════════════════════════${C.reset}`);
    console.log(`  ${C.bold}${C.yellow}${spaced}${C.reset}`);
    console.log(`${C.dim}  WhatsApp → Linked Devices → Link with phone number${C.reset}`);
    console.log(`${C.green}${C.bold}════════════════════════════════════════${C.reset}`);
    console.log("");
  },
};

let cachedInternal: Logger | null = null;

function resolveLogLevel(v: string | undefined): LogLevel {
  switch (v) {
    case "trace":
    case "debug":
    case "info":
    case "warn":
    case "error":
      return v;
    default:
      return "error";
  }
}

export async function getInternalLogger(): Promise<Logger> {
  if (cachedInternal) return cachedInternal;
  cachedInternal = await createPinoLogger({
    level: resolveLogLevel(process.env.ZAPO_LOG_LEVEL),
    pretty: false,
  });
  return cachedInternal;
}