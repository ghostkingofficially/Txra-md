# native/ — mesin gambar Rust

Dipakai otomatis oleh `lib/func/image.ts` (→ thumbnail menu, fake reply, fake quoted, foto profil, thumbnail video, `Toolkit.resize`).
Kalau file `.node` tidak ada atau error, bot otomatis memakai ffmpeg — bot tidak pernah berhenti karena ini.

## Build (sekali, di mesin tempat bot berjalan)

    bun run native:build     # cargo build --release → native/mybes_image_engine.node
    bun run native:test      # uji ukuran hasil + benchmark vs ffmpeg + cek event loop tidak terblokir

Saat bot start, log menampilkan `[image] mesin native aktif: ...` atau alasan kenapa memakai ffmpeg.

## Pengaturan (env, opsional)

| env | bawaan | arti |
|---|---|---|
| `IMAGE_NATIVE=0` | – | matikan native, paksa ffmpeg |
| `IMAGE_NATIVE_PARALLEL` | 2 | maks. gambar diolah bersamaan (turunkan ke 1 kalau HP panas) |
| `MYBES_NATIVE_PATH` | – | path `.node` kustom |
| `FFMPEG_NICE` | 10 | prioritas CPU ffmpeg (0 = tidak diubah) |
| `DISK_CACHE=0` / `DISK_CACHE_MAX_MB` | on / 48 | cache hasil olahan di `db/configuration/thumbs/cache/blobs` |
| `PREWARM=0` | on | matikan pemanasan cache latar belakang |

## Isi

- `src/geom.rs` — hitung crop/skala (murni, ada unit test: `rustc --test src/geom.rs`)
- `src/gate.rs` — pembatas pekerjaan serentak (ada unit test)
- `src/lib.rs` — binding N-API: `processImage`, `processImageMulti` (decode sekali → banyak ukuran), `configure`, `engineInfo`
