//! Hitung geometri resize — murni aritmetika (tanpa crate luar), jadi bisa diuji dengan `cargo test`
//! maupun `rustc --test src/geom.rs` tanpa mengunduh dependensi.
//!
//! Semantik disamakan dengan jalur ffmpeg lama (lib/func/image.ts):
//!   cover : isi penuh kotak w×h lalu crop tengah (boleh memperbesar, seperti `scale=increase,crop`)
//!   fit   : muat di dalam kotak w×h, TIDAK diperbesar
//!   width : lebar = min(w, lebar asli), tinggi mengikuti rasio

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Mode {
    Cover,
    Fit,
    Width,
}

impl Mode {
    pub fn parse(s: &str) -> Option<Mode> {
        match s {
            "cover" => Some(Mode::Cover),
            "fit" => Some(Mode::Fit),
            "width" => Some(Mode::Width),
            _ => None,
        }
    }
}

/// Rencana olah satu gambar: ambil area (sx,sy,sw,sh) dari sumber, lalu skala ke (dw,dh).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Plan {
    pub sx: u32,
    pub sy: u32,
    pub sw: u32,
    pub sh: u32,
    pub dw: u32,
    pub dh: u32,
}

pub const MAX_DIM: u32 = 8192;
pub const MAX_PIXELS: u64 = 80_000_000;

pub fn plan(mode: Mode, src_w: u32, src_h: u32, w: u32, h: u32) -> Result<Plan, &'static str> {
    if src_w == 0 || src_h == 0 || (src_w as u64) * (src_h as u64) > MAX_PIXELS {
        return Err("dimensi gambar tidak valid/terlalu besar");
    }
    if w == 0 || w > MAX_DIM {
        return Err("width di luar batas");
    }
    if h == 0 || h > MAX_DIM {
        return Err("height di luar batas");
    }
    match mode {
        Mode::Cover => {
            // Crop sumber ke rasio target lebih dulu (tengah), baru skala sekali ke w×h.
            // Hasilnya sama dengan "skala besar lalu crop", tetapi jauh lebih hemat CPU/RAM.
            let (mut sw, mut sh) = (src_w as u64, src_h as u64);
            if sw * h as u64 > sh * w as u64 {
                // sumber lebih lebar dari target → potong kiri/kanan
                sw = (sh * w as u64 + h as u64 / 2) / h as u64;
            } else {
                // sumber lebih tinggi → potong atas/bawah
                sh = (sw * h as u64 + w as u64 / 2) / w as u64;
            }
            let sw = sw.clamp(1, src_w as u64) as u32;
            let sh = sh.clamp(1, src_h as u64) as u32;
            Ok(Plan { sx: (src_w - sw) / 2, sy: (src_h - sh) / 2, sw, sh, dw: w, dh: h })
        }
        Mode::Fit => {
            let sc = f64::min(1.0, f64::min(w as f64 / src_w as f64, h as f64 / src_h as f64));
            let dw = ((src_w as f64 * sc).round() as u32).max(1);
            let dh = ((src_h as f64 * sc).round() as u32).max(1);
            Ok(Plan { sx: 0, sy: 0, sw: src_w, sh: src_h, dw, dh })
        }
        Mode::Width => {
            let dw = w.min(src_w);
            let dh = ((src_h as f64 * dw as f64 / src_w as f64).round() as u32).max(1);
            Ok(Plan { sx: 0, sy: 0, sw: src_w, sh: src_h, dw, dh })
        }
    }
}

/// Faktor pengecilan terbesar (sumber/target). Dipakai memilih filter.
pub fn reduction(p: &Plan) -> f64 {
    f64::max(p.sw as f64 / p.dw as f64, p.sh as f64 / p.dh as f64)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kernel {
    /// Tidak ada perubahan ukuran sama sekali.
    None,
    /// Rata-rata area (bilinear berbasis luas) — cepat, kualitas bagus untuk pengecilan ≥ 2×.
    Triangle,
    /// Tajam untuk perubahan kecil / pembesaran.
    CatmullRom,
}

/// Lanczos3 (bawaan kode lama) paling mahal; untuk thumbnail kecil hasilnya hampir tidak bisa dibedakan dari Triangle.
pub fn kernel_for(p: &Plan) -> Kernel {
    if p.sw == p.dw && p.sh == p.dh {
        return Kernel::None;
    }
    if reduction(p) >= 1.8 {
        Kernel::Triangle
    } else {
        Kernel::CatmullRom
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cover_landscape_to_square_crops_sides() {
        let p = plan(Mode::Cover, 1600, 900, 300, 300).unwrap();
        assert_eq!((p.sw, p.sh), (900, 900));
        assert_eq!((p.sx, p.sy), (350, 0));
        assert_eq!((p.dw, p.dh), (300, 300));
    }

    #[test]
    fn cover_portrait_to_wide_crops_top_bottom() {
        let p = plan(Mode::Cover, 900, 1600, 320, 180).unwrap();
        assert_eq!(p.sw, 900);
        assert_eq!(p.sh, 506); // 900*180/320 = 506.25
        assert_eq!(p.sx, 0);
        assert_eq!(p.sy, (1600 - 506) / 2);
    }

    #[test]
    fn cover_upscales_small_source() {
        let p = plan(Mode::Cover, 100, 100, 300, 300).unwrap();
        assert_eq!((p.sw, p.sh, p.dw, p.dh), (100, 100, 300, 300));
    }

    #[test]
    fn cover_exact_same_ratio_keeps_all() {
        let p = plan(Mode::Cover, 640, 480, 160, 120).unwrap();
        assert_eq!((p.sx, p.sy, p.sw, p.sh), (0, 0, 640, 480));
    }

    #[test]
    fn fit_never_upscales() {
        let p = plan(Mode::Fit, 400, 200, 800, 450).unwrap();
        assert_eq!((p.dw, p.dh), (400, 200));
        let p = plan(Mode::Fit, 1600, 900, 800, 800).unwrap();
        assert_eq!((p.dw, p.dh), (800, 450));
    }

    #[test]
    fn width_keeps_ratio_and_never_upscales() {
        let p = plan(Mode::Width, 1000, 500, 120, 0 + 120).unwrap();
        assert_eq!((p.dw, p.dh), (120, 60));
        let p = plan(Mode::Width, 100, 50, 120, 120).unwrap();
        assert_eq!((p.dw, p.dh), (100, 50));
    }

    #[test]
    fn rejects_bad_sizes() {
        assert!(plan(Mode::Cover, 0, 10, 10, 10).is_err());
        assert!(plan(Mode::Cover, 10, 10, 0, 10).is_err());
        assert!(plan(Mode::Cover, 10, 10, 10, 9000).is_err());
        assert!(plan(Mode::Cover, 20000, 20000, 10, 10).is_err());
    }

    #[test]
    fn kernel_choice() {
        let big = plan(Mode::Cover, 4000, 3000, 300, 300).unwrap();
        assert_eq!(kernel_for(&big), Kernel::Triangle);
        let same = plan(Mode::Fit, 300, 300, 300, 300).unwrap();
        assert_eq!(kernel_for(&same), Kernel::None);
        let small = plan(Mode::Cover, 400, 400, 300, 300).unwrap();
        assert_eq!(kernel_for(&small), Kernel::CatmullRom);
    }

    #[test]
    fn crop_never_exceeds_source() {
        for (sw, sh, w, h) in [(1, 1, 8192, 8192), (7, 3, 5, 9), (3000, 10, 100, 100), (10, 3000, 100, 100)] {
            let p = plan(Mode::Cover, sw, sh, w, h).unwrap();
            assert!(p.sx + p.sw <= sw && p.sy + p.sh <= sh, "{:?}", p);
            assert!(p.sw >= 1 && p.sh >= 1);
        }
    }
}
