//! mybes_image_engine — mesin olah gambar native untuk bot (dipanggil dari Bun lewat N-API).
//!
//! Ide utamanya:
//!  1. ASYNC: pekerjaan berjalan di thread pool (napi `AsyncTask`), event loop bot tidak pernah terblokir.
//!  2. DECODE SEKALI: `processImageMulti` memakai satu hasil decode untuk banyak ukuran (mis. 120/160/300/800/1280 px).
//!  3. HEMAT CPU: cover = crop dulu baru skala; filter adaptif (Triangle untuk pengecilan besar, bukan Lanczos3 untuk semua);
//!     jumlah pekerjaan serentak dibatasi (`configure`), sisanya antre.
//!  4. AMAN: panic ditangkap → jadi error JS biasa; sisi TS otomatis jatuh ke ffmpeg bila ada error.
mod gate;
mod geom;

use gate::Gate;
use geom::{Kernel, Mode};
#[allow(unused_imports)]
use image::GenericImageView;
use image::imageops::{self, FilterType};
use image::{DynamicImage, ImageBuffer, ImageFormat, Rgb, Rgba};
use napi::bindgen_prelude::*;
use napi_derive::napi;
use std::io::Cursor;
use std::panic::{catch_unwind, AssertUnwindSafe};

static GATE: Gate = Gate::new(2);

#[napi(object)]
pub struct ImageOpts {
  /// "cover" | "fit" | "width"
  pub mode: Option<String>,
  pub width: u32,
  pub height: Option<u32>,
  /// 1–100, hanya jpeg (bawaan 80)
  pub quality: Option<u8>,
  /// "jpeg" | "png" (bawaan jpeg)
  pub format: Option<String>,
}

#[napi(object)]
pub struct ImageOutput {
  pub buffer: Buffer,
  pub width: u32,
  pub height: u32,
  /// Terisi bila item ini gagal (hanya pada processImageMulti); buffer kosong.
  pub error: Option<String>,
}

/// Versi + info singkat (untuk log "native aktif").
#[napi]
pub fn engine_info() -> String {
  format!("mybes_image_engine {} (image 0.25, async, gate)", env!("CARGO_PKG_VERSION"))
}

/// Batasi jumlah gambar yang diolah bersamaan (bawaan 2). Panggil sekali saat start.
#[napi]
pub fn configure(max_parallel: u32) {
  GATE.set_limit(max_parallel.max(1) as usize);
}

// ───────────────────────── inti (tanpa napi, mudah dibaca) ─────────────────────────


pub struct Out {
    bytes: Vec<u8>,
    width: u32,
    height: u32,
  }
fn has_alpha(img: &DynamicImage) -> bool {
  img.color().has_alpha()
}

/// Gambar transparan → tempel di atas putih (JPEG tidak punya alpha; hitam akan terlihat jelek).
fn rgb_over_white(img: &DynamicImage) -> ImageBuffer<Rgb<u8>, Vec<u8>> {
  if !has_alpha(img) {
    return img.to_rgb8();
  }
  let rgba = img.to_rgba8();
  let (w, h) = rgba.dimensions();
  let mut out = ImageBuffer::<Rgb<u8>, Vec<u8>>::new(w, h);
  for (src, dst) in rgba.pixels().zip(out.pixels_mut()) {
    let a = src[3] as u32;
    let mix = |c: u8| (((c as u32) * a + 255 * (255 - a) + 127) / 255) as u8;
    *dst = Rgb([mix(src[0]), mix(src[1]), mix(src[2])]);
  }
  out
}

fn filter(k: Kernel) -> FilterType {
  match k {
    Kernel::Triangle => FilterType::Triangle,
    Kernel::CatmullRom => FilterType::CatmullRom,
    Kernel::None => FilterType::Nearest,
  }
}

fn encode_jpeg(rgb: &ImageBuffer<Rgb<u8>, Vec<u8>>, quality: u8) -> std::result::Result<Vec<u8>, String> {
  let (w, h) = rgb.dimensions();
  let mut cur = Cursor::new(Vec::with_capacity(64 * 1024));
  image::codecs::jpeg::JpegEncoder::new_with_quality(&mut cur, quality.clamp(1, 100))
    .encode(rgb.as_raw(), w, h, image::ExtendedColorType::Rgb8)
    .map_err(|e| format!("encode gambar gagal: {e}"))?;
  Ok(cur.into_inner())
}

fn encode_png(rgba: ImageBuffer<Rgba<u8>, Vec<u8>>) -> std::result::Result<Vec<u8>, String> {
  let mut cur = Cursor::new(Vec::with_capacity(128 * 1024));
  DynamicImage::ImageRgba8(rgba)
    .write_to(&mut cur, ImageFormat::Png)
    .map_err(|e| format!("encode gambar gagal: {e}"))?;
  Ok(cur.into_inner())
}

/// Satu pekerjaan olah dari gambar yang SUDAH di-decode.
fn render(decoded: &DynamicImage, o: &ImageOpts) -> std::result::Result<Out, String> {
  let height = o.height.unwrap_or(o.width);
  let mode_s = o.mode.as_deref().unwrap_or(if o.height.is_some() { "cover" } else { "width" });
  let mode = Mode::parse(mode_s).ok_or_else(|| "mode image tidak dikenal".to_string())?;
  let fmt = o.format.as_deref().unwrap_or("jpeg");
  if fmt != "jpeg" && fmt != "png" {
    return Err("format harus jpeg atau png".into());
  }
  let (sw, sh) = (decoded.width(), decoded.height());
  let plan = geom::plan(mode, sw, sh, o.width, height).map_err(|e| e.to_string())?;
  let kernel = geom::kernel_for(&plan);

  if fmt == "png" {
    let rgba = decoded.to_rgba8();
    let cropped = if plan.sw != sw || plan.sh != sh {
      imageops::crop_imm(&rgba, plan.sx, plan.sy, plan.sw, plan.sh).to_image()
    } else {
      rgba
    };
    let out = if kernel == Kernel::None { cropped } else { imageops::resize(&cropped, plan.dw, plan.dh, filter(kernel)) };
    let (w, h) = out.dimensions();
    return Ok(Out { bytes: encode_png(out)?, width: w, height: h });
  }

  let rgb = rgb_over_white(decoded);
  let cropped = if plan.sw != sw || plan.sh != sh {
    imageops::crop_imm(&rgb, plan.sx, plan.sy, plan.sw, plan.sh).to_image()
  } else {
    rgb
  };
  let out = if kernel == Kernel::None { cropped } else { imageops::resize(&cropped, plan.dw, plan.dh, filter(kernel)) };
  let (w, h) = out.dimensions();
  Ok(Out { bytes: encode_jpeg(&out, o.quality.unwrap_or(80))?, width: w, height: h })
}

fn decode(bytes: &[u8]) -> std::result::Result<DynamicImage, String> {
  if bytes.is_empty() {
    return Err("gambar kosong".into());
  }
  image::load_from_memory(bytes).map_err(|e| format!("decode gambar gagal: {e}"))
}

fn guarded<T>(f: impl FnOnce() -> std::result::Result<T, String>) -> std::result::Result<T, String> {
  match catch_unwind(AssertUnwindSafe(f)) {
    Ok(r) => r,
    Err(_) => Err("native panic saat mengolah gambar".into()),
  }
}

// ───────────────────────── N-API: satu gambar ─────────────────────────

pub struct ProcessTask {
  input: Vec<u8>,
  opts: ImageOpts,
}

impl Task for ProcessTask {
  type Output = Out;
  type JsValue = ImageOutput;

  fn compute(&mut self) -> Result<Self::Output> {
    let _permit = GATE.acquire();
    guarded(|| {
      let img = decode(&self.input)?;
      render(&img, &self.opts)
    })
    .map_err(Error::from_reason)
  }

  fn resolve(&mut self, _env: Env, out: Self::Output) -> Result<Self::JsValue> {
    Ok(ImageOutput { buffer: out.bytes.into(), width: out.width, height: out.height, error: None })
  }
}

/// Olah satu gambar di thread pool. Promise<ImageOutput>.
#[napi(ts_return_type = "Promise<ImageOutput>")]
pub fn process_image(input: Buffer, opts: ImageOpts) -> AsyncTask<ProcessTask> {
  AsyncTask::new(ProcessTask { input: input.to_vec(), opts })
}

// ───────────────────────── N-API: banyak ukuran, decode sekali ─────────────────────────

pub struct MultiTask {
  input: Vec<u8>,
  jobs: Vec<ImageOpts>,
}

impl Task for MultiTask {
  type Output = Vec<std::result::Result<Out, String>>;
  type JsValue = Vec<ImageOutput>;

  fn compute(&mut self) -> Result<Self::Output> {
    let _permit = GATE.acquire();
    let img = guarded(|| decode(&self.input)).map_err(Error::from_reason)?;
    // Kegagalan satu ukuran tidak membatalkan ukuran lain.
    Ok(self.jobs.iter().map(|o| guarded(|| render(&img, o))).collect())
  }

  fn resolve(&mut self, _env: Env, outs: Self::Output) -> Result<Self::JsValue> {
    Ok(
      outs
        .into_iter()
        .map(|r| match r {
          Ok(o) => ImageOutput { buffer: o.bytes.into(), width: o.width, height: o.height, error: None },
          Err(e) => ImageOutput { buffer: Vec::<u8>::new().into(), width: 0, height: 0, error: Some(e) },
        })
        .collect(),
    )
  }
}

/// Decode SEKALI, hasilkan banyak ukuran. Urutan hasil = urutan `jobs`. Promise<ImageOutput[]>.
#[napi(ts_return_type = "Promise<Array<ImageOutput>>")]
pub fn process_image_multi(input: Buffer, jobs: Vec<ImageOpts>) -> AsyncTask<MultiTask> {
  AsyncTask::new(MultiTask { input: input.to_vec(), jobs })
}
