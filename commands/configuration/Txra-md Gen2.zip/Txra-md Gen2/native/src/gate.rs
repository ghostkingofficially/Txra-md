//! Pembatas jumlah pekerjaan berat yang berjalan bersamaan (semaphore sederhana, std saja).
//! Tujuan: di HP (Termux) CPU kecil — maksimal N gambar diolah serentak, sisanya antre tanpa membebani CPU.
use std::sync::{Condvar, Mutex};

pub struct Gate {
    state: Mutex<(usize, usize)>, // (sedang jalan, batas)
    cv: Condvar,
}

pub struct Permit<'a>(&'a Gate);

impl Gate {
    pub const fn new(limit: usize) -> Gate {
        Gate { state: Mutex::new((0, limit)), cv: Condvar::new() }
    }

    pub fn set_limit(&self, limit: usize) {
        let mut s = self.state.lock().unwrap_or_else(|e| e.into_inner());
        s.1 = limit.max(1);
        self.cv.notify_all();
    }

    pub fn acquire(&self) -> Permit<'_> {
        let mut s = self.state.lock().unwrap_or_else(|e| e.into_inner());
        while s.0 >= s.1 {
            s = self.cv.wait(s).unwrap_or_else(|e| e.into_inner());
        }
        s.0 += 1;
        Permit(self)
    }

    #[cfg(test)]
    pub fn running(&self) -> usize {
        self.state.lock().unwrap().0
    }
}

impl Drop for Permit<'_> {
    fn drop(&mut self) {
        let mut s = self.0.state.lock().unwrap_or_else(|e| e.into_inner());
        s.0 -= 1;
        self.0.cv.notify_one();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Arc;
    use std::thread;
    use std::time::Duration;

    #[test]
    fn never_exceeds_limit() {
        static GATE: Gate = Gate::new(2);
        let peak = Arc::new(AtomicUsize::new(0));
        let cur = Arc::new(AtomicUsize::new(0));
        let hs: Vec<_> = (0..8)
            .map(|_| {
                let (peak, cur) = (peak.clone(), cur.clone());
                thread::spawn(move || {
                    let _p = GATE.acquire();
                    let n = cur.fetch_add(1, Ordering::SeqCst) + 1;
                    peak.fetch_max(n, Ordering::SeqCst);
                    thread::sleep(Duration::from_millis(15));
                    cur.fetch_sub(1, Ordering::SeqCst);
                })
            })
            .collect();
        for h in hs {
            h.join().unwrap();
        }
        assert!(peak.load(Ordering::SeqCst) <= 2);
        assert_eq!(GATE.running(), 0);
    }

    #[test]
    fn raising_limit_wakes_waiters() {
        static GATE: Gate = Gate::new(1);
        let first = GATE.acquire();
        let h = thread::spawn(|| {
            let _p = GATE.acquire();
        });
        thread::sleep(Duration::from_millis(30));
        GATE.set_limit(2);
        h.join().unwrap();
        drop(first);
    }
}
